<?php
/* Smarty version 3.1.31, created on 2019-11-11 11:29:24
  from "D:\www\ks_invoicing\modules\inv\view\templates\pages\setup.tax.type.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5dc929f48225e7_57759203',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '7897eef694ecf02428b438039007d1b8f72c7f36' => 
    array (
      0 => 'D:\\www\\ks_invoicing\\modules\\inv\\view\\templates\\pages\\setup.tax.type.tpl',
      1 => 1573464561,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5dc929f48225e7_57759203 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_96555dc929f480ad39_61777771', 'title');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_2925dc929f480c3f7_83023283', 'lang');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_93575dc929f480d154_57901052', 'app');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_138905dc929f480df67_84480703', 'controller');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_261955dc929f480ed13_03187652', 'style');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_29605dc929f4814564_77599776', 'script');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_318815dc929f481a948_48672667', 'dialog');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_298385dc929f481e812_52243771', 'page_title');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_52955dc929f481f7a2_05708411', 'toolbar');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_206685dc929f4820587_94723508', 'content');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, ((string)@constant('LOCAL__THEME'))."/template/masters/master1/master.tpl");
}
/* {block 'title'} */
class Block_96555dc929f480ad39_61777771 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'title' => 
  array (
    0 => 'Block_96555dc929f480ad39_61777771',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
Tax Types<?php
}
}
/* {/block 'title'} */
/* {block 'lang'} */
class Block_2925dc929f480c3f7_83023283 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'lang' => 
  array (
    0 => 'Block_2925dc929f480c3f7_83023283',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
}
}
/* {/block 'lang'} */
/* {block 'app'} */
class Block_93575dc929f480d154_57901052 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'app' => 
  array (
    0 => 'Block_93575dc929f480d154_57901052',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

data-ng-app="INV"
<?php
}
}
/* {/block 'app'} */
/* {block 'controller'} */
class Block_138905dc929f480df67_84480703 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'controller' => 
  array (
    0 => 'Block_138905dc929f480df67_84480703',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

data-ng-controller="TaxType" 
<?php
}
}
/* {/block 'controller'} */
/* {block 'style'} */
class Block_261955dc929f480ed13_03187652 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'style' => 
  array (
    0 => 'Block_261955dc929f480ed13_03187652',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<link rel="stylesheet" href="<?php echo @constant('PATH__CSS');?>
/setup.tax.type.css?ver=<?php echo @constant('VERSION');?>
"></link>
<?php
}
}
/* {/block 'style'} */
/* {block 'script'} */
class Block_29605dc929f4814564_77599776 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'script' => 
  array (
    0 => 'Block_29605dc929f4814564_77599776',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('PATH__JS');?>
/enum.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('PATH__JS');?>
/common.angular.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('PATH__JS');?>
/setup.tax.type.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
<?php
}
}
/* {/block 'script'} */
/* {block 'dialog'} */
class Block_318815dc929f481a948_48672667 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'dialog' => 
  array (
    0 => 'Block_318815dc929f481a948_48672667',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<div id="dlgAdd" class="modal fade modal-scroll modal-dialog" tabindex="-1" data-width="760" style="display: none;height:auto!important;width:500px!important ">
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        <h3 class="modal-title"><i style="font-size:24px" class=" font-blue fa fa-plus"></i> <?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6774');?>
 <?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6775');?>
 </h3>
    </div>
    <div class="modal-body" style="margin: 0 auto;">
        <form name="addForm">
            <div class="row">
                <div class="form-group">
                    <div class="col-md-12">

                        <label class="control-label"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6776');?>
*</label>
                        <select name="taxType" data-ng-model="objTaxAdd.strType" 
                            data-ng-options="objLang.inv.CLS_BLL_TAX_TYPE[type] for type in arrTaxType" 
                            class="form-control" required>
                            <option value=""><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6776');?>
*</option>
                        </select>
                        <small class="help-block font-red" data-ng-show="addForm.taxType.$touched && addForm.taxType.$invalid">*<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6777');?>
</small>  
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="form-group">
                    <div class="col-md-12">
                        <label class="control-label"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6775');?>
*</label>   
                        <input type="text" name="taxType" class="form-control" placeholder="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6775');?>
" autocomplete="off" data-ng-model="objTaxAdd.strTaxType" required />
                        <small class="help-block font-red" data-ng-show="addForm.taxType.$touched && addForm.taxType.$invalid">*Field Required</small>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="form-group">
                    <div class="col-md-12">
                        <label class="control-label">Value*</label>
                        <input type="text" name="inTaxValue" class="form-control" placeholder="" autocomplete="off" data-ng-model="objTaxAdd.intValue" required />
                        <small class="help-block font-red" data-ng-show="addForm.inTaxValue.$touched && addForm.inTaxValue.$invalid">*Field Required</small>
                    </div>
                </div>
            </div>   
        </form>  
    </div>
    <div class="modal-footer">
        <button type="button" data-ng-click="add()" class="btn green-jungle" data-dismiss="modal" ng-disabled="addForm.$invalid">ADD</button>
        <button type="button" class="btn red-thunderbird" data-dismiss="modal">CANCEL</button>
    </div>
</div>
<div id="dlgEdit" class="modal fade modal-scroll modal-dialog" tabindex="-1" data-width="760" style="display: none;height:auto!important">
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        <h3 class="modal-title"><i style="font-size:24px" class=" font-blue fa fa-edit"></i>Edit Tax Type</h3>
    </div>
    <div class="modal-body" style="margin: 0 auto;">
        <div class="row">
            <div class="form-group">
                <div class="col-md-12">
                    <label class="control-label">Type*</label>
                    <!--<input type="text" name="taxType" class="form-control" autocomplete="off" data-ng-model="objTaxEdit.strType" />-->
                    <select name="taxType" data-ng-model="objTaxEdit.strType" 
                        data-ng-options="objLang.inv.CLS_BLL_TAX_TYPE[type] for type in arrTaxType" class="form-control" required>
                        <option value="">Tax Type</option>
                    </select>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="form-group">
                <div class="col-md-12">
                    <label class="control-label">Tax Type*</label>   
                    <input type="text" name="textTaxType" class="form-control" autocomplete="off" data-ng-model="objTaxEdit.strTaxType" />
                </div>
            </div>
        </div>
        <div class="row">
            <div class="form-group">
                <div class="col-md-12">
                    <label class="control-label">Value*</label>
                    <input type="text" name="inTaxValue" class="form-control" placeholder="" autocomplete="off" data-ng-model="objTaxEdit.intValue" />
                </div>
            </div>
        </div>
    </div> 
    <div class="modal-footer">
        <button type="button" data-ng-click="editTax()" class="btn green-jungle" data-dismiss="modal">Save</button>
        <button type="button" class="btn red-thunderbird" data-dismiss="modal">Cancel</button>
    </div>  
</div>
<div id="dlgRemove" class="modal fade modal-scroll modal-dialog" tabindex="-1" data-width="760" style="display: none;height:auto!important">
    <div class="modal-header" >
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        <h3 class="modal-title"><i style="font-size:24px" class="font-red-thunderbird fa fa-trash"></i> Delete Tax Type</h3>
    </div>
    <div class="modal-body" style="margin: 0 auto;">
        <div class="row">
            <div class="col-md-6" >
                <label class="control-label" >&nbsp;&nbsp; Do you want to delete this tax type?</label>
            </div>    
        </div>
    </div>
    <div class="modal-footer">
        <button type="button" data-ng-click="removeTax()" class="btn red-thunderbird" data-dismiss="modal">Delete</button>
        <button type="button" class="btn green-jungle" data-dismiss="modal">Cancel</button>
    </div>
</div>
<?php
}
}
/* {/block 'dialog'} */
/* {block 'page_title'} */
class Block_298385dc929f481e812_52243771 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'page_title' => 
  array (
    0 => 'Block_298385dc929f481e812_52243771',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<h1>Tax Types <small>Management</small></h1>
<?php
}
}
/* {/block 'page_title'} */
/* {block 'toolbar'} */
class Block_52955dc929f481f7a2_05708411 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'toolbar' => 
  array (
    0 => 'Block_52955dc929f481f7a2_05708411',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<div class="btn-group pull-right">      
    <a class="btn green-jungle btn-fit-height" data-toggle="modal" data-target="#dlgAdd">
        <i class="fa fa-plus"></i> <span class="visible-lg-inline-block">Tax Type</span>
    </a>
</div>
<?php
}
}
/* {/block 'toolbar'} */
/* {block 'content'} */
class Block_206685dc929f4820587_94723508 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_206685dc929f4820587_94723508',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<div class="row">
    <div class="col-md-12">
        <div class="portlet light">
            <div class="portlet-title">
                <div class="caption font-blue">
                    <span class="fa fa-money"></span> Tax Types
                </div>
            </div>
            <div class="portlet-body">
                <div class="table-responsive">
                    <table class="table table-condensed table-light table-hover">
                        <thead>
                            <tr>
                                <th>ID</th>    
                                <th>Tax Type</th>
                                <th>Type</th>    
                                <th>Value</th>
                                <th></th>    
                            </tr>    
                        </thead>
                        <tbody>
                            <tr data-ng-repeat="objTax in arrTaxTypes">
                                <td>{{objTax.intID}}</td>
                                <td>{{objTax.strTaxType}}</td>                                 
                                <td>{{objLang.inv.CLS_BLL_TAX_TYPE[objTax.strType]}}</td>                            
                                <td>{{objTax.intValue}}</td>                                 
                                <td width="10%" class="icon">
                                    <a data-ng-click="edit(objTax ,$index)" data-toggle="modal" data-target="#dlgEdit" class="btn blue-dark btn-xs" title="Edit"><i class="fa fa-edit"></i></a>
                                    <a data-ng-click="remove(objTax.intID)" data-toggle="modal" data-target="#dlgRemove" class="btn red-thunderbird btn-xs" title="Delete"><i class="fa fa-trash-o"></i></a>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="note note-info" data-ng-if="mode==0">
                    No terms found!
                </div>                
            </div>
        </div>
    </div>
</div>
    
<?php
}
}
/* {/block 'content'} */
}
