<?php
/* Smarty version 3.1.31, created on 2019-11-07 17:04:18
  from "D:\www\ks_invoicing\themes\admin2\template\components\main.menu.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5dc43272992d64_31062538',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '16a12a60baf3daa8e6cd5a8afa064d3ed36ff0f9' => 
    array (
      0 => 'D:\\www\\ks_invoicing\\themes\\admin2\\template\\components\\main.menu.tpl',
      1 => 1570612279,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5dc43272992d64_31062538 (Smarty_Internal_Template $_smarty_tpl) {
?>
<!-- START OF LEFT SIDE MENU -->
<ul class="page-sidebar-menu  page-header-fixed  page-sidebar-menu-compact" data-keep-expanded="false" data-auto-scroll="true" data-slide-speed="400" data-height="477">
    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['_User']->value->arrMenuItems, 'MenuItems', false, 'GroupOrder');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['GroupOrder']->value => $_smarty_tpl->tpl_vars['MenuItems']->value) {
?>

        <?php $_smarty_tpl->_assignInScope('intLastLevel', -1);
?> 
        
        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['MenuItems']->value, 'Item');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['Item']->value) {
?>

            <?php $_smarty_tpl->_assignInScope('LanguageKey', $_smarty_tpl->tpl_vars['Item']->value['strMenuText']);
?>
            <?php $_smarty_tpl->_assignInScope('MenuText', $_smarty_tpl->smarty->ext->configload->_getConfigVariable($_smarty_tpl, $_smarty_tpl->tpl_vars['LanguageKey']->value));
?>
            
            
            <?php if ($_smarty_tpl->tpl_vars['Item']->value['boolShowInMenu'] != 0) {?>

                <?php if ($_smarty_tpl->tpl_vars['intLastLevel']->value >= 0) {?>
                    <?php if (($_smarty_tpl->tpl_vars['Item']->value['intLevel'] < $_smarty_tpl->tpl_vars['intLastLevel']->value)) {?>
                        <?php
$_smarty_tpl->tpl_vars['i'] = new Smarty_Variable(null, $_smarty_tpl->isRenderingCache);$_smarty_tpl->tpl_vars['i']->step = 1;$_smarty_tpl->tpl_vars['i']->total = (int) ceil(($_smarty_tpl->tpl_vars['i']->step > 0 ? $_smarty_tpl->tpl_vars['intLastLevel']->value-$_smarty_tpl->tpl_vars['Item']->value['intLevel']-1+1 - (0) : 0-($_smarty_tpl->tpl_vars['intLastLevel']->value-$_smarty_tpl->tpl_vars['Item']->value['intLevel']-1)+1)/abs($_smarty_tpl->tpl_vars['i']->step));
if ($_smarty_tpl->tpl_vars['i']->total > 0) {
for ($_smarty_tpl->tpl_vars['i']->value = 0, $_smarty_tpl->tpl_vars['i']->iteration = 1;$_smarty_tpl->tpl_vars['i']->iteration <= $_smarty_tpl->tpl_vars['i']->total;$_smarty_tpl->tpl_vars['i']->value += $_smarty_tpl->tpl_vars['i']->step, $_smarty_tpl->tpl_vars['i']->iteration++) {
$_smarty_tpl->tpl_vars['i']->first = $_smarty_tpl->tpl_vars['i']->iteration == 1;$_smarty_tpl->tpl_vars['i']->last = $_smarty_tpl->tpl_vars['i']->iteration == $_smarty_tpl->tpl_vars['i']->total;?>
                                <!-- Closing SubMenu [LEVEL <?php echo $_smarty_tpl->tpl_vars['intLastLevel']->value-$_smarty_tpl->tpl_vars['i']->value;?>
] -->     
                                </ul>
                            </li>
                        <?php }
}
?>

                    <?php }?>
                <?php }?>

                <?php if ($_smarty_tpl->tpl_vars['Item']->value['intActionID'] == null) {?>
                    <!-- Starting SubMenu [LEVEL <?php echo $_smarty_tpl->tpl_vars['Item']->value['intLevel'];?>
] -->
                    <?php if (isset($_smarty_tpl->tpl_vars['_ActiveMenuItems']->value) && in_array($_smarty_tpl->tpl_vars['Item']->value['intMenuItemID'],$_smarty_tpl->tpl_vars['_ActiveMenuItems']->value)) {?>
                        <li class="nav-item start active"> 
                    <?php } else { ?>
                        <li class="nav-item"> 
                    <?php }?>
                    <a href="javascript:;" class="nav-link nav-toggle">
                        <?php if (isset($_smarty_tpl->tpl_vars['Item']->value['strMenuStyle']) && $_smarty_tpl->tpl_vars['Item']->value['strMenuStyle'] != '') {?>
                            <i class="<?php echo $_smarty_tpl->tpl_vars['Item']->value['strMenuStyle'];?>
"></i>
                        <?php }?>
                        <span class="title"><?php echo $_smarty_tpl->tpl_vars['MenuText']->value;?>
</span>
                        <?php if (isset($_smarty_tpl->tpl_vars['_ActiveMenuItems']->value) && in_array($_smarty_tpl->tpl_vars['Item']->value['intMenuItemID'],$_smarty_tpl->tpl_vars['_ActiveMenuItems']->value)) {?>
                            <span class="selected"></span>
                            <span class="arrow"></span>
                        <?php } else { ?>
                            <span class="arrow"></span>
                        <?php }?>
                    </a>
                    <ul class="sub-menu">
                <?php } else { ?>
                    <!-- MenuItem [LEVEL <?php echo $_smarty_tpl->tpl_vars['Item']->value['intLevel'];?>
] -->
                    <?php if (isset($_smarty_tpl->tpl_vars['_ActiveMenuItems']->value) && in_array($_smarty_tpl->tpl_vars['Item']->value['intMenuItemID'],$_smarty_tpl->tpl_vars['_ActiveMenuItems']->value)) {?>
                        <?php ob_start();
echo mb_strtolower($_smarty_tpl->tpl_vars['Item']->value['strModule'], 'UTF-8');
$_prefixVariable1=ob_get_clean();
ob_start();
echo mb_strtolower($_smarty_tpl->tpl_vars['Item']->value['strModule'], 'UTF-8');
$_prefixVariable2=ob_get_clean();
$_smarty_tpl->_subTemplateRender(((string)@constant('LOCAL__THEME__BLOCKS'))."/menu.button.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('Style'=>$_smarty_tpl->tpl_vars['Item']->value['strMenuStyle'],'Text'=>$_smarty_tpl->tpl_vars['MenuText']->value,'Link'=>"index.php?module=".$_prefixVariable1."&amp;page=".((string)$_smarty_tpl->tpl_vars['Item']->value['strControllerClass'])."&amp;action=".((string)$_smarty_tpl->tpl_vars['Item']->value['strAction']),'Selected'=>"1",'Function'=>$_smarty_tpl->tpl_vars['Item']->value['strAction'],'ControllerClass'=>$_smarty_tpl->tpl_vars['Item']->value['strControllerClass'],'ControllerType'=>"page",'Module'=>$_prefixVariable2), 0, true);
?>

                    <?php } else { ?>
                        <?php ob_start();
echo mb_strtolower($_smarty_tpl->tpl_vars['Item']->value['strModule'], 'UTF-8');
$_prefixVariable3=ob_get_clean();
ob_start();
echo mb_strtolower($_smarty_tpl->tpl_vars['Item']->value['strModule'], 'UTF-8');
$_prefixVariable4=ob_get_clean();
$_smarty_tpl->_subTemplateRender(((string)@constant('LOCAL__THEME__BLOCKS'))."/menu.button.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('Style'=>$_smarty_tpl->tpl_vars['Item']->value['strMenuStyle'],'Text'=>$_smarty_tpl->tpl_vars['MenuText']->value,'Link'=>"index.php?module=".$_prefixVariable3."&amp;page=".((string)$_smarty_tpl->tpl_vars['Item']->value['strControllerClass'])."&amp;action=".((string)$_smarty_tpl->tpl_vars['Item']->value['strAction']),'Selected'=>"0",'Function'=>$_smarty_tpl->tpl_vars['Item']->value['strAction'],'ControllerClass'=>$_smarty_tpl->tpl_vars['Item']->value['strControllerClass'],'ControllerType'=>"page",'Module'=>$_prefixVariable4), 0, true);
?>

                    <?php }?>
                <?php }?> 

                <?php $_smarty_tpl->_assignInScope('intLastLevel', $_smarty_tpl->tpl_vars['Item']->value['intLevel']);
?>
            <?php }?> 
        <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);
?>
   

        <?php
$_smarty_tpl->tpl_vars['i'] = new Smarty_Variable(null, $_smarty_tpl->isRenderingCache);$_smarty_tpl->tpl_vars['i']->step = 1;$_smarty_tpl->tpl_vars['i']->total = (int) ceil(($_smarty_tpl->tpl_vars['i']->step > 0 ? $_smarty_tpl->tpl_vars['intLastLevel']->value-1+1 - (0) : 0-($_smarty_tpl->tpl_vars['intLastLevel']->value-1)+1)/abs($_smarty_tpl->tpl_vars['i']->step));
if ($_smarty_tpl->tpl_vars['i']->total > 0) {
for ($_smarty_tpl->tpl_vars['i']->value = 0, $_smarty_tpl->tpl_vars['i']->iteration = 1;$_smarty_tpl->tpl_vars['i']->iteration <= $_smarty_tpl->tpl_vars['i']->total;$_smarty_tpl->tpl_vars['i']->value += $_smarty_tpl->tpl_vars['i']->step, $_smarty_tpl->tpl_vars['i']->iteration++) {
$_smarty_tpl->tpl_vars['i']->first = $_smarty_tpl->tpl_vars['i']->iteration == 1;$_smarty_tpl->tpl_vars['i']->last = $_smarty_tpl->tpl_vars['i']->iteration == $_smarty_tpl->tpl_vars['i']->total;?>
                <!-- Closing SubMenu [LEVEL <?php echo $_smarty_tpl->tpl_vars['intLastLevel']->value-$_smarty_tpl->tpl_vars['i']->value;?>
] -->     
                </ul>
            </li>
        <?php }
}
?>


    <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);
?>

</ul>
<!-- END OF LEFT SIDE MENU --><?php }
}
