<?php
/* Smarty version 3.1.31, created on 2019-11-10 11:51:12
  from "D:\www\ks_invoicing\modules\inv\view\templates\pages\payment.list.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5dc7dd908338c7_16083869',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'eb691e233b34d350d0e00c857d1fa98b7ea4b4ce' => 
    array (
      0 => 'D:\\www\\ks_invoicing\\modules\\inv\\view\\templates\\pages\\payment.list.tpl',
      1 => 1572430035,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5dc7dd908338c7_16083869 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_310025dc7dd907e5789_85972592', 'app');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_113395dc7dd907e9237_19536053', 'controller');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_261525dc7dd907ebfd9_03259844', 'style');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_243855dc7dd907ee7d7_60630490', 'script');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_33025dc7dd907fd108_08051849', 'page_title');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_169355dc7dd907fffb7_45509199', 'dialog');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_155725dc7dd90811ba8_62174073', 'toolbar');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_119015dc7dd9081b828_17400298', 'content');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, ((string)@constant('LOCAL__THEME'))."/template/masters/master1/master.tpl");
}
/* {block 'app'} */
class Block_310025dc7dd907e5789_85972592 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'app' => 
  array (
    0 => 'Block_310025dc7dd907e5789_85972592',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

data-ng-app="INV"
<?php
}
}
/* {/block 'app'} */
/* {block 'controller'} */
class Block_113395dc7dd907e9237_19536053 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'controller' => 
  array (
    0 => 'Block_113395dc7dd907e9237_19536053',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

data-ng-controller="Payment" 
<?php
}
}
/* {/block 'controller'} */
/* {block 'style'} */
class Block_261525dc7dd907ebfd9_03259844 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'style' => 
  array (
    0 => 'Block_261525dc7dd907ebfd9_03259844',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


<?php
}
}
/* {/block 'style'} */
/* {block 'script'} */
class Block_243855dc7dd907ee7d7_60630490 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'script' => 
  array (
    0 => 'Block_243855dc7dd907ee7d7_60630490',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('PATH__JS');?>
/common.angular.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('PATH__JS');?>
/payment.list.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
<?php
}
}
/* {/block 'script'} */
/* {block 'page_title'} */
class Block_33025dc7dd907fd108_08051849 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'page_title' => 
  array (
    0 => 'Block_33025dc7dd907fd108_08051849',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<h1><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6742');?>
 <small><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6743');?>
</small></h1>
<?php
}
}
/* {/block 'page_title'} */
/* {block 'dialog'} */
class Block_169355dc7dd907fffb7_45509199 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'dialog' => 
  array (
    0 => 'Block_169355dc7dd907fffb7_45509199',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


<div id="dlgRemove" class="modal fade modal-scroll modal-dialog" tabindex="-1" data-width="560">
    <div class="modal-header" >
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        <h3 class="modal-title"><i style="font-size:24px" class=" font-red fa fa-trash"></i> <?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6747');?>
 <?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6730');?>
</h3>
    </div>
    <div class="modal-body" style="margin: 0 auto;">
        <div class="row">
            <div class="col-md-6" >
                <label class="control-label"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6749');?>
</label>
            </div>    
        </div>
        <div class="modal-footer">
            <button type="button" data-ng-click="removePayment()" class="btn red-thunderbird" data-dismiss="modal"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6747');?>
</button>
            <button type="button" class="btn green-jungle" data-dismiss="modal"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6748');?>
</button>
        </div>
    </div>
</div>

<div id="dlgAdd" class="modal fade modal-scroll modal-dialog" tabindex="-1" data-width="760">
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        <h3 class="modal-title"><i style="font-size:24px" class=" font-blue fa fa-plus"></i> <?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6750');?>
 <?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6730');?>
</h3>
    </div>
    <div class="modal-body">
        <form name="addForm"> 
            <div class="row">
                <div class="col-md-6" >
                    <div class="form-group">
                        <label class="control-label"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6735');?>
</label>
                        <input type="text" name="ref" class="form-control" placeholder="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6735');?>
" autocomplete="off" data-ng-model="objPaymentAdd.strReference"/>
                    </div>
                </div>
                <div class="col-md-6" >
                    <div class="form-group">
                        <label class="control-label"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6732');?>
*</label>
                        <input type="text" class="form-control" placeholder="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6732');?>
" autocomplete="off" data-ng-model="objPaymentAdd.strCustomerName" data-ng-keyup="completeCustomerName(objPaymentAdd.strCustomerName)" required/>
                        <select name="customer" data-ng-if="customerList.length > 0" data-ng-change = "listInvoices(objPaymentAdd.intCustomerID)" data-ng-model="objPaymentAdd.intCustomerID" data-ng-options="customer.intID as customer.strName for customer in customerList" class="form-control" required>
                            <option value=""><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6755');?>
</option>
                        </select>
                        <small class="help-block font-red" data-ng-show="addForm.customer.$touched && addForm.customer.$invalid"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6753');?>
</small>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6" >
                    <div class="form-group">
                        <label class="control-label"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6737');?>
*</label>
                        <input type="text" name="amount" class="form-control" placeholder="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6737');?>
" autocomplete="off" data-ng-model="objPaymentAdd.decAmount" required/>
                        <small class="help-block font-red" data-ng-show="addForm.amount.$touched && addForm.amount.$invalid"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6753');?>
</small>
                    </div>
                </div>
                <div class="col-md-6" >
                    <div class="form-group">
                        <label class="control-label"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6731');?>
*</label>
                        <select name="method" data-ng-model="objPaymentAdd.intPaymentMethodID" data-ng-options="paymentMethod.intID as paymentMethod.strType for paymentMethod in arrPaymentMethodAdd" class="form-control" required>
                            <option value=""><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6731');?>
</option>
                        </select>
                        <small class="help-block font-red" data-ng-show="addForm.method.$touched && addForm.method.$invalid"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6753');?>
</small>
                    </div> 
                </div>    
            </div>
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label class="control-label"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6734');?>
*</label>
                        <select name="user" data-ng-model="objPaymentAdd.intCreatedByUserID" data-ng-options="createdBy.intID as createdBy.strUserName for createdBy in arrUsers" class="form-control" required>
                            <option value=""><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6734');?>
</option>
                        </select>
                        <small class="help-block font-red" data-ng-show="addForm.user.$touched && addForm.user.$invalid"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6753');?>
</small>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label class="control-label"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6736');?>
*</label>
                        <input type="text" class="form-control input-fixed input-daterange" datetimepicker="" data-date-format="yyyy-mm-dd" data-min-view="2" data-start-view="2" placeholder="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6736');?>
" data-ng-model="objPaymentAdd.dtDate"> 
                    </div>
                    <small class="help-block font-red" data-ng-show="addForm.date.$touched && addForm.date.$invalid"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6753');?>
</small>
                </div>
            </div>

        </form>  
    </div>
    <div class="modal-footer"> 
        <button type="button" data-ng-click="add()" class="btn green-jungle"  ng-disabled="addForm.$invalid"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6751');?>
</button>
        <button type="button" class="btn red-thunderbird" data-dismiss="modal"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6748');?>
</button>
    </div>  
</div>
<div id="dlgInvoices" class="modal fade modal-scroll modal-dialog" tabindex="-1" data-width="560">
<div class="modal-header" >
    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
    <h3 class="modal-title"><i style="font-size:24px" class=" font-blue fa fa-money "></i> <?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6759');?>
 </h3>
</div>
<div class="modal-body" style="margin: 0 auto;">
    <div class="portlet-body">
        <div class="table-responsive">
            <table class="table table-condensed table-light table-hover">
                <thead>
                    <tr>
                        <th><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6760');?>
</th>
                        <th><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6763');?>
</th>
                        <th style ="text-align:right"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6762');?>
</th> 
                        <th width="15%" ></th>
                    </tr>
                </thead>
                <tbody>
                    <tr data-ng-repeat="invoice in arrInvoice">
                        <td>{{invoice.fldInvoiceNumber}}</td>  
                        <td>{{invoice.fldDueDate}}</td>
                        <td><div class="pull-right">{{invoice.fldPaymentAmount}}</div></td>
                        <td class="icon" style ="text-align:right">
                            <a href="index.php?module=inv&page=Invoice&action=View&invoice_id={{invoice.pfInvoiceID}}" class="btn btn-xs yellow-saffron"  title="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6764');?>
"><i class="fa fa-search-plus"></i> <span class="visible-lg-inline-block"></span></a>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div> 
<?php
}
}
/* {/block 'dialog'} */
/* {block 'toolbar'} */
class Block_155725dc7dd90811ba8_62174073 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'toolbar' => 
  array (
    0 => 'Block_155725dc7dd90811ba8_62174073',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<!--<?php if (in_array(\NsCMN\ClsBllUserPermission::PERMISSION_ADD,$_smarty_tpl->tpl_vars['_UserPermission']->value)) {
}?>-->
<div class="btn-group">
    <a data-toggle="modal" data-target="#dlgAdd" class="btn btn-fit-height green-jungle" title="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6730');?>
">
        <i class="fa fa-plus"></i> 
        <span class="visible-lg-inline-block"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6730');?>
</span>
    </a>
</div>
<?php
}
}
/* {/block 'toolbar'} */
/* {block 'content'} */
class Block_119015dc7dd9081b828_17400298 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_119015dc7dd9081b828_17400298',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<div class="row">
    <div class="col-md-12">
        <div class="portlet light">
            <div class="portlet-title">
                <div class="caption font-blue"><i class="fa fa-filter font-blue"></i> <?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6740');?>
</div>
                <div class="tools"><a href="#" class="collapse"></a></div>
            </div>
            <div class="portlet-body" style="margin:0 auto!important">
                <form id="frmFilter">
                    <div class="row">
                        <div class="col-md-3">
                            <div class="form-group"> 
                                <label class="control-label"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6732');?>
</label>
                                <input list="customers" type="text" class="form-control" placeholder="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6732');?>
" autocomplete="off" data-ng-model="objFilter.strCustomerName"/></label>
                                <datalist id="customers">
                                    <option ng-repeat="customer in arrCustomer" value="{{customer.strName}}"></option>    
                                </datalist>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label class="control-label"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6733');?>
</label>
                                <input type="text" class="form-control" placeholder="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6734');?>
" autocomplete="off" data-ng-model="objFilter.intPaymentNumber"/>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label class="control-label"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6735');?>
</label>
                                <input type="text" class="form-control" placeholder="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6735');?>
" autocomplete="off" data-ng-model="objFilter.strReference"/>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label class="control-label"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6731');?>
</label>
                                <select data-ng-model="objFilter.intPaymentMethodID" data-ng-options="paymentMethod.intID as paymentMethod.strType for paymentMethod in arrPaymentMethod" data-ng-model="objFilter.intPaymentMethodID" class="form-control">
                                    <option value=""><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6731');?>
</option>
                                </select>
                            </div>
                        </div>                 
                    </div>
                    <div class="row">           
                        <div class="col-md-1">
                            <div class="form-group">
                                <label class="control-label"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6737');?>
</label>
                                <select data-ng-model="objFilter.strAmountOperator" class="form-control">
                                    <option value=">">></option>
                                    <option value="<"><</option>
                                    <option value="=">=</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label class="control-label">&nbsp;</label>
                                <input type="text" class="form-control" placeholder="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6737');?>
" autocomplete="off" data-ng-model="objFilter.decAmount"/>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label class="control-label"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6734');?>
</label>
                                <select data-ng-model="objFilter.intCreatedByUserID" data-ng-options="createdBy.intID as createdBy.strUserName for createdBy in arrUsers" data-ng-model="objFilter.intCreatedByUserID" class="form-control">
                                    <option value=""><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6734');?>
</option>
                                </select>
                            </div>
                        </div> 
                        <div class="col-md-3">
                            <div class="form-group">
                                <label class="control-label"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6758');?>
</label>
                                <div class="hidden-print input-group input-fixed date-picker input-daterange">
                                    <input type="text" class="form-control input-daterange ng-isolate-scope" datetimepicker="" data-date-format="yyyy-mm-dd" data-min-view="2" data-start-view="2" placeholder="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6736');?>
 <?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6744');?>
" data-ng-model="objFilter.dtDateBefore" style="cursor:context-menu"> 
                                    <span class="input-group-addon"></span>
                                    <input type="text" class="form-control input-daterange" datetimepicker="" data-date-format="yyyy-mm-dd" data-min-view="2" data-start-view="2" placeholder="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6736');?>
 <?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6745');?>
" data-ng-model="objFilter.dtDateAfter" style="cursor:context-menu"> 
                                </div> 
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group pull-right">
                                <label class="control-label">&nbsp;</label>
                                <div>
                                    <button type="button" class="btn blue" title="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6740');?>
" data-ng-click="listPayments()"><i class="fa fa-filter"></i> <?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6740');?>
</button>
                                    <button type="button" class="btn red-thunderbird" title="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6741');?>
" data-ng-click="reset()"><i class="fa fa-refresh"></i> <?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6741');?>
</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-12">
        <div class="portlet light">
            <div class="portlet-title">
                <div class="caption font-blue">
                    <i style="font-size:20px" class=" font-blue fa fa-money"></i>&nbsp;<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6742');?>

                </div>
                <pagination  data-ng-if="objPayments.arrData.length>0" data-total-items="objPayments.intTotal" data-items-per-page="objPaging.intPageSize" data-ng-model="objPaging.intPageNo" data-max-size="objPaging.intMaxSize" class="pagination-sm" data-boundary-links="true" data-ng-change="nextPage()"></pagination>
            </div>                                                               
            <div class="portlet-body">
                <div class="table-responsive">
                    <table class="table table-condensed table-light table-hover">
                        <thead>
                            <tr>
                                <th><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6733');?>
</th>
                                <th><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6732');?>
</th>
                                <th><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6735');?>
</th>
                                <th><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6731');?>
</th>
                                <th><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6734');?>
</th>
                                <th><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6736');?>
</th>
                                <th style="text-align:right;"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6737');?>
</th> 
                                <th width="10%"></th>
                                <th width="10%"></th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr data-ng-repeat="payment in objPayments.arrData">
                                <td>{{payment.intPaymentNumber}}</td>  
                                <td>{{payment.objCustomer.strName}}</td>
                                <td>{{payment.strReference}}</td>
                                <td>{{payment.objMethod.strType}}</td>
                                <td>{{payment.objUser.strUserName}}</td>
                                <td>{{payment.dtDate}}</td>
                                <td><div style="text-align:right;">{{payment.decAmount}}</div></td>
                                <td class="icon pull-right">
                                    <a data-ng-click="getInvoices(payment.intID)" class="btn btn-xs yellow-saffron" title="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6764');?>
" data-toggle="modal" data-target="#dlgInvoices"><i class="fa fa-search-plus"></i> <span class="visible-lg-inline-block"></span></a>
                                </td>
                                <td>
                                    <a data-ng-click="remove(payment.intID, $index)" data-toggle="modal" data-target="#dlgRemove" class="btn red-thunderbird btn-xs" title="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6747');?>
"><i class="fa fa-trash-o"></i> <span class="visible-lg-inline-block"></span></a>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div data-ng-if="objPayments.arrData.length == 0" class="alert alert-warning">
                    <p><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6754');?>
</p>
                </div>
            </div>
        </div>
    </div> 
</div>
<?php
}
}
/* {/block 'content'} */
}
