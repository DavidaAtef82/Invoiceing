<?php
/* Smarty version 3.1.31, created on 2019-11-07 17:04:18
  from "D:\www\ks_invoicing\themes\admin2\template\masters\master1\scripts.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5dc43272a242b8_36591155',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '859990f20a9822c1569d588d2f3c819a7a56ee48' => 
    array (
      0 => 'D:\\www\\ks_invoicing\\themes\\admin2\\template\\masters\\master1\\scripts.tpl',
      1 => 1570523813,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5dc43272a242b8_36591155 (Smarty_Internal_Template $_smarty_tpl) {
echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('WEB__ASSETS__JQUERY');?>
/jquery/jquery-1.10.2.min.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('WEB__ASSETS__JQUERY');?>
/jquery/jquery-migrate-1.2.1.min.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('WEB__ASSETS__JQUERY');?>
/jquery/jquery.blockui.min.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('WEB__ASSETS__JQUERY');?>
/jquery/jquery.cokie.min.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('WEB__ASSETS__JQUERY');?>
/slimscroll/jquery.slimscroll.min.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>

<?php echo '<script'; ?>
 src="https://code.highcharts.com/highcharts.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="https://code.highcharts.com/highcharts-more.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>



<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('WEB__ASSETS__OTHER');?>
/underscore/underscore-min.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('WEB__ASSETS__OTHER__MOMENT');?>
/moment-with-locales.min.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('WEB__ASSETS__OTHER__EGYNILE');?>
/dateformat.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('WEB__ASSETS__OTHER__EGYNILE');?>
/dates.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('WEB__ASSETS__OTHER__EGYNILE');?>
/common.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>

<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('WEB__ASSETS__BOOTSTRAP');?>
/bootstrap/js/bootstrap.min.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('WEB__ASSETS__BOOTSTRAP');?>
/modal/js/bootstrap-modal.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('WEB__ASSETS__BOOTSTRAP');?>
/modal/js/bootstrap-modalmanager.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
<?php if ($_smarty_tpl->tpl_vars['_Direction']->value == 'rtl') {
echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('WEB__ASSETS__BOOTSTRAP');?>
/datepicker/js/bootstrap-datetimepicker-ar.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('WEB__ASSETS__BOOTSTRAP');?>
/datepicker/js/bootstrap-datepicker.ar.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
<?php } else {
echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('WEB__ASSETS__BOOTSTRAP');?>
/datepicker/js/bootstrap-datetimepicker.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('WEB__ASSETS__BOOTSTRAP');?>
/datepicker/js/bootstrap-datepicker.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
<?php }?> 
<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('WEB__ASSETS__BOOTSTRAP');?>
/datepicker/js/bootstrap-datepicker.min.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>


<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('WEB__ASSETS__BOOTSTRAP');?>
/toastr/toastr.min.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('WEB__ASSETS__BOOTSTRAP');?>
/hover-dropdown/twitter-bootstrap-hover-dropdown.min.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('WEB__ASSETS__BOOTSTRAP');?>
/bootstrap-datepaginator/bootstrap-datepaginator.min.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>

<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('WEB__ASSETS__ANGULAR');?>
/angular.min.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('WEB__ASSETS__ANGULAR');?>
/angular-nl2br.min.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('WEB__ASSETS__ANGULAR');?>
/angular-sanitize.min.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('WEB__ASSETS__ANGULAR');?>
/wizard/angular-wizard.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('WEB__ASSETS__ANGULAR');?>
/bootstrap/ui-bootstrap-tpls-0.13.0.min.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('WEB__ASSETS__ANGULAR');?>
/sham-spinner/angular-sham-spinner.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('WEB__ASSETS__ANGULAR');?>
/datepicker/js/datepicker.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('WEB__ASSETS__ANGULAR');?>
/ui-select/js/select.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('WEB__ASSETS__ANGULAR');?>
/knobify/knobify.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('WEB__ASSETS__ANGULAR');?>
/xeditable/js/xeditable.min.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('WEB__ASSETS__ANGULAR');?>
/xeditable/js/checklist-model.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('WEB__ASSETS__ANGULAR');?>
/highcharts/highcharts-ng.min.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('WEB__ASSETS__ANGULAR');?>
/highcharts/drilldown.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('WEB__ASSETS__ANGULAR');?>
/ui-calendar/calendar.min.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>



                              
<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['_ClientSideLanguage']->value;?>
?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>

<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('WEB__THEME');?>
/js/app.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('WEB__THEME');?>
/js/layout.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('WEB__THEME');?>
/js/custom.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('WEB__THEME');?>
/js/master.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
><?php }
}
