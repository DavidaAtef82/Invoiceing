<?php
/* Smarty version 3.1.31, created on 2019-11-13 11:08:13
  from "D:\www\ks_invoicing\modules\inv\view\templates\pages\online.payment.error.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5dcbc7fdc409c9_81333651',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '3eb61719e61cf9c8eaa77407d966ad08de7a0038' => 
    array (
      0 => 'D:\\www\\ks_invoicing\\modules\\inv\\view\\templates\\pages\\online.payment.error.tpl',
      1 => 1573635869,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5dcbc7fdc409c9_81333651 (Smarty_Internal_Template $_smarty_tpl) {
?>
<!DOCTYPE>
<html>
    <head>
        <title>Payment Error</title>
        <link href="https://fonts.googleapis.com/css?family=McLaren&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
        <?php echo '<script'; ?>
 src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"><?php echo '</script'; ?>
>
        <?php echo '<script'; ?>
 src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"><?php echo '</script'; ?>
>
    </head>
    <body style="background-color:#4d5b69; font-family: 'McLaren', cursive; color:white">
        <div class="row" style="width:800px; margin:0 auto; margin-top:50px">
            <img src="http://localhost:80/ks_invoicing/modules/inv/view/images/error_404.png" style="width:190px; display: block; margin-left: auto; margin-right: auto; margin-top:100px;">
        </div>
        <div class="row">
            <div style="text-align:center; font-size:30px;white-space: nowrap;"> <?php echo $_smarty_tpl->tpl_vars['response']->value;?>
</div>                        
        </div>
        </div>

    </body>
</html>
<?php }
}
