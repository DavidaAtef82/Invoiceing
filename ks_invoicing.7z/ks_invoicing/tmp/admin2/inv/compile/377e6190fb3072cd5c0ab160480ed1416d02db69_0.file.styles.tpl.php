<?php
/* Smarty version 3.1.31, created on 2019-11-07 17:04:18
  from "D:\www\ks_invoicing\themes\admin2\template\masters\master1\styles.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5dc4327292e8c0_59761606',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '377e6190fb3072cd5c0ab160480ed1416d02db69' => 
    array (
      0 => 'D:\\www\\ks_invoicing\\themes\\admin2\\template\\masters\\master1\\styles.tpl',
      1 => 1570523812,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5dc4327292e8c0_59761606 (Smarty_Internal_Template $_smarty_tpl) {
?>
<link rel="shortcut icon" type="image/png" href="<?php echo @constant('WEB__THEME');?>
/images/<?php echo @constant('THEME_FAV_LOGO');?>
?ver=<?php echo @constant('VERSION');?>
"/>

<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700&subset=all" />
<link rel="stylesheet" type="text/css" href="<?php echo @constant('WEB__ASSETS__FONTS__AWESOME');?>
/css/font-awesome.min.css?ver=<?php echo @constant('VERSION');?>
"/>
<link rel="stylesheet" type="text/css" href="<?php echo @constant('WEB__ASSETS__FONTS');?>
/font.css?ver=<?php echo @constant('VERSION');?>
"/>
<link rel="stylesheet" type="text/css" href="<?php echo @constant('WEB__ASSETS__FONTS__SIMPLE_LINE_ICON');?>
/simple-line-icons.css?ver=<?php echo @constant('VERSION');?>
"/>

<?php if ($_smarty_tpl->tpl_vars['_Direction']->value == 'rtl') {?>
<link rel="stylesheet" type="text/css" href="<?php echo @constant('WEB__ASSETS__BOOTSTRAP');?>
/bootstrap/css/bootstrap-rtl.min.css?ver=<?php echo @constant('VERSION');?>
"/>
<link rel="stylesheet" type="text/css" href="<?php echo @constant('WEB__ASSETS__BOOTSTRAP');?>
/editable/css/bootstrap-editable-rtl.css?ver=<?php echo @constant('VERSION');?>
"/>
<link rel="stylesheet" type="text/css" href="<?php echo @constant('WEB__ASSETS__ANGULAR');?>
/ui-select/css/select-rtl.min.css?ver=<?php echo @constant('VERSION');?>
"/>
<link rel="stylesheet" type="text/css" href="<?php echo @constant('WEB__THEME');?>
/css/global/components-md-rtl.css?ver=<?php echo @constant('VERSION');?>
" id="style_components"/>
<link rel="stylesheet" type="text/css" href="<?php echo @constant('WEB__THEME');?>
/css/global/plugins-md-rtl.css?ver=<?php echo @constant('VERSION');?>
"/>
<link rel="stylesheet" type="text/css" href="<?php echo @constant('WEB__THEME');?>
/css/layout-rtl.css?ver=<?php echo @constant('VERSION');?>
"/>
<link rel="stylesheet" type="text/css" href="<?php echo @constant('WEB__THEME');?>
/css/themes/grey.css?ver=<?php echo @constant('VERSION');?>
" id="style_color"/>
<link rel="stylesheet" type="text/css" href="<?php echo @constant('WEB__THEME');?>
/css/custom-rtl.css?ver=<?php echo @constant('VERSION');?>
"/>
<?php } else { ?>
<link rel="stylesheet" type="text/css" href="<?php echo @constant('WEB__ASSETS__BOOTSTRAP');?>
/editable/css/bootstrap-editable.css?ver=<?php echo @constant('VERSION');?>
"/>
<link rel="stylesheet" type="text/css" href="<?php echo @constant('WEB__ASSETS__BOOTSTRAP');?>
/bootstrap/css/bootstrap.min.css?ver=<?php echo @constant('VERSION');?>
"/>
<link rel="stylesheet" type="text/css" href="<?php echo @constant('WEB__ASSETS__ANGULAR');?>
/ui-select/css/select.min.css?ver=<?php echo @constant('VERSION');?>
"/>
<link rel="stylesheet" type="text/css" href="<?php echo @constant('WEB__THEME');?>
/css/global/components-md.css?ver=<?php echo @constant('VERSION');?>
" id="style_components"/>
<link rel="stylesheet" type="text/css" href="<?php echo @constant('WEB__THEME');?>
/css/global/plugins-md.css?ver=<?php echo @constant('VERSION');?>
"/>
<link rel="stylesheet" type="text/css" href="<?php echo @constant('WEB__THEME');?>
/css/layout.css?ver=<?php echo @constant('VERSION');?>
"/>
<link rel="stylesheet" type="text/css" href="<?php echo @constant('WEB__THEME');?>
/css/themes/grey.css?ver=<?php echo @constant('VERSION');?>
" id="style_color"/>
<link rel="stylesheet" type="text/css" href="<?php echo @constant('WEB__THEME');?>
/css/custom.css?ver=<?php echo @constant('VERSION');?>
"/>
<?php }?>

<link rel="stylesheet" type="text/css" href="<?php echo @constant('WEB__ASSETS__BOOTSTRAP');?>
/modal/css/bootstrap-modal-bs3patch.css?ver=<?php echo @constant('VERSION');?>
"/>
<link rel="stylesheet" type="text/css" href="<?php echo @constant('WEB__ASSETS__BOOTSTRAP');?>
/modal/css/bootstrap-modal.css?ver=<?php echo @constant('VERSION');?>
"/>
<link rel="stylesheet" type="text/css" href="<?php echo @constant('WEB__ASSETS__BOOTSTRAP');?>
/fileupload/css/bootstrap-fileupload.css?ver=<?php echo @constant('VERSION');?>
"/>
<link rel="stylesheet" type="text/css" href="<?php echo @constant('WEB__ASSETS__BOOTSTRAP');?>
/bootstrap-datepaginator/bootstrap-datepaginator.min.css?ver=<?php echo @constant('VERSION');?>
"/>

<link rel="stylesheet" type="text/css" href="<?php echo @constant('WEB__ASSETS__BOOTSTRAP');?>
/datepicker/css/bootstrap-datepicker.css?ver=<?php echo @constant('VERSION');?>
"/>

<link rel="stylesheet" type="text/css" href="<?php echo @constant('WEB__ASSETS__BOOTSTRAP');?>
/toastr/toastr.min.css?ver=<?php echo @constant('VERSION');?>
"/>
<link rel="stylesheet" type="text/css" href="<?php echo @constant('WEB__ASSETS__BOOTSTRAP');?>
/datepicker/css/bootstrap-datetimepicker.css?ver=<?php echo @constant('VERSION');?>
" />

<link rel="stylesheet" type="text/css" href="<?php echo @constant('WEB__ASSETS__ANGULAR');?>
/xeditable/css/xeditable.css?ver=<?php echo @constant('VERSION');?>
"/>
<link rel="stylesheet" type="text/css" href="<?php echo @constant('WEB__ASSETS__ANGULAR');?>
/sham-spinner/angular-sham-spinner.css?ver=<?php echo @constant('VERSION');?>
"/>
<link rel="stylesheet" type="text/css" href="<?php echo @constant('WEB__ASSETS__ANGULAR');?>
/wizard/angular-wizard.min.css?ver=<?php echo @constant('VERSION');?>
"/><?php }
}
