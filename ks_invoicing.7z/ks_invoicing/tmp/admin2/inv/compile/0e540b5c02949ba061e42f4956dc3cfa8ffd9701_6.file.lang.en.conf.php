<?php /* Smarty version 3.1.31, created on 2019-11-11 11:46:14
         compiled from "D:\www\ks_invoicing\modules\inv\view\lang\lang.en.conf" */ ?>
<?php
/* Smarty version 3.1.31, created on 2019-11-11 11:46:14
  from "D:\www\ks_invoicing\modules\inv\view\lang\lang.en.conf" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5dc92de67f1fe8_64226705',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '0e540b5c02949ba061e42f4956dc3cfa8ffd9701' => 
    array (
      0 => 'D:\\www\\ks_invoicing\\modules\\inv\\view\\lang\\lang.en.conf',
      1 => 1573465571,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5dc92de67f1fe8_64226705 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->smarty->ext->configLoad->_loadConfigVars($_smarty_tpl, array (
  'sections' => 
  array (
    'AUX_MENU' => 
    array (
      'vars' => 
      array (
        'LNG_MENU_USER' => 'User Details',
        'LNG_MENU_NEW_USER' => 'User New',
        'LNG_MENU_NOTIFICATION' => 'Notification',
        'LNG_MENU_CITIES' => 'Cities',
        'LNG_MENU_CONFIGURATIONS' => 'Configurations',
        'LNG_MENU_LOCATIONS' => 'Locations',
        'LNG_MENU_INVOICING' => 'Invoicing',
        'LNG_MENU_REPORT_INVOICE_AGING' => 'Invoice Aging',
        'LNG_MENU_SETUP_PAYMENT_METHODS' => 'Payment Methods',
        'LNG_MENU_SETUP_CATALOGUE' => 'Catalogue',
        'LNG_MENU_SETUP_PAYMENT_TERMS' => 'Payment Terms',
        'LNG_MENU_CUSTOMERS' => 'Customers',
        'LNG_MENU_COUNTRIES' => 'Countries',
        'LNG_MENU_GEOGRAPHY' => 'Geography',
        'LNG_MENU_CONTACTS' => 'Contacts',
        'LNG_MENU_SETUP_TAX_TYPES' => 'Tax Types',
        'LNG_MENU_Payments' => 'Payments',
        'LNG_MENU_INVOICES' => 'Invoices',
        'LNG_MENU_ADD_INVOICE' => 'Add Invoice',
        'LNG_MENU_EDIT_INVOICE' => 'Edit Invoice',
        'LNG_MENU_VIEW_INVOICE' => 'View Invoice',
        'LNG_MENU_CUSTOMER_VIEW' => 'View Customer',
        'LNG_MENU_REPORTS' => 'Reports',
        'LNG_MENU_SETUP' => 'Setup',
        'LNG_MENU_SYSTEM' => 'System',
        'LNG_MENU_USERS' => 'Users',
        'LNG_MENU_STARTUP_DIALOG' => 'Announcements',
        'LNG_MENU_CRON_JOBS' => 'Cron Jobs',
        'LNG_MENU_USERLEVEL' => 'User Levels',
        'LNG_MENU_SITEMAP' => 'Sitemap',
        'LNG_MENU_MODULE_ACTIONS' => 'Module Actions',
        'LNG_MENU_USERLEVEL_PERMISSION' => 'User Level Permissions',
        'LNG_MENU_EDIT_USER' => 'User Edit',
      ),
    ),
    'META' => 
    array (
      'vars' => 
      array (
        'LNG_AUTHOR' => 'Agile Business Modules (ABM)',
        'LNG_DESCRIPTION' => 'Health Information Technology and Statistics Training Center',
        'LNG_KEYWORD' => '',
        'LNG_PROJECT_CREATION_DATE' => '2015-10-01',
      ),
    ),
    'CLS_BLL_INVOICE_ROW_TYPE' => 
    array (
      'vars' => 
      array (
        'LNG_ENUM_ITEM' => 'Item',
        'LNG_ENUM_DISCOUNT' => 'Discount',
        'LNG_ENUM_TAX' => 'Tax',
      ),
    ),
    'CLS_BLL_INVOICE_STATUS' => 
    array (
      'vars' => 
      array (
        'LNG_ENUM_STATUS_DRAFT' => 'Draft',
        'LNG_ENUM_STATUS_SENT' => 'Sent',
        'LNG_ENUM_STATUS_OVERDUE' => 'Overdue',
        'LNG_ENUM_STATUS_PARTIAL' => 'Partial',
        'LNG_ENUM_STATUS_PAID' => 'Paid',
        'LNG_ENUM_STATUS_WRITE_OFF' => 'Write Off',
        'LNG_ENUM_STATUS_VOID' => 'Void',
      ),
    ),
    'CLS_BLL_TAX_TYPE' => 
    array (
      'vars' => 
      array (
        'LNG_ENUM_FIXED' => 'Fixed',
        'LNG_ENUM_PERCENT' => 'Percent',
      ),
    ),
    'ERROR_CODE' => 
    array (
      'vars' => 
      array (
        'ERR_1000' => 'Schedule not loaded.',
        'ERR_1005' => 'Schedule is not set for the requested date.',
        'ERR_1006' => 'Cannot add permission: It affects a salary sheet that is already generated.',
        'ERR_1007' => 'Permission is not allowed on a non working day.',
        'ERR_1008' => 'Another permission exists on the same date.',
        'ERR_1009' => 'No attended shifts found for this permission.',
        'ERR_1010' => 'This permission will cause the earlier shift to be less than 2 minute long.',
        'ERR_1011' => 'This permission will cause the later shift to be less than 2 minute long.',
        'ERR_1012' => 'No Balance.',
        'ERR_1013' => 'Permission exceeds the allowed period.',
        'ERR_1014' => 'Permission period cannot be less than $intMinPermissionHours hours.',
        'ERR_1015' => 'Remaining permission is only $intRemainingPermissionHours hours.',
        'ERR_1021' => 'This employee consumed $intDaysSum days during this pregnancy. There are only $intAvailableDays available days.',
        'ERR_1028' => '$dt Start Date',
        'ERR_1029' => 'Cannot add vacation: It affects a salary sheet that is already issued.',
        'ERR_1030' => 'Vacation intersects with another one during the specified period.',
        'ERR_1040' => 'You are not allowed to request errand earlier than $dtCurrentDate.',
        'ERR_1042' => 'Chosen days are non working days.',
        'ERR_1043' => 'Another errand shift exists in the same time.',
        'ERR_1044' => 'A permission exists on the requested errand date, remove it first.',
        'ERR_1045' => 'A permission exists during this period, remove it first.',
        'ERR_1046' => 'Cannot load this installment.',
        'ERR_1047' => 'You exceeded the max number for postponing installments ($intMaxPostponeTimes).',
        'ERR_1053' => 'Vacation must be requested $intDaysBeforeVacation days before vacation date.',
        'ERR_1056' => 'Employee has no vacation balance.',
        'ERR_1057' => 'You can only add vacation that will end by this year. Adding vacation in the next year can be done only after the next year starts.',
        'ERR_1059' => 'Vacation is effectively $intEffectiveDays day(s), while employee vacation balance is only $intBalanceBefore day(s).',
        'ERR_1060' => 'Terminated/Resigned Employee.',
        'ERR_1061' => 'Vacation date cannot be earlier than joining date.',
        'ERR_1062' => 'Vacation date cannot be earlier than joining date.',
        'ERR_1063' => 'Schedule is not set for month [$intStartMonth/$intStartYear].',
        'ERR_1064' => 'Schedule is not set for month [$intEndMonth/$intEndYear].',
        'ERR_1066' => 'Cannot postpone installments.',
        'ERR_1067' => 'No Installments Found.',
        'ERR_1068' => 'Salary for $intMonth-$intYear is calculated.',
        'ERR_1069' => 'You cannot add vacation: It affects a salary sheet that is already issued.',
        'ERR_1070' => 'Start Date $dtStartDate is invalid.',
        'ERR_1071' => 'Vacation intersects with another during this specified period.',
        'ERR_1078' => 'Employee data is not loaded.',
        'ERR_1079' => 'Cannot delete device.',
        'ERR_1080' => 'Vacation overlaps with another in the specific period.',
        'ERR_1081' => 'Attachment not uploaded successfully.',
        'ERR_1082' => 'Device is disabled: It was referenced by other records.',
        'ERR_1086' => 'Wedding Vacation is entitled after $intMonths months of joining date.',
        'ERR_1087' => 'Wedding Vacation Consumed.',
        'ERR_1089' => 'This vacation is entitled after $intDays days of joining date.',
        'ERR_1092' => 'No dates to update.',
        'ERR_1093' => 'All dates are invalid.',
        'ERR_1094' => 'Some dates are invalid.',
        'ERR_1095' => 'Cannot Update Schedule.',
        'ERR_1096' => 'Not allowed to add vacation without setting a number of days.',
        'ERR_1097' => 'Cannot delete permission in the past.',
        'ERR_1098' => 'Cannot take vacation after termination date.',
        'ERR_1099' => 'Short Name must be entered.',
        'ERR_1100' => 'Invalid Employee Code.',
        'ERR_1101' => 'Employee Code is duplicated.',
        'ERR_1102' => 'Full Name must be entered.',
        'ERR_1103' => 'Education must be entered.',
        'ERR_1104' => 'Invalid Annual Normal Vacation Balance.',
        'ERR_1105' => 'Invalid Annual Casual Vacation Balance.',
        'ERR_1106' => 'Annual Casual Vacation Balance cannot be greater than annual Normal Vacation Balance.',
        'ERR_1107' => 'Invalid Remaining Normal Vacation Balance.',
        'ERR_1108' => 'Invalid Remaining Casual Vacation Balance.',
        'ERR_1109' => 'Remaining Casual Vacation Balance cannot be greater than remaining Normal Vacation Balance.',
        'ERR_1110' => 'Invalid Date of Birth .',
        'ERR_1111' => 'Invalid Join Date.',
        'ERR_1112' => 'Invalid Sex Value.',
        'ERR_1113' => 'Invalid Nationality Value.',
        'ERR_1114' => 'Invalid Religion Value.',
        'ERR_1115' => 'Invalid Marital Status Value.',
        'ERR_1116' => 'Invalid Military Status Value.',
        'ERR_1117' => 'Position value cannot be empty.',
        'ERR_1118' => 'Invalid Loacation Value.',
        'ERR_1119' => 'Invalid Contract Type Value.',
        'ERR_1120' => 'Invalid Direct Head Code.',
        'ERR_1121' => 'Direct Head Code not found.',
        'ERR_1122' => 'Invalid Social Insurance Date.',
        'ERR_1123' => 'Invalid Personal Email.',
        'ERR_1124' => 'Invalid Bussiness Email.',
        'ERR_1126' => 'Department value cannot be empty.',
        'ERR_1127' => 'Sub Department value cannot be empty.',
        'ERR_1128' => 'Invalid User Name.',
        'ERR_1129' => 'Request is already responded to.',
        'ERR_1130' => 'Cannot respond to this request: Target employee does not report to you.',
        'ERR_1131' => 'Invalid Response Type.',
        'ERR_1132' => 'Cannot load employee info.',
        'ERR_1133' => 'This request is posted for an employee that is no longer working in the organization.',
        'ERR_1134' => 'No employees selected.',
        'ERR_1135' => 'Duration intersects with a non pending payroll cycle.',
        'ERR_1136' => 'Vacation Type disabled.',
        'ERR_1137' => 'New Value',
        'ERR_1141' => 'Only employee can cancel his own requests.',
        'ERR_1142' => 'Cannot Set Schedule.',
        'ERR_1143' => 'Object is not loaded.',
        'ERR_1144' => 'Duplicate Social Insurance Number.',
        'ERR_1151' => 'Cannot add permission.',
        'ERR_1152' => 'Cannot accept this vacation; as it exceeds max successive period ($strMaxPeriod).',
        'ERR_1153' => 'Cannot send request.',
        'ERR_1154' => 'Employee not loaded.',
        'ERR_1155' => 'Head user not found.',
        'ERR_1156' => 'Cannot add vacation.',
        'ERR_1157' => 'Negative Value.',
        'ERR_1158' => 'Incorrect Format.',
        'ERR_1159' => 'Partial vacation intersected with permission shift.',
        'ERR_1160' => 'Partial vacations within a day must not exceed its working hours.',
        'ERR_1161' => 'No Attended Shifts.',
        'ERR_1162' => 'Incomplete Data.',
        'ERR_1163' => 'Permission exists during partial vacation.',
        'ERR_1164' => 'Invalid Start Time.',
        'ERR_1165' => 'Invalid End Time.',
        'ERR_1166' => 'Payroll cycle is calculated.',
        'ERR_1167' => 'Not Allowed! To manage schedule in the past.',
        'ERR_1168' => 'Vacation day',
        'ERR_1169' => 'File upload filed.',
        'ERR_1170' => 'Cannot accept this vacation; as it is less than the min period ($strMinPeriod).',
        'ERR_1171' => 'Permission spans over the only working shift.',
        'ERR_1172' => 'Vacation replaces all working shift on its date.',
        'ERR_1185' => 'Future join date value is not allowed.',
        'ERR_1186' => 'Could not modify join date.',
        'ERR_1187' => 'Could not update attendance schedule.',
        'ERR_1188' => 'Could not assign holidays.',
        'ERR_1189' => 'Could not adjust vacations balances.',
        'ERR_1190' => 'Could not updated salary logs.',
        'ERR_1191' => 'Could remove old schedule days.',
        'ERR_1192' => 'Could not check payroll transactions.',
        'ERR_1193' => 'Payroll transactions found between old and new join dates.',
        'ERR_1194' => 'Could not update salary effects while CAB module is not enabled.',
      ),
    ),
    'PAGE_CUSTOMER_LIST' => 
    array (
      'vars' => 
      array (
        'LNG_6688' => 'Customers',
        'LNG_6689' => 'Listing',
        'LNG_6690' => 'Filter',
        'LNG_6691' => 'Customer Name',
        'LNG_6692' => 'Country',
        'LNG_6693' => 'City',
        'LNG_6694' => 'Reset',
        'LNG_6695' => 'Pending Invoices',
        'LNG_6697' => 'Name',
        'LNG_6698' => 'Customer ID',
        'LNG_6700' => 'Receivables',
        'LNG_6701' => 'Total Invoices',
        'LNG_6702' => 'Status',
        'LNG_6703' => 'Address',
        'LNG_6704' => 'Phone',
        'LNG_6705' => 'Customer',
        'LNG_6706' => 'Add',
        'LNG_6707' => 'Location',
        'LNG_6708' => 'There are no customers!',
        'LNG_6710' => 'Edit',
        'LNG_6711' => 'Notes',
        'LNG_6712' => 'Delete',
        'LNG_6713' => 'Cancel',
        'LNG_6717' => '*Field Required',
        'LNG_6718' => 'Email',
        'LNG_6719' => 'Do you want to delete this element?',
      ),
    ),
    'PAGE_INVOICE_ADDPAYMENT' => 
    array (
      'vars' => 
      array (
        'LNG_6768' => 'Add Payment',
        'LNG_6769' => 'Card Number',
        'LNG_6770' => 'Expiry Date',
        'LNG_6771' => 'CVV',
        'LNG_6772' => 'Finish and Pay',
      ),
    ),
    'PAGE_INVOICE_VIEW' => 
    array (
      'vars' => 
      array (
        'LNG_6766' => 'Payment Link',
        'LNG_6767' => 'Generate',
      ),
    ),
    'PAGE_PAYMENT_LIST' => 
    array (
      'vars' => 
      array (
        'LNG_6730' => 'Payment',
        'LNG_6731' => 'Payment Method',
        'LNG_6732' => 'Customer Name',
        'LNG_6733' => 'Payment Number',
        'LNG_6734' => 'Created By',
        'LNG_6735' => 'Reference Number',
        'LNG_6736' => 'Date',
        'LNG_6737' => 'Amount',
        'LNG_6738' => 'Created On',
        'LNG_6740' => 'Filter',
        'LNG_6741' => 'Reset',
        'LNG_6742' => 'Payments',
        'LNG_6743' => 'Manageent',
        'LNG_6744' => 'Before',
        'LNG_6745' => 'After',
        'LNG_6746' => 'Operator',
        'LNG_6747' => 'Delete',
        'LNG_6748' => 'Cancel',
        'LNG_6749' => 'Do you want to delete this payment?',
        'LNG_6750' => 'Add ',
        'LNG_6751' => 'Save',
        'LNG_6752' => 'Edit',
        'LNG_6753' => '*Field Required',
        'LNG_6754' => 'No payments found!',
        'LNG_6755' => 'Select Customer',
        'LNG_6756' => 'Invoice Number',
        'LNG_6757' => 'Select Invoice',
        'LNG_6758' => 'Date Range',
        'LNG_6759' => 'Payment Invoices',
        'LNG_6760' => 'Invoice Number',
        'LNG_6761' => 'Invoice Status',
        'LNG_6762' => 'Payment',
        'LNG_6763' => 'Due Date',
        'LNG_6764' => 'View',
      ),
    ),
    'PAGE_REPORT_INVOICEAGING' => 
    array (
      'vars' => 
      array (
        'LNG_6680' => 'Invoice Aging',
        'LNG_6681' => 'Report',
      ),
    ),
    'PAGE_REPORT_MENU' => 
    array (
      'vars' => 
      array (
        'LNG_6058' => 'Reports',
        'LNG_6059' => 'Menu',
      ),
    ),
    'PAGE_SETUP_CATALOGUE' => 
    array (
      'vars' => 
      array (
        'LNG_6682' => 'Item and Service Catalogue',
        'LNG_6683' => 'Management',
      ),
    ),
    'PAGE_SETUP_MENU' => 
    array (
      'vars' => 
      array (
        'LNG_6057' => 'Menu',
        'LNG_6060' => 'Setup',
      ),
    ),
    'PAGE_SETUP_PAYMENTMETHOD' => 
    array (
      'vars' => 
      array (
        'LNG_6684' => 'Payment Methods',
        'LNG_6685' => 'Management',
      ),
    ),
    'PAGE_SETUP_PAYMENTTERM' => 
    array (
      'vars' => 
      array (
        'LNG_6686' => 'Payment Terms',
        'LNG_6687' => 'Management',
      ),
    ),
    'PAGE_SETUP_TAXTYPE' => 
    array (
      'vars' => 
      array (
        'LNG_6773' => 'Tax Types',
        'LNG_6774' => 'Add',
        'LNG_6775' => 'Tax Type',
        'LNG_6776' => 'Type',
        'LNG_6777' => 'Required Field',
      ),
    ),
    'SERVICE_CONFIG_LANG' => 
    array (
      'vars' => 
      array (
        'LNG_1180' => 'Success',
        'LNG_1181' => 'Language keys were listed successfully.',
      ),
    ),
    'SERVICE_CONFIG_LIST' => 
    array (
      'vars' => 
      array (
        'LNG_1176' => 'Success',
        'LNG_1177' => 'Configurations listed sucessfully.',
      ),
    ),
  ),
  'vars' => 
  array (
    'MONTH_JAN' => 'Jan',
    'MONTH_FEB' => 'Feb',
    'MONTH_MAR' => 'Mar',
    'MONTH_APR' => 'Apr',
    'MONTH_MAY' => 'May',
    'MONTH_JUN' => 'Jun',
    'MONTH_JUL' => 'Jul',
    'MONTH_AUG' => 'Aug',
    'MONTH_SEP' => 'Sep',
    'MONTH_OCT' => 'Oct',
    'MONTH_NOV' => 'Nov',
    'MONTH_DEC' => 'Dec',
    'HELP' => 'Help',
    'KNOWLEDGE_BASE' => 'User Guide',
    'YOUTUBE_CHANNEL' => 'Video',
    'NEW_NOTIFICATIONS' => 'New Notification',
    'VIEW_ALL' => 'View All',
    'NOTIFICATION' => 'Notification',
    'CLOSE' => 'Close',
    'LOADING' => 'Loading',
    'MY_ACCOUNT' => 'My Account',
    'LOG_OUT' => 'Log out',
    'ANNOUNCE' => 'Announcement',
    'CANCEL' => 'Cancel',
    'APP_NAME' => 'modulus business suite',
  ),
));
}
}
