<?php
/* Smarty version 3.1.31, created on 2019-11-11 13:16:48
  from "D:\www\ks_invoicing\modules\inv\view\templates\pages\invoice.list.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5dc943202ebdc1_38830666',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '79338f44d0cc432c1851cb93ac9c275c538e4244' => 
    array (
      0 => 'D:\\www\\ks_invoicing\\modules\\inv\\view\\templates\\pages\\invoice.list.tpl',
      1 => 1573471005,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5dc943202ebdc1_38830666 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_219715dc943202c1281_43753970', 'app');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_12965dc943202c2b47_77220160', 'controller');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_143455dc943202c3da9_20080607', 'style');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_189585dc943202c4db7_78610709', 'script');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_317915dc943202d10f8_57790288', 'page_title');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_251485dc943202d28f3_29838150', 'dialog');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_193975dc943202d5637_75946069', 'toolbar');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_310025dc943202e2ae7_61259854', 'content');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, ((string)@constant('LOCAL__THEME'))."/template/masters/master1/master.tpl");
}
/* {block 'app'} */
class Block_219715dc943202c1281_43753970 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'app' => 
  array (
    0 => 'Block_219715dc943202c1281_43753970',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

data-ng-app="INV"
<?php
}
}
/* {/block 'app'} */
/* {block 'controller'} */
class Block_12965dc943202c2b47_77220160 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'controller' => 
  array (
    0 => 'Block_12965dc943202c2b47_77220160',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

data-ng-controller="Invoice" 
<?php
}
}
/* {/block 'controller'} */
/* {block 'style'} */
class Block_143455dc943202c3da9_20080607 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'style' => 
  array (
    0 => 'Block_143455dc943202c3da9_20080607',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
}
}
/* {/block 'style'} */
/* {block 'script'} */
class Block_189585dc943202c4db7_78610709 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'script' => 
  array (
    0 => 'Block_189585dc943202c4db7_78610709',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('PATH__JS');?>
/common.angular.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('PATH__JS');?>
/invoice.list.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('PATH__JS');?>
/enum.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
<?php
}
}
/* {/block 'script'} */
/* {block 'page_title'} */
class Block_317915dc943202d10f8_57790288 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'page_title' => 
  array (
    0 => 'Block_317915dc943202d10f8_57790288',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<h1>Invoices</h1>
<?php
}
}
/* {/block 'page_title'} */
/* {block 'dialog'} */
class Block_251485dc943202d28f3_29838150 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'dialog' => 
  array (
    0 => 'Block_251485dc943202d28f3_29838150',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


<div id="dlgRemove" class="modal fade modal-scroll modal-dialog" tabindex="-1" 
    data-width="500" style="display: none;height:auto!important">
    <div class="modal-header" >
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        <h3 class="modal-title"><i style="font-size:24px" class=" font-blue fa fa-trash"></i> Delete Invoice</h3>
    </div>
    <div class="modal-body" style="margin: 0 auto;">
        <div class="row">
            <div class="col-md-12" >
                <label class="control-label" >&nbsp;&nbsp; Do you want to delete this element?</label>
            </div>    
        </div>
        <div class="modal-footer">
            <button type="button" data-ng-click="removeInvoice()" class="btn red-thunderbird" 
                data-dismiss="modal">DELETE</button>
            <button type="button" class="btn green-jungle" data-dismiss="modal">CANCEL</button>
        </div>
    </div>
</div>

<div id="dlgEditStatus" class="modal fade modal-scroll modal-dialog" tabindex="-1" data-width="500" 
    style="display: none;height:auto!important">
    <div class="modal-header" >
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        <h3 class="modal-title"><i style="font-size:24px" class=" font-blue fa fa-edit"></i> Change Status</h3>
    </div>
    <div class="modal-body" style="margin: 0 auto;">
        <div class="row">
            <div class="col-md-12" >
                <div class="form-group"> 
                    <label class="control-label" >Are you sure you want to change the status to 
                        <b>{{objLang.inv.CLS_BLL_INVOICE_STATUS[objNewStatus.Status]}}</b> ?</label>
                </div>

            </div>    
        </div>
        <div class="modal-footer">
            <button type="button" data-ng-click="updateStatus()" class="btn green-jungle" 
                data-dismiss="modal">Change</button>
            <button type="button" class="btn red-thunderbird" data-dismiss="modal">CANCEL</button>
        </div>
    </div>
</div>
<?php
}
}
/* {/block 'dialog'} */
/* {block 'toolbar'} */
class Block_193975dc943202d5637_75946069 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'toolbar' => 
  array (
    0 => 'Block_193975dc943202d5637_75946069',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php if (in_array(\NsCMN\ClsBllUserPermission::PERMISSION_ADD,$_smarty_tpl->tpl_vars['_UserPermission']->value)) {?>
<div class="btn-group">
    <a href="index.php?module=inv&page=Invoice&action=Add" class="btn btn-fit-height green-jungle" 
        title="Add Invoice">
        <i class="fa fa-plus"></i> 
        <span class="visible-lg-inline-block">Invoice</span>
    </a>
</div>
<?php }
}
}
/* {/block 'toolbar'} */
/* {block 'content'} */
class Block_310025dc943202e2ae7_61259854 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_310025dc943202e2ae7_61259854',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<div class="row">
    <div class="col-md-12">
        <div class="portlet light">
            <div class="portlet-title">
                <div class="caption font-blue">
                    <i class="fa fa-filter font-blue"></i> 
                    Filter
                </div>
                <div class="tools"><a href="#" class="collapse"></a></div>
            </div>
            <div class="portlet-body">
                <form id="frmFilter">
                    <div class="row">
                        <div class="col-md-3">
                            <div class="form-group">
                                <input type="text" data-ng-enter="filter()" 
                                    name="txtInvoiceNumber" data-ng-model="objFilter.strInvoiceNumber" 
                                    placeholder="Invoice Number" class="form-control"/>
                            </div>
                        </div>  
                        <div class="col-md-3">
                            <div class="form-group">
                                <input type="text" data-ng-enter="filter()" name="txtReference" 
                                    data-ng-model="objFilter.strReference" placeholder="Invoice Reference" 
                                    class="form-control"/>
                            </div>
                        </div>                            
                        <div class="col-md-3">
                            <div class="form-group"> 
                                <input list="customers" type="text" data-ng-enter="filter()" 
                                    name="txtCustomer" data-ng-model="objFilter.strCustomerName" 
                                    placeholder="Customer Name" class="form-control"/>

                                <datalist id="customers">
                                    <option ng-repeat="customer in arrCustomers" value="{{customer.strName}}"></option>
                                </datalist>
                            </div>
                        </div>    
                        <div class="col-md-3 form-group">
                            <div   class="hidden-print input-group input-fixed date-picker input-daterange">
                                <input type="text" id="txtFilterDateFrom" name="txtFilterDateFrom" 
                                    class="form-control input-daterange ng-pristine ng-isolate-scope ng-invalid ng-invalid-required ng-touched" 
                                    datetimepicker="" data-date-format="yyyy-mm-dd" data-min-view="2" 
                                    data-start-view="2" placeholder="Issue Date From" 
                                    data-ng-model="objFilter.dtIssueDateFrom" required="required"> 
                                <span class="input-group-addon">to</span> 
                                <input type="text" id="txtFilterDateTo" name="txtFilterDateTo" 
                                    class="form-control input-daterange ng-pristine ng-untouched ng-isolate-scope ng-invalid ng-invalid-required" datetimepicker="" data-date-format="yyyy-mm-dd" data-min-view="2" 
                                    data-start-view="2" placeholder="Issue Date To" 
                                    data-ng-model="objFilter.dtIssueDateTo" required="required">
                            </div> 
                        </div>
                    </div>
                    <div class='row'>
                        <div class="col-md-3">
                            <div class="form-group"> 
                                <select data-ng-model="objFilter.intPaymentTermID" 
                                    data-ng-options="paymentterm.intID as paymentterm.strName for paymentterm in arrPaymentTerms" 
                                    class="form-control">
                                    <option value="">Payment Term</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group"> 
                                <select data-ng-model="objFilter.intStatusID" 
                                    data-ng-options="status.intID as objLang.inv.CLS_BLL_INVOICE_STATUS[status.strStatus] for status in arrStatus" 
                                    class="form-control">
                                    <option value="">Status</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group"> 
                                <select data-ng-model="objFilter.intCreatedByUserID" 
                                    data-ng-options="user.intID as user.strDisplayName for user in arrUsers" 
                                    class="form-control">
                                    <option value="">User</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-3 form-group">
                            <div class="hidden-print input-group input-fixed date-picker input-daterange">
                                <input type="text" id="txtFilterDateFrom" name="txtFilterDateFrom" 
                                    class="form-control input-daterange ng-pristine ng-isolate-scope ng-invalid ng-invalid-required ng-touched" 
                                    datetimepicker="" data-date-format="yyyy-mm-dd" data-min-view="2" data-start-view="2" placeholder="Due Date From" data-ng-model="objFilter.dtDueDateFrom" required="required"> 
                                <span class="input-group-addon">to</span> 
                                <input type="text" id="txtFilterDateTo" name="txtFilterDateTo" 
                                    class="form-control input-daterange ng-pristine ng-untouched ng-isolate-scope ng-invalid ng-invalid-required" 
                                    datetimepicker="" data-date-format="yyyy-mm-dd" data-min-view="2" data-start-view="2" 
                                    placeholder="Due Date To" data-ng-model="objFilter.dtDueDateTo" required="required">
                            </div> 
                        </div>
                    </div>       
                    <div class="row">

                        <div class="col-md-12">
                            <div classclass="col-md-3 "> 
                                <input type="checkbox" data-ng-model="objFilter.boolShowOverdue" 
                                    data-ng-checked="objFilter.boolShowOverdue"/> 
                                <span>Show Due date Invoices</span>
                            </div>
                            <div class="form-group pull-right">
                                <button type="button" class="btn blue" title="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6690');?>
" 
                                    data-ng-click="filter()"><i class="fa fa-filter"></i> Filter</button>
                                <button type="button" class="btn red-thunderbird" title="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6694');?>
"
                                    data-ng-click="reset()"><i class="fa fa-refresh"></i> Reset</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-12">
        <div class="portlet light">
            <div class="portlet-title">
                <div class="caption font-blue">
                    <i style="font-size:15px" class=" font-blue fa fa-paperclip"></i>&nbsp;Invoices
                </div>
                <pagination  data-ng-if="objInvoices.intTotal>20" data-total-items="objInvoices.intTotal"
                    data-items-per-page="objPaging.intPageSize" data-ng-model="objPaging.intPageNo" 
                    data-max-size="objPaging.intMaxSize"
                    class="pagination-sm" data-boundary-links="true" data-ng-change="nextPage()"></pagination>
            </div>                                                               
            <div class="portlet-body">
                <div data-ng-if="objInvoices.intTotal > 0" class="table-responsive">
                    <table class="table table-condensed table-hover">
                        <thead>
                            <tr>
                                <th>Invoice#</th>
                                <th>IssueDate</th> 
                                <th>DueDate</th> 
                                <th>Customer</th>
                                <th>Gross Amount</th>
                                <th>Total Payment</th>  
                                <th>Remaining</th> 
                                <th>User</th>
                                <th>Status</th>
                                <th>&nbsp;</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr  style="color:'#37434c'"
                                
                                data-ng-style="
                                objInvoice.objStatus.strStatus == objEnumStatus.STATUS_VOID &&
                                {'text-decoration':'line-through'}
                                ||objInvoice.objStatus.strStatus == objEnumStatus.STATUS_WRITE_OFF && 
                                {'text-decoration':'line-through'} 
                                ||objInvoice.boolOverDue && 
                                {'background-color':'rgb(247, 79, 95)'}
                                ||objInvoice.objStatus.strStatus == objEnumStatus.STATUS_DRAFT && 
                                {'background-color':'rgb(193, 174, 178)'}  
                                ||objInvoice.objStatus.strStatus == objEnumStatus.STATUS_PAID && 
                                {'background-color':'rgb(159, 247, 156)'} 
                                "                        
                                 
                                data-ng-repeat="objInvoice in objInvoices.arrData">
                                <td>{{objInvoice.strInvoiceNumber}}</td>
                                <td>{{objInvoice.dtIssueDate | date: "yyyy-MM-dd"}}</td>
                                <td>{{objInvoice.dtDueDate | date: "yyyy-MM-dd"}}</td>
                                <td>{{objInvoice.objCustomer.strName}} </td>
                                <td class="text-right">{{objInvoice.decGrossAmount | number:2}} </td>
                                <td class="text-right">{{objInvoice.decTotalPayment| number:2}} </td>
                                <td class="text-right">
                                    {{objInvoice.decGrossAmount - objInvoice.decTotalPayment| number:2}}
                                </td>
                                <td>{{objInvoice.objUser.strDisplayName}} </td>
                                <td>
                                    <span data-ng-if="isStatusDisabled(objInvoice.objStatus.strStatus)">
                                        <i class="fa fa-lock"></i> 
                                        {{objLang.inv.CLS_BLL_INVOICE_STATUS[objInvoice.objStatus.strStatus]}} 
                                    </span>
                                    <a href="#" data-ng-if="!isStatusDisabled(objInvoice.objStatus.strStatus)"
                                        data-ng-click="changeStatus($index)" data-toggle="modal" data-target="#dlgEditStatus"  title="Change Status">
                                        <i  class="fa fa-unlock"></i>
                                        {{objLang.inv.CLS_BLL_INVOICE_STATUS[objInvoice.objStatus.strStatus]}} 
                                    </a>
                                </td>
                                <td class="icon">
                                    <?php if (in_array(\NsCMN\ClsBllUserPermission::PERMISSION_VIEW,$_smarty_tpl->tpl_vars['_UserPermission']->value)) {?>
                                    <a href="index.php?module=inv&page=Invoice&action=View&invoice_id={{objInvoice.intID}}"
                                        class="btn btn-xs yellow-saffron" style="cursor: pointer;" 
                                        title="View"><i class="fa fa-search-plus"></i> 
                                        <span class="visible-lg-inline-block"></span></a>
                                    <?php }?>
                                    <?php if (in_array(\NsCMN\ClsBllUserPermission::PERMISSION_EDIT,$_smarty_tpl->tpl_vars['_UserPermission']->value)) {?>
                                    <a href="index.php?module=inv&page=Invoice&action=Edit&invoice_id={{objInvoice.intID}}"
                                        class="btn btn-xs blue-dark" style="cursor: pointer;" 
                                        title="Edit" data-ng-disabled="objInvoice.objStatus.intID!=1">
                                        <i class="fa fa-edit"></i> 
                                        <span class="visible-lg-inline-block"></span></a> 
                                    <?php }?>
                                    <?php if (in_array(\NsCMN\ClsBllUserPermission::PERMISSION_DELETE,$_smarty_tpl->tpl_vars['_UserPermission']->value)) {?>
                                    <a href="#" class="btn btn-xs red-thunderbird" style="cursor: pointer;"
                                        title="Delete" data-ng-disabled="objInvoice.objStatus.intID!=1" 
                                        data-ng-click="remove(objInvoice.intID, $index)" data-toggle="modal" 
                                        data-target="#dlgRemove"><i class="fa fa-trash-o"></i> 
                                        <span class="visible-lg-inline-block"></span></a>
                                    <?php }?>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div data-ng-if="objInvoices.intTotal == 0" class="alert alert-warning">
                    <p>No Invoices Found</p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
}
}
/* {/block 'content'} */
}
