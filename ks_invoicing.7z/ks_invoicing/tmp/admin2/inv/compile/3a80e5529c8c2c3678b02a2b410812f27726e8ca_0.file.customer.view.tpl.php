<?php
/* Smarty version 3.1.31, created on 2019-11-10 16:42:31
  from "D:\www\ks_invoicing\modules\inv\view\templates\pages\customer.view.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5dc821d7258d35_60231075',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '3a80e5529c8c2c3678b02a2b410812f27726e8ca' => 
    array (
      0 => 'D:\\www\\ks_invoicing\\modules\\inv\\view\\templates\\pages\\customer.view.tpl',
      1 => 1573396939,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5dc821d7258d35_60231075 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>
 <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_40155dc821d7239489_80102466', 'app');
?>
 <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_122205dc821d723aca3_99567507', 'controller');
?>
 <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_192695dc821d723bdd0_62143515', 'style');
?>
 <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_170505dc821d723d159_14669479', 'script');
?>
 
<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_306675dc821d7247d07_22467218', 'page_title');
?>
  
<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_29845dc821d7248b66_71207834', 'content');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, ((string)@constant('LOCAL__THEME'))."/template/masters/master1/master.tpl");
}
/* {block 'app'} */
class Block_40155dc821d7239489_80102466 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'app' => 
  array (
    0 => 'Block_40155dc821d7239489_80102466',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
 data-ng-app="INV" <?php
}
}
/* {/block 'app'} */
/* {block 'controller'} */
class Block_122205dc821d723aca3_99567507 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'controller' => 
  array (
    0 => 'Block_122205dc821d723aca3_99567507',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
 data-ng-controller="Customer" <?php
}
}
/* {/block 'controller'} */
/* {block 'style'} */
class Block_192695dc821d723bdd0_62143515 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'style' => 
  array (
    0 => 'Block_192695dc821d723bdd0_62143515',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
}
}
/* {/block 'style'} */
/* {block 'script'} */
class Block_170505dc821d723d159_14669479 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'script' => 
  array (
    0 => 'Block_170505dc821d723d159_14669479',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('PATH__JS');?>
/common.angular.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('PATH__JS');?>
/customer.view.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('PATH__JS');?>
/enum.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
<?php
}
}
/* {/block 'script'} */
/* {block 'page_title'} */
class Block_306675dc821d7247d07_22467218 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'page_title' => 
  array (
    0 => 'Block_306675dc821d7247d07_22467218',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<h1>Customer Details</h1>
<?php
}
}
/* {/block 'page_title'} */
/* {block 'content'} */
class Block_29845dc821d7248b66_71207834 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_29845dc821d7248b66_71207834',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


<div class="row">

    <div data-ng-if="true" class="table-responsive">
        <div class="col-md-12">
            <div class="row profile">
                <div class="col-md-12">
                    <div class="portlet light">
                        <div class="portlet-title">
                            <div class="caption ng-binding">
                                {{objCustomer.strName}}
                            </div>
                        </div>
                        <div class="portlet-body">
                            <div class="tab-content">
                                <table class="table light">
                                    <tbody>
                                        <tr>
                                            <td rowspan="3" style="min-width:100px; max-width:150px"></td>
                                            <th>Customer ID</th>
                                            <td class="ng-binding">{{objCustomer.intID}}</td>
                                            <th> Address </th>
                                            <td class="ng-binding"> {{objCustomer.strAddress}}</td>
                                            <th width="12%"> Phone </th>
                                            <td class="ng-binding"> {{objCustomer.strPhone}} </td>
                                            <td rowspan="3" style="min-width:150px; max-width:150px"> </td>
                                        </tr>
                                        <tr>
                                            <th> Email</th>
                                            <td width="13%" class="ng-binding">{{objCustomer.strEmail}}</td>
                                            <th>City </th>
                                            <td class="ng-binding">{{objCustomer.objCity.strCity}} </td>
                                            <th>Country</th>
                                            <td class="ng-binding">{{objCustomer.objCity.objCountry.strCountry}}</td>
                                        </tr>
                                        <tr class="alert-info">
                                            <th> Total Transactions</th>
                                            <td width="13%" class="ng-binding">{{intTotalTransactions | number:2}}</td>
                                            <th>Total Payments </th>
                                            <td class="ng-binding">{{intTotalPayments | number:2}} </td>
                                            <th>Total Remaining</th>
                                            <td class="ng-binding">{{intTotalRemaining | number:2}}</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-12">
            <div class="col-md-12">
                <div class="portlet light tabbable">
                    <div class="portlet-title tabbable-line">
                        <ul class="nav nav-tabs">
                            <li class="">
                                <a href="#tbInvoices" data-toggle="tab">Invoices</a>
                            </li>
                            <li class="">
                                <a href="#tbPayments" data-toggle="tab">Payments  </a>
                            </li>
                        </ul>
                    </div>
                    <div class="portlet-body">
                        <div class="tab-content">

                            <div class="tab-pane ng-scope" id="tbInvoices">
                                <div class="row">
                                    <div class="col-md-12">
                                        <h4>Invoices</h4>
                                        <div class="table-responsive ng-scope">
                                            <table class="table table-condensed table-light table-bordered">
                                                <thead>
                                                    <tr>
                                                        <th>Invoice# </th>
                                                        <th>IssueDate</th>
                                                        <th>DueDate</th>
                                                        <th class="text-right ng-binding">Total Amount</th>
                                                        <th class="text-right ng-binding">Total Payment</th>
                                                        <th class="text-right ng-binding">Remaining</th>
                                                        <th>Status</th>
                                                        <th>&nbsp;</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr data-ng-repeat="objInvoice in objCustomer.arrInvoice">
                                                        <td>{{objInvoice.strInvoiceNumber}}</td>
                                                        <td>{{objInvoice.dtIssueDate | date: "yyyy-MM-dd"}}</td>
                                                        <td>{{objInvoice.dtDueDate | date: "yyyy-MM-dd"}}</td>
                                                        <td class="text-right ng-binding">{{objInvoice.decTotalAmount -- objInvoice.decTotalTax - objInvoice.decTotalDiscount | number:2}} </td>
                                                        <td class="text-right ng-binding">{{objInvoice.decTotalPayment| number:2}} </td>
                                                        <td class="text-right ng-binding">
                                                            {{objInvoice.decTotalAmount -- objInvoice.decTotalTax - objInvoice.decTotalDiscount - objInvoice.decTotalPayment| number:2}}
                                                        </td>
                                                        <td>
                                                            <span>
                                                                {{objLang.inv.CLS_BLL_INVOICE_STATUS[objInvoice.objStatus.strStatus]}} 
                                                            </span>
                                                        </td>
                                                        <td class="icon">
                                                            <?php if (in_array(\NsCMN\ClsBllUserPermission::PERMISSION_VIEW,$_smarty_tpl->tpl_vars['_UserPermission']->value)) {?>
                                                            <a href="index.php?module=inv&page=Invoice&action=View&invoice_id={{objInvoice.intID}}" class="btn btn-xs yellow-saffron" style="cursor: pointer;" title="View"><i class="fa fa-search-plus"></i> 
                                                                <span class="visible-lg-inline-block"></span></a> <?php }?> <?php if (in_array(\NsCMN\ClsBllUserPermission::PERMISSION_EDIT,$_smarty_tpl->tpl_vars['_UserPermission']->value)) {?>
                                                            <?php }?> 
                                                        </td>
                                                    </tr>

                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="tab-pane ng-scope" id="tbPayments">
                                <div class="row">
                                    <div class="col-md-12">
                                        <h4>Payments</h4>
                                        <div class="table-responsive ng-scope">
                                            <table class="table table-condensed table-light table-bordered">
                                                <thead>
                                                    <tr>
                                                        <th>Payment#</th>
                                                        <th>Reference#</th>
                                                        <th>Payment Method</th>
                                                        <th>Date</th>
                                                        <th style="width:5%">Amount</th> 
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr data-ng-repeat="payment in objCustomer.arrPayment">
                                                        <td>{{payment.intPaymentNumber}}</td>  
                                                        <td>{{payment.strReference}}</td>
                                                        <td>{{payment.objMethod.strType}}</td>
                                                        <td>{{payment.dtDate}}</td>
                                                        <td class="text-right ng-binding" style="width:5%">{{payment.decAmount}}</td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <div data-ng-if="false" class="alert alert-warning">
        <p>No Customer Found</p>
    </div>

</div>
<?php
}
}
/* {/block 'content'} */
}
