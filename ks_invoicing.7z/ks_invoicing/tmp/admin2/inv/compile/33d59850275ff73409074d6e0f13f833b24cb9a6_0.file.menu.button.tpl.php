<?php
/* Smarty version 3.1.31, created on 2019-11-07 17:04:18
  from "D:\www\ks_invoicing\themes\admin2\template\blocks\menu.button.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5dc432729a4e42_57084488',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '33d59850275ff73409074d6e0f13f833b24cb9a6' => 
    array (
      0 => 'D:\\www\\ks_invoicing\\themes\\admin2\\template\\blocks\\menu.button.tpl',
      1 => 1570523812,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5dc432729a4e42_57084488 (Smarty_Internal_Template $_smarty_tpl) {
if ($_smarty_tpl->tpl_vars['Selected']->value == true && $_smarty_tpl->tpl_vars['Link']->value == '') {?>
    <li class="active">
        <a href="#" class="nav-link nav-toggle"> <?php echo $_smarty_tpl->tpl_vars['Text']->value;?>

        <?php if ($_smarty_tpl->tpl_vars['Style']->value != '') {?>
            <i class="<?php echo $_smarty_tpl->tpl_vars['Style']->value;?>
"></i>
        <?php }?>
        </a>
    </li>
<?php } elseif ($_smarty_tpl->tpl_vars['Selected']->value == true && $_smarty_tpl->tpl_vars['Link']->value != '') {?>
    <li class="active">
        <a href="<?php echo $_smarty_tpl->tpl_vars['Link']->value;?>
" class="nav-link"> <?php echo $_smarty_tpl->tpl_vars['Text']->value;?>

        <?php if ($_smarty_tpl->tpl_vars['Style']->value != '') {?>
            <i class="<?php echo $_smarty_tpl->tpl_vars['Style']->value;?>
"></i>
        <?php }?>        
        </a>
    </li>
<?php } else { ?>
    <li>
        <a href="<?php echo $_smarty_tpl->tpl_vars['Link']->value;?>
" class="nav-link"> <?php echo $_smarty_tpl->tpl_vars['Text']->value;?>

        <?php if ($_smarty_tpl->tpl_vars['Style']->value != '') {?>
            <i class="<?php echo $_smarty_tpl->tpl_vars['Style']->value;?>
"></i>
        <?php }?>        
        </a>
    </li>
<?php }
}
}
