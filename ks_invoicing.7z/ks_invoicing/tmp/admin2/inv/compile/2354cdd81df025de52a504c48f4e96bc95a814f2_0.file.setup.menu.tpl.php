<?php
/* Smarty version 3.1.31, created on 2019-11-10 10:09:58
  from "D:\www\ks_invoicing\modules\inv\view\templates\pages\setup.menu.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5dc7c5d68e7670_40386765',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '2354cdd81df025de52a504c48f4e96bc95a814f2' => 
    array (
      0 => 'D:\\www\\ks_invoicing\\modules\\inv\\view\\templates\\pages\\setup.menu.tpl',
      1 => 1570523806,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5dc7c5d68e7670_40386765 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_250365dc7c5d68c20f7_75426688', 'app');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_317655dc7c5d68c3b36_98071809', 'controller');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_274345dc7c5d68c4b02_17702018', 'style');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_74515dc7c5d68c5c28_51324887', 'script');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_201525dc7c5d68cb1a1_90063461', 'dialog');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_175535dc7c5d68cc465_86868201', 'page_title');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_40865dc7c5d68cecd1_47914850', 'toolbar');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_286635dc7c5d68d01f2_68193946', 'content');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, ((string)@constant('LOCAL__THEME'))."/template/masters/master1/master.tpl");
}
/* {block 'app'} */
class Block_250365dc7c5d68c20f7_75426688 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'app' => 
  array (
    0 => 'Block_250365dc7c5d68c20f7_75426688',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

data-ng-app="INV"
<?php
}
}
/* {/block 'app'} */
/* {block 'controller'} */
class Block_317655dc7c5d68c3b36_98071809 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'controller' => 
  array (
    0 => 'Block_317655dc7c5d68c3b36_98071809',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php
}
}
/* {/block 'controller'} */
/* {block 'style'} */
class Block_274345dc7c5d68c4b02_17702018 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'style' => 
  array (
    0 => 'Block_274345dc7c5d68c4b02_17702018',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
}
}
/* {/block 'style'} */
/* {block 'script'} */
class Block_74515dc7c5d68c5c28_51324887 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'script' => 
  array (
    0 => 'Block_74515dc7c5d68c5c28_51324887',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('PATH__JS');?>
/common.angular.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 type="text/javascript">
        app.controller(controllers);
    <?php echo '</script'; ?>
>
<?php
}
}
/* {/block 'script'} */
/* {block 'dialog'} */
class Block_201525dc7c5d68cb1a1_90063461 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'dialog' => 
  array (
    0 => 'Block_201525dc7c5d68cb1a1_90063461',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


<?php
}
}
/* {/block 'dialog'} */
/* {block 'page_title'} */
class Block_175535dc7c5d68cc465_86868201 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'page_title' => 
  array (
    0 => 'Block_175535dc7c5d68cc465_86868201',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<h1><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6060');?>
 <small><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6057');?>
</small></h1>
<?php
}
}
/* {/block 'page_title'} */
/* {block 'toolbar'} */
class Block_40865dc7c5d68cecd1_47914850 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'toolbar' => 
  array (
    0 => 'Block_40865dc7c5d68cecd1_47914850',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php
}
}
/* {/block 'toolbar'} */
/* {block 'content'} */
class Block_286635dc7c5d68d01f2_68193946 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_286635dc7c5d68d01f2_68193946',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<div class="row"> 
    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['arrMenuItems']->value, 'obj', false, 'index');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['index']->value => $_smarty_tpl->tpl_vars['obj']->value) {
?>
        <?php if (in_array($_smarty_tpl->tpl_vars['index']->value,$_smarty_tpl->tpl_vars['_User']->value->arrActionsIDs)) {?>                                                                
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                <a class="dashboard-stat dashboard-stat-v2 <?php echo $_smarty_tpl->tpl_vars['obj']->value['strColor'];?>
" href="index.php?module=<?php echo @constant('MODULE_NAME');?>
&amp;page=<?php echo $_smarty_tpl->tpl_vars['obj']->value['page'];?>
&amp;action=<?php echo $_smarty_tpl->tpl_vars['obj']->value['action'];?>
">
                    <div class="visual">
                        <i style="margin-left: -10px;margin-top: -30px;" class="<?php echo $_smarty_tpl->tpl_vars['obj']->value['strIcon'];?>
"></i>
                    </div>
                    <div class="details">
                        <div class="number">
                            <span data-counter="counterup" data-value=""></span>
                        </div>
                        <div class="desc"> <h2 style="width:200px"><?php echo $_smarty_tpl->tpl_vars['obj']->value['strName'];?>
</h2> </div>
                    </div>
                </a>
            </div>
        <?php }?>
    <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);
?>

</div>

<?php
}
}
/* {/block 'content'} */
}
