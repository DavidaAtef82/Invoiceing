<?php
/* Smarty version 3.1.31, created on 2019-11-10 12:48:07
  from "D:\www\ks_invoicing\modules\inv\view\templates\pages\setup.payment.term.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5dc7eae7e07947_99245354',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '290a544a3a5ce90cb6f69fcf32a3f4834d4cdbf4' => 
    array (
      0 => 'D:\\www\\ks_invoicing\\modules\\inv\\view\\templates\\pages\\setup.payment.term.tpl',
      1 => 1573382885,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5dc7eae7e07947_99245354 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_38645dc7eae7de8ef2_26823658', 'app');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_280175dc7eae7dea524_29306957', 'controller');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_141665dc7eae7deb4b1_26984140', 'style');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_296555dc7eae7ded0a7_18081583', 'script');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_12205dc7eae7df7192_32002727', 'dialog');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_285895dc7eae7df9096_22435617', 'toolbar');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_294105dc7eae7e02b79_99968433', 'content');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, ((string)@constant('LOCAL__THEME'))."/template/masters/master1/master.tpl");
}
/* {block 'app'} */
class Block_38645dc7eae7de8ef2_26823658 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'app' => 
  array (
    0 => 'Block_38645dc7eae7de8ef2_26823658',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

data-ng-app="INV"
<?php
}
}
/* {/block 'app'} */
/* {block 'controller'} */
class Block_280175dc7eae7dea524_29306957 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'controller' => 
  array (
    0 => 'Block_280175dc7eae7dea524_29306957',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

data-ng-controller="PaymentTerm" 
<?php
}
}
/* {/block 'controller'} */
/* {block 'style'} */
class Block_141665dc7eae7deb4b1_26984140 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'style' => 
  array (
    0 => 'Block_141665dc7eae7deb4b1_26984140',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
}
}
/* {/block 'style'} */
/* {block 'script'} */
class Block_296555dc7eae7ded0a7_18081583 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'script' => 
  array (
    0 => 'Block_296555dc7eae7ded0a7_18081583',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('PATH__JS');?>
/common.angular.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('PATH__JS');?>
/setup.payment.term.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
<?php
}
}
/* {/block 'script'} */
/* {block 'dialog'} */
class Block_12205dc7eae7df7192_32002727 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'dialog' => 
  array (
    0 => 'Block_12205dc7eae7df7192_32002727',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<div id="dlgEdit" class="modal fade modal-scroll modal-dialog" tabindex="-1" data-width="500" style="display: none;height:auto!important">
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        <h3 class="modal-title">
            <i style="font-size:24px" class=" font-blue fa fa-edit"></i> Edit Payment Term</h3>
    </div>
    <div class="modal-body" style="margin: 0 auto;">
        <form name="editForm">
            <div class="row">
                <div class="col-md-12" >
                    <div class="form-group">
                        <label class="control-label">Name*</label>
                        <input type="text" name="paymenttermName" class="form-control" placeholder="Name" 
                            autocomplete="off" data-ng-model="objEditPaymentTerm.strName" required />
                        <small class="help-block font-red" 
                            data-ng-show="editForm.paymenttermName.$touched && editForm.paymenttermName.$invalid">
                            Name is required
                        </small>
                    </div>
                    <div class="form-group">
                        <label class="control-label">Description</label>
                        <textarea style=" width: 100%;" rows="10" name="paymenttermDescription"
                            data-ng-model="objEditPaymentTerm.strDescription">
                        </textarea>
                    </div>
                </div>
            </div>
        </form>   
    </div>
    <div class="modal-footer">
        <button type="button"  data-ng-click="editPaymentTerm()" class="btn green-jungle" 
            data-dismiss="modal" data-ng-disabled="editForm.$invalid">EDIT</button>
        <button type="button" class="btn red-thunderbird" data-dismiss="modal">CANCEL</button>

    </div>
</div>

<div id="dlgRemove" class="modal fade modal-scroll modal-dialog" tabindex="-1" data-width="500" style="display: none;height:auto!important">
    <div class="modal-header" >
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        <h3 class="modal-title"><i style="font-size:24px" class=" font-blue fa fa-trash"></i> Delete Payment Term</h3>
    </div>
    <div class="modal-body" style="margin: 0 auto;">
        <div class="row">
            <div class="col-md-12" >
                <label class="control-label" >&nbsp;&nbsp; Do you want to delete this element?</label>
            </div>    
        </div>
        <div class="modal-footer">
            <button type="button" data-ng-click="removePaymentTerm()" class="btn red-thunderbird" data-dismiss="modal">DELETE</button>
            <button type="button" class="btn green-jungle" data-dismiss="modal">CANCEL</button>
        </div>
    </div>
</div>
<div id="dlgAdd" class="modal fade modal-scroll modal-dialog" tabindex="-1" data-width="500" style="display: none;height:auto!important">
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        <h3 class="modal-title"><i style="font-size:24px" class=" font-blue fa fa-user-plus"></i> Add Payment Term</h3>
    </div>
    <div class="modal-body" style="margin: 0 auto;">
        <form name="addForm">
            <div class="row">
                <div class="col-md-12" >
                    <div class="form-group">
                        <label class="control-label">Name*</label>
                        <input type="text" name="paymenttermName" class="form-control" placeholder="Name" 
                            autocomplete="off" data-ng-model="objAddPaymentTerm.strName" required />
                        <small class="help-block font-red" 
                            data-ng-show="addForm.paymenttermName.$touched && addForm.paymenttermName.$invalid">
                            Name is required
                        </small>
                    </div>
                    <div class="form-group">
                        <label class="control-label">Description</label>
                        <textarea style=" width: 100%;" rows="10" name="paymenttermDescription"
                            data-ng-model="objAddPaymentTerm.strDescription">
                        </textarea>
                    </div>
                </div>
            </div> 
        </form>  
    </div>
    <div class="modal-footer">
        <button type="button" data-ng-click="addPaymentTerm()" class="btn green-jungle" 
            data-ng-disabled="addForm.$invalid">ADD</button>
        <button type="button" class="btn red-thunderbird" data-dismiss="modal">CANCEL</button>
    </div>
</div>
<?php
}
}
/* {/block 'dialog'} */
/* {block 'toolbar'} */
class Block_285895dc7eae7df9096_22435617 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'toolbar' => 
  array (
    0 => 'Block_285895dc7eae7df9096_22435617',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<!--<?php if (in_array(\NsCMN\ClsBllUserPermission::PERMISSION_ADD,$_smarty_tpl->tpl_vars['_UserPermission']->value)) {
}?>-->
<div class="btn-group">
    <a data-toggle="modal" data-target="#dlgAdd" class="btn btn-fit-height green-jungle" title="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6705');?>
">
        <i class="fa fa-plus"></i> 
        <span class="visible-lg-inline-block">Payment Term</span>
    </a>
</div>
<?php
}
}
/* {/block 'toolbar'} */
/* {block 'content'} */
class Block_294105dc7eae7e02b79_99968433 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_294105dc7eae7e02b79_99968433',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<div class="row">
    <div class="col-md-12">
        <div class="portlet light">
            <div class="portlet-title">
                <div class="caption font-blue"><i class="fa fa-filter font-blue"></i> Filter</div>
                <div class="tools"><a href="#" class="collapse"></a></div>
            </div>
            <div class="portlet-body">
                <form id="frmFilter">
                    <div class="row">
                        <div class="col-md-3">
                            <div class="form-group">
                                <input type="text" data-ng-enter="filter()" name="txtPaymentTermName" 
                                    data-ng-model="objFilter.strName" placeholder="PaymentTerm Name" class="form-control"/>
                            </div>
                        </div>  
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group pull-right">
                                <button type="button" class="btn blue" title="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6690');?>
" data-ng-click="filter()"><i class="fa fa-filter"></i> Filter</button>
                                <button type="button" class="btn red-thunderbird" title="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6694');?>
" data-ng-click="reset()"><i class="fa fa-refresh"></i> Reset</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-12">
        <div class="portlet light">
            <div class="portlet-title">
                <div class="caption font-blue">
                    <i style="font-size:15px" class=" font-blue fa fa-users"></i>&nbsp;Payment Terms
                </div>
                <pagination  data-ng-if="objPaymentTerms.arrData.length>20" data-total-items="objPaymentTerms.intTotal" 
                data-items-per-page="objPaging.intPageSize" data-ng-model="objPaging.intPageNo" 
                data-max-size="objPaging.intMaxSize" class="pagination-sm" data-boundary-links="true" 
                data-ng-change="nextPage()"></pagination>
            </div>                                                               
            <div class="portlet-body">
                <div data-ng-if="objPaymentTerms.arrData.length > 0" class="table-responsive">
                    <table class="table  table-light table-hover">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Description</th>
                                <th>&nbsp;</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr data-ng-repeat="objPaymentTerm in objPaymentTerms.arrData"><!--data-ng-class="{'striped':objUser.intDisabled == 1}"--> 
                                <td>{{objPaymentTerm.intID}}</td>
                                <td>{{objPaymentTerm.strName}}</td>
                                <td>{{objPaymentTerm.strDescription}}</td>
                                <!--<?php if (in_array(\NsCMN\ClsBllUserPermission::PERMISSION_DELETE,$_smarty_tpl->tpl_vars['_UserPermission']->value)) {
}?>-->
                                <td class="icon">
                                    <a data-ng-disabled='objPaymentTerm.boolIsReserved' data-ng-click="edit(objPaymentTerm ,$index)" 
                                    data-toggle="modal" data-target="#dlgEdit" class="btn blue-dark btn-xs" 
                                    title="Edit"><i class="fa fa-edit"></i> <span class="visible-lg-inline-block">
                                    </span></a>
                                    &nbsp;&nbsp;<a data-ng-click="remove(objPaymentTerm.intID, $index)" data-toggle="modal" data-target="#dlgRemove" class="btn red-thunderbird btn-xs" title="Delete"><i class="fa fa-trash-o"></i> <span class="visible-lg-inline-block"></span></a>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div data-ng-if="objPaymentTerms.arrData.length == 0" class="alert alert-warning">
                    <p><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6708');?>
</p>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Temp delet form until solcing 2 modals in the same page problem-->
<!--End temp form-->
<!---temp add form-->
<?php
}
}
/* {/block 'content'} */
}
