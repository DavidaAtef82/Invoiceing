<?php /* Smarty version 3.1.31, created on 2019-11-11 11:46:09
         compiled from "D:\www\ks_invoicing\modules\cmn\view\lang\lang.en.conf" */ ?>
<?php
/* Smarty version 3.1.31, created on 2019-11-11 11:46:09
  from "D:\www\ks_invoicing\modules\cmn\view\lang\lang.en.conf" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5dc92de1bf4761_60739999',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'd8a1f2c628a784c7f85d4fe2cce14d59626f17be' => 
    array (
      0 => 'D:\\www\\ks_invoicing\\modules\\cmn\\view\\lang\\lang.en.conf',
      1 => 1573465280,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5dc92de1bf4761_60739999 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->smarty->ext->configLoad->_loadConfigVars($_smarty_tpl, array (
  'sections' => 
  array (
    'AUX_MENU' => 
    array (
      'vars' => 
      array (
        'LNG_MENU_USER' => 'User Details',
        'LNG_MENU_NEW_USER' => 'User New',
        'LNG_MENU_NOTIFICATION' => 'Notification',
        'LNG_MENU_CITIES' => 'Cities',
        'LNG_MENU_CONFIGURATIONS' => 'Configurations',
        'LNG_MENU_LOCATIONS' => 'Locations',
        'LNG_MENU_INVOICING' => 'Invoicing',
        'LNG_MENU_REPORT_INVOICE_AGING' => 'Invoice Aging',
        'LNG_MENU_SETUP_PAYMENT_METHODS' => 'Payment Methods',
        'LNG_MENU_SETUP_CATALOGUE' => 'Catalogue',
        'LNG_MENU_SETUP_PAYMENT_TERMS' => 'Payment Terms',
        'LNG_MENU_CUSTOMERS' => 'Customers',
        'LNG_MENU_COUNTRIES' => 'Countries',
        'LNG_MENU_GEOGRAPHY' => 'Geography',
        'LNG_MENU_CONTACTS' => 'Contacts',
        'LNG_MENU_SETUP_TAX_TYPES' => 'Tax Types',
        'LNG_MENU_Payments' => 'Payments',
        'LNG_MENU_INVOICES' => 'Invoices',
        'LNG_MENU_ADD_INVOICE' => 'Add Invoice',
        'LNG_MENU_EDIT_INVOICE' => 'Edit Invoice',
        'LNG_MENU_VIEW_INVOICE' => 'View Invoice',
        'LNG_MENU_CUSTOMER_VIEW' => 'View Customer',
        'LNG_MENU_REPORTS' => 'Reports',
        'LNG_MENU_SETUP' => 'Setup',
        'LNG_MENU_SYSTEM' => 'System',
        'LNG_MENU_USERS' => 'Users',
        'LNG_MENU_STARTUP_DIALOG' => 'Announcements',
        'LNG_MENU_CRON_JOBS' => 'Cron Jobs',
        'LNG_MENU_USERLEVEL' => 'User Levels',
        'LNG_MENU_SITEMAP' => 'Sitemap',
        'LNG_MENU_MODULE_ACTIONS' => 'Module Actions',
        'LNG_MENU_USERLEVEL_PERMISSION' => 'User Level Permissions',
        'LNG_MENU_EDIT_USER' => 'User Edit',
      ),
    ),
    'META' => 
    array (
      'vars' => 
      array (
        'LNG_AUTHOR' => 'Agile Business Modules (ABM)',
        'LNG_DESCRIPTION' => 'Health Information Technology and Statistics Training Center',
        'LNG_KEYWORD' => '',
        'LNG_PROJECT_CREATION_DATE' => '2015-10-01',
      ),
    ),
    'ERROR_CODE' => 
    array (
      'vars' => 
      array (
        'ERR_1173' => 'Username is blank.',
        'ERR_1174' => 'Username is shorter than min length.',
        'ERR_1175' => 'Username does not comply with naming rules.',
        'ERR_1176' => 'Password cannot be less than 6 characters.',
        'ERR_1177' => 'No user levels defined.',
        'ERR_1178' => 'Could not create user account.',
        'ERR_1179' => 'Could not assign specified user levels to user.',
        'ERR_1180' => 'Unknown error.',
        'ERR_1181' => 'Specified username is unavailable.',
        'ERR_1182' => 'No employee defined.',
        'ERR_1183' => 'No sales team defined.',
        'ERR_1184' => 'Password mismatch.',
        'ERR_1195' => 'User Level name is blank.',
        'ERR_1196' => 'User Level name is shorter than min length.',
        'ERR_1197' => 'User Level name does not comply with naming rules.',
        'ERR_1198' => 'Specified user level name is unavailable.',
      ),
    ),
    'MODULE_ACTION_ADD_TPL' => 
    array (
      'vars' => 
      array (
        'LNG_2067' => 'Add Module Action',
        'LNG_2068' => 'Select',
        'LNG_2069' => 'Save',
        'LNG_2070' => 'Cancel',
        'LNG_2071' => 'Controller Type',
        'LNG_2072' => 'Controller Class',
        'LNG_2073' => 'Field is required',
        'LNG_2074' => 'Module',
        'LNG_2075' => 'Action',
      ),
    ),
    'MODULE_ACTION_VIEW_TPL' => 
    array (
      'vars' => 
      array (
        'LNG_2060' => 'Permissions',
        'LNG_2061' => 'User Levels',
        'LNG_2062' => 'Module',
        'LNG_2063' => 'Action',
        'LNG_2064' => 'Module Action Permissions',
        'LNG_2065' => 'Permissions',
        'LNG_2066' => 'Close',
      ),
    ),
    'PAGE_CITY_LIST' => 
    array (
      'vars' => 
      array (
        'LNG_2963' => 'City Management',
        'LNG_2964' => 'City',
        'LNG_2965' => 'Management',
        'LNG_2966' => 'Home',
        'LNG_2967' => 'Default',
        'LNG_2968' => 'Add',
        'LNG_2969' => 'View Districts',
        'LNG_2970' => 'Delete City',
        'LNG_2971' => 'District',
        'LNG_2972' => 'Add',
        'LNG_2973' => 'Delete',
        'LNG_2974' => 'No districts found',
        'LNG_2975' => 'City Listing',
      ),
    ),
    'PAGE_CONFIG_LIST' => 
    array (
      'vars' => 
      array (
        'LNG_2058' => 'Reload Configurations',
        'LNG_2059' => 'Reload Language',
        'LNG_2061' => 'Configurations',
        'LNG_2062' => 'Listing',
        'LNG_2063' => 'Home',
        'LNG_2064' => 'Default',
        'LNG_2065' => 'Configurations',
        'LNG_2066' => 'Modules',
        'LNG_2067' => 'Title',
        'LNG_2068' => 'Value',
        'LNG_2069' => 'Click on section to load its configurations',
        'LNG_2070' => 'No configurations found',
        'LNG_2071' => 'N/A',
      ),
    ),
    'PAGE_INDEX_ERROR' => 
    array (
      'vars' => 
      array (
        'LNG_2662' => 'Click here to return to your home page',
      ),
    ),
    'PAGE_INDEX_LOGIN' => 
    array (
      'vars' => 
      array (
        'LNG_3079' => 'Welcome to HITSTC',
        'LNG_3080' => 'Error',
        'LNG_3081' => 'Success',
        'LNG_3082' => 'Username',
        'LNG_3083' => 'Username is required',
        'LNG_3084' => 'Password',
        'LNG_3085' => 'Account password',
        'LNG_3086' => 'Login',
        'LNG_3087' => 'Forgot your password?',
        'LNG_3088' => 'Click',
        'LNG_3089' => 'here',
        'LNG_3090' => 'to reset your password',
        'LNG_3091' => 'Forgot Password?',
        'LNG_3092' => 'Error',
        'LNG_3093' => 'Enter your user name to reset your password',
        'LNG_3095' => 'Back',
        'LNG_3096' => 'Submit',
        'LNG_5655' => 'Login',
      ),
    ),
    'PAGE_INDEX_RESETPASSWORD' => 
    array (
      'vars' => 
      array (
        'LNG_5750' => 'Welcome to HITSTC',
        'LNG_5751' => 'Error',
        'LNG_5752' => 'Success',
        'LNG_5753' => 'Username',
        'LNG_5754' => 'Username is required',
        'LNG_5755' => 'Password',
        'LNG_5756' => 'Your account password',
        'LNG_5757' => 'Enter your user name and new password to complete password reset process.',
        'LNG_5758' => 'Cancel',
        'LNG_5759' => 'Update',
        'LNG_5786' => 'Confirm Password',
        'LNG_5787' => 'Passwords don\'t match.',
      ),
    ),
    'PAGE_LOCATION_LIST' => 
    array (
      'vars' => 
      array (
        'LNG_2976' => 'Location Management',
        'LNG_2977' => 'New Location',
        'LNG_2978' => 'Name',
        'LNG_2979' => 'Phone',
        'LNG_2980' => 'City',
        'LNG_2981' => 'Please Select City',
        'LNG_2982' => 'District',
        'LNG_2983' => 'Please Select District',
        'LNG_2984' => 'Longitude',
        'LNG_2985' => 'Latitude',
        'LNG_2986' => 'Address',
        'LNG_2987' => 'Phone',
        'LNG_2988' => 'Notes',
        'LNG_2989' => 'Add Notes',
        'LNG_2990' => 'Save',
        'LNG_2991' => 'Cancel',
        'LNG_2992' => 'Location',
        'LNG_2993' => 'New Location',
        'LNG_2994' => 'Home',
        'LNG_2995' => 'Default',
        'LNG_2996' => 'Location Management',
        'LNG_2997' => 'Locations',
        'LNG_2998' => 'Location Name',
        'LNG_2999' => 'District',
        'LNG_3000' => 'Address',
        'LNG_3001' => 'Long.',
        'LNG_3002' => 'Lat.',
        'LNG_3003' => 'Phone',
        'LNG_3005' => 'Notes',
        'LNG_3006' => 'Management',
      ),
    ),
    'PAGE_LOOKUP_LIST' => 
    array (
      'vars' => 
      array (
        'LNG_6720' => 'Lookups',
        'LNG_6721' => 'Listing',
        'LNG_6722' => 'Add',
        'LNG_6723' => 'Lookup',
        'LNG_6724' => 'Payment Methods',
        'LNG_6725' => 'Payment Terms',
        'LNG_6726' => 'Services',
        'LNG_6727' => 'Method ID',
        'LNG_6728' => 'Method Name',
        'LNG_6729' => 'Manual',
      ),
    ),
    'PAGE_MODULE_LISTACTIONS' => 
    array (
      'vars' => 
      array (
        'LNG_6562' => 'Module Actions',
        'LNG_6563' => 'Management',
        'LNG_6564' => 'Modules',
        'LNG_6565' => 'List module actions',
        'LNG_6566' => 'Module Action',
        'LNG_6568' => 'Add module action',
        'LNG_6678' => 'View Permissions',
        'LNG_6679' => 'Delete Action',
      ),
    ),
    'PAGE_NOTIFICATION_VIEWNOTIFICATION' => 
    array (
      'vars' => 
      array (
        'LNG_3007' => 'Notifications',
        'LNG_3008' => 'Home',
        'LNG_3009' => 'No notifications found',
        'LNG_3010' => 'Delete',
        'LNG_3011' => 'Mark UnRead',
        'LNG_3012' => 'UnRead',
        'LNG_3013' => 'Mark Read',
        'LNG_3014' => 'Read',
        'LNG_5675' => 'Read',
        'LNG_5676' => 'Un Read',
        'LNG_5677' => 'All',
      ),
    ),
    'PAGE_SITEMAP_LIST' => 
    array (
      'vars' => 
      array (
        'LNG_6543' => 'Sitemap Items',
        'LNG_6544' => 'Filter',
        'LNG_6545' => 'Reset',
        'LNG_6546' => 'Sitemap',
        'LNG_6547' => 'Group',
        'LNG_6548' => 'Order',
        'LNG_6549' => 'Page',
        'LNG_6550' => 'Title',
        'LNG_6551' => 'Menu',
        'LNG_6552' => 'Level',
        'LNG_6553' => 'Module',
        'LNG_6554' => 'Select',
        'LNG_6555' => 'Style',
        'LNG_6556' => 'Show in Menu',
        'LNG_6557' => 'Save',
        'LNG_6558' => 'Cancel',
        'LNG_6559' => 'Management',
        'LNG_6560' => 'Add sitemap item',
        'LNG_6561' => 'Edit sitemap item',
      ),
    ),
    'PAGE_USERLEVELPERMISSION_LIST' => 
    array (
      'vars' => 
      array (
        'LNG_6631' => 'User Levels Permissions',
        'LNG_6632' => 'Management',
        'LNG_6635' => 'Permissions',
        'LNG_6636' => 'Permission',
        'LNG_6637' => 'Filter',
      ),
    ),
    'PAGE_USERLEVEL_LIST' => 
    array (
      'vars' => 
      array (
        'LNG_6535' => 'User Levels',
        'LNG_6536' => 'Management',
        'LNG_6537' => 'User Level',
        'LNG_6538' => 'Add User Level',
        'LNG_6539' => 'User Levels',
        'LNG_6541' => 'Filter',
      ),
    ),
    'PAGE_USER_LIST' => 
    array (
      'vars' => 
      array (
        'LNG_2931' => 'User Details',
        'LNG_2932' => 'User Name:',
        'LNG_2933' => 'Display Name:',
        'LNG_2934' => 'Email:',
        'LNG_2938' => 'Employee:',
        'LNG_2939' => 'Team:',
        'LNG_2940' => 'Close',
        'LNG_2941' => 'User',
        'LNG_2942' => 'Management',
        'LNG_2943' => 'User',
        'LNG_2944' => 'Home',
        'LNG_2945' => 'Default',
        'LNG_2946' => 'Users Listing',
        'LNG_2947' => 'Filter',
        'LNG_2948' => 'Username',
        'LNG_2949' => 'Display Name',
        'LNG_2950' => 'Email',
        'LNG_2951' => 'Select Location',
        'LNG_2952' => 'Select User Level',
        'LNG_2953' => 'Filter',
        'LNG_2954' => 'Reset',
        'LNG_2955' => 'Users',
        'LNG_2956' => 'Username',
        'LNG_2957' => 'Display Name',
        'LNG_2958' => 'Email',
        'LNG_2959' => 'Location',
        'LNG_2960' => 'View Details',
        'LNG_2961' => 'Edit',
        'LNG_2962' => 'There are no users',
        'LNG_6630' => 'Add User',
      ),
    ),
    'PAGE_USER_NEW' => 
    array (
      'vars' => 
      array (
        'LNG_6598' => 'User',
        'LNG_6599' => 'New',
        'LNG_6600' => 'New User Info',
        'LNG_6601' => 'User Levels',
        'LNG_6602' => '- Username must be between 2 and 20 characters
- It can only include: english letters, numbers, \'.\' and \'_\'
- It must start with an english letter
- It must end with an an english letter or a number
- Successive \'.\' or \'_\' or both is not allowed',
        'LNG_6603' => 'Username',
        'LNG_6604' => 'Display Name',
        'LNG_6605' => 'Field is required',
        'LNG_6606' => 'Password',
        'LNG_6607' => 'Confirm Password',
        'LNG_6608' => 'Password mismatch',
        'LNG_6609' => 'Email',
        'LNG_6610' => 'Invalid field value',
        'LNG_6611' => 'Add',
        'LNG_6612' => 'Add & Continue',
        'LNG_6618' => 'Send Welcome Email to User',
        'LNG_6619' => 'Employee',
        'LNG_6620' => 'Team',
        'LNG_6621' => 'Select',
        'LNG_6622' => 'User Details',
        'LNG_6626' => 'XXXX No user levels defined',
        'LNG_6627' => 'Error',
        'LNG_6628' => 'XXXX You must select an employee',
        'LNG_6629' => 'XXXX You must select sales team',
      ),
    ),
    'SERVICE_INDEX_CREATEPASSWORDRESETRECORD' => 
    array (
      'vars' => 
      array (
        'LNG_5788' => 'Error',
        'LNG_5789' => 'Success',
        'LNG_5790' => 'Provided email is of an inactive user account. Contact Support Team.',
        'LNG_5791' => 'Check your inbox to confirm resetting password.',
        'LNG_5792' => 'Cannot reset password. Contact your Support Team.',
        'LNG_5793' => 'Provided user name is not found in the system.',
      ),
    ),
    'SERVICE_INDEX_RESETPASSWORD' => 
    array (
      'vars' => 
      array (
        'LNG_5794' => 'Error',
        'LNG_5795' => 'User not found.',
        'LNG_5796' => 'Process cannot be completed: Wrong user name or password.',
        'LNG_5797' => 'Cannot change password.',
        'LNG_5798' => 'Success',
        'LNG_5799' => 'Password changed successfully.',
      ),
    ),
    'SERVICE_LANG_RELOAD' => 
    array (
      'vars' => 
      array (
        'LNG_6592' => 'Success',
        'LNG_6593' => 'Language files have been successfully reloaded',
      ),
    ),
    'SERVICE_MODULE_ADDMODULEACTION' => 
    array (
      'vars' => 
      array (
        'LNG_6594' => 'Success',
        'LNG_6595' => 'Error',
        'LNG_6596' => 'Action successfully added to module',
        'LNG_6597' => 'Could not add action to module',
      ),
    ),
    'SERVICE_MODULE_DELETEMODULEACTION' => 
    array (
      'vars' => 
      array (
        'LNG_6587' => 'Error',
        'LNG_6588' => 'Could not load specified module.',
        'LNG_6589' => 'Success',
        'LNG_6590' => 'Module action successfully deleted',
        'LNG_6591' => 'Could not delete module action.',
      ),
    ),
    'SERVICE_MODULE_LIST' => 
    array (
      'vars' => 
      array (
        'LNG_6585' => 'Modules successfully listed',
        'LNG_6586' => 'Success',
      ),
    ),
    'SERVICE_MODULE_LISTMODULEACTIONS' => 
    array (
      'vars' => 
      array (
        'LNG_6580' => 'Error',
        'LNG_6581' => 'Success',
        'LNG_6582' => 'Could not load specified module.',
        'LNG_6583' => 'Could not load module actions',
        'LNG_6584' => 'Module actions successfully loaded',
      ),
    ),
    'SERVICE_NOTIFICATION_UPDATE' => 
    array (
      'vars' => 
      array (
        'LNG_5669' => 'Success',
        'LNG_5670' => 'Error',
        'LNG_5671' => 'Notification status updated successfully.',
        'LNG_5672' => 'Cannot update notification status.',
        'LNG_5673' => 'Notification not found.',
      ),
    ),
    'SERVICE_USERLEVELPERMISSION_ADDPERMISSION' => 
    array (
      'vars' => 
      array (
        'LNG_6667' => 'Success',
        'LNG_6668' => 'Permission successfully added',
        'LNG_6669' => 'Error',
        'LNG_6670' => 'Could not add permission',
        'LNG_6672' => 'Permission details are not specified',
        'LNG_6673' => 'Missing permission details',
      ),
    ),
    'SERVICE_USERLEVELPERMISSION_LISTPERMISSIONS' => 
    array (
      'vars' => 
      array (
        'LNG_6660' => 'Success',
        'LNG_6664' => 'Permissions successfully listed',
        'LNG_6674' => 'Error',
        'LNG_6675' => 'Filter details are not specified',
        'LNG_6676' => 'Could not list permissions',
      ),
    ),
    'SERVICE_USERLEVELPERMISSION_LISTPERMISSIONSNOTINUSERLEVEL' => 
    array (
      'vars' => 
      array (
        'LNG_6661' => 'Error',
        'LNG_6662' => 'Success',
        'LNG_6665' => 'User level is not specified',
        'LNG_6666' => 'Permissions successfully listed',
        'LNG_6677' => 'Could not list permissions',
      ),
    ),
    'SERVICE_USERLEVEL_LIST' => 
    array (
      'vars' => 
      array (
        'LNG_6659' => 'Success',
        'LNG_6663' => 'User levels successfully listed',
      ),
    ),
    'SERVICE_USER_ADD' => 
    array (
      'vars' => 
      array (
        'LNG_6613' => 'User information is missing',
        'LNG_6614' => 'Username is not defined',
        'LNG_6616' => 'Error',
        'LNG_6617' => 'Success',
        'LNG_6623' => 'User is added successfully',
      ),
    ),
    'SERVICE_USER_VALIDATEUSERNAME' => 
    array (
      'vars' => 
      array (
        'LNG_6615' => 'Username is not modified',
        'LNG_6624' => 'Username is valid',
        'LNG_6625' => 'Username is not defined',
      ),
    ),
    'USER_LEVEL_PERMISSION_ADD' => 
    array (
      'vars' => 
      array (
        'LNG_2042' => 'User Level',
        'LNG_2043' => 'Select',
        'LNG_2044' => 'Permissions',
        'LNG_2045' => 'New Permission',
        'LNG_2046' => 'Add Permission',
        'LNG_2047' => 'Module',
        'LNG_2048' => 'Action',
        'LNG_2049' => 'Selected user level already has all permissions on the selected module.',
        'LNG_2050' => 'Save',
        'LNG_2051' => 'Cancel',
        'LNG_2052' => 'User level permissions',
      ),
    ),
    'USER_LEVEL_PERMISSION_EDIT' => 
    array (
      'vars' => 
      array (
        'LNG_2053' => 'Edit Permission',
        'LNG_2054' => 'Module',
        'LNG_2055' => 'Action',
        'LNG_2056' => 'Permissions',
        'LNG_2057' => 'Save',
        'LNG_2058' => 'Cancel',
        'LNG_2059' => 'User Level',
      ),
    ),
  ),
  'vars' => 
  array (
    'MONTH_JAN' => 'Jan',
    'MONTH_FEB' => 'Feb',
    'MONTH_MAR' => 'Mar',
    'MONTH_APR' => 'Apr',
    'MONTH_MAY' => 'May',
    'MONTH_JUN' => 'Jun',
    'MONTH_JUL' => 'Jul',
    'MONTH_AUG' => 'Aug',
    'MONTH_SEP' => 'Sep',
    'MONTH_OCT' => 'Oct',
    'MONTH_NOV' => 'Nov',
    'MONTH_DEC' => 'Dec',
    'HELP' => 'Help',
    'KNOWLEDGE_BASE' => 'User Guide',
    'YOUTUBE_CHANNEL' => 'Video',
    'NEW_NOTIFICATIONS' => 'New Notification',
    'VIEW_ALL' => 'View All',
    'NOTIFICATION' => 'Notification',
    'CLOSE' => 'Close',
    'LOADING' => 'Loading',
    'MY_ACCOUNT' => 'My Account',
    'LOG_OUT' => 'Log out',
    'ANNOUNCE' => 'Announcement',
    'CANCEL' => 'Cancel',
    'APP_NAME' => 'modulus business suite',
  ),
));
}
}
