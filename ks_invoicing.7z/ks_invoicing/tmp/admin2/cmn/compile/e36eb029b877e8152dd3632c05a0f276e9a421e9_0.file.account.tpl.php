<?php
/* Smarty version 3.1.31, created on 2019-10-24 09:23:45
  from "D:\www\ks_invoicing\modules\cmn\view\templates\pages\account.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5db15181a04033_72064894',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'e36eb029b877e8152dd3632c05a0f276e9a421e9' => 
    array (
      0 => 'D:\\www\\ks_invoicing\\modules\\cmn\\view\\templates\\pages\\account.tpl',
      1 => 1570523806,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5db15181a04033_72064894 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_207425db151819f4174_25045317', 'app');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_9675db151819f5af1_57127236', 'controller');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_281485db151819f6993_63679307', 'lang');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_228135db151819f79b9_33564389', 'style');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_306105db151819f8839_61530564', 'script');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_54755db151819fe9c9_22607943', 'dialog');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_300485db151819ff907_63822097', 'page_title');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_271615db15181a00702_33573808', 'toolbar');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_314545db15181a01504_78323029', 'content');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, ((string)@constant('LOCAL__THEME'))."/template/masters/master1/master.tpl");
}
/* {block 'app'} */
class Block_207425db151819f4174_25045317 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'app' => 
  array (
    0 => 'Block_207425db151819f4174_25045317',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

data-ng-app="CMN"
<?php
}
}
/* {/block 'app'} */
/* {block 'controller'} */
class Block_9675db151819f5af1_57127236 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'controller' => 
  array (
    0 => 'Block_9675db151819f5af1_57127236',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

data-ng-controller="User" 
<?php
}
}
/* {/block 'controller'} */
/* {block 'lang'} */
class Block_281485db151819f6993_63679307 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'lang' => 
  array (
    0 => 'Block_281485db151819f6993_63679307',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
}
}
/* {/block 'lang'} */
/* {block 'style'} */
class Block_228135db151819f79b9_33564389 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'style' => 
  array (
    0 => 'Block_228135db151819f79b9_33564389',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
}
}
/* {/block 'style'} */
/* {block 'script'} */
class Block_306105db151819f8839_61530564 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'script' => 
  array (
    0 => 'Block_306105db151819f8839_61530564',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('PATH__JS');?>
/common.angular.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('PATH__JS');?>
/user.account.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
<?php
}
}
/* {/block 'script'} */
/* {block 'dialog'} */
class Block_54755db151819fe9c9_22607943 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'dialog' => 
  array (
    0 => 'Block_54755db151819fe9c9_22607943',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<div id="dlgChangePassword" class="modal fade modal-scroll modal-dialog" tabindex="-1" style="display: none;width:auto;height:auto!important">
    <div class="modal-header">
        <button type="button" data-ng-click="closeChangePasswordDialog()" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        <h3 class="modal-title">Change Password</h3>
    </div>
    <div class="modal-body">
        <form name="frmChangePassword">
            <div class="row">
                <div class="col-md-10">
                    <div class="form-group">
                        <label class="control-label">Old Password</label>
                        <input class="form-control" type="password" data-ng-model="objChangePassword.strOldPassword" placeholder="Old Password" required="required"/>
                    </div>
                    <div class="form-group">
                        <label class="control-label">Password</label>
                        <input class="form-control" type="password" data-ng-model="objChangePassword.strNewPassword" placeholder="New Password" required="required"/>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-10">
                    <div class="form-group">
                        <label class="control-label">Confirm Password</label>
                        <input class="form-control" type="password" data-ng-model="objChangePassword.strConfirmPassword" placeholder="Confirm Password" required="required"/>
                        <p ng-show="objChangePassword.strNewPassword != objChangePassword.strConfirmPassword" class="help-block" style="color: rgb(206, 135, 135);font-size: 12px;">Passwords don't match.</p>
                    </div>
                </div>
            </div>
        </form>
    </div>
    <div class="modal-footer">
        <button type="button" class="btn green-jungle" data-ng-disabled="frmChangePassword.$invalid || (objChangePassword.strNewPassword != objChangePassword.strConfirmPassword)" data-ng-click="changePassword()">Save</button>
        <button type="button" data-dismiss="modal" class="btn red-thunderbird" data-ng-click="closeChangePasswordDialog()">Cancel</button>
    </div>
</div>
<?php
}
}
/* {/block 'dialog'} */
/* {block 'page_title'} */
class Block_300485db151819ff907_63822097 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'page_title' => 
  array (
    0 => 'Block_300485db151819ff907_63822097',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<h1>Account</h1>
<?php
}
}
/* {/block 'page_title'} */
/* {block 'toolbar'} */
class Block_271615db15181a00702_33573808 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'toolbar' => 
  array (
    0 => 'Block_271615db15181a00702_33573808',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <div class="btn-group pull-right">
        <a data-toggle="modal" href="#dlgChangePassword" class="btn btn-fit-height blue-dark" title="Change Password">
            <i class="fa fa-pencil-square-o"></i>
            <span class="visible-lg-inline-block">Change Password</span>
        </a>
    </div>
<?php
}
}
/* {/block 'toolbar'} */
/* {block 'content'} */
class Block_314545db15181a01504_78323029 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_314545db15181a01504_78323029',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<div class="row">
    <div class="col-md-7">
        <div class="portlet light">
            <div class="portlet-title">
                <div class="caption font-blue-chambray">Account Edit</div>
            </div>
            <div class="portlet-body">
                <div class="row">
                    <div class="col-md-5">
                        <img width="300" data-ng-if="objUser.intPhotoID == -1" src="<?php echo @constant('PATH__IMAGE');?>
/user.png" class="img-responsive">
                        <img width="300" data-ng-if="objUser.intPhotoID != -1" data-ng-src="index.php?module=cmn&page=Index&action=Download&file_id={{objUser.intPhotoID}}" class="img-responsive">
                        <input type="file" name="fileImage" data-file="objUser.objFile" class="form-control" accept="image/*"/>        
                    </div>
                    <div class="col-md-7">
                        <form name="frmAccount">
                            <div class="form-group">
                                <label class="control-label">Username</label>
                                <input type="text" data-ng-model="objUser.strUserName" name="txtUsername" placeholder="Username name" disabled="disabled" class="form-control" required="required"/>
                            </div>
                            <div class="form-group">
                                <label class="control-label">Display name</label>
                                <input type="text" data-ng-model="objUser.strDisplayName" name="txtDisplayName" placeholder="Display name" class="form-control" required="required"/>
                            </div>
                            <div class="form-group">
                                <label class="control-label">Email</label>
                                <input type="email" data-ng-model="objUser.strEmail" name="txtEmail" placeholder="Email" class="form-control" required="required"/>
                            </div>
                            <div class="form-group pull-right">
                                <button type="button" class="btn btn-success" data-ng-click="update()" ng-disabled="frmAccount.$invalid">Save</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-5">
        <div class="portlet light">
            <div class="portlet-title">
                <div class="caption font-blue-chambray">Userlevels</div>
            </div>
            <div class="portlet-body">
                <div data-ng-repeat="objModule in objUser.arrModules">
                    <h4>{{objModule.strTitle}}</h4>
                    <span data-ng-repeat="objUserLevel in objUser.arrModuleUserLevels[objModule.intID]">
                        <span class="label bg-blue-chambray">{{objUserLevel.strUserLevel}}</span>&nbsp;
                    </span>        
                </div>                        
            </div>
        </div>
    </div>
</div>
<?php
}
}
/* {/block 'content'} */
}
