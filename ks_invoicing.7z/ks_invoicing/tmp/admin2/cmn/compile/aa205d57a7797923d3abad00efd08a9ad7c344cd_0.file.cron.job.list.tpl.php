<?php
/* Smarty version 3.1.31, created on 2019-10-16 13:53:46
  from "D:\www\ks_invoicing\modules\cmn\view\templates\pages\cron.job.list.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5da704ca04e422_38402746',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'aa205d57a7797923d3abad00efd08a9ad7c344cd' => 
    array (
      0 => 'D:\\www\\ks_invoicing\\modules\\cmn\\view\\templates\\pages\\cron.job.list.tpl',
      1 => 1570547423,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5da704ca04e422_38402746 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_223605da704ca039e87_68809667', 'app');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_124655da704ca03b299_93571094', 'controller');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_229345da704ca03c0e4_91343462', 'style');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_23275da704ca03cf98_16592086', 'script');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_43565da704ca044293_53397789', 'dialog');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_99655da704ca048a34_67493534', 'page_title');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_310105da704ca049836_66296263', 'toolbar');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_81155da704ca04aac7_11787212', 'content');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, ((string)@constant('LOCAL__THEME'))."/template/masters/master1/master.tpl");
}
/* {block 'app'} */
class Block_223605da704ca039e87_68809667 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'app' => 
  array (
    0 => 'Block_223605da704ca039e87_68809667',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    data-ng-app="CMN"
<?php
}
}
/* {/block 'app'} */
/* {block 'controller'} */
class Block_124655da704ca03b299_93571094 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'controller' => 
  array (
    0 => 'Block_124655da704ca03b299_93571094',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

     data-ng-controller="CronJob" 
<?php
}
}
/* {/block 'controller'} */
/* {block 'style'} */
class Block_229345da704ca03c0e4_91343462 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'style' => 
  array (
    0 => 'Block_229345da704ca03c0e4_91343462',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
}
}
/* {/block 'style'} */
/* {block 'script'} */
class Block_23275da704ca03cf98_16592086 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'script' => 
  array (
    0 => 'Block_23275da704ca03cf98_16592086',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('PATH__JS');?>
/enum.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>   
<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('PATH__JS');?>
/common.angular.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>   
<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('PATH__JS');?>
/cron.job.list.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>   
<?php
}
}
/* {/block 'script'} */
/* {block 'dialog'} */
class Block_43565da704ca044293_53397789 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'dialog' => 
  array (
    0 => 'Block_43565da704ca044293_53397789',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <div id="dlgAddCronJob" class="modal fade modal-dialog" tabindex="-1" data-width="500" style="display: none;">
        <div class="modal-header">
            <button type="button" class="close" data-ng-click="resetAdd()" data-dismiss="modal" aria-hidden="true">×</button>
            <h3 class="modal-title">Add New Cron Job</h3>
        </div>
        <div class="modal-body">  
            <form name="frmAddCronJob">
                <div class="row">
                    <div class="col-md-12">
                        <label>Cron</label>
                        <input type="text" name="txtAddCronJobName" class="form-control" required="required" data-ng-model="objAddCronJob.strCron"/>
                    </div>
                </div>
                <div class="row margin-top-10">
                    <div class="col-md-12">
                        <label>Module</label>
                        <select name="cmbAddCronJobModule" class="form-control" required="required" data-ng-model="objAddCronJob.intModuleID" data-ng-options="objModule.intID as objModule.strTitle for objModule in arrModules">
                            <option value="">Select Module</option>
                        </select>                        
                    </div>
                </div>
                <div class="row margin-top-10"> 
                    <div class="col-md-12">
                        <label>Run Time</label>
                    </div>
                    <div class="col-md-12">
                        <div class="row">
                            <div class="col-md-3">
                                <input type="text" name="txtAddCronJobYear"  class="form-control" placeholder="Year"  data-ng-model="objAddCronJob.intYear"  datetimepicker data-date-format="yyyy" data-min-view="4" data-start-view="4"/>
                            </div>
                            <div class="col-md-3">
                                <select name="cmbAddCronJobMonth" class="form-control" data-ng-model="objAddCronJob.intMonth">
                                    <option value="">Month</option>
                                    <option value=1>Jan</option>
                                    <option value=2>Feb</option>
                                    <option value=3>Mar</option>
                                    <option value=4>Apr</option>
                                    <option value=5>May</option>
                                    <option value=6>Jun</option>
                                    <option value=7>Jul</option>
                                    <option value=8>Aug</option>
                                    <option value=9>Sep</option>
                                    <option value=10>Oct</option>
                                    <option value=11>Nov</option>
                                    <option value=12>Dec</option>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <select name="cmbAddCronJobDay" class="form-control" data-ng-model="objAddCronJob.intDay">
                                    <option value="">Day</option>
                                    <option value=1>1</option>
                                    <option value=2>2</option>
                                    <option value=3>3</option>
                                    <option value=4>4</option>
                                    <option value=5>5</option>
                                    <option value=6>6</option>
                                    <option value=7>7</option>
                                    <option value=8>8</option>
                                    <option value=9>9</option>
                                    <option value=10>10</option>
                                    <option value=11>11</option>
                                    <option value=12>12</option>
                                    <option value=13>13</option>
                                    <option value=14>14</option>
                                    <option value=15>15</option>
                                    <option value=16>16</option>
                                    <option value=17>17</option>
                                    <option value=18>18</option>
                                    <option value=19>19</option>
                                    <option value=20>20</option>
                                    <option value=21>21</option>
                                    <option value=22>22</option>
                                    <option value=23>23</option>
                                    <option value=24>24</option>
                                    <option value=25>25</option>
                                    <option value=26>26</option>
                                    <option value=27>27</option>
                                    <option value=28>28</option>
                                    <option value=29>29</option>
                                    <option value=30>30</option>
                                    <option value=31>31</option>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <select name="cmbAddCronJobHour" class="form-control" data-ng-model="objAddCronJob.intHour">
                                    <option value="">Hour</option>
                                    <option value=0>0</option>
                                    <option value=1>1</option>
                                    <option value=2>2</option>
                                    <option value=3>3</option>
                                    <option value=4>4</option>
                                    <option value=5>5</option>
                                    <option value=6>6</option>
                                    <option value=7>7</option>
                                    <option value=8>8</option>
                                    <option value=9>9</option>
                                    <option value=10>10</option>
                                    <option value=11>11</option>
                                    <option value=12>12</option>
                                    <option value=13>13</option>
                                    <option value=14>14</option>
                                    <option value=15>15</option>
                                    <option value=16>16</option>
                                    <option value=17>17</option>
                                    <option value=18>18</option>
                                    <option value=19>19</option>
                                    <option value=20>20</option>
                                    <option value=21>21</option>
                                    <option value=22>22</option>
                                    <option value=23>23</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row margin-top-10">
                    <div class="col-md-12">
                        <label>Description</label>
                        <textarea name="txtAddCronJobDescription" data-ng-model="objAddCronJob.strDescription" placeholder="Description" class="form-control"></textarea>
                    </div>
                </div>
            </form>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn blue" data-ng-disabled="frmAddCronJob.$invalid" data-ng-click="add()">Save</button>
            <button type="button" data-dismiss="modal" class="btn btn-danger" data-ng-click="resetAdd()">Cancel</button>
        </div>
    </div>
    <div id="dlgEditCronJob" class="modal fade modal-dialog" tabindex="-1" data-width="500" style="display: none;">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            <h3 class="modal-title">Edit {{objOriginalCronJob.strCron}}</h3>
        </div>
        <div class="modal-body">  
            <form name="frmEditCronJob">
                <div class="row">
                    <div class="col-md-12">
                        <label>Cron</label>
                        <input type="text" name="txtEditCronJobName" class="form-control" required="required" data-ng-model="objEditCronJob.strCron"/>
                    </div>
                </div>
                <div class="row margin-top-10">
                    <div class="col-md-12">
                        <label>Module</label>
                        <select name="cmbEditCronJobModule" class="form-control" required="required" data-ng-model="objEditCronJob.intModuleID" data-ng-options="objModule.intID as objModule.strTitle for objModule in arrModules">
                            <option value="">Select Module</option>
                        </select>                        
                    </div>
                </div>
                <div class="row margin-top-10">
                    <div class="col-md-12">
                        <label>Run Time</label>
                    </div>
                    <div class="col-md-12">
                        <div class="row">
                            <div class="col-md-3">
                                <input type="text" name="txtEditCronJobYear" class="form-control" placeholder="Year" data-ng-model="objEditCronJob.intYear"  datetimepicker data-date-format="yyyy" data-min-view="4" data-start-view="4"/>
                            </div>
                            <div class="col-md-3">
                                <select name="cmbEditCronJobMonth" class="form-control" data-ng-model="objEditCronJob.intMonth">
                                    <option value="">Month</option>
                                    <option value=1>Jan</option>
                                    <option value=2>Feb</option>
                                    <option value=3>Mar</option>
                                    <option value=4>Apr</option>
                                    <option value=5>May</option>
                                    <option value=6>Jun</option>
                                    <option value=7>Jul</option>
                                    <option value=8>Aug</option>
                                    <option value=9>Sep</option>
                                    <option value=10>Oct</option>
                                    <option value=11>Nov</option>
                                    <option value=12>Dec</option>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <select name="cmbEditCronJobDay" class="form-control" data-ng-model="objEditCronJob.intDay">
                                    <option value="">Day</option>
                                    <option value=1>1</option>
                                    <option value=2>2</option>
                                    <option value=3>3</option>
                                    <option value=4>4</option>
                                    <option value=5>5</option>
                                    <option value=6>6</option>
                                    <option value=7>7</option>
                                    <option value=8>8</option>
                                    <option value=9>9</option>
                                    <option value=10>10</option>
                                    <option value=11>11</option>
                                    <option value=12>12</option>
                                    <option value=13>13</option>
                                    <option value=14>14</option>
                                    <option value=15>15</option>
                                    <option value=16>16</option>
                                    <option value=17>17</option>
                                    <option value=18>18</option>
                                    <option value=19>19</option>
                                    <option value=20>20</option>
                                    <option value=21>21</option>
                                    <option value=22>22</option>
                                    <option value=23>23</option>
                                    <option value=24>24</option>
                                    <option value=25>25</option>
                                    <option value=26>26</option>
                                    <option value=27>27</option>
                                    <option value=28>28</option>
                                    <option value=29>29</option>
                                    <option value=30>30</option>
                                    <option value=31>31</option>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <select name="cmbEditCronJobHour" class="form-control" data-ng-model="objEditCronJob.intHour">
                                    <option value="">Hour</option>
                                    <option value=0>0</option>
                                    <option value=1>1</option>
                                    <option value=2>2</option>
                                    <option value=3>3</option>
                                    <option value=4>4</option>
                                    <option value=5>5</option>
                                    <option value=6>6</option>
                                    <option value=7>7</option>
                                    <option value=8>8</option>
                                    <option value=9>9</option>
                                    <option value=10>10</option>
                                    <option value=11>11</option>
                                    <option value=12>12</option>
                                    <option value=13>13</option>
                                    <option value=14>14</option>
                                    <option value=15>15</option>
                                    <option value=16>16</option>
                                    <option value=17>17</option>
                                    <option value=18>18</option>
                                    <option value=19>19</option>
                                    <option value=20>20</option>
                                    <option value=21>21</option>
                                    <option value=22>22</option>
                                    <option value=23>23</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row margin-top-10">
                    <div class="col-md-12">
                        <label>Description</label>
                        <textarea name="txtEditCronJobDescription" data-ng-model="objEditCronJob.strDescription" placeholder="Description" class="form-control"></textarea>
                    </div>
                </div>
            </form>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn blue" data-ng-disabled="frmEditCronJob.$invalid || (objEditCronJob.intYear != '' && objEditCronJob.intYear <= 0)" data-ng-click="update()">Save</button>
            <button type="button" data-dismiss="modal" class="btn btn-danger">Cancel</button>
        </div>
    </div>
    <div id="dlgRunCronJob" class="modal fade modal-dialog" tabindex="-1" data-width="500" style="display: none;">
        <div class="modal-header">
            <button type="button" class="close" data-ng-click="cancelRun()" data-dismiss="modal" aria-hidden="true">×</button>
            <h3 class="modal-title">Run</h3>
        </div>
        <div class="modal-body">  
            <form name="frmAddParams">
                <p data-ng-if="objRunningCron.objDetails.param.length==0">This cron doesn't take any parameters, just hit the run button.</p>
                <div class="form-group" data-ng-if="objRunningCron.objDetails.param.length>0">
                    <input type="checkbox" data-ng-model="boolIgnoreParam" data-ng-change="toggle()"/>
                    <label>Ignore the parameters and run the default</label>
                </div>
                <div class="form-group" data-ng-repeat="objParam in objRunningCron.objDetails.param track by $index" data-ng-if="boolIgnoreParam==false">
                    <label>{{objParam.label}}</label>
                    <input data-ng-if="objParam.type=='date'" type="text" name="txtParam_{{$index}}" data-ng-model="objParam.value" class="form-control" datetimepicker data-date-format="yyyy-mm-dd" data-min-view="2" data-start-view="2" data-ng-required="objParam.required"/>
                    <input data-ng-if="objParam.type=='string'" type="text" name="txtParam_{{$index}}" class="form-control" data-ng-model="objParam.value" data-ng-required="objParam.required"/>
                    <input data-ng-if="objParam.type=='number'" type="number" name="txtParam_{{$index}}" class="form-control" data-ng-model="objParam.value" data-ng-required="objParam.required"/>
                    <div class="form-inline" data-ng-if="objParam.type=='boolean'">
                        <input type="radio" name="txtParam_{{$index}}" id="txtParam_{{$index}}1" data-ng-model="objParam.value" data-ng-value="1" class="form-control"/><label for="txtParam_{{$index}}1">Yes</label>
                        <input type="radio" name="txtParam_{{$index}}" id="txtParam_{{$index}}2" data-ng-model="objParam.value" data-ng-value="0" class="form-control"/><label for="txtParam_{{$index}}2">No</label>
                    </div>
                </div>
            </form>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn yellow-saffron" data-ng-disabled="frmAddParams.$invalid"  data-ng-click="run()">Run</button>
            <button type="button" data-dismiss="modal" class="btn btn-danger" data-ng-click="cancelRun()">Cancel</button>
        </div>
    </div>
<?php
}
}
/* {/block 'dialog'} */
/* {block 'page_title'} */
class Block_99655da704ca048a34_67493534 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'page_title' => 
  array (
    0 => 'Block_99655da704ca048a34_67493534',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <h1>Cron Jobs <small>Listing</small></h1>
<?php
}
}
/* {/block 'page_title'} */
/* {block 'toolbar'} */
class Block_310105da704ca049836_66296263 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'toolbar' => 
  array (
    0 => 'Block_310105da704ca049836_66296263',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    
        <div class="btn-group pull-right">
            <a data-toggle="modal" href="#dlgAddCronJob" class="btn btn-fit-height btn-success" title="Add Cron Job">
                <i class="fa fa-plus"></i> 
                <span class="visible-lg-inline-block">Cron Job</span>
            </a>
        </div>
    
<?php
}
}
/* {/block 'toolbar'} */
/* {block 'content'} */
class Block_81155da704ca04aac7_11787212 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_81155da704ca04aac7_11787212',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <div class="row">
        <div class="col-md-12">
            <div class="portlet light">
                <div class="portlet-title"> 
                    <div class="caption">Cron Jobs</div>
                </div>
                <div class="portlet-body">
                    <table class="table table-light table-hover">
                        <thead>
                            <tr>
                                <th class="text-left">ID</th>
                                <th class="text-left">Cron</th>
                                <th class="text-left">Status</th>
                                <th class="text-left">Module</th>
                                <th class="text-left" style="width:140px">Run Time <small>[y-m-d H]</small></th>
                                <th class="text-left">Description</th>
                                <th colspan="3">&nbsp;</th>
                            </tr>
                        </thead>
                        <tbody>
                               <tr data-ng-repeat="objCronJob in arrCronJobs track by $index" data-ng-class="{'striped':objCronJob.intDisabled == 1}">
                                    <td>{{objCronJob.intID |numberFixedLen:4}}</td>
                                    <td>
                                        {{objCronJob.strCron || 'N/A'}}
                                    </td>
                                    <td><span class="label label-sm label-info">{{objCronJob.strStatus || 'N/A'}}</span></td>
                                    <td>{{objCronJob.objModule.strTitle || 'N/A'}}</td>
                                    <td>{{objCronJob.intYear || '*'}} - {{objCronJob.intMonth || '*'}} - {{objCronJob.intDay || '*'}} {{objCronJob.dtTime || '*'}}</td>
                                    <td>
                                        {{objCronJob.objDetails.description}}
                                    </td>
                                    <td>
                                        <a class="btn btn-xs yellow-saffron" data-ng-if="objCronJob.strStatus == objEnum.ClsBllCronJob.STATUS_STOPPED"  data-toggle="modal" href="#dlgRunCronJob" data-ng-click="setRunningCron(objCronJob)" title="Run"><i class="fa fa-play"></i></a>
                                    </td> 
                                    <td>
                                        <a class="btn btn-xs blue" data-ng-click="edit(objCronJob,$index)" title="Edit"><i class="fa fa-edit"></i></a>
                                    </td> 
                                    <td>
                                        <a class="btn btn-xs btn-success" data-ng-if="objCronJob.intDisabled == 1" data-ng-click="disable(objCronJob,0,$index)" title="Enable"><i class="fa fa-check"></i></a>
                                        <a class="btn btn-xs btn-danger" data-ng-if="objCronJob.intDisabled == 0" data-ng-click="disable(objCronJob,1,$index)" title="Disable"><i class="fa fa-ban"></i></a>
                                    </td> 
                               </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>    
<?php
}
}
/* {/block 'content'} */
}
