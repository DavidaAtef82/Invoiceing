<?php
/* Smarty version 3.1.31, created on 2019-10-16 13:53:42
  from "D:\www\ks_invoicing\modules\cmn\view\templates\partials\user.level\user.level.edit.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5da704c63ee938_94080100',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '7ff59cd86e93e02fcb283e89df80528e0899560f' => 
    array (
      0 => 'D:\\www\\ks_invoicing\\modules\\cmn\\view\\templates\\partials\\user.level\\user.level.edit.tpl',
      1 => 1570523806,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5da704c63ee938_94080100 (Smarty_Internal_Template $_smarty_tpl) {
?>
<div id="dlgEditUserLevel" class="modal fade modal-scroll modal-dialog" tabindex="-1" data-width="350" style="display: none;height:auto!important" data-ng-controller="EditUserLevel">
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        <h3 class="modal-title">Edit</h3>
    </div>
    <div class="modal-body">
        <form name="frmEditUserLevel">
        <div class="row">
            <div class="col-md-12">
                <div class="form-group">
                    <label>User Level</label>                                      
                    <input type="text" name="txtUserLevel" class="form-control" placeholder="User Level Name" required="required" data-ng-model="objEditUserLevel.strUserLevel" data-ng-blur="ValidateUserLevel()" />
                    <small class="help-block font-red" data-ng-show="frmEditUserLevel.txtUserLevel.$touched && frmEditUserLevel.txtUserLevel.$invalid">{{objError.strUserLevel}}</small>
                </div>
            </div>
        </div>    
        </form>
    </div>
    <div class="modal-footer">
        <button type="button" class="btn btn-success" data-ng-disabled="frmEditUserLevel.$invalid" data-ng-click="EditUserLevel()">Save</button>
        <button type="button" class="btn btn-danger" data-dismiss="modal" data-ng-click="ResetEditUserLevel()">Cancel</button>
    </div>
</div><?php }
}
