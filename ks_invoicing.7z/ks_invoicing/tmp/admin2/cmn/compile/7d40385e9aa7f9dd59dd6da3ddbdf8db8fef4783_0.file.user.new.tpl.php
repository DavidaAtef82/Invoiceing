<?php
/* Smarty version 3.1.31, created on 2019-10-16 16:11:09
  from "D:\www\ks_invoicing\modules\cmn\view\templates\pages\user.new.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5da724fdefc3c5_51830191',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '7d40385e9aa7f9dd59dd6da3ddbdf8db8fef4783' => 
    array (
      0 => 'D:\\www\\ks_invoicing\\modules\\cmn\\view\\templates\\pages\\user.new.tpl',
      1 => 1570523806,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5da724fdefc3c5_51830191 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_180005da724fded8db2_35710408', 'app');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_735da724fdeda6f2_82145572', 'controller');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_34065da724fdedb576_06743781', 'lang');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_77915da724fdedc521_72635016', 'style');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_305885da724fdedd468_93195354', 'script');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_225335da724fdee5556_64714598', 'dialog');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_123785da724fdee6244_60846469', 'page_title');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_129395da724fdee9136_31187982', 'content');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, ((string)@constant('LOCAL__THEME'))."/template/masters/master1/master.tpl");
}
/* {block 'app'} */
class Block_180005da724fded8db2_35710408 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'app' => 
  array (
    0 => 'Block_180005da724fded8db2_35710408',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

data-ng-app="CMN"
<?php
}
}
/* {/block 'app'} */
/* {block 'controller'} */
class Block_735da724fdeda6f2_82145572 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'controller' => 
  array (
    0 => 'Block_735da724fdeda6f2_82145572',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

data-ng-controller="User" 
<?php
}
}
/* {/block 'controller'} */
/* {block 'lang'} */
class Block_34065da724fdedb576_06743781 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'lang' => 
  array (
    0 => 'Block_34065da724fdedb576_06743781',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
}
}
/* {/block 'lang'} */
/* {block 'style'} */
class Block_77915da724fdedc521_72635016 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'style' => 
  array (
    0 => 'Block_77915da724fdedc521_72635016',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php
}
}
/* {/block 'style'} */
/* {block 'script'} */
class Block_305885da724fdedd468_93195354 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'script' => 
  array (
    0 => 'Block_305885da724fdedd468_93195354',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('PATH__JS');?>
/enum.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('PATH__JS');?>
/common.angular.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('PATH__JS');?>
/user.new.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
<?php
}
}
/* {/block 'script'} */
/* {block 'dialog'} */
class Block_225335da724fdee5556_64714598 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'dialog' => 
  array (
    0 => 'Block_225335da724fdee5556_64714598',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
}
}
/* {/block 'dialog'} */
/* {block 'page_title'} */
class Block_123785da724fdee6244_60846469 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'page_title' => 
  array (
    0 => 'Block_123785da724fdee6244_60846469',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<h1><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6598');?>
 <small><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6599');?>
</small></h1>
<?php
}
}
/* {/block 'page_title'} */
/* {block 'content'} */
class Block_129395da724fdee9136_31187982 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_129395da724fdee9136_31187982',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<div class="row">
    <div class="col-md-12">
        <div class="portlet light">
            <div class="portlet-title">
                <div class="caption font-blue"><i class="fa fa-plus-circle font-blue"></i> <?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6600');?>
</div>
            </div>
            <div class="portlet-body">
                <form name="frmNewUser" autocomplete="off">

                <hr style="margin: 5px 0px 5px 0px;" />
                <h4 style="font-weight:500"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6622');?>
</h4>

                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="control-label"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6603');?>
* <i class="fa fa-info-circle" title="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6602');?>
"></i></label>
                            <input type="text" name="txtUsername" class="form-control" placeholder="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6603');?>
" autocomplete="off" required="required" data-ng-model="objUser.strUsername" data-ng-blur="ValidateUsername()" />
                            <small class="help-block font-red" data-ng-show="frmNewUser.txtUsername.$touched && frmNewUser.txtUsername.$invalid">{{objError.strUsername}}</small>
                        </div>
                        <div class="form-group">
                            <label class="control-label"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6609');?>
*</label>
                            <input type="email" name="txtEmail" class="form-control" placeholder="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6609');?>
" autocomplete="off" required="required" data-ng-model="objUser.strEmail" />
                            <small class="help-block font-red" data-ng-show="frmNewUser.txtEmail.$touched && frmNewUser.txtEmail.$invalid"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6610');?>
</small>
                        </div>
                        <div class="form-group">
                            <label class="control-label"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6604');?>
*</label>
                            <input type="text" name="txtDisplayName" class="form-control" placeholder="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6604');?>
" autocomplete="off" required="required" data-ng-model="objUser.strDisplayName" />
                            <small class="help-block font-red" data-ng-show="frmNewUser.txtDisplayName.$touched && frmNewUser.txtDisplayName.$invalid"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6605');?>
</small>
                        </div>
                        <div class="form-group">
                            <label class="control-label"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6606');?>
*</label>
                            <input type="password" name="txtPassword" class="form-control" placeholder="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6606');?>
" autocomplete="new-password" required="required" data-ng-model="objUser.strPassword" data-ng-change="ValidatePassword()" />
                            <small class="help-block font-red" data-ng-show="frmNewUser.txtPassword.$touched && frmNewUser.txtPassword.$invalid">{{objError.strPassword}}</small>
                        </div>
                        <div class="form-group">
                            <label class="control-label"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6607');?>
*</label>
                            <input type="password" name="txtConfirmPassword" class="form-control" placeholder="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6607');?>
" autocomplete="new-password" required="required" data-ng-model="objUser.strConfirmPassword" data-ng-change="ConfirmPassword()" />
                            <small class="help-block font-red" data-ng-show="frmNewUser.txtConfirmPassword.$invalid">{{objError.strPasswordConfirm}}</small>
                        </div>
                    </div>
                </div>

                <hr style="margin: 5px 0px 5px 0px;" />

                <h4 style="font-weight:500"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6601');?>
</h4>
                <div class="row">
                    <div class="col-md-4" data-ng-repeat="objModule in arrModules">
                        <div class="row">
                            <div class="col-md-12">
                                <h5><b>{{objModule.strTitle}}</b></h5>
                            </div>
                            <div class="col-md-12">
                                <ul>
                                    <li style="list-style-type: none;" data-ng-repeat="objUserlevel in objModule.arrUserLevels">
                                        <input type="checkbox" id="chkUserlevel_{{objUserlevel.intID}}" name="chkUserlevel_{{objUserlevel.intID}}" data-ng-true-value="1" data-ng-false-value="0" data-ng-model="objUserlevel.intChecked" data-ng-change="SetUserLevel(objUserlevel)" />
                                        <span for="chkUserlevel_{{objUserlevel.intID}}" class="control-label">{{objUserlevel.strUserLevel}}</span>
                                    </li>
                                    <li style="list-style-type: none;" data-ng-if="objModule.intID == objEnum.ClsBllModule.MODULE_HR">
                                        <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6619');?>
</label>
                                        <ui-select name="txtEmployeeName" class="ui-border" data-ng-model="objUser.intEmployeeID" data-ng-disabled="objCmbDisabled.boolEmployee" theme="bootstrap">
                                            <ui-select-match allow-clear placeholder="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6621');?>
">[{{$select.selected.strCode}}] {{$select.selected.strShortName| limitTo: 20}}</ui-select-match>
                                            <ui-select-choices repeat="objEmployee.intID as objEmployee in arrEmployees | filter: $select.search">
                                                [{{objEmployee.strCode}}] {{objEmployee.strShortName}}
                                            </ui-select-choices>
                                        </ui-select>
                                    </li>
                                    <li style="list-style-type: none;" data-ng-if="objModule.intID == objEnum.ClsBllModule.MODULE_SF">
                                        <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6620');?>
</label>
                                        <select name="cmbTeam" ng-model="objUser.intTeamID" class="form-control" data-ng-disabled="objCmbDisabled.boolTeam" data-ng-options="obj.intID as obj.strTeamName for obj in arrTeams">
                                            <option value=""><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6621');?>
</option>
                                        </select>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <hr style="margin: 5px 0px 5px 0px;" />

                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <input type="checkbox" id="chkSendWelcomeEmail" name="chkSendWelcomeEmail" data-ng-change="" data-ng-true-value="1" data-ng-false-value="0" data-ng-model="objUser.intSendWelcomeEmail" />
                            <span for="chkSendWelcomeEmail" class="control-label"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6618');?>
</span>
                            <div class="pull-right">
                                <button type="button" name="btnSave" class="btn btn-success" data-ng-disabled="frmNewUser.$invalid" data-ng-click="Add(false)"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6611');?>
</button>
                                <button type="button" name="btnSave" class="btn btn-success" data-ng-disabled="frmNewUser.$invalid" data-ng-click="Add(true)"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6612');?>
</button>
                            </div>
                        </div>
                    </div>
                </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php
}
}
/* {/block 'content'} */
}
