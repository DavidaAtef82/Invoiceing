<?php
/* Smarty version 3.1.31, created on 2019-10-16 17:32:36
  from "D:\www\ks_invoicing\modules\cmn\view\templates\pages\user.edit.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5da738140e33c8_28040372',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'dc15331a03b63ddd58978990e3b75854db4f9a80' => 
    array (
      0 => 'D:\\www\\ks_invoicing\\modules\\cmn\\view\\templates\\pages\\user.edit.tpl',
      1 => 1570523806,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5da738140e33c8_28040372 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_232685da738140d0cb5_81938021', 'app');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_233735da738140d2128_64670974', 'controller');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_15385da738140d2f92_72882089', 'lang');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_233155da738140d3dc5_53925978', 'style');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_167205da738140d8107_32820394', 'script');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_243935da738140dcfb1_49723023', 'dialog');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_785da738140ddd50_02014158', 'page_title');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_54875da738140deae0_94614112', 'content');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, ((string)@constant('LOCAL__THEME'))."/template/masters/master1/master.tpl");
}
/* {block 'app'} */
class Block_232685da738140d0cb5_81938021 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'app' => 
  array (
    0 => 'Block_232685da738140d0cb5_81938021',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    data-ng-app="CMN"
<?php
}
}
/* {/block 'app'} */
/* {block 'controller'} */
class Block_233735da738140d2128_64670974 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'controller' => 
  array (
    0 => 'Block_233735da738140d2128_64670974',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

     data-ng-controller="User" 
<?php
}
}
/* {/block 'controller'} */
/* {block 'lang'} */
class Block_15385da738140d2f92_72882089 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'lang' => 
  array (
    0 => 'Block_15385da738140d2f92_72882089',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
}
}
/* {/block 'lang'} */
/* {block 'style'} */
class Block_233155da738140d3dc5_53925978 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'style' => 
  array (
    0 => 'Block_233155da738140d3dc5_53925978',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <link rel="stylesheet" type="text/css" href="<?php echo @constant('WEB__THEME');?>
/css/pages/profile-old.css"/>
<?php
}
}
/* {/block 'style'} */
/* {block 'script'} */
class Block_167205da738140d8107_32820394 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'script' => 
  array (
    0 => 'Block_167205da738140d8107_32820394',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('PATH__JS');?>
/enum.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('PATH__JS');?>
/common.angular.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('PATH__JS');?>
/user.edit.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
<?php
}
}
/* {/block 'script'} */
/* {block 'dialog'} */
class Block_243935da738140dcfb1_49723023 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'dialog' => 
  array (
    0 => 'Block_243935da738140dcfb1_49723023',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
}
}
/* {/block 'dialog'} */
/* {block 'page_title'} */
class Block_785da738140ddd50_02014158 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'page_title' => 
  array (
    0 => 'Block_785da738140ddd50_02014158',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <h1>User <small>Edit</small></h1>
<?php
}
}
/* {/block 'page_title'} */
/* {block 'content'} */
class Block_54875da738140deae0_94614112 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_54875da738140deae0_94614112',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <div class="row">
        <div class="col-md-12">
            <div class="portlet box blue-hoki">
                <div class="portlet-title">
                    <div class="caption"><i class="fa fa-user"></i> Edit User</div>
                </div>
                <div class="portlet-body">
                    <form id="frmUser">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="col-md-6">
                                    <div class="row margin-top-10">
                                        <div class="col-md-6 margin-top-10">
                                            <img width="300" data-ng-if="objUser.intPhotoID == -1" src="<?php echo @constant('PATH__IMAGE');?>
/user.png" class="img-responsive">
                                            <img width="300" data-ng-if="objUser.intPhotoID != -1" data-ng-src="index.php?module=cmn&page=Index&action=Download&file_id={{objUser.intPhotoID}}" class="img-responsive">
                                            <input type="file" name="fileImage" data-file="objUser.objFile" class="form-control" accept="image/*"/>        
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="control-label">User Name</label>
                                                <input type="text" required="required" data-ng-model="objUser.strUserName" class="form-control" placeholder="User Name"/>
                                            </div>
                                            <div class="form-group">
                                                <label class="control-label">Display Name</label>
                                                <input type="text" required="required" data-ng-model="objUser.strDisplayName" class="form-control" placeholder="Display Name"/>
                                            </div>
                                            <div class="form-group">
                                                <label class="control-label">Email</label>
                                                <input type="email" required="required" data-ng-model="objUser.strEmail" class="form-control" placeholder="Email"/>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div data-ng-repeat="objModule in arrModules">
                                        <label><b>{{objModule.strTitle}}</b></label>
                                        <div class="row">
                                            <div class="col-md-12" data-ng-class="{'col-md-5':(objModule.intID == objEnum.ClsBllModule.MODULE_HR || objModule.intID == objEnum.ClsBllModule.MODULE_SF)}">
                                                <ul>
                                                    <li style="list-style-type: none;" data-ng-repeat="objUserlevel in objModule.arrUserLevels">
                                                        <input type="checkbox" id="chkUserlevel_{{objUserlevel.intID}}" data-ng-change="setUserlevelSelected(objUserlevel)" data-ng-true-value="1" data-ng-false-value="0" data-ng-model="objUserlevel.intChecked"/>
                                                        <span for="chkUserlevel_{{objUserlevel.intID}}" class="control-label">{{objUserlevel.strUserLevel}}</span>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div class="col-md-7" data-ng-if="objModule.intID == objEnum.ClsBllModule.MODULE_HR || objModule.intID == objEnum.ClsBllModule.MODULE_SF">
                                                <div data-ng-if="objModule.intID == objEnum.ClsBllModule.MODULE_HR">
                                                    <label>Employee</label>
                                                    <ui-select name="txtEmployeeName" data-ng-model="objUser.intEmployeeID" theme="bootstrap" class="ui-border">
                                                        <ui-select-match allow-clear placeholder="Select Employee">[{{$select.selected.strCode}}] {{$select.selected.strShortName| limitTo: 20}}</ui-select-match>
                                                        <ui-select-choices repeat="objEmployee.intID as objEmployee in arrEmployees | filter: $select.search">
                                                            [{{objEmployee.strCode}}] {{objEmployee.strShortName}}
                                                        </ui-select-choices>
                                                    </ui-select>
                                                </div>
                                                <div data-ng-if="objModule.intID == objEnum.ClsBllModule.MODULE_SF">
                                                    <label>Team</label>
                                                    <select ng-model="objUser.intTeamID" class="form-control" data-ng-options="obj.intID as obj.strTeamName for obj in arrTeams">
                                                        <option value="">Select Team</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <button class="btn btn-info pull-right" data-ng-disabled="frmUser.$invalid" data-ng-click="save()">Save</button>
                            </div>
                        </div>
                    </form>    
                </div>
            </div>
        </div>
    </div>
    
<?php
}
}
/* {/block 'content'} */
}
