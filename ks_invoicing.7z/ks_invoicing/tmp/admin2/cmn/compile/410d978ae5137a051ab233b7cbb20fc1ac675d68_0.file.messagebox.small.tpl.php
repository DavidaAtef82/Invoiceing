<?php
/* Smarty version 3.1.31, created on 2019-10-14 13:30:45
  from "D:\www\ks_invoicing\themes\admin2\template\blocks\messagebox.small.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5da45c656c0760_89007703',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '410d978ae5137a051ab233b7cbb20fc1ac675d68' => 
    array (
      0 => 'D:\\www\\ks_invoicing\\themes\\admin2\\template\\blocks\\messagebox.small.tpl',
      1 => 1570523813,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5da45c656c0760_89007703 (Smarty_Internal_Template $_smarty_tpl) {
if ($_smarty_tpl->tpl_vars['Type']->value == 'Warning') {?>
    <?php $_smarty_tpl->_assignInScope('strOuterClass', "alert-warning");
?>
    <?php $_smarty_tpl->_assignInScope('strTitle', "Warning!");
} elseif ($_smarty_tpl->tpl_vars['Type']->value == 'Error') {?>
    <?php $_smarty_tpl->_assignInScope('strOuterClass', "alert-danger");
?>
    <?php $_smarty_tpl->_assignInScope('strTitle', "Error!");
} elseif ($_smarty_tpl->tpl_vars['Type']->value == 'AccessDenied') {?>
    <?php $_smarty_tpl->_assignInScope('strOuterClass', "alert-danger");
?>
    <?php $_smarty_tpl->_assignInScope('strTitle', "Access Denied!");
} elseif ($_smarty_tpl->tpl_vars['Type']->value == 'Success') {?>
    <?php $_smarty_tpl->_assignInScope('strOuterClass', "alert-success");
?>
    <?php $_smarty_tpl->_assignInScope('strTitle', "Success!");
} elseif ($_smarty_tpl->tpl_vars['Type']->value == 'Add') {?>
    <?php $_smarty_tpl->_assignInScope('strOuterClass', "alert-default");
?>
    <?php $_smarty_tpl->_assignInScope('strTitle', "Add!");
} else { ?>
    <?php $_smarty_tpl->_assignInScope('strOuterClass', "alert-info");
?>
    <?php $_smarty_tpl->_assignInScope('strTitle', "Help!");
}
if (isset($_smarty_tpl->tpl_vars['ID']->value)) {?>
    <?php $_smarty_tpl->_assignInScope('id', "id='".((string)$_smarty_tpl->tpl_vars['ID']->value)."'");
} else { ?>
    <?php $_smarty_tpl->_assignInScope('id', '');
}?>

<?php if (!isset($_smarty_tpl->tpl_vars['Class']->value)) {?>
    <?php $_smarty_tpl->_assignInScope('Class', '');
}?>

<div <?php echo $_smarty_tpl->tpl_vars['id']->value;?>
 class="alert margin-top-10 margin-bottom-10 <?php echo $_smarty_tpl->tpl_vars['strOuterClass']->value;?>
 <?php echo $_smarty_tpl->tpl_vars['Class']->value;?>
">
    <strong><?php echo $_smarty_tpl->tpl_vars['strTitle']->value;?>
</strong>
    <?php echo $_smarty_tpl->tpl_vars['Message']->value;?>

</div>
<?php }
}
