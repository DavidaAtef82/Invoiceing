<?php
/* Smarty version 3.1.31, created on 2019-10-14 10:29:55
  from "D:\www\ks_invoicing\modules\cmn\view\templates\partials\sitemap\edit.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5da43203789ef4_75937002',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'eaf4504e6512a3594ecb31b40f924ea7c7dc80f2' => 
    array (
      0 => 'D:\\www\\ks_invoicing\\modules\\cmn\\view\\templates\\partials\\sitemap\\edit.tpl',
      1 => 1570523806,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5da43203789ef4_75937002 (Smarty_Internal_Template $_smarty_tpl) {
?>
<div id="dlgEdit" class="modal fade modal-scroll modal-dialog" tabindex="-1" data-width="760" style="display: none;height:auto!important" data-ng-controller="Edit">
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        <h3 class="modal-title"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6561');?>
</h3>
    </div>
    <div class="modal-body">
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6547');?>
</label>
                    <select name="cmbGroupOrder" class="form-control" data-ng-model="objMenu.decGroupOrder" data-ng-options="obj.decGroupOrder as obj.strItemText for obj in arrTopMenu" required="required">
                        <option value=""><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6554');?>
</option>
                    </select>
                </div>
            </div>
            <div class="col-md-3">
                <div class="form-group">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6552');?>
</label>
                    <input type="text" class="form-control" data-ng-model="objMenu.intItemLevel" required="required"/>
                </div>
            </div>
            <div class="col-md-3">
                <div class="form-group">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6548');?>
</label>
                    <input type="text" class="form-control" data-ng-model="objMenu.decItemOrder" required="required"/>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6553');?>
</label>
                    <select name="cmbModule" data-ng-model="objMenu.intModuleID" data-ng-options="obj.intID as obj.strModule for obj in arrModules" data-ng-change="ListActions()" class="form-control">
                        <option value=""><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6554');?>
</option>
                    </select>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6549');?>
</label>
                    <select name="cmbAction" data-ng-model="objMenu.intActionID" data-ng-options="obj.intID as (obj.strControllerClass + '/' + obj.strAction) for obj in arrActions" class="form-control">
                        <option value=""><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6554');?>
</option>
                    </select>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6550');?>
</label>
                    <input type="text" class="form-control" data-ng-model="objMenu.strItemText" required="required"/>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6555');?>
</label>
                    <input type="text" class="form-control" data-ng-model="objMenu.strItemStyle" required="required"/>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="form-group">
                    <input type="checkbox" data-ng-model="objMenu.boolShowInMenu" data-ng-checked="objMenu.boolShowInMenu"/>
                    <span><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6556');?>
</span>
                </div>
            </div>
        </div>
    </div>
    <div class="modal-footer">
        <button type="button" class="btn btn-success" data-ng-click="Save()"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6557');?>
</button>
        <button type="button" class="btn btn-danger" data-dismiss="modal"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6558');?>
</button>
    </div>
</div><?php }
}
