<?php
/* Smarty version 3.1.31, created on 2019-10-24 09:22:13
  from "D:\www\ks_invoicing\modules\cmn\view\templates\pages\login.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5db15125bdc610_09743700',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '1459e7c6664fd1d52424a98db916be51ec13baac' => 
    array (
      0 => 'D:\\www\\ks_invoicing\\modules\\cmn\\view\\templates\\pages\\login.tpl',
      1 => 1570523806,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5db15125bdc610_09743700 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->smarty->ext->configLoad->_loadConfigFile($_smarty_tpl, $_smarty_tpl->tpl_vars['_LanguageFile']->value, "AUX_MENU", 0);
?>

<?php
$_smarty_tpl->smarty->ext->configLoad->_loadConfigFile($_smarty_tpl, $_smarty_tpl->tpl_vars['_LanguageFile']->value, $_smarty_tpl->tpl_vars['_LanguageSection']->value, 0);
?>

<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8 no-js"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9 no-js"> <![endif]-->
<!--[if !IE]><!-->
<html lang="<?php echo $_smarty_tpl->tpl_vars['_Language']->value;?>
" class="no-js" dir="<?php echo $_smarty_tpl->tpl_vars['_Direction']->value;?>
">
<!--<![endif]-->
    <head>
        <meta charset="utf-8"/>
        <title><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'APP_NAME');?>
 | <?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_5655');?>
</title>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta content="width=device-width, initial-scale=1.0" name="viewport"/>
        <meta content="" name="description"/>
        <meta content="" name="author"/>
        <meta name="MobileOptimized" content="320">

        <?php $_smarty_tpl->_subTemplateRender(((string)@constant('LOCAL__THEME'))."/template/masters/master1/styles.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, true);
?>

        <link rel="stylesheet" type="text/css" href="<?php echo @constant('WEB__THEME');?>
/css/pages/login-soft.css"/>
        <link rel="shortcut icon" href="<?php echo @constant('WEB__THEME');?>
/images/<?php echo @constant('THEME_FAV_LOGO');?>
?ver=<?php echo @constant('VERSION');?>
" type="image/png"/>
    </head>

    <body class="login" data-ng-app="CMN" ng-cloak>
        <div class="logo">
            <img src="<?php echo @constant('WEB__THEME');?>
/images/<?php echo @constant('THEME_LOGIN_LOGO');?>
" style="width:200px" alt=""/>            
        </div>
        <div class="content" data-ng-controller="Login">
            <form name="frmLogin" class="login-form" method="post" data-ng-submit="LogMeIn(frmLogin.$valid)" novalidate="novalidate" data-ng-show="mode.login">
                <?php if ($_smarty_tpl->tpl_vars['URL']->value != '') {?>
                    <input type="hidden" id="url" name="url" data-ng-model="objLogin.strUrl" value="<?php echo $_smarty_tpl->tpl_vars['URL']->value;?>
" />
                <?php } else { ?>
                    <input type="hidden" id="url" name="url" data-ng-model="objLogin.strUrl" value="" />
                <?php }?>
                <h3 class="form-title text-center"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_3079');?>
</h3>
                <div class="alert alert-danger" ng-cloak data-ng-if="!objLogin.boolResult && objLogin.strMessage!=''">
                    <strong><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_3080');?>
</strong> <span>{{ objLogin.strMessage }}</span>
                </div>
                <div class="alert alert-success" ng-cloak data-ng-if="objLogin.boolResult && objLogin.strMessage!=''">
                    <strong><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_3081');?>
</strong> <span>{{ objLogin.strMessage }}</span>
                </div>
                <div class="form-group">
                    <!--ie8, ie9 does not support html5 placeholder, so we just show field title for that-->
                    <label class="control-label visible-ie8 visible-ie9"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_3082');?>
</label>
                    <div class="input-icon">
                        <i class="fa fa-user-secret"></i>
                        <input type="text" name="txtUserName" class="form-control placeholder-no-fix" placeholder="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_3082');?>
" required="required" focus="true" data-ng-model="objLogin.strUserName" />
                        <p class="help-block" style="color: #ddd;font-size: 12px;" ng-show="frmLogin.txtUserName.$invalid"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_3083');?>
</p>
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label visible-ie8 visible-ie9"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_3084');?>
</label>
                    <div class="input-icon">
                        <i class="fa fa-unlock-alt"></i>
                        <input type="password" name="txtPassword" class="form-control placeholder-no-fix" placeholder="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_3084');?>
" required="required" data-ng-model="objLogin.strPassword" />
                        <p class="help-block" style="color: #ddd;font-size: 12px;" ng-show="frmLogin.txtPassword.$invalid"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_3085');?>
</p>
                    </div>
                </div>
                <div class="form-actions">
                    <button type="submit" class="btn blue pull-right" data-ng-disabled="frmLogin.$invalid"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_3086');?>
</button>
                </div>
                <div class="forget-password">
                    <h4><a href="#" class="font-grey-cararra" data-ng-click="ForgetPassword()"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_3087');?>
</a></h4>
                </div>
            </form>

            <form name="frmForgetPassword" ng-cloak novalidate="novalidate" data-ng-hide="mode.login">
                <h3><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_3091');?>
</h3>
                <div class="alert alert-danger" data-ng-if="objReset.strMessage!=''">
                    <strong><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_3092');?>
</strong> <span>{{ objReset.strMessage }}</span>
                </div>
                <p><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_3093');?>
</p>
                <div class="form-group">
                    <div class="input-icon">
                        <i class="fa fa-user-secret"></i>
                        <input type="text" name="txtUserName" class="form-control placeholder-no-fix" placeholder="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_3082');?>
" required="required" data-ng-model="objReset.strUserName" />
                        <p class="help-block" style="color: #ddd;font-size: 12px;" ng-show="frmForgetPassword.txtUserName.$invalid"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_3083');?>
</p>
                    </div>
                </div>
                <div class="form-actions">
                    <button type="button" id="back-btn" class="btn red" data-ng-click="Login()"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_3095');?>
</button>
                    <button type="button" class="btn blue pull-right" data-ng-disabled="frmForgetPassword.$invalid" data-ng-click="CreatePasswordResetRecord(frmForgetPassword.$valid)"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_3096');?>
</button>
                </div>
            </form>
            
            <sham-spinner></sham-spinner>
        </div>

        <div class="copyright">
            <?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'APP_NAME');?>
 <?php echo @constant('VERSION');?>
 | 2015 - <?php echo date('Y');?>
 &copy;
        </div>

        <!--[if lt IE 9]>
        <?php echo '<script'; ?>
 src="<?php echo @constant('WEB__ASSETS');?>
/respond.min.js"><?php echo '</script'; ?>
>
        <?php echo '<script'; ?>
 src="<?php echo @constant('PATH_ASSETS');?>
/excanvas.min.js"><?php echo '</script'; ?>
>
        <![endif]-->

        <?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('WEB__ASSETS__JQUERY');?>
/jquery/jquery-1.10.2.min.js"><?php echo '</script'; ?>
>
        <?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('WEB__ASSETS__JQUERY');?>
/jquery/jquery-migrate-1.2.1.min.js"><?php echo '</script'; ?>
>
        <?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('WEB__ASSETS__JQUERY');?>
/jquery/jquery.blockui.min.js"><?php echo '</script'; ?>
>
        <?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('WEB__ASSETS__JQUERY');?>
/jquery/jquery.cokie.min.js"><?php echo '</script'; ?>
>
        <?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('WEB__ASSETS__JQUERY');?>
/backstretch/backstretch.min.js"><?php echo '</script'; ?>
>

        <?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('WEB__ASSETS__BOOTSTRAP');?>
/bootstrap/js/bootstrap.min.js"><?php echo '</script'; ?>
>

        <?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('WEB__ASSETS__ANGULAR');?>
/angular.min.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
        <?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('WEB__ASSETS__ANGULAR');?>
/xeditable/js/xeditable.min.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
        <?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('WEB__ASSETS__ANGULAR');?>
/bootstrap/ui-bootstrap-tpls-0.11.0.min.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
        <?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('WEB__ASSETS__ANGULAR');?>
/wizard/angular-wizard.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
        <?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('WEB__ASSETS__ANGULAR');?>
/sham-spinner/angular-sham-spinner.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
        <?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('WEB__ASSETS__ANGULAR');?>
/datepicker/js/datepicker.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
        <?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('WEB__ASSETS__ANGULAR');?>
/ui-select/js/select.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>

        
        <?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('PATH__JS');?>
/common.angular.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
        <?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('PATH__JS');?>
/login.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
        <?php echo '<script'; ?>
 type="text/javascript">
            jQuery(document).ready(function() {     
                // init background slide images
               localStorage.clear();
               sessionStorage.clear();
               var path = "<?php echo @constant('WEB__THEME');?>
";
               $.backstretch([
                        path+"/images/bg/1.jpg",
                        path+"/images/bg/2.jpg",
                        path+"/images/bg/3.jpg",
                        path+"/images/bg/4.jpg"
                    ],
                    {
                      fade: 1000,
                      duration: 8000
                    }
                );
            });
        <?php echo '</script'; ?>
>
    </body>
</html><?php }
}
