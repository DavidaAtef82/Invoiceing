<?php
/* Smarty version 3.1.31, created on 2019-10-14 10:29:08
  from "D:\www\ks_invoicing\themes\admin2\template\masters\master1\meta.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5da431d4abf0e4_30700190',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'ff7b23626dbd66d921f0dfa44ddfad6a68716369' => 
    array (
      0 => 'D:\\www\\ks_invoicing\\themes\\admin2\\template\\masters\\master1\\meta.tpl',
      1 => 1570523813,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5da431d4abf0e4_30700190 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->smarty->ext->configLoad->_loadConfigFile($_smarty_tpl, "lang.en.conf", "META", 0);
?>

<meta charset="utf-8"/>
<meta content="width=device-width, initial-scale=1.0" name="viewport"/>
<meta http-equiv="Expires" content="-1"/>
<meta http-equiv="Pragma" content="no-cache"/>
<meta http-equiv="Cache-Control" content="no-cache"/>
<meta http-equiv="Lang" content="<?php echo $_smarty_tpl->tpl_vars['_Language']->value;?>
"/>
<meta http-equiv="accept-encoding" content="gzip deflate"/>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="author" content="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_AUTHOR');?>
"/>
<meta name="description" content="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_DESCRIPTION');?>
"/>
<meta name="generator" content="ABM Platform"/>
<meta name="keywords" content="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_KEYWORD');?>
"/>
<meta name="creation-date" content="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_PROJECT_CREATION_DATE');?>
"/>
<meta name="revisit-after" content="15 days"/>
<meta name="robots" content="noindex, nofollow"/>
<meta name="googlebot" content="noindex, nofollow"/>
<meta name="MobileOptimized" content="320"><?php }
}
