<?php
/* Smarty version 3.1.31, created on 2019-10-16 13:53:42
  from "D:\www\ks_invoicing\modules\cmn\view\templates\partials\user.level\user.level.add.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5da704c63e3ab8_65698247',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'df9a9821def10bc41fab1f10ea1396eb8ba24ae5' => 
    array (
      0 => 'D:\\www\\ks_invoicing\\modules\\cmn\\view\\templates\\partials\\user.level\\user.level.add.tpl',
      1 => 1570523806,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5da704c63e3ab8_65698247 (Smarty_Internal_Template $_smarty_tpl) {
?>
<div id="dlgAddUserLevel" class="modal fade modal-scroll modal-dialog" tabindex="-1" data-width="760" style="display: none;height:auto!important" data-ng-controller="AddUserLevel">
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        <h3 class="modal-title">Add</h3>
    </div>
    <div class="modal-body">
        <form name="frmAddUserLevel">
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label>User Level</label>
                    <input type="text" name="txtUserLevel" class="form-control" placeholder="User Level Name" required="required" autocomplete="off" data-ng-model="objNewUserLevel.strUserLevel" data-ng-blur="ValidateUserLevel()" />
                    <small class="help-block font-red" data-ng-show="frmAddUserLevel.txtUserLevel.$touched && frmAddUserLevel.txtUserLevel.$invalid">{{objError.strUserLevel}}</small>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label>Copy Permissions from other user level</label>
                    <select name="cmbSrcUserLevel" class="form-control" data-ng-model="objNewUserLevel.intSrcUserLevelID" data-ng-options="obj.intID as obj.strUserLevel for obj in $parent.arrUserLevelLookup">
                        <option value="">Select user level</option>
                    </select>
                </div>
            </div>
        </div>    
        </form>
    </div>
    <div class="modal-footer">
        <button type="button" class="btn btn-success" data-ng-disabled="frmAddUserLevel.$invalid" data-ng-click="AddUserLevel()">Save</button>
        <button type="button" class="btn btn-danger" data-dismiss="modal" data-ng-click="ResetAddUserLevel()">Cancel</button>
    </div>
</div><?php }
}
