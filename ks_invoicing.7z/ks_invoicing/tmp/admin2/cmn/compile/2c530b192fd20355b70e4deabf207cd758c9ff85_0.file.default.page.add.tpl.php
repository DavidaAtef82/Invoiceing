<?php
/* Smarty version 3.1.31, created on 2019-10-16 13:53:42
  from "D:\www\ks_invoicing\modules\cmn\view\templates\partials\user.level\default.page.add.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5da704c63fb107_90476900',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '2c530b192fd20355b70e4deabf207cd758c9ff85' => 
    array (
      0 => 'D:\\www\\ks_invoicing\\modules\\cmn\\view\\templates\\partials\\user.level\\default.page.add.tpl',
      1 => 1570523806,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5da704c63fb107_90476900 (Smarty_Internal_Template $_smarty_tpl) {
?>
<div id="dlgAddDefaultPage" class="modal fade modal-scroll modal-dialog" tabindex="-1" data-width="380" style="display: none;height:auto!important" data-ng-controller="AddDefaultPage">
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        <h3 class="modal-title">Add Default Page</h3>
    </div>
    <div class="modal-body">
        <form name="frmAddDefaultPage">
        <div class="row">
            <div class="col-md-12">
                <div class="form-group">
                    <label>User Level</label>
                    <span class="form-control">{{objUserLevel.strUserLevel}}</span>
                </div>
            </div>
            <div class="col-md-12">
                <div class="form-group">
                    <label>Module</label>
                    <select name="cmbModule" class="form-control" required="required" data-ng-model="objNewDefaultPage.intModuleID" data-ng-options="obj.intID as obj.strTitle for obj in $parent.arrModules">
                        <option value="">Select Module</option>
                    </select>
                </div>
            </div>
            <div class="col-md-12">
                <div class="form-group">
                    <label>Default Page</label>
                    <input type="text" name="txtDefaultPage" class="form-control" placeholder="url: index.php?module=x&amp;page=y&amp;action=z" required="required" data-ng-model="objNewDefaultPage.strDefaultPage" />
                </div>
            </div>
            <div class="col-md-12">
                <div class="form-group">
                    <input type="checkbox" id="chkDefaultModule" name="chkDefaultModule" data-ng-model="objNewDefaultPage.intDefaultModule" data-ng-true-value="1" data-ng-false-value="0" />
                    <label for="chkDefaultModule">Mark as default module</label>
                </div>
            </div>
        </div>    
        </form>
    </div>
    <div class="modal-footer">
        <button type="button" class="btn btn-success" data-ng-disabled="frmAddDefaultPage.$invalid" data-ng-click="AddDefaultPage()">Save</button>
        <button type="button" class="btn btn-danger" data-dismiss="modal" data-ng-click="ResetAddDefaultPage()">Cancel</button>
    </div>
</div><?php }
}
