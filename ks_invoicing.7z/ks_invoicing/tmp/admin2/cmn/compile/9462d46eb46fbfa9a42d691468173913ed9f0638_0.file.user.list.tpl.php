<?php
/* Smarty version 3.1.31, created on 2019-10-16 17:44:42
  from "D:\www\ks_invoicing\modules\cmn\view\templates\pages\user.list.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5da73aeaf2a834_30751789',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '9462d46eb46fbfa9a42d691468173913ed9f0638' => 
    array (
      0 => 'D:\\www\\ks_invoicing\\modules\\cmn\\view\\templates\\pages\\user.list.tpl',
      1 => 1571240557,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5da73aeaf2a834_30751789 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_223165da73aeaf00f96_99580432', 'app');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_138135da73aeaf024e3_60024761', 'controller');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_203625da73aeaf033d5_84619823', 'style');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_66515da73aeaf04089_25299915', 'script');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_148725da73aeaf0a1c5_36286485', 'dialog');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_154735da73aeaf10006_22053919', 'page_title');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_231265da73aeaf11a73_24059879', 'toolbar');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_232555da73aeaf1a6f4_81260025', 'content');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, ((string)@constant('LOCAL__THEME'))."/template/masters/master1/master.tpl");
}
/* {block 'app'} */
class Block_223165da73aeaf00f96_99580432 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'app' => 
  array (
    0 => 'Block_223165da73aeaf00f96_99580432',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    data-ng-app="CMN"
<?php
}
}
/* {/block 'app'} */
/* {block 'controller'} */
class Block_138135da73aeaf024e3_60024761 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'controller' => 
  array (
    0 => 'Block_138135da73aeaf024e3_60024761',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

     data-ng-controller="User" 
<?php
}
}
/* {/block 'controller'} */
/* {block 'style'} */
class Block_203625da73aeaf033d5_84619823 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'style' => 
  array (
    0 => 'Block_203625da73aeaf033d5_84619823',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
}
}
/* {/block 'style'} */
/* {block 'script'} */
class Block_66515da73aeaf04089_25299915 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'script' => 
  array (
    0 => 'Block_66515da73aeaf04089_25299915',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('PATH__JS');?>
/common.angular.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('PATH__JS');?>
/user.list.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
<?php
}
}
/* {/block 'script'} */
/* {block 'dialog'} */
class Block_148725da73aeaf0a1c5_36286485 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'dialog' => 
  array (
    0 => 'Block_148725da73aeaf0a1c5_36286485',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <div id="dlgDetails" class="modal fade modal-scroll modal-dialog" tabindex="-1" data-width="760" style="display: none;height:auto!important">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            <h3 class="modal-title"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2931');?>
</h3>
        </div>
        <div class="modal-body">
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <b><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2932');?>
 </b>{{objCurrentUser.strUserName}}
                    </div>
                    <div class="form-group">
                        <b><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2933');?>
 </b>{{objCurrentUser.strDisplayName}}
                    </div>
                    <div class="form-group">
                        <b><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2934');?>
 </b>{{objCurrentUser.strEmail}}
                    </div>
                    <div data-ng-if="objCurrentUser.objEmployee != null" class="form-group">
                        <b><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2938');?>
 </b>{{objCurrentUser.objEmployee.strShortName || '-'}}
                    </div>
                    <div data-ng-if="objCurrentUser.objTeam != null" class="form-group">
                        <b><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2939');?>
 </b>{{objCurrentUser.objTeam.strTeamName || '-'}}
                    </div>
                </div>
                <div class="col-md-6">
                    <div data-ng-repeat="objModule in objCurrentUser.arrModules" class="form-group">
                        <b><u>{{objModule.strTitle}}</u></b>
                        <ul>
                            <li data-ng-repeat="objUserLevel in objCurrentUser.arrModuleUserLevels[objModule.intID]">
                                {{objUserLevel.strUserLevel}}
                            </li>
                        </ul>
                    </div>
                </div>    
            </div>    
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-danger" data-dismiss="modal"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2940');?>
</button>
        </div>
    </div>
<?php
}
}
/* {/block 'dialog'} */
/* {block 'page_title'} */
class Block_154735da73aeaf10006_22053919 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'page_title' => 
  array (
    0 => 'Block_154735da73aeaf10006_22053919',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <h1><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2941');?>
 <small><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2942');?>
</small></h1>
<?php
}
}
/* {/block 'page_title'} */
/* {block 'toolbar'} */
class Block_231265da73aeaf11a73_24059879 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'toolbar' => 
  array (
    0 => 'Block_231265da73aeaf11a73_24059879',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <?php if (in_array(\NsCMN\ClsBllUserPermission::PERMISSION_ADD,$_smarty_tpl->tpl_vars['_UserPermission']->value)) {?>
        <div class="btn-group">
            <a href="index.php?module=cmn&page=User&action=New" class="btn btn-fit-height btn-success" title="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6630');?>
">
                <i class="fa fa-plus"></i> 
                <span class="visible-lg-inline-block"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2943');?>
</span>
            </a>
        </div>
    <?php }
}
}
/* {/block 'toolbar'} */
/* {block 'content'} */
class Block_232555da73aeaf1a6f4_81260025 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_232555da73aeaf1a6f4_81260025',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<div class="row">
    <div class="col-md-12">
        <div class="portlet light">
            <div class="portlet-title">
                <div class="caption font-blue"><i class="fa fa-filter font-blue"></i> <?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2947');?>
</div>
                <div class="tools"><a href="#" class="collapse"></a></div>
            </div>
            <div class="portlet-body">
                <form id="frmFilter">
                    <div class="row">
                        <div class="col-md-3">
                            <div class="form-group">
                                <input type="text" data-ng-model="objFilter.strUserName" name="txtUserName" class="form-control" placeholder="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2948');?>
">
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <input type="text" data-ng-model="objFilter.strDisplayName" name="txtUserDisplayName" class="form-control" placeholder="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2949');?>
">
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <input type="text" data-ng-model="objFilter.strEmail" name="txtEmail" class="form-control" placeholder="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2950');?>
">
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <select data-ng-model="objFilter.intUserLevelID" name="cmbUserLevel" class="form-control" data-ng-options="obj.intID as obj.strUserLevel for obj in arrUserLevels">
                                    <option value=""><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2952');?>
</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group pull-right">
                                <button type="button" class="btn blue" title="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2953');?>
" data-ng-click="filter()"><i class="fa fa-filter"></i> <?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2953');?>
</button>
                                <button type="button" class="btn red-thunderbird" title="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2954');?>
" data-ng-click="reset()"><i class="fa fa-refresh"></i> <?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2954');?>
</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-12">
        <div class="portlet light">
            <div class="portlet-title">
                <div class="caption font-blue"><i class="fa fa-list font-blue"></i> <?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2955');?>
</div>
                <pagination data-ng-if="objUsers.arrData.length>0"  data-total-items="objUsers.intTotal" data-items-per-page="objPaging.intPageSize" data-ng-model="objPaging.intPageNo" data-max-size="objPaging.intMaxSize" class="pagination-sm" data-boundary-links="true" data-ng-change="nextPage()"></pagination>
            </div>
            <div class="portlet-body">
                <div data-ng-if="objUsers.arrData.length > 0" class="table-responsive">
                    <table class="table table-condensed table-light table-hover">
                        <thead>
                            <tr>
                                <th><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2956');?>
</th>
                                <th><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2957');?>
</th>
                                <th><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2958');?>
</th>
                                <th width="5%">&nbsp;</th>
                                <?php if (in_array(\NsCMN\ClsBllUserPermission::PERMISSION_EDIT,$_smarty_tpl->tpl_vars['_UserPermission']->value)) {?>
                                    <th width="5%">&nbsp;</th>
                                <?php }?>
                                <?php if (in_array(\NsCMN\ClsBllUserPermission::PERMISSION_DELETE,$_smarty_tpl->tpl_vars['_UserPermission']->value)) {?>
                                    <th width="5%">&nbsp;</th>
                                <?php }?>
                            </tr>
                        </thead>
                        <tbody>
                            <tr data-ng-repeat="objUser in objUsers.arrData" data-ng-class="{'striped':objUser.intDisabled == 1}">
                                <td>{{objUser.strUserName}}</td>
                                <td>{{objUser.strDisplayName}}</td>
                                <td>{{objUser.strEmail}}</td>
                                <td class="icon">
                                    <a data-ng-click="viewDetails(objUser.intID)" data-toggle="modal" href="#dlgDetails" class="btn btn-xs yellow-saffron" title="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2960');?>
">
                                        <i class="fa fa-search-plus"></i> <span class="visible-lg-inline-block"></span>
                                    </a>
                                </td>
                                <?php if (in_array(\NsCMN\ClsBllUserPermission::PERMISSION_EDIT,$_smarty_tpl->tpl_vars['_UserPermission']->value)) {?>
                                <td class="icon">
                                    <a data-ng-if="objUser.intID!=1" href="index.php?module=cmn&page=User&action=Edit&user_id={{objUser.intID}}" class="btn btn-xs btn-info" title="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2961');?>
"><i class="fa fa-edit"></i> <span class="visible-lg-inline-block"></span></a>
                                </td>
                                <?php }?>
                                <?php if (in_array(\NsCMN\ClsBllUserPermission::PERMISSION_DELETE,$_smarty_tpl->tpl_vars['_UserPermission']->value)) {?>
                                <td class="icon">
                                    <a data-ng-if="objUser.intDisabled == 0 && objUser.intID!=1" data-ng-click="deleteUser(objUser.intID,$index)" class="btn btn-danger btn-xs" title="Delete"><i class="fa fa-trash-o"></i> <span class="visible-lg-inline-block"></span></a>
                                    <a data-ng-if="objUser.intDisabled == 1 && objUser.intID!=1" data-ng-click="enable(objUser.intID,$index)" class="btn btn-success btn-xs" title="Enable"><i class="fa fa-check"></i> <span class="visible-lg-inline-block"></span></a>
                                </td>
                                <?php }?>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div data-ng-if="objUsers.arrData.length == 0" class="alert alert-warning">
                    <p><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2962');?>
</p>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
}
}
/* {/block 'content'} */
}
