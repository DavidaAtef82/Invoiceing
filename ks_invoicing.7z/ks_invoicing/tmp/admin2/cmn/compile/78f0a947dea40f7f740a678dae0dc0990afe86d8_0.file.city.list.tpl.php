<?php
/* Smarty version 3.1.31, created on 2019-10-14 13:30:45
  from "D:\www\ks_invoicing\modules\cmn\view\templates\pages\city.list.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5da45c6564df24_83882740',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '78f0a947dea40f7f740a678dae0dc0990afe86d8' => 
    array (
      0 => 'D:\\www\\ks_invoicing\\modules\\cmn\\view\\templates\\pages\\city.list.tpl',
      1 => 1570532937,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5da45c6564df24_83882740 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_306425da45c65623185_53359708', 'app');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_253475da45c65624812_42888863', 'controller');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_170245da45c656256e0_09207421', 'style');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_1855da45c65629996_77267724', 'script');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_238065da45c6562d550_53158072', 'dialog');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_113595da45c6562e3a3_43888523', 'page_title');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_17085da45c656300d2_21216599', 'toolbar');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_285335da45c65630ee8_90283481', 'content');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, ((string)@constant('LOCAL__THEME'))."/template/masters/master1/master.tpl");
}
/* {block 'app'} */
class Block_306425da45c65623185_53359708 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'app' => 
  array (
    0 => 'Block_306425da45c65623185_53359708',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    data-ng-app="CMN"
<?php
}
}
/* {/block 'app'} */
/* {block 'controller'} */
class Block_253475da45c65624812_42888863 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'controller' => 
  array (
    0 => 'Block_253475da45c65624812_42888863',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

     data-ng-controller="City" 
<?php
}
}
/* {/block 'controller'} */
/* {block 'style'} */
class Block_170245da45c656256e0_09207421 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'style' => 
  array (
    0 => 'Block_170245da45c656256e0_09207421',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <link rel="stylesheet" type="text/css" href="<?php echo @constant('WEB__THEME');?>
/css/pages/todo.css"/>
<?php
}
}
/* {/block 'style'} */
/* {block 'script'} */
class Block_1855da45c65629996_77267724 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'script' => 
  array (
    0 => 'Block_1855da45c65629996_77267724',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('PATH__JS');?>
/common.angular.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('PATH__JS');?>
/city.list.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
<?php
}
}
/* {/block 'script'} */
/* {block 'dialog'} */
class Block_238065da45c6562d550_53158072 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'dialog' => 
  array (
    0 => 'Block_238065da45c6562d550_53158072',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php
}
}
/* {/block 'dialog'} */
/* {block 'page_title'} */
class Block_113595da45c6562e3a3_43888523 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'page_title' => 
  array (
    0 => 'Block_113595da45c6562e3a3_43888523',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <h1><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2964');?>
 <small><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2965');?>
</small></h1>
<?php
}
}
/* {/block 'page_title'} */
/* {block 'toolbar'} */
class Block_17085da45c656300d2_21216599 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'toolbar' => 
  array (
    0 => 'Block_17085da45c656300d2_21216599',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php
}
}
/* {/block 'toolbar'} */
/* {block 'content'} */
class Block_285335da45c65630ee8_90283481 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_285335da45c65630ee8_90283481',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <div class="row">
        <div class="col-md-4">
            <div class="portlet light">
                <div class="portlet-title">
                    <div class="caption" data-toggle="collapse" data-target=".todo-project-list-content">
                        <span class="caption-subject font-blue bold uppercase"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2964');?>
</span>
                        <span class="caption-helper visible-sm-inline-block visible-xs-inline-block"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2965');?>
</span>
                    </div>
                </div>
                <div class="portlet-body">
                    <?php if (in_array(\NsCMN\ClsBllUserPermission::PERMISSION_ADD,$_smarty_tpl->tpl_vars['_UserPermission']->value)) {?>
                        <form name="frmCity">
                            <div class="input-group margin-bottom-10"> 
                                <input type="text" name="txtCity" data-ng-model="objNewCity.strCity" placeholder="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2964');?>
" class="form-control" required="required">
                                <span class="input-group-btn">
                                    <button class="btn blue" data-ng-disabled="frmCity.$invalid" data-ng-click="addCity()" ><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2968');?>
</button>
                                </span> 
                            </div>
                        </form>
                    <?php }?>
                    <div class="scroller" style="height:400px">
                        <div class="todo-project-list">
                            <ul class="nav nav-pills nav-stacked">
                                <li data-ng-repeat="objCity in arrCities" data-ng-class=" {'active':objCity.intID==objCurrentCity.intID}">
                                    <a href="#" data-ng-click="listDistrict(objCity)" title="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2969');?>
">
                                        <i class="fa fa-map-marker"></i><span>{{objCity.strCity}}</span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-8" data-ng-if="objCurrentCity!=null">
            <div class="portlet light">
                <div class="portlet-title">
                    <div class="caption">{{objCurrentCity.strCity}}</div>
                    <?php if (in_array(\NsCMN\ClsBllUserPermission::PERMISSION_DELETE,$_smarty_tpl->tpl_vars['_UserPermission']->value)) {?>
                        <div class="actions">
                            <a href="#" class="btn btn-circle red-thunderbird" data-ng-click="deleteCity()" title="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2970');?>
">
                                <i class="fa fa-trash-o"></i> <span class="visible-lg-inline-block"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2970');?>
</span>
                            </a>
                        </div>
                    <?php }?>
                </div>
                <div class="portlet-body">
                    <?php if (in_array(\NsCMN\ClsBllUserPermission::PERMISSION_ADD,$_smarty_tpl->tpl_vars['_UserPermission']->value)) {?>
                        <form name="frmDistrict">
                            <div class="input-group margin-bottom-10"> 
                                <input type="text" name="txtDistrict" data-ng-model="objNewDistrict.strDistrict" placeholder="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2971');?>
" class="form-control" required="required">
                                <span class="input-group-btn">
                                    <button class="btn blue" data-ng-disabled="frmDistrict.$invalid" data-ng-click="addDistrict()" ><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2972');?>
</button>
                                </span> 
                            </div>
                        </form>
                    <?php }?>
                    <div data-ng-show="objCurrentCity.arrDistricts.length>0">
                        <table name="tblDistrict" class="table table-bordered table-hover table-striped">
                            <thead>
                                <tr>
                                    <th><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2971');?>
</th>
                                    <?php if (in_array(\NsCMN\ClsBllUserPermission::PERMISSION_DELETE,$_smarty_tpl->tpl_vars['_UserPermission']->value)) {?>
                                        <th>&nbsp;</th>
                                    <?php }?>
                                </tr>
                            </thead>
                            <tbody>
                                <tr data-ng-repeat="objDistrict in objCurrentCity.arrDistricts">
                                    <td>{{objDistrict.strDistrict}}</td>
                                    <?php if (in_array(\NsCMN\ClsBllUserPermission::PERMISSION_DELETE,$_smarty_tpl->tpl_vars['_UserPermission']->value)) {?>
                                        <td class="icon">                                                
                                            <button data-ng-click="deleteDistrict(objDistrict.intID, $index)" class="btn btn-danger btn-xs" title="Delete"><i class="fa fa-trash-o"></i> <?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2973');?>
</button>
                                        </td>
                                    <?php }?>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div data-ng-show="objCurrentCity.arrDistricts.length==0">
                        <?php $_smarty_tpl->_subTemplateRender(((string)@constant('LOCAL__THEME__BLOCKS'))."/messagebox.small.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('ID'=>"pnlMsgWarning",'Type'=>"Warning",'Message'=>((string)$_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2974'))), 0, true);
?>

                    </div>
                </div>
            </div>
        </div>
    </div>
    
<?php
}
}
/* {/block 'content'} */
}
