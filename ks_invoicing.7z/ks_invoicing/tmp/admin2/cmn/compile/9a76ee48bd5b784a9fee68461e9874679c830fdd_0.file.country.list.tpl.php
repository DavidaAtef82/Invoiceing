<?php
/* Smarty version 3.1.31, created on 2019-10-16 17:27:39
  from "D:\www\ks_invoicing\modules\cmn\view\templates\pages\country.list.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5da736eb004f28_49301238',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '9a76ee48bd5b784a9fee68461e9874679c830fdd' => 
    array (
      0 => 'D:\\www\\ks_invoicing\\modules\\cmn\\view\\templates\\pages\\country.list.tpl',
      1 => 1570627472,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5da736eb004f28_49301238 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_116935da736eaf22176_72755989', 'app');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_227545da736eaf237c5_53597844', 'controller');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_257155da736eaf246a7_80844474', 'style');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_325605da736eaf28a17_80715091', 'script');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_306335da736eaf2c163_20924309', 'dialog');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_84945da736eaf2cf40_36160566', 'page_title');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_217115da736eaf2ec42_05782535', 'toolbar');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_241565da736eaf2fa06_37948172', 'content');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, ((string)@constant('LOCAL__THEME'))."/template/masters/master1/master.tpl");
}
/* {block 'app'} */
class Block_116935da736eaf22176_72755989 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'app' => 
  array (
    0 => 'Block_116935da736eaf22176_72755989',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

data-ng-app="CMN"
<?php
}
}
/* {/block 'app'} */
/* {block 'controller'} */
class Block_227545da736eaf237c5_53597844 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'controller' => 
  array (
    0 => 'Block_227545da736eaf237c5_53597844',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

data-ng-controller="Country" 
<?php
}
}
/* {/block 'controller'} */
/* {block 'style'} */
class Block_257155da736eaf246a7_80844474 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'style' => 
  array (
    0 => 'Block_257155da736eaf246a7_80844474',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<link rel="stylesheet" type="text/css" href="<?php echo @constant('WEB__THEME');?>
/css/pages/todo.css"/>
<?php
}
}
/* {/block 'style'} */
/* {block 'script'} */
class Block_325605da736eaf28a17_80715091 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'script' => 
  array (
    0 => 'Block_325605da736eaf28a17_80715091',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('PATH__JS');?>
/common.angular.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('PATH__JS');?>
/country.list.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
<?php
}
}
/* {/block 'script'} */
/* {block 'dialog'} */
class Block_306335da736eaf2c163_20924309 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'dialog' => 
  array (
    0 => 'Block_306335da736eaf2c163_20924309',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php
}
}
/* {/block 'dialog'} */
/* {block 'page_title'} */
class Block_84945da736eaf2cf40_36160566 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'page_title' => 
  array (
    0 => 'Block_84945da736eaf2cf40_36160566',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<h1><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2964');?>
 <small><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2965');?>
</small></h1>
<?php
}
}
/* {/block 'page_title'} */
/* {block 'toolbar'} */
class Block_217115da736eaf2ec42_05782535 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'toolbar' => 
  array (
    0 => 'Block_217115da736eaf2ec42_05782535',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php
}
}
/* {/block 'toolbar'} */
/* {block 'content'} */
class Block_241565da736eaf2fa06_37948172 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_241565da736eaf2fa06_37948172',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<div class="row">
    <div class="col-md-4">
        <div class="portlet light">
            <div class="portlet-title">
                <div class="caption" data-toggle="collapse" data-target=".todo-project-list-content">
                    <span class="caption-subject font-blue bold uppercase"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2964');?>
</span>
                    <span class="caption-helper visible-sm-inline-block visible-xs-inline-block"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2965');?>
</span>
                </div>
            </div>
            <div class="portlet-body">
                <?php if (in_array(\NsCMN\ClsBllUserPermission::PERMISSION_ADD,$_smarty_tpl->tpl_vars['_UserPermission']->value)) {?>
                <form name="frmCountry">
                    <div class="input-group margin-bottom-10"> 
                        <input type="text" name="txtCountry" data-ng-model="objNewCountry.strCountry" placeholder="Country" class="form-control" required="required">
                        <span class="input-group-btn">
                            <button class="btn blue" data-ng-disabled="frmCountry.$invalid" data-ng-click="addCountry()">ADD</button>
                        </span> 
                    </div>
                </form>
                <?php }?>
                <div class="scroller" style="height:400px">
                    <div class="todo-project-list">
                        <ul class="nav nav-pills nav-stacked">
                            <li data-ng-repeat="objCountry in arrCountries" data-ng-class=" {'active':objCountry.intID==objCurrentCountry.intID}">
                                <a href="#" data-ng-click="listCity(objCountry,$index)" title="objCountry.strCountry">
                                    <i class="fa fa-map-marker"></i><span>{{objCountry.strCountry}}</span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-md-8" data-ng-if="objCurrentCountry!=null">
        <div class="portlet light">
            <div class="portlet-title">
                <div class="caption">{{objCurrentCountry.strCountry}}</div>
                <div class="actions">
                    <?php if (in_array(\NsCMN\ClsBllUserPermission::PERMISSION_EDIT,$_smarty_tpl->tpl_vars['_UserPermission']->value)) {?>
                    <a href="#" class="btn btn-primary btn-info" data-ng-click="editCountry()" title="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2970');?>
">
                        <i class="fa fa-edit"></i> <span class="visible-lg-inline-block">Edit Country</span>
                    </a>
                    <?php }?>
                    <?php if (in_array(\NsCMN\ClsBllUserPermission::PERMISSION_DELETE,$_smarty_tpl->tpl_vars['_UserPermission']->value)) {?>
                    <a href="#" class="btn red-thunderbird" data-ng-click="deleteCountry()" title="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2970');?>
">
                        <i class="fa fa-trash-o"></i> <span class="visible-lg-inline-block">Delete Country</span>
                    </a>
                    <?php }?>
                </div>
            </div>
            <div class="portlet-body">
                <?php if (in_array(\NsCMN\ClsBllUserPermission::PERMISSION_ADD,$_smarty_tpl->tpl_vars['_UserPermission']->value)) {?>
                <form name="frmCity">
                    <div class="input-group margin-bottom-10"> 
                        <input type="text" name="txtCity" data-ng-model="objNewCity.strCity" placeholder="City" class="form-control" required="required">
                        <span class="input-group-btn">
                            <button class="btn blue" data-ng-disabled="frmCity.$invalid" data-ng-click="addCity()" >ADD</button>
                        </span> 
                    </div>
                </form>
                <?php }?>
                <div data-ng-show="objCurrentCountry.arrCities.length>0">
                    <table name="tblCity" class="table table-bordered table-hover table-striped">
                        <thead>
                        </thead>
                        <tbody>
                            <tr data-ng-repeat="objCity in objCurrentCountry.arrCities">
                                <td>{{objCity.strCity }}</td>
                                <?php if (in_array(\NsCMN\ClsBllUserPermission::PERMISSION_EDIT,$_smarty_tpl->tpl_vars['_UserPermission']->value)) {?>
                                <td class="icon">                                                
                                    <button data-ng-click="editCity(objCity, $index)" class="btn btn-xs btn-info" title="Edit"><i class="fa fa-edit"></i> Edit City</button>
                                    <?php }?>
                                    <?php if (in_array(\NsCMN\ClsBllUserPermission::PERMISSION_DELETE,$_smarty_tpl->tpl_vars['_UserPermission']->value)) {?>                                                                     
                                    <button data-ng-click="deleteCity(objCity.intID, $index)" class="btn btn-xs btn-danger" title="Delete"><i class="fa fa-trash-o"></i> Delete City</button>
                                    <?php }?>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div data-ng-show="objCurrentCountry.arrCities.length==0">
                    <?php $_smarty_tpl->_subTemplateRender(((string)@constant('LOCAL__THEME__BLOCKS'))."/messagebox.small.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('ID'=>"pnlMsgWarning",'Type'=>"Warning",'Message'=>"No Cities"), 0, true);
?>

                </div>
            </div>
        </div>
    </div>

    <div id="dlgEditCountry" class="modal fade modal-dialog" tabindex="-1" data-width="500" style="display: none;">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            <h3 class="modal-title">Edit {{objCurrentCountry.strCountry}}</h3>
        </div>
        <div class="modal-body">  
            <form name="frmEditCountry">
                <div class="row">
                    <div class="col-md-12">
                        <label>Country Name</label>
                        <input type="text" name="txtEditCountry" class="form-control" required="required" data-ng-change ="isDisableCountryUpdate=false" data-ng-model="NewCountry" data-ng-value="objCurrentCountry.strCountry"/>
                    </div>
                </div>
            </form>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn blue" data-ng-init = "isDisableCountryUpdate=true" data-ng-disabled="frmEditCountry.$invalid || isDisableCountryUpdate" data-ng-click="updateCountry(NewCountry)">Update</button>
            <button type="button" data-dismiss="modal" class="btn btn-danger">Cancel</button>
        </div>
    </div>
    
    <div id="dlgEditCity" class="modal fade modal-dialog" tabindex="-1" data-width="500" style="display: none;">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            <h3 class="modal-title">Edit {{objSelectedCity.strCity}}</h3>
        </div>
        <div class="modal-body">  
            <form name="frmEditCity">
                <div class="row">
                    <div class="col-md-12">
                        <label>City Name</label>
                        <input type="text" name="txtEditCity" class="form-control" required="required" data-ng-change ="isDisableCityUpdate=false" data-ng-model="NewCity" data-ng-value="objSelectedCity.strCity"/>
                    </div>
                </div>
            </form>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn blue"  data-ng-init = "isDisableCityUpdate=true" data-ng-disabled="frmEditCity.$invalid || isDisableCityUpdate" data-ng-click="updateCity(NewCity)">Update</button>
            <button type="button" data-dismiss="modal" class="btn btn-danger">Cancel</button>
        </div>
    </div>

    </div>
    
<?php
}
}
/* {/block 'content'} */
}
