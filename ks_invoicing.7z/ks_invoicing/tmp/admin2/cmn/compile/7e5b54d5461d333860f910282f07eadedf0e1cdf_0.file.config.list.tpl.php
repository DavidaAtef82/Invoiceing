<?php
/* Smarty version 3.1.31, created on 2019-10-14 10:29:08
  from "D:\www\ks_invoicing\modules\cmn\view\templates\pages\config.list.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5da431d49d7e90_38886705',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '7e5b54d5461d333860f910282f07eadedf0e1cdf' => 
    array (
      0 => 'D:\\www\\ks_invoicing\\modules\\cmn\\view\\templates\\pages\\config.list.tpl',
      1 => 1570523806,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5da431d49d7e90_38886705 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_285925da431d49b9c55_89242339', 'app');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_241055da431d49bb786_20580136', 'controller');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_178385da431d49bc708_10930722', 'lang');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_243995da431d49bd750_59205627', 'style');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_222365da431d49c2508_89062748', 'script');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_132855da431d49c62f5_96198780', 'dialog');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_37705da431d49c71a0_80933331', 'page_title');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_85555da431d49c8e19_62335260', 'toolbar');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_12245da431d49ca2c0_65167465', 'content');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, ((string)@constant('LOCAL__THEME'))."/template/masters/master1/master.tpl");
}
/* {block 'app'} */
class Block_285925da431d49b9c55_89242339 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'app' => 
  array (
    0 => 'Block_285925da431d49b9c55_89242339',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    data-ng-app="CMN"
<?php
}
}
/* {/block 'app'} */
/* {block 'controller'} */
class Block_241055da431d49bb786_20580136 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'controller' => 
  array (
    0 => 'Block_241055da431d49bb786_20580136',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    data-ng-controller="Config" 
<?php
}
}
/* {/block 'controller'} */
/* {block 'lang'} */
class Block_178385da431d49bc708_10930722 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'lang' => 
  array (
    0 => 'Block_178385da431d49bc708_10930722',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
}
}
/* {/block 'lang'} */
/* {block 'style'} */
class Block_243995da431d49bd750_59205627 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'style' => 
  array (
    0 => 'Block_243995da431d49bd750_59205627',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <link rel="stylesheet" type="text/css" href="<?php echo @constant('WEB__THEME');?>
/css/pages/todo.css"/>
<?php
}
}
/* {/block 'style'} */
/* {block 'script'} */
class Block_222365da431d49c2508_89062748 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'script' => 
  array (
    0 => 'Block_222365da431d49c2508_89062748',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('PATH__JS');?>
/common.angular.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>    
    <?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('PATH__JS');?>
/config.list.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>    
<?php
}
}
/* {/block 'script'} */
/* {block 'dialog'} */
class Block_132855da431d49c62f5_96198780 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'dialog' => 
  array (
    0 => 'Block_132855da431d49c62f5_96198780',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
}
}
/* {/block 'dialog'} */
/* {block 'page_title'} */
class Block_37705da431d49c71a0_80933331 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'page_title' => 
  array (
    0 => 'Block_37705da431d49c71a0_80933331',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <h1><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2061');?>
 <small><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2062');?>
</small></h1>
<?php
}
}
/* {/block 'page_title'} */
/* {block 'toolbar'} */
class Block_85555da431d49c8e19_62335260 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'toolbar' => 
  array (
    0 => 'Block_85555da431d49c8e19_62335260',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <div class="btn-group pull-right">
        <a href="#" class="btn btn-fit-height btn-success" data-ng-click="reloadLanguage()">
            <i class="fa fa-refresh"></i> <span class="visible-lg-inline-block"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2059');?>
</span>
        </a>
    </div>
<?php
}
}
/* {/block 'toolbar'} */
/* {block 'content'} */
class Block_12245da431d49ca2c0_65167465 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_12245da431d49ca2c0_65167465',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <div class="row" data-ng-if="arrConfigs.length > 0">
        <div class="col-md-3">
            <div class="portlet light">
                <div class="portlet-title">
                    <div class="caption">
                        <span class="caption-subject font-blue bold uppercase"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2066');?>
</span>
                        <span class="caption-helper visible-sm-inline-block visible-xs-inline-block">List</span>
                    </div>
                </div>
                <div class="portlet-body todo-project-list-content" style="height: auto;">
                    <div class="scroller" style="height:500px">
                        <div class="todo-project-list">
                            <ul class="nav nav-pills nav-stacked">
                                <li ng-repeat="objModule in arrModules" data-ng-class="{'active':$first}">
                                    <a data-toggle="tab" href="#" data-ng-click="listSections(objModule)" title="List Sections">
                                        <i class="fa fa-list"></i> <span>{{objModule.strTitle}}</span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-9">
             <div class="portlet light">
                <div class="portlet-title">
                    <div class="caption"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2065');?>
</div>
                </div>
                <div class="portlet-body">
                    <div class="panel-group accordion-custom accordion-teal" id="accordion">
                        <div data-ng-repeat="strSection in arrSections" class="panel panel-default">
                            <div class="panel-heading">
                                <h4 class="panel-title">
                                    <a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion" href="#tb_{{strSection}}">
                                        <i class="fa fa-chevron-right"></i> {{strSection}}
                                    </a>
                                </h4>
                            </div>
                            <div id="tb_{{strSection}}" class="panel-collapse collapse">
                                <div class="panel-body">
                                    <div class="table-responsive" data-ng-repeat="objSection in arrConfigs" data-ng-if="objSection.section==strSection">
                                        <table class="table table-light table-full-width table-condensed table-hover">
                                            <thead>
                                                <tr>
                                                    <th class="text-right"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2067');?>
</th>    
                                                    <th class="text-left"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2068');?>
</th>          
                                                </tr>    
                                            </thead>
                                            <tbody>
                                                <tr data-ng-repeat="objItem in objSection.items" data-ng-if="objItem.intModuleID == intCurrentModuleID">
                                                    <td class="text-right" width="50%">
                                                        {{objItem.strCaption}}
                                                        <span data-ng-if="objItem.strComments != ''">
                                                            <br/>
                                                            <small class="text-muted">{{objItem.strComments}}</small>
                                                        </span>
                                                    </td>
                                                    <td>
                                                        <?php if (in_array(\NsCMN\ClsBllUserPermission::PERMISSION_EDIT,$_smarty_tpl->tpl_vars['_UserPermission']->value)) {?>
                                                            <a e-value='{{objItem.strConfigValue}}' onbeforesave="validate(objItem.intIsOptional, $data)" editable-text="objItem.strConfigValue" onaftersave="update(objItem)" ng-model="objItem.strConfigValue">
                                                                {{objItem.strConfigValue|| 'Empty'}}
                                                            </a>
                                                        <?php } else { ?>
                                                            <span data-ng-if="objItem.strConfigValue == ''"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2071');?>
</span>
                                                            <span data-ng-if="objItem.strConfigValue != ''">{{objItem.strConfigValue}}</span>
                                                        <?php }?>
                                                    </td>                               
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>         
    </div>
 
<?php
}
}
/* {/block 'content'} */
}
