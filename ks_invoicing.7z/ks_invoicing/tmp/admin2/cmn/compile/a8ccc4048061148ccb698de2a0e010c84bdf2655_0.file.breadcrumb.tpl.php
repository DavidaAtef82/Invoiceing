<?php
/* Smarty version 3.1.31, created on 2019-10-14 10:29:08
  from "D:\www\ks_invoicing\themes\admin2\template\components\breadcrumb.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5da431d4b85e73_85742311',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a8ccc4048061148ccb698de2a0e010c84bdf2655' => 
    array (
      0 => 'D:\\www\\ks_invoicing\\themes\\admin2\\template\\components\\breadcrumb.tpl',
      1 => 1570523812,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5da431d4b85e73_85742311 (Smarty_Internal_Template $_smarty_tpl) {
?>
<ul class="page-breadcrumb breadcrumb">
    <?php
$_smarty_tpl->tpl_vars['startIndex'] = new Smarty_Variable(null, $_smarty_tpl->isRenderingCache);$_smarty_tpl->tpl_vars['startIndex']->step = 1;$_smarty_tpl->tpl_vars['startIndex']->total = (int) ceil(($_smarty_tpl->tpl_vars['startIndex']->step > 0 ? count($_smarty_tpl->tpl_vars['_BreadcrumbItems']->value)-1+1 - (0) : 0-(count($_smarty_tpl->tpl_vars['_BreadcrumbItems']->value)-1)+1)/abs($_smarty_tpl->tpl_vars['startIndex']->step));
if ($_smarty_tpl->tpl_vars['startIndex']->total > 0) {
for ($_smarty_tpl->tpl_vars['startIndex']->value = 0, $_smarty_tpl->tpl_vars['startIndex']->iteration = 1;$_smarty_tpl->tpl_vars['startIndex']->iteration <= $_smarty_tpl->tpl_vars['startIndex']->total;$_smarty_tpl->tpl_vars['startIndex']->value += $_smarty_tpl->tpl_vars['startIndex']->step, $_smarty_tpl->tpl_vars['startIndex']->iteration++) {
$_smarty_tpl->tpl_vars['startIndex']->first = $_smarty_tpl->tpl_vars['startIndex']->iteration == 1;$_smarty_tpl->tpl_vars['startIndex']->last = $_smarty_tpl->tpl_vars['startIndex']->iteration == $_smarty_tpl->tpl_vars['startIndex']->total;?>
        <li>
            <?php if ($_smarty_tpl->tpl_vars['startIndex']->value == 0) {?>
                <i class="fa fa-home"></i>
            <?php } else { ?>
                <i></i>
            <?php }?>
            
            <?php if ($_smarty_tpl->tpl_vars['startIndex']->value == count($_smarty_tpl->tpl_vars['_BreadcrumbItems']->value)-1) {?>
                <a href="#"><?php echo $_smarty_tpl->tpl_vars['_BreadcrumbItems']->value[$_smarty_tpl->tpl_vars['startIndex']->value]['strText'];?>
</a>
            <?php } else { ?>
                <a href=<?php echo $_smarty_tpl->tpl_vars['_BreadcrumbItems']->value[$_smarty_tpl->tpl_vars['startIndex']->value]['strURL'];?>
><?php echo $_smarty_tpl->tpl_vars['_BreadcrumbItems']->value[$_smarty_tpl->tpl_vars['startIndex']->value]['strText'];?>
</a>
            <?php }?>
            
            <?php if ($_smarty_tpl->tpl_vars['startIndex']->value != count($_smarty_tpl->tpl_vars['_BreadcrumbItems']->value)-1) {?>
                <?php if ($_smarty_tpl->tpl_vars['_Direction']->value == 'rtl') {?>
                    <i class="fa fa-angle-left"></i>
                <?php } else { ?>
                    <i class="fa fa-angle-right"></i>
                <?php }?>
            <?php } else { ?>
                <i></i>
            <?php }?>
        </li>
    <?php }
}
?>

</ul><?php }
}
