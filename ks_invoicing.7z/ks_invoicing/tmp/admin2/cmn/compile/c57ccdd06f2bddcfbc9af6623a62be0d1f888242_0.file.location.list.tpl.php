<?php
/* Smarty version 3.1.31, created on 2019-10-16 17:27:27
  from "D:\www\ks_invoicing\modules\cmn\view\templates\pages\location.list.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5da736dfa50851_24347229',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c57ccdd06f2bddcfbc9af6623a62be0d1f888242' => 
    array (
      0 => 'D:\\www\\ks_invoicing\\modules\\cmn\\view\\templates\\pages\\location.list.tpl',
      1 => 1570523806,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5da736dfa50851_24347229 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_25855da736dfa1d9c8_92519649', 'app');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_68785da736dfa1f216_79835481', 'controller');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_175995da736dfa20225_77152505', 'style');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_101245da736dfa210a9_66343761', 'script');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_119895da736dfa27bd0_38105681', 'dialog');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_17705da736dfa2ed43_08229987', 'page_title');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_281235da736dfa307d3_35135551', 'toolbar');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_124085da736dfa38d18_81869658', 'content');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, ((string)@constant('LOCAL__THEME'))."/template/masters/master1/master.tpl");
}
/* {block 'app'} */
class Block_25855da736dfa1d9c8_92519649 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'app' => 
  array (
    0 => 'Block_25855da736dfa1d9c8_92519649',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    data-ng-app="CMN"
<?php
}
}
/* {/block 'app'} */
/* {block 'controller'} */
class Block_68785da736dfa1f216_79835481 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'controller' => 
  array (
    0 => 'Block_68785da736dfa1f216_79835481',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

     data-ng-controller="Location" 
<?php
}
}
/* {/block 'controller'} */
/* {block 'style'} */
class Block_175995da736dfa20225_77152505 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'style' => 
  array (
    0 => 'Block_175995da736dfa20225_77152505',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
}
}
/* {/block 'style'} */
/* {block 'script'} */
class Block_101245da736dfa210a9_66343761 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'script' => 
  array (
    0 => 'Block_101245da736dfa210a9_66343761',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('PATH__JS');?>
/common.angular.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>   
<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('PATH__JS');?>
/location.list.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>   
<?php
}
}
/* {/block 'script'} */
/* {block 'dialog'} */
class Block_119895da736dfa27bd0_38105681 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'dialog' => 
  array (
    0 => 'Block_119895da736dfa27bd0_38105681',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <div id="dlgAddLocation" class="modal fade modal-dialog" tabindex="-1" data-width="600" style="display: none;">
        <div class="modal-header">
            <button type="button" class="close" data-ng-click="resetAdd()" data-dismiss="modal" aria-hidden="true">×</button>
            <h3 class="modal-title"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2977');?>
</h3>
        </div>
        <div class="modal-body">  
            <form name="frmAddLocation">
                <div class="row">
                    <div class="col-md-6">
                        <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2978');?>
</label>
                        <input type="text" name="txtAddLocationName" class="form-control" required="required" data-ng-model="objAddLocation.strName"/>
                    </div>
                    <div class="col-md-6">
                        <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2979');?>
</label>
                        <input type="text" name="txtAddLocationPhone" class="form-control" required="required" data-ng-model="objAddLocation.strPhone"/>
                    </div>
                </div>
                <div class="row margin-top-10">
                    <div class="col-md-6">
                        <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2980');?>
</label>
                        <select name="cmbAddLocationCity" class="form-control" required="required" data-ng-model="objAddLocation.intCityID" data-ng-options="objCity.intID as objCity.strCity for objCity in arrCities">
                            <option value=""><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2981');?>
</option>
                        </select>                        
                    </div>
                    <div class="col-md-6">
                        <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2982');?>
</label>
                        <select name="cmbAddLocationCity" class="form-control" required="required" data-ng-model="objAddLocation.intDistrictID" data-ng-options="objDistrict.intID as objDistrict.strDistrict for objDistrict in arrDistrictsInCity">
                            <option value=""><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2983');?>
</option>
                        </select>                        
                    </div>
                </div>
                <div class="row margin-top-10">
                    <div class="col-md-6">
                        <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2984');?>
</label>
                        <input type="text" name="txtAddLocationLongitude" class="form-control" required="required" data-ng-model="objAddLocation.strLongitude"/>
                    </div>
                    <div class="col-md-6">
                        <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2985');?>
</label>
                        <input type="text" name="txtAddLocationLatitude" class="form-control" required="required" data-ng-model="objAddLocation.strLatitude"/>
                    </div>
                </div>
                <div class="row margin-top-10">
                    <div class="col-md-12">
                        <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2986');?>
</label>
                        <input type="text" name="txtAddLocation" class="form-control" required="required"  data-ng-model="objAddLocation.strAddress"/>
                    </div>
                </div>
                <div class="row margin-top-10">
                    <div class="col-md-12">
                        <label><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2988');?>
</label>
                        <textarea name="txtAddLocationNotes" data-ng-model="objAddLocation.strNotes" placeholder="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2989');?>
" class="form-control"></textarea>
                    </div>
                </div>
            </form>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn green" data-ng-disabled="frmAddLocation.$invalid" data-ng-click="add()"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2990');?>
</button>
            <button type="button" data-dismiss="modal" class="btn red" data-ng-click="resetAdd()"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2991');?>
</button>
        </div>
    </div>
<?php
}
}
/* {/block 'dialog'} */
/* {block 'page_title'} */
class Block_17705da736dfa2ed43_08229987 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'page_title' => 
  array (
    0 => 'Block_17705da736dfa2ed43_08229987',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <h1><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2992');?>
 <small><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_3006');?>
</small></h1>
<?php
}
}
/* {/block 'page_title'} */
/* {block 'toolbar'} */
class Block_281235da736dfa307d3_35135551 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'toolbar' => 
  array (
    0 => 'Block_281235da736dfa307d3_35135551',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <?php if (in_array(\NsCMN\ClsBllUserPermission::PERMISSION_ADD,$_smarty_tpl->tpl_vars['_UserPermission']->value)) {?>
        <div class="btn-group pull-right">
            <a data-toggle="modal" href="#dlgAddLocation" class="btn btn-fit-height btn-success" title="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2993');?>
">
                <i class="fa fa-plus"></i> 
                <span class="visible-lg-inline-block"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2993');?>
</span>
            </a>
        </div>
    <?php }
}
}
/* {/block 'toolbar'} */
/* {block 'content'} */
class Block_124085da736dfa38d18_81869658 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_124085da736dfa38d18_81869658',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <div class="row">
        <div class="col-md-12">
            <div class="portlet light">
                <div class="portlet-title"> 
                    <div class="caption"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2997');?>
</div>
                </div>
                <div class="portlet-body">
                    <table class="table table-striped table-bordered table-condensed table-hover table-responsive">
                        <thead>
                            <tr>
                                <th><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2998');?>
</th>
                                <th class="text-left"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_2999');?>
</th>
                                <th class="text-left"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_3000');?>
</th>
                                <th class="text-center" title="Longitude"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_3001');?>
</th>
                                <th class="text-center" title="Latitude"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_3002');?>
</th>
                                <th class="text-left"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_3003');?>
</th>
                                <th class="text-left"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_3005');?>
</th>
                                <?php if (in_array(\NsCMN\ClsBllUserPermission::PERMISSION_DELETE,$_smarty_tpl->tpl_vars['_UserPermission']->value)) {?>
                                    <th>&nbsp;</th>
                                <?php }?>
                            </tr>
                        </thead>
                        <tbody>
                               <tr data-ng-repeat="objLocation in arrLocations track by $index">
                                    <td>
                                        <?php if (in_array(\NsCMN\ClsBllUserPermission::PERMISSION_EDIT,$_smarty_tpl->tpl_vars['_UserPermission']->value)) {?>
                                            <a href="#" data-editable-text="objLocation.strName" onaftersave="update(objLocation,'strName',$data)" e-required>{{ objLocation.strName || 'empty' }}</a>
                                        <?php } else { ?>
                                            {{objLocation.strName}}
                                        <?php }?>
                                    </td>
                                    <td>
                                        <?php if (in_array(\NsCMN\ClsBllUserPermission::PERMISSION_EDIT,$_smarty_tpl->tpl_vars['_UserPermission']->value)) {?>
                                            <a href="#" editable-select="objLocation.objDistrict" e-ng-options="obj.strDistrict for obj in arrDistricts" onaftersave="update(objLocation,'intDistrictID', $data.intID)">
                                            {{objLocation.objDistrict.strDistrict || 'Empty'}}
                                            <!--<a data-e-placeholder="District" 
                                                data-e-typeahead="obj as obj.objCity.strCity+' >> '+obj.strDistrict for obj in arrDistricts | filter: $viewValue" 
                                                data-editable-text="objLocation.objDistrict"
                                                onaftersave="update(objLocation,'intDistrictID', $data.intID,$index)"  >
                                                {{objLocation.objDistrict.strDistrict || 'Empty'}}
                                            </a>-->
                                        <?php } else { ?>
                                            {{objLocation.objDistrict.strDistrict}}
                                        <?php }?>
                                    </td>
                                    <td>
                                        <?php if (in_array(\NsCMN\ClsBllUserPermission::PERMISSION_EDIT,$_smarty_tpl->tpl_vars['_UserPermission']->value)) {?>
                                            <a href="#" data-editable-text="objLocation.strAddress" onaftersave="update(objLocation,'strAddress',$data)" e-required>{{ objLocation.strAddress || 'empty' }}</a>
                                        <?php } else { ?>
                                            {{objLocation.strAddress}}
                                        <?php }?>
                                    </td>
                                    <td class="icon">
                                        <?php if (in_array(\NsCMN\ClsBllUserPermission::PERMISSION_EDIT,$_smarty_tpl->tpl_vars['_UserPermission']->value)) {?>
                                            <a href="#" data-editable-text="objLocation.strLongitude" onaftersave="update(objLocation,'strLongitude',$data)" e-required>{{ objLocation.strLongitude || 'empty' }}</a>
                                        <?php } else { ?>
                                            {{objLocation.strLongitude}}
                                        <?php }?>
                                    </td>
                                    <td class="icon">
                                        <?php if (in_array(\NsCMN\ClsBllUserPermission::PERMISSION_EDIT,$_smarty_tpl->tpl_vars['_UserPermission']->value)) {?>
                                            <a href="#" data-editable-text="objLocation.strLatitude" onaftersave="update(objLocation,'strLatitude',$data)" e-required>{{ objLocation.strLatitude || 'empty' }}</a>
                                        <?php } else { ?>
                                            {{objLocation.strLatitude}}
                                        <?php }?>
                                    </td>
                                    <td>
                                        <?php if (in_array(\NsCMN\ClsBllUserPermission::PERMISSION_EDIT,$_smarty_tpl->tpl_vars['_UserPermission']->value)) {?>
                                            <a href="#" data-editable-text="objLocation.strPhone" onaftersave="update(objLocation,'strPhone',$data)" e-required>{{ objLocation.strPhone|| 'empty' }}</a>
                                        <?php } else { ?>
                                            {{objLocation.strPhone}}
                                        <?php }?>
                                    </td>
                                    <td>
                                        <?php if (in_array(\NsCMN\ClsBllUserPermission::PERMISSION_EDIT,$_smarty_tpl->tpl_vars['_UserPermission']->value)) {?>
                                            <a href="#" data-editable-text="objLocation.strNotes" onaftersave="update(objLocation,'strNotes',$data)" e-required>{{ objLocation.strNotes|| 'empty' }}</a>
                                        <?php } else { ?>
                                            {{objLocation.strNotes}}
                                        <?php }?>
                                    </td>                       
                                    <?php if ((in_array(\NsCMN\ClsBllUserPermission::PERMISSION_EDIT,$_smarty_tpl->tpl_vars['_UserPermission']->value)) || (in_array(\NsCMN\ClsBllUserPermission::PERMISSION_DELETE,$_smarty_tpl->tpl_vars['_UserPermission']->value))) {?>
                                        <td class="icon">
                                            <a class="btn red btn-xs" data-ng-click="del(objLocation.intID,$index)" title="Delete"><i class="fa fa-trash-o"></i></a>
                                        </td>
                                    <?php }?>
                               </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>    
<?php
}
}
/* {/block 'content'} */
}
