<?php
/* Smarty version 3.1.31, created on 2019-10-14 10:29:08
  from "D:\www\ks_invoicing\themes\admin2\template\masters\master1\master.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5da431d4a3bef3_05528770',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '833b027c5234bd8aedada8c4c3797ad60265ba87' => 
    array (
      0 => 'D:\\www\\ks_invoicing\\themes\\admin2\\template\\masters\\master1\\master.tpl',
      1 => 1570523812,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5da431d4a3bef3_05528770 (Smarty_Internal_Template $_smarty_tpl) {
if (!is_callable('smarty_modifier_date_format')) require_once 'D:\\www\\ks_invoicing\\vendor\\smarty\\smarty\\libs\\plugins\\modifier.date_format.php';
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, false);
$_smarty_tpl->smarty->ext->configLoad->_loadConfigFile($_smarty_tpl, $_smarty_tpl->tpl_vars['_LanguageFile']->value, "AUX_MENU", 0);
?>

<?php
$_smarty_tpl->smarty->ext->configLoad->_loadConfigFile($_smarty_tpl, $_smarty_tpl->tpl_vars['_LanguageFile']->value, $_smarty_tpl->tpl_vars['_LanguageSection']->value, 0);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_236865da431d49f3cd4_81533294', 'lang');
?>

<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8 no-js"> <![endif]-->                                                  
<!--[if IE 9]> <html lang="en" class="ie9 no-js"> <![endif]-->
<!--[if !IE]><!-->
<html lang="<?php echo $_smarty_tpl->tpl_vars['_Language']->value;?>
" class="no-js" dir="<?php echo $_smarty_tpl->tpl_vars['_Direction']->value;?>
" <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_269515da431d49f7b58_90966518', 'app');
?>
>
    <head>
        <title><?php echo $_smarty_tpl->tpl_vars['_BreadcrumbItems']->value[count($_smarty_tpl->tpl_vars['_BreadcrumbItems']->value)-1]['strText'];?>
</title>

        <?php $_smarty_tpl->_subTemplateRender(((string)@constant('LOCAL__THEME'))."/template/masters/master1/meta.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, true);
?>

        <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_95885da431d4a05db2_31215412', 'themeMeta');
?>

        <?php $_smarty_tpl->_subTemplateRender(((string)@constant('LOCAL__THEME'))."/template/masters/master1/styles.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, true);
?>

        <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_313895da431d4a07e87_14739140', 'style');
?>

    </head>
    
    <body class="page-md page-container-bg-solid page-header-fixed page-sidebar-closed-hide-logo page-sidebar-fixed"  data-ng-controller="Common" style="display:none">
        <div <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_151225da431d4a08bb5_04913691', 'controller');
?>
>
            <input type="hidden" id="hdModuleName" name="hdModuleName" value="<?php echo @constant('MODULE_NAME');?>
"/>
            <input type="hidden" id="hdWebPath" name="hdWebPath" value="<?php echo @constant('WEB__ROOT__PATH');?>
"/>

            <div class="page-header md-shadow-z-1-i navbar navbar-fixed-top">
                <div class="page-header-inner">
                    <div class="page-logo">
                        <a href="index.php">
                            <img src="<?php echo @constant('WEB__THEME');?>
/images/<?php echo @constant('THEME_TOP_LOGO');?>
" alt="logo" class="logo-default"/>
                        </a>
                        <div class="menu-toggler sidebar-toggler">
                        </div>
                    </div>

                    <a href="javascript:;" class="menu-toggler responsive-toggler" data-toggle="collapse" data-target=".navbar-collapse"></a>

                    <div class="page-top">
                        <div class="page-title"><?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_212195da431d4a0c136_69907542', 'page_title');
?>
</div>

                        <div class="top-menu">
                            <ul class="nav navbar-nav pull-right">
                                <li class="dropdown dropdown-extended dropdown-notification dropdown-dark" id="header_notification_bar">
                                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="true">
                                        <i class="icon-bell"></i>
                                        <span id="lblMasterNotificationCount" class="badge badge-danger"><?php echo $_smarty_tpl->tpl_vars['_User']->value->intUnreadNotificationCount;?>
</span>
                                    </a>
                                    <ul class="dropdown-menu">
                                        <li class="external">
                                            <h3><span id="lblDropDownNotificationCount" class="bold"><?php echo $_smarty_tpl->tpl_vars['_User']->value->intUnreadNotificationCount;?>
</span> <?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'NEW_NOTIFICATIONS');?>
</h3>
                                            <a href="index.php?module=cmn&amp;page=Notification&amp;action=ViewNotification"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'VIEW_ALL');?>
</a>
                                        </li>
                                        <li>
                                            <ul class="dropdown-menu-list scroller" style="height: 250px;" data-handle-color="#DFE4E8">
                                                <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['_User']->value->arrTopUnreadNotification, 'Notification', false, NULL, 'index', array (
));
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['Notification']->value) {
?>
                                                <li id="rNotification_<?php echo $_smarty_tpl->tpl_vars['Notification']->value['intID'];?>
">
                                                    <a href="#dlgMasterNotification" data-toggle="modal" data-notification-id="<?php echo $_smarty_tpl->tpl_vars['Notification']->value['intID'];?>
" data-title="<?php echo $_smarty_tpl->tpl_vars['Notification']->value['strTitle'];?>
" data-details="<?php echo $_smarty_tpl->tpl_vars['Notification']->value['strNotificationEncoded'];?>
">
                                                        <span class="time"><?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['Notification']->value['dtNotificationDateTime'],"%Y-%m-%d");?>
</span>                                             
                                                        <span class="details"><?php echo $_smarty_tpl->tpl_vars['Notification']->value['strTitle'];?>
</span>
                                                    </a>
                                                </li>
                                                <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);
?>

                                            </ul>
                                        </li>
                                    </ul>
                                </li>
                                <li class="dropdown dropdown-user dropdown-dark">
                                    <a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="true">
                                        <?php if ($_smarty_tpl->tpl_vars['_User']->value->intPhotoID != -1) {?> 
                                            <span class="username username-hide-on-mobile"><?php echo $_smarty_tpl->tpl_vars['_User']->value->strDisplayName;?>
</span>
                                            <img alt="" src="index.php?module=cmn&page=Index&action=Download&file_id=<?php echo $_smarty_tpl->tpl_vars['_User']->value->intPhotoID;?>
"/>
                                        <?php } else { ?>
                                            <span class="username"><?php echo $_smarty_tpl->tpl_vars['_User']->value->strDisplayName;?>
</span>
                                        <?php }?>
                                    </a>
                                    <ul class="dropdown-menu dropdown-menu-default">
                                        <li><a href="index.php?module=cmn&page=User&action=Default"><i class="icon-user"></i> <?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'MY_ACCOUNT');?>
</a></li>
                                        <li class="divider"></li>
                                        <li><a href="index.php?module=cmn&amp;page=Index&amp;action=LogMeOut"><i class="icon-key"></i> <?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LOG_OUT');?>
</a></li>
                                    </ul>
                                </li>
                                <li class="dropdown dropdown-user dropdown-language">
                                    <a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="true">
                                        <span class="username"><i class="fa"></i> <?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'HELP');?>
</span>
                                    </a>
                                    <ul class="dropdown-menu dropdown-menu-default">
                                        <li><a href="htt://hitstc.org/" target="_blank"><i class="icon-info"></i> <?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'KNOWLEDGE_BASE');?>
</a></li>
                                        <li class="divider"></li>
                                        <li><a href="https://www.youtube.com/channel/UCDD9_Bx_eC1R4-oxvoVxjQg" target="_blank"><i class="fa fa-youtube"></i> <?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'YOUTUBE_CHANNEL');?>
</a></li>
                                    </ul>
                                </li>
                                <li class="dropdown dropdown-language">
                                    <?php if ($_smarty_tpl->tpl_vars['_Language']->value == 'en') {?>
                                        <a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="true" aria-expanded="false">
                                            <img alt="" src="<?php echo @constant('WEB__THEME');?>
/images/flags/gb.png"><span class="langname"> English </span><i class="fa fa-angle-down"></i>
                                        </a>
                                        <ul class="dropdown-menu" style="min-width: 105px!important;">
                                            <li>
                                                <a href="#" onclick="SwitchLang('ar')"><img alt="" src="<?php echo @constant('WEB__THEME');?>
/images/flags/eg.png"> عربي </a>
                                            </li>
                                        </ul>
                                    <?php } else { ?>
                                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="true" aria-expanded="false">
                                            <img src="<?php echo @constant('WEB__THEME');?>
/images/flags/eg.png"><span class="langname"> عربي </span><i class="fa fa-angle-down"></i>
                                        </a>
                                        <ul class="dropdown-menu" style="min-width: 105px!important;">
                                            <li>
                                                <a href="#" onclick="SwitchLang('en')"><img alt="" src="<?php echo @constant('WEB__THEME');?>
/images/flags/gb.png"> English</a>
                                            </li>
                                        </ul>
                                    <?php }?>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <div class="clearfix"></div>

            <div class="page-container">

                <div class="page-sidebar-wrapper">
                    <div class="page-sidebar navbar-collapse collapse">
                        <?php $_smarty_tpl->_subTemplateRender(((string)@constant('LOCAL__THEME__COMPONENTS'))."/main.menu.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, true);
?>

                    </div>
                </div>
                <div class="page-content-wrapper">
                    <div class="page-content">
                        <div class="page-head">
                            <div class="page-bar">
                                <?php $_smarty_tpl->_subTemplateRender(((string)@constant('LOCAL__THEME__COMPONENTS'))."/breadcrumb.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, true);
?>

                                
                                <div class="page-toolbar">
                                <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_94405da431d4a2b3c5_40848062', 'toolbar');
?>

                                </div>
                            </div>
                        </div>                        
                        
                        <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_91135da431d4a2cf48_51386336', 'content');
?>


                        <sham-spinner text="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LOADING');?>
"></sham-spinner>
                    </div>
                </div>
            </div>    

            <div class="page-footer">
                <div class="page-footer-inner">
                    <?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'APP_NAME');?>
 <?php echo @constant('VERSION');?>
 | 2015 - <?php echo date('Y');?>
 &copy;
                </div>
                <div class="scroll-to-top">
                    <i class="icon-arrow-up"></i>
                </div>
            </div>
            
            <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_303025da431d4a34948_51692828', 'dialog');
?>

            <?php $_smarty_tpl->_subTemplateRender(((string)@constant('LOCAL__THEME'))."/template/masters/master1/scripts.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, true);
?>

            <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_149115da431d4a370c3_42667445', 'script');
?>

            
            <div id="dlgMasterNotification" class="modal fade modal-dialog" tabindex="-1" data-width="400" style="display: none;">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">?</button>
                    <h3 class="modal-title"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'NOTIFICATION');?>
</h3>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-12"></div>
                    </div>
                </div>
                <div class="modal-footer form-action">
                    <button type="button" class="btn red-flamingo" data-dismiss="modal"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'CLOSE');?>
</button>
                </div>
            </div>
        </div>
    </body>
</html><?php }
/* {block 'lang'} */
class Block_236865da431d49f3cd4_81533294 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'lang' => 
  array (
    0 => 'Block_236865da431d49f3cd4_81533294',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
}
}
/* {/block 'lang'} */
/* {block 'app'} */
class Block_269515da431d49f7b58_90966518 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'app' => 
  array (
    0 => 'Block_269515da431d49f7b58_90966518',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
}
}
/* {/block 'app'} */
/* {block 'themeMeta'} */
class Block_95885da431d4a05db2_31215412 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'themeMeta' => 
  array (
    0 => 'Block_95885da431d4a05db2_31215412',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
}
}
/* {/block 'themeMeta'} */
/* {block 'style'} */
class Block_313895da431d4a07e87_14739140 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'style' => 
  array (
    0 => 'Block_313895da431d4a07e87_14739140',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
}
}
/* {/block 'style'} */
/* {block 'controller'} */
class Block_151225da431d4a08bb5_04913691 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'controller' => 
  array (
    0 => 'Block_151225da431d4a08bb5_04913691',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
}
}
/* {/block 'controller'} */
/* {block 'page_title'} */
class Block_212195da431d4a0c136_69907542 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'page_title' => 
  array (
    0 => 'Block_212195da431d4a0c136_69907542',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
}
}
/* {/block 'page_title'} */
/* {block 'toolbar'} */
class Block_94405da431d4a2b3c5_40848062 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'toolbar' => 
  array (
    0 => 'Block_94405da431d4a2b3c5_40848062',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
}
}
/* {/block 'toolbar'} */
/* {block 'content'} */
class Block_91135da431d4a2cf48_51386336 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_91135da431d4a2cf48_51386336',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
}
}
/* {/block 'content'} */
/* {block 'dialog'} */
class Block_303025da431d4a34948_51692828 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'dialog' => 
  array (
    0 => 'Block_303025da431d4a34948_51692828',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
}
}
/* {/block 'dialog'} */
/* {block 'script'} */
class Block_149115da431d4a370c3_42667445 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'script' => 
  array (
    0 => 'Block_149115da431d4a370c3_42667445',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
}
}
/* {/block 'script'} */
}
