<?php
/* Smarty version 3.1.31, created on 2019-10-16 13:53:42
  from "D:\www\ks_invoicing\modules\cmn\view\templates\partials\user.level\default.page.edit.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5da704c6405bc5_11992642',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '3cd94681c899b73c42dace14c0d3a447f5a74390' => 
    array (
      0 => 'D:\\www\\ks_invoicing\\modules\\cmn\\view\\templates\\partials\\user.level\\default.page.edit.tpl',
      1 => 1570523806,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5da704c6405bc5_11992642 (Smarty_Internal_Template $_smarty_tpl) {
?>
<div id="dlgEditDefaultPage" class="modal fade modal-scroll modal-dialog" tabindex="-1" data-width="380" style="display: none;height:auto!important" data-ng-controller="EditDefaultPage">
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        <h3 class="modal-title">Edit Default Page</h3>
    </div>
    <div class="modal-body">
        <form name="frmEditDefaultPage">
        <div class="row">
            <div class="col-md-12">
                <div class="form-group">
                    <label>User Level</label>
                    <span class="form-control">{{objEditDefaultPage.strUserLevel}}</span>
                </div>
            </div>
            <div class="col-md-12">
                <div class="form-group">
                    <label>Module</label>
                    <span class="form-control">{{objEditDefaultPage.strTitle}}</span>
                </div>
            </div>
            <div class="col-md-12">
                <div class="form-group">
                    <label>Default Page</label>
                    <input type="text" name="txtEditDefaultPage" class="form-control" placeholder="url: index.php?module=x&amp;page=y&amp;action=z" required="required" data-ng-model="objEditDefaultPage.strDefaultPage" />
                </div>
            </div>
            <div class="col-md-12">
                <div class="form-group">
                    <input type="checkbox" id="chkEditDefaultModule" name="chkEditDefaultModule" data-ng-model="objEditDefaultPage.intDefaultModule" data-ng-true-value="1" data-ng-false-value="0" />
                    <label for="chkEditDefaultModule">Mark as default module</label>
                </div>
            </div>
        </div>    
        </form>
    </div>
    <div class="modal-footer">
        <button type="button" class="btn btn-success" data-ng-disabled="frmEditDefaultPage.$invalid" data-ng-click="EditDefaultPage()">Save</button>
        <button type="button" class="btn btn-danger" data-dismiss="modal" data-ng-click="ResetEditDefaultPage()">Cancel</button>
    </div>
</div><?php }
}
