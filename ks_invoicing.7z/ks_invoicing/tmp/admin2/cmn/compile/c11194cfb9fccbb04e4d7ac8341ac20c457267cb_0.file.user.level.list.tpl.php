<?php
/* Smarty version 3.1.31, created on 2019-10-16 13:53:42
  from "D:\www\ks_invoicing\modules\cmn\view\templates\pages\user.level.list.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5da704c6386d77_67048575',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c11194cfb9fccbb04e4d7ac8341ac20c457267cb' => 
    array (
      0 => 'D:\\www\\ks_invoicing\\modules\\cmn\\view\\templates\\pages\\user.level.list.tpl',
      1 => 1570523806,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:partials/user.level/user.level.add.tpl' => 1,
    'file:partials/user.level/user.level.edit.tpl' => 1,
    'file:partials/user.level/default.page.add.tpl' => 1,
    'file:partials/user.level/default.page.edit.tpl' => 1,
  ),
),false)) {
function content_5da704c6386d77_67048575 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_195985da704c63558b2_79267174', 'app');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_32475da704c6356ce1_78738215', 'controller');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_268125da704c6357b40_60500174', 'style');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_41655da704c63588f4_23867672', 'script');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_91145da704c6360021_16550484', 'dialog');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_176115da704c636ef35_50670551', 'page_title');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_216725da704c63720c9_33135835', 'toolbar');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_275855da704c637d4e3_17959720', 'content');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, ((string)@constant('LOCAL__THEME'))."/template/masters/master1/master.tpl");
}
/* {block 'app'} */
class Block_195985da704c63558b2_79267174 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'app' => 
  array (
    0 => 'Block_195985da704c63558b2_79267174',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

data-ng-app="CMN"
<?php
}
}
/* {/block 'app'} */
/* {block 'controller'} */
class Block_32475da704c6356ce1_78738215 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'controller' => 
  array (
    0 => 'Block_32475da704c6356ce1_78738215',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

data-ng-controller="UserLevel" 
<?php
}
}
/* {/block 'controller'} */
/* {block 'style'} */
class Block_268125da704c6357b40_60500174 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'style' => 
  array (
    0 => 'Block_268125da704c6357b40_60500174',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php
}
}
/* {/block 'style'} */
/* {block 'script'} */
class Block_41655da704c63588f4_23867672 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'script' => 
  array (
    0 => 'Block_41655da704c63588f4_23867672',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('PATH__JS');?>
/enum.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('PATH__JS');?>
/common.angular.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('PATH__JS');?>
/user.level.list.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
<?php
}
}
/* {/block 'script'} */
/* {block 'dialog'} */
class Block_91145da704c6360021_16550484 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'dialog' => 
  array (
    0 => 'Block_91145da704c6360021_16550484',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php $_smarty_tpl->_subTemplateRender("file:partials/user.level/user.level.add.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<?php $_smarty_tpl->_subTemplateRender("file:partials/user.level/user.level.edit.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<?php $_smarty_tpl->_subTemplateRender("file:partials/user.level/default.page.add.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<?php $_smarty_tpl->_subTemplateRender("file:partials/user.level/default.page.edit.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<?php
}
}
/* {/block 'dialog'} */
/* {block 'page_title'} */
class Block_176115da704c636ef35_50670551 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'page_title' => 
  array (
    0 => 'Block_176115da704c636ef35_50670551',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<h1><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6535');?>
 <small><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6536');?>
</small></h1>
<?php
}
}
/* {/block 'page_title'} */
/* {block 'toolbar'} */
class Block_216725da704c63720c9_33135835 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'toolbar' => 
  array (
    0 => 'Block_216725da704c63720c9_33135835',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php if (in_array(\NsCMN\ClsBllUserPermission::PERMISSION_ADD,$_smarty_tpl->tpl_vars['_UserPermission']->value)) {?>
<div class="btn-group">
    <a class="btn btn-fit-height yellow-saffron" style="border-radius:0px" href="index.php?module=<?php echo @constant('MODULE_NAME');?>
&page=Module&action=ListActions" title="Modules Actions">
        <i class="fa fa-bolt"></i> <span class="visible-lg-inline-block"> Actions</span>
    </a>
    <a class="btn btn-fit-height blue" style="border-radius:0px" href="index.php?module=<?php echo @constant('MODULE_NAME');?>
&page=UserLevelPermission&action=List" title="User Levels Permissions">
        <i class="fa fa-lock"></i> <span class="visible-lg-inline-block"> Permissions</span>
    </a>
    <a href="#dlgAddUserLevel" class="btn btn-fit-height btn-success" title="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6538');?>
" data-toggle="modal">
        <i class="fa fa-plus"></i> <span class="visible-lg-inline-block"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6537');?>
</span>
    </a>
</div>
<?php }
}
}
/* {/block 'toolbar'} */
/* {block 'content'} */
class Block_275855da704c637d4e3_17959720 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_275855da704c637d4e3_17959720',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<div class="row">
    <div class="col-md-12">
        <div class="portlet light">
            <div class="portlet-title">
                <div class="caption font-blue"><i class="fa fa-filter font-blue"></i> <?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6541');?>
</div>
                <div class="tools"><a href="#" class="collapse"></a></div>
            </div>
            <div class="portlet-body">
                <form id="frmFilter" name="frmFilter">
                    <div class="row">
                        <div class="col-md-3">
                            <div class="form-group">
                                <input type="text" name="txtUserLevel" class="form-control" placeholder="User Level" data-ng-model="objFilter.strUserLevel" />
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <select name="cmbModule" class="form-control" data-ng-model="objFilter.intModuleID" data-ng-options="module.intID as module.strTitle for module in arrModules">
                                    <option value="">Module</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <button type="button" class="btn blue" data-ng-click="Filter()">
                                    <i class="fa fa-filter"></i> Filter
                                </button>
                                <button type="reset" class="btn red-thunderbird" data-ng-click="Reset()">
                                    <i class="fa fa-refresh"></i> Reset
                                </button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="portlet light">
            <div class="portlet-title">
                <div class="caption font-blue"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6539');?>
</div>
            </div>
            <div class="portlet-body">
                <div data-ng-if="objFilter.boolFiltered == true && arrUserLevels.length > 0">
                    <div class="row-details margin-bottom-20" data-ng-repeat="obj in arrUserLevels">
                        <span class="font-lg font-blue-dark bold"><i class="fa fa-users"></i> {{obj.strUserLevel}}</span>
                        &nbsp;
                        <span class="margin-right-10 inline-block" data-ng-repeat="module in obj.arrModule" data-ng-class="{'label label-success': module.strDefaultPage!='', 'label label-danger': module.strDefaultPage==''}">{{module.strTitle}}</span>
                        <?php if (in_array(\NsCMN\ClsBllUserPermission::PERMISSION_DELETE,$_smarty_tpl->tpl_vars['_UserPermission']->value)) {?>
                            <span class="pull-right">
                                <a class="btn btn-xs blue-dark" title="Edit User Level" data-ng-click="EditUserLevel(obj, $index)">
                                    <i class="fa fa-pencil"></i> <span class="visible-lg-inline-block"></span>
                                </a>
                                <a class="btn btn-danger btn-xs" title="Delete User Level" data-ng-click="DeleteUserLevel(obj, $index)">
                                    <i class="fa fa-trash-o"></i> <span class="visible-lg-inline-block"></span>
                                </a>
                            </span>
                        <?php } else { ?>
                            &nbsp;
                        <?php }?>
                        
                        <div class="padding-tb-10">
                            <table class="table table-condensed table-striped table-bordered table-light">
                                <thead>
                                    <tr>
                                        <th width="12%">Module</th>
                                        <th>Default Page</th>
                                        <th width="3%">
                                            &nbsp;
                                        </th>
                                        <th width="3%">
                                            <?php if (in_array(\NsCMN\ClsBllUserPermission::PERMISSION_ADD,$_smarty_tpl->tpl_vars['_UserPermission']->value)) {?>
                                                <a class="btn btn-success btn-xs" title="Add Module Default Page" data-ng-click="AddDefaultPage(obj, $index)"><i class="fa fa-plus"></i> <span class="visible-lg-inline-block"></span></a>
                                            <?php } else { ?>
                                                &nbsp;
                                            <?php }?>
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr data-ng-repeat="page in obj.arrDefaultPage">
                                        <td>{{page.strTitle}}&nbsp;<i data-ng-if="page.intDefaultModule == 1" class="fa fa-star"></i></td>
                                        <td>{{page.strDefaultPage}}</td>                                
                                        <td class="icon">
                                            <?php if (in_array(\NsCMN\ClsBllUserPermission::PERMISSION_EDIT,$_smarty_tpl->tpl_vars['_UserPermission']->value)) {?>
                                                <a class="btn btn-xs blue-dark" title="Edit Default Page" data-ng-click="EditDefaultPage(obj, page, $parent.$index)">
                                                    <i class="fa fa-pencil"></i> <span class="visible-lg-inline-block"></span>
                                                </a>
                                            <?php } else { ?>
                                                &nbsp;
                                            <?php }?>
                                        </td>
                                        <td class="icon">
                                            <?php if (in_array(\NsCMN\ClsBllUserPermission::PERMISSION_DELETE,$_smarty_tpl->tpl_vars['_UserPermission']->value)) {?>
                                                <a class="btn btn-danger btn-xs" title="Delete Default Page" data-ng-click="DeleteDefaultPage(obj, page, $parent.$index)">
                                                    <i class="fa fa-trash-o"></i> <span class="visible-lg-inline-block"></span>
                                                </a>
                                            <?php } else { ?>
                                                &nbsp;
                                            <?php }?>
                                        </td>
                                    </tr>
                                    <tr data-ng-if="obj.arrDefaultPage.length == 0">
                                        <td colspan="4">No default pages found. <a data-ng-click="AddDefaultPage(obj, $index)">Add default page</a></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div data-ng-if="objFilter.boolFiltered == true && arrUserLevels.length == 0" class="alert alert-warning">
                    <p>No data found matching your filter</p>
                </div>
                <div data-ng-if="objFilter.boolFiltered == false" class="alert alert-info">
                    <p>Use filter to load data</p>
                </div>
            </div>
        </div>        
    </div>
</div>
<?php
}
}
/* {/block 'content'} */
}
