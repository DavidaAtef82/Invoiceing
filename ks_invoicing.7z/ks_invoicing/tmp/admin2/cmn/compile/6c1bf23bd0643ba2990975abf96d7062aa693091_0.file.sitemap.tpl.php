<?php
/* Smarty version 3.1.31, created on 2019-10-14 10:29:55
  from "D:\www\ks_invoicing\modules\cmn\view\templates\pages\sitemap.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5da43203719f86_12618558',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '6c1bf23bd0643ba2990975abf96d7062aa693091' => 
    array (
      0 => 'D:\\www\\ks_invoicing\\modules\\cmn\\view\\templates\\pages\\sitemap.tpl',
      1 => 1570523806,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:partials/sitemap/add.tpl' => 1,
    'file:partials/sitemap/edit.tpl' => 1,
  ),
),false)) {
function content_5da43203719f86_12618558 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_25695da432036e6863_19225184', 'app');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_133265da432036e96d1_15972654', 'controller');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_77275da432036ecab6_85455035', 'style');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_236125da432036f2f68_55284292', 'script');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_158135da432036f74e1_99690847', 'dialog');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_7945da432036fe691_15797269', 'page_title');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_282355da432037009b4_72055195', 'toolbar');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_405da4320370a097_08483257', 'content');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, ((string)@constant('LOCAL__THEME'))."/template/masters/master1/master.tpl");
}
/* {block 'app'} */
class Block_25695da432036e6863_19225184 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'app' => 
  array (
    0 => 'Block_25695da432036e6863_19225184',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

data-ng-app="CMN"
<?php
}
}
/* {/block 'app'} */
/* {block 'controller'} */
class Block_133265da432036e96d1_15972654 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'controller' => 
  array (
    0 => 'Block_133265da432036e96d1_15972654',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

data-ng-controller="Sitemap" 
<?php
}
}
/* {/block 'controller'} */
/* {block 'style'} */
class Block_77275da432036ecab6_85455035 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'style' => 
  array (
    0 => 'Block_77275da432036ecab6_85455035',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<link rel="stylesheet" type="text/css" href="<?php echo @constant('WEB__THEME');?>
/css/pages/todo.css"/>
<?php
}
}
/* {/block 'style'} */
/* {block 'script'} */
class Block_236125da432036f2f68_55284292 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'script' => 
  array (
    0 => 'Block_236125da432036f2f68_55284292',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('PATH__JS');?>
/common.angular.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo @constant('PATH__JS');?>
/sitemap.js?ver=<?php echo @constant('VERSION');?>
"><?php echo '</script'; ?>
>
<?php
}
}
/* {/block 'script'} */
/* {block 'dialog'} */
class Block_158135da432036f74e1_99690847 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'dialog' => 
  array (
    0 => 'Block_158135da432036f74e1_99690847',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php $_smarty_tpl->_subTemplateRender("file:partials/sitemap/add.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<?php $_smarty_tpl->_subTemplateRender("file:partials/sitemap/edit.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<?php
}
}
/* {/block 'dialog'} */
/* {block 'page_title'} */
class Block_7945da432036fe691_15797269 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'page_title' => 
  array (
    0 => 'Block_7945da432036fe691_15797269',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<h1><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6546');?>
 <small><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6559');?>
</small></h1>
<?php
}
}
/* {/block 'page_title'} */
/* {block 'toolbar'} */
class Block_282355da432037009b4_72055195 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'toolbar' => 
  array (
    0 => 'Block_282355da432037009b4_72055195',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php if (in_array(\NsCMN\ClsBllUserPermission::PERMISSION_ADD,$_smarty_tpl->tpl_vars['_UserPermission']->value)) {?>
<div class="btn-group">
    <a href="#dlgAdd" data-toggle="modal" class="btn btn-fit-height btn-success" title="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6560');?>
">
        <i class="fa fa-plus"></i> 
        <span class="visible-lg-inline-block"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6546');?>
</span>
    </a>
</div>
<?php }
}
}
/* {/block 'toolbar'} */
/* {block 'content'} */
class Block_405da4320370a097_08483257 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_405da4320370a097_08483257',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<div class="row">
    <div class="col-md-12">
        <div class="portlet light">
            <div class="portlet-title">
                <div class="caption"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6544');?>
</div>
                <div class="tools"><a href="#" class="collapse"></a></div>
            </div>
            <div class="portlet-body">
                <div class="row">
                    <div class="col-md-9">
                        <div class="form-group">
                            <input type="text" name="txtFilterText" data-ng-model="objFilter.strMenuText" class="form-control" placeholder="<?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6550');?>
" data-ng-change="Filter()"/>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <button type="submit" class="btn blue" data-ng-click="Filter()">
                                <i class="fa fa-filter"></i> <?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6544');?>

                            </button>
                            <button type="button" class="btn red-thunderbird" data-ng-click="Reset()">
                                <i class="fa fa-refresh"></i> <?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6545');?>

                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="portlet light">
            <div class="portlet-title">
                <div class="caption"><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6543');?>
</div>
            </div>
            <div class="portlet-body">
                <table class="table table-condensed table-bordered table-hover">
                    <thead>
                        <tr>
                            <th><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6547');?>
</th>
                            <th><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6548');?>
</th>
                            <th><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6549');?>
</th>
                            <th><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6550');?>
</th>
                            <th><?php echo $_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'LNG_6551');?>
</th>
                            <?php if (in_array(\NsCMN\ClsBllUserPermission::PERMISSION_EDIT,$_smarty_tpl->tpl_vars['_UserPermission']->value)) {?>
                            <th>&nbsp;</th>
                            <?php }?>
                            <?php if (in_array(\NsCMN\ClsBllUserPermission::PERMISSION_DELETE,$_smarty_tpl->tpl_vars['_UserPermission']->value)) {?>
                            <th>&nbsp;</th>
                            <?php }?>
                        </tr>
                    </thead>
                    <tbody>
                        <tr data-ng-repeat="obj in arrMenu" data-ng-class="{'bg-yellow-saffron':obj.intActionID==null}">
                            <td>{{obj.decGroupOrder}}</td>
                            <td>{{obj.decItemOrder}}</td>
                            <td>
                                <span data-ng-if="obj.intActionID!=null">{{obj.strControllerType}}\{{obj.strControllerClass}}\{{obj.strAction}}</span>
                            </td>
                            <td>
                                <span>
                                    {{RepeatNumber("____",obj.intItemLevel)}}
                                </span>
                                {{obj.strItemText}}
                                &nbsp;&nbsp;<i class="{{obj.strItemStyle}}"></i>
                            </td>
                            <td>
                                <i data-ng-class="{'fa fa-check': obj.boolShowInMenu, 'fa fa-close':!obj.boolShowInMenu}"></i>
                            </td>
                            <?php if (in_array(\NsCMN\ClsBllUserPermission::PERMISSION_EDIT,$_smarty_tpl->tpl_vars['_UserPermission']->value)) {?>
                            <td class="icon">
                                <a class="btn btn-xs blue-dark" title="" href="#dlgEdit" data-toggle="modal" data-ng-click="Edit(obj, $index)">
                                    <i class="fa fa-pencil"></i> 
                                    <span class="visible-lg-inline-block"></span>
                                </a>
                            </td>
                            <?php }?>
                            <?php if (in_array(\NsCMN\ClsBllUserPermission::PERMISSION_DELETE,$_smarty_tpl->tpl_vars['_UserPermission']->value)) {?>
                            <td class="icon">
                                <a data-ng-click="Delete(obj.intID,$index)" class="btn btn-danger btn-xs" title="Delete">
                                    <i class="fa fa-trash-o"></i> <span class="visible-lg-inline-block"></span>
                                </a>
                            </td>
                            <?php }?>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>        
    </div>
</div>
<?php
}
}
/* {/block 'content'} */
}
