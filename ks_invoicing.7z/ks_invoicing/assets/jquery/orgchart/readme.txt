﻿www.getorgchart.com
GetOrgChart version 1.3

Installation:
	In your html document between the head tags include the following code, and then GetOrgChart will be installed:
	<script src="www.yourdomain.com/getorgchart/getorgchart.js"></script>
    <link href="www.yourdomain.com/getorgchart/getorgchart.css" rel="stylesheet" />

Dependencies:
	jQuery

Send us an email if you need assistance
	email: support@getorgchart.com

License:
	http://getorgchart/home/eula