'use strict';

// Declare app level module
angular.module('bootstrap.wrapper', []);
angular.module('bootstrap.wrapper').directive('datetimepicker', ['$http',function ($http) {
    return {
        restrict: 'A',
        scope: {
            startDate:'@',
            eventDateChange: '&',
            ngModel:'='
        },
        link: function (scope, element, attrs) { 
            var objScope = scope;
            attrs.autoclose = true;
            attrs.fontAwesome = true;

            element.datetimepicker(attrs);
            element.bind('changeDate', function(event){
                objScope.ngModel = event.target.value;
                objScope.$apply();
                objScope.eventDateChange();
            });    
            attrs.$observe('startDate', function(value) {
                if (value) {
                    element.datetimepicker({'startDate': new Date(value)});
                }
            });            
            attrs.$observe('endDate', function(value) {
                if (value) {
                    element.datetimepicker({'endDate': new Date(value)});
                }
            });            
        }
    };
}]);