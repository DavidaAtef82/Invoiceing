'use strict';

// Declare app level module
angular.module('bootstrap.knobify', []);
angular.module('bootstrap.knobify').directive('knobify', ['$http', function ($http) {
    return {
        restrict: 'A',
        link: function (scope, element, attrs) {
            attrs.$observe('value', function(value) {
                if(value) {
                    element.val(value).trigger('change');
                }
            });
            attrs.$observe('max', function(value) {
                if(value) {
                    element.attr('data-max',value).trigger('change');
                    element.knob(attrs);
                }
            });          
        }            
    };
}]);