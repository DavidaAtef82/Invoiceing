<?php
namespace NsCMN;
class ClsBllLang extends \NsFWK\ClsLanguage{
    
    /***
    * Retrieves module-less lang keys from lookup
    * @param mixed $strLang: target language
    */
    public function GetCommonLangKeys(){
        if (empty($this->_data['strLang'])) {
            return false;
        }
        $strFld = $this->_data['strFld'];

        $DB_COMMON = &\ADODB_Connection_Manager::GetConnection('common');
        $strSQL = "SELECT UPPER(fldLookup) AS strSection,
                        fldLangKey AS strLangKey,
                        $strFld AS strLangValue
                    FROM lng_lang_lookup
                    WHERE fkModuleID IS NULL
                        AND fldLangKey IS NOT NULL
                        AND fldLangKey <> ''
                    ORDER BY fkModuleID, fldLookup ASC;";

        $arrKey = $DB_COMMON->GetArray($strSQL);
        if(empty($arrKey)){
            return array();
        }

        return $arrKey;
    }

    /***
    * Retrieves module lang keys: controller / lookup / error in .ini format
    * @param mixed $intModuleID: module for which keys to be retrieved
    * @param mixed $strLang: target language
    */
    public function GetModuleLangKeys($intModuleID){
        if (empty($this->_data['strLang'])) {
            return false;
        }
        $strFld = $this->_data['strFld'];

        $DB_COMMON = &\ADODB_Connection_Manager::GetConnection('common');
        $strSQL = "SELECT UPPER(CONCAT(fldControllerType, '_', fldControllerClass, '_', fldAction)) AS strSection,
                            CONCAT('LNG_', pkID) AS strLangKey, 
                            $strFld AS strLangValue
                    FROM lng_lang_controller
                    WHERE fkModuleID = ?
                    UNION
                    SELECT UPPER(fldLookup) AS strSection,
                            fldLangKey AS strLangKey,
                            $strFld AS strLangValue
                    FROM lng_lang_lookup
                    WHERE fkModuleID = ?
                            AND fldLangKey IS NOT NULL
                            AND fldLangKey <> ''
                    UNION
                    SELECT 'ERROR_CODE' as strSection,
                            CONCAT('ERR_',pkID) AS strLangKey,
                            $strFld AS strLangValue
                    FROM lng_lang_error
                    WHERE fkModuleID = ?
                    ORDER BY strSection;";

        $arrKey = $DB_COMMON->GetArray($strSQL, array($intModuleID, $intModuleID, $intModuleID));
        if(empty($arrKey)){
            return array();
        }

        return $arrKey;
    }


    /***
    * Method accepts array of language keys and returns text content of ini file
    * @param mixed $arrKey: array of language keys
    */
    static public function GetINIFormat($arrKey){
        $strSection = '';
        $strContent = '';

        foreach($arrKey as $strKey){ 
            $strNewSection = $strKey['strSection'];

            if($strNewSection != $strSection && $strNewSection != ''){
                // New section
                $strContent .= "[$strNewSection]\n";
            }

            $strSection = $strNewSection;
            $strContent .= $strKey['strLangKey'] . ' = "' . $strKey['strLangValue'] . '"' . "\n";
        }
        
        return $strContent;
    }

    /***
    * Method accepts array of language keys. It sorts them according to the corresponding section
    * and returns JSON encoded string 
    * @param mixed $arrKey: array of language keys
    */
    static public function GetJSONFormat($arrKey){
        $arrContent = array();
        foreach($arrKey as $strKey){
            $arrContent[$strKey['strSection']][$strKey['strLangKey']] =  $strKey['strLangValue'];
        }

        $strContent = json_encode($arrContent);
        return $strContent;
    }

}