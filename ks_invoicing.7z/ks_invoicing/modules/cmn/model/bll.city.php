<?php
namespace NsCMN;
class ClsBllCity extends \NsFWK\ClsBll{
    public function __construct(){
        $this->_strClsDalLoad = '\NsCMN\ClsDalCity';
        $this->_strClsDalSave = '\NsCMN\ClsDalCity';
        $this->_data = array('intID'=>-1, 'strCity'=>'','intCountryID'=>'');
        parent::__construct(func_get_args());
    }

    public function __get($name){
        switch($name){
            case 'arrDistricts':
                if(!key_exists($name, $this->_data)){
                    $this->_data[$name] = $this->GetDistricts();
                }
                break;
            case 'arrLocations':
                if(!key_exists($name, $this->_data)){
                    $this->_data[$name] = $this->GetLocations();
                }
                break;
            case 'objCountry':
                if(!isset($this->_data['objCountry'])){
                    $obj = new \NsCMN\ClsBllCountry();
                    $obj->LoadByID($this->_data['intCountryID']);
                    $this->_data['objCountry'] = $obj;
                }
                break;
        }

        return parent::__get($name);
    }

    protected function _save(\ADODB_Active_Record $objDAL){
        if($this->getIsLoaded()){
            $rslt = $objDAL->Load('pkCityID=?',array($this->_data['intID']));
            if(!$rslt){  
                return 'Could not load object!';
            }
        }
        $objDAL->fkCountryID = $this->_data['intCountryID'];           
        $objDAL->fldCity = $this->_data['strCity'];
        $rslt = $objDAL->Save();
        if($rslt){
            $this->_data['intID'] = $objDAL->pkCityID;
        }
        return $rslt;
    }

    protected function _delete(\ADODB_Active_Record $objDAL){
        $DB = &\ADODB_Connection_Manager::GetConnection('customer');
        $rslt = $DB->GetArray("SELECT fkCityID FROM cmn_district WHERE fkCityID = {$this->_data['intID']}");
        if($rslt === false){
            return false;
        }elseif(is_array($rslt) && !empty($rslt)){
            return false;
        }else{
            return $DB->Execute('DELETE FROM cmn_city WHERE pkCityID = ? ', array($this->_data['intID']));
        }
    }

    protected function _load(\ADODB_Active_Record $objDAL){
        $this->_data['intID'] = $objDAL->pkCityID;
        $this->_data['strCity'] = $objDAL->fldCity;
        $this->_data['intCountryID'] = $objDAL->fkCountryID;
    }


    public function LoadByID($intID){
        $objFilter = new \NsFWK\ClsFilter();
        $objFilter->intID = "pkCityID = $intID";
        return $this->Load($objFilter);
    }

    public function LoadByName($strName){
        $objFilter = new \NsFWK\ClsFilter();
        $objFilter->strCity = "fldCity = '$strName'";
        return $this->Load($objFilter); 
    }

    public function GetDataAssociative(\NsFWK\ClsFilter $objFilter, $strOrder = '', $strGroup = '', $intOffset = false, $intCount = false){
        $arrData =  @parent::GetDataAssociative($objFilter);
        if (isset($arrData)){
            $this->loadBindingAssociative($arrData, 'intCountryID', 'objCountry', new \NsCMN\ClsBllCountry(), 'pkCountryID', 'intID');
            return $arrData;
        }else{
            return null;
        }
    }

    public function GetLocations(){
        $objFilter = new \NsFWK\ClsFilter();
        $objFilter->intID = "fkDistrictID IN(SELECT pkDistrictID FROM cmn_district WHERE fkCityID = {$this->_data['intID']})";
        $objLocation = new ClsBllLocation();
        return $objLocation->GetDataAssociative($objFilter, '');
    }

    public function GetDistricts(){
        $objFilter = new \NsFWK\ClsFilter();
        $objFilter->intID = 'fkCityID = '.$this->_data['intID'];

        $objDistrict = new ClsBllDistrict();
        return $objDistrict->GetDataAssociative($objFilter, 'fldDistrict ASC');
    }

    public function GetAllCities(){
        $objFilter = new \NsFWK\ClsFilter();
        $strWhere = $objFilter->GetWhereStatement();
        $arrData = $this->GetDataAssociative($objFilter, 'fldCity ASC');
        $this->loadBindingAssociative($arrData, 'intID', 'arrDistricts', new ClsBllDistrict(), 'fkCityID', 'intCityID', true); 
        return $arrData;

    }
    public function UpdateCity($intCityID, $strCityName){
        $DB = &\ADODB_Connection_Manager::GetConnection('customer');
        $strSQL = 'UPDATE cmn_city SET fldCity = "'.$strCityName.'" WHERE pkCityID = '.$intCityID;
        $result = $DB->Execute($strSQL);
        if (!$result) {
            print($DB->errorMsg());
            $objResult['result'] = false;
            $objResult['title'] = 'Failure';
            $objResult['message'] = $DB->errorMsg();
            return $objResult;                
        }else{
            $objResult['result'] = true;
            $objResult['title'] = 'Success';
            $objResult['message'] = 'Data updated successfully!';
            return $objResult; 
        }
    }
}