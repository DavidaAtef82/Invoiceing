<?php
namespace NsCMN;

class ClsBllModuleAction extends \NsFWK\ClsBll{

    public function __set($name, $value){
        return parent::__set($name, $value);
    }

    public function __get($name){
        switch($name){
            case 'arrUserLevels':
                if(!key_exists($name, $this->_data)){
                    $obj = new ClsBllUserLevelAction();
                    $arrData = $obj->GetByAction($this->_data['intID']);
                    $this->_data[$name] = $arrData;
                }
                break;
        }
        return parent::__get($name);
    }

    public function __construct(){
        $this->_strClsDalLoad = '\NsCMN\ClsDalModuleAction';
        $this->_strClsDalSave = '\NsCMN\ClsDalModuleAction';
        $this->_data = array(
            'intID'=>-1,
            'intModuleID'=>'',
            'strAction'=>'',
            'strControllerClass'=>'',
            'strControllerType'=>''
        );

        @parent::__construct(func_get_args());
    }


    protected function _save(\ADODB_Active_Record $objDAL){
        if($this->getIsLoaded()){
            $rslt = $objDAL->Load('pkActionID=?',array($this->_data['intID']));
            if(!$rslt){
                return 'Could not load object!';
            }
        }

        $objDAL->fkModuleID = $this->_data['intModuleID'];
        $objDAL->fldControllerType = $this->_data['strControllerType'];
        $objDAL->fldControllerClass = $this->_data['strControllerClass'];
        $objDAL->fldAction = $this->_data['strAction'];
        $rslt = $objDAL->Save();
        if($rslt){
            $this->_data['intID'] = $objDAL->pkActionID;
        }

        return $rslt;
    }

    protected function _delete(\ADODB_Active_Record $objDAL){
            $conn = $objDAL->DB();                                
            $rslt = $conn->Execute('DELETE FROM mod_module_action WHERE pkActionID = ?', array($this->_data['intID']));
            if($rslt)
                return true;
            else
                return false;
    }

    protected function _load(\ADODB_Active_Record $objDAL){
        $this->_data['intID'] = $objDAL->pkActionID;
        $this->_data['intModuleID'] = $objDAL->fkModuleID;
        $this->_data['strAction'] = $objDAL->fldAction;
        $this->_data['strControllerClass'] = $objDAL->fldControllerClass;
        $this->_data['strControllerType'] = $objDAL->fldControllerType;
    }


    public function LoadByID($intID){
        $objFilter = new \NsFWK\ClsFilter();
        $objFilter->intID = "pkActionID = $intID";
        return $this->Load($objFilter);
    }

    public function GetAll(){
        $objFilter = new \NsFWK\ClsFilter();
        $arrData = $this->GetDataAssociative($objFilter,'fkModuleID, fldControllerType, fldControllerClass,fldAction');
        return $arrData;        
    }
    
    public function GetActionsByModule($intModuleID){
        $objFilter = new \NsFWK\ClsFilter();
        $objFilter->intID = "fkModuleID = $intModuleID";
        $arrData = $this->GetDataAssociative($objFilter, 'fkModuleID, fldControllerType, fldControllerClass, fldAction ASC');
        $this->loadBindingAssociative($arrData, 'intID', 'arrUserLevels', new ClsBllUserLevelAction(), 'pfActionID', 'intActionID', true);
        
        return $arrData;
    }
    
    public function GetActionsNotInUserLevel($intUserLevelID){
        $objFilter = new \NsFWK\ClsFilter();
        $objFilter->intActionID = "pkActionID NOT IN (SELECT pfActionID FROM mod_user_level_action WHERE pfUserLevelID = $intUserLevelID)";
        
        $arrData = $this->GetDataAssociative($objFilter, 'fkModuleID, fldControllerClass, fldControllerType, fldAction ASC');
        return $arrData;
    }

}