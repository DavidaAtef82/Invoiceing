<?php
namespace NsCMN;

class ClsBllConfig extends \NsFWK\ClsBll{
    public function __construct(){
        $this->_strClsDalLoad = '\NsCMN\ClsDalConfig';
        $this->_strClsDalSave = '\NsCMN\ClsDalConfig';
        $this->_data = array('strConfigKey'=>'',
            'intModuleID'=>'',
            'strSection'=>'',
            'strCaption'=>'',
            'strConfigValue'=>'',
            'intUseQuotes'=>0,
            'strComments'=>'',
            'intIsEdit'=>0,
            'intIsOptional'=>0);
        @parent::__construct(func_get_args());
    }


    protected function _save(\ADODB_Active_Record $objDAL){
        if($this->getIsLoaded()){
            $rslt = $objDAL->Load('pkConfigKey=?',array($this->_data['strConfigKey']));
            if(!$rslt){
                return 'Could not load object!';
            }
        }
        $objDAL->fldCaption = $this->_data['strCaption'];
        $objDAL->fldConfigValue = $this->_data['strConfigValue'];
        $objDAL->fldUseQuotes = $this->_data['intUseQuotes'];
        $objDAL->fldComments = $this->_data['strComments'];
        $objDAL->fldIsEdit = $this->_data['intIsEdit'];
        $objDAL->fldIsOptional = $this->_data['intIsOptional'];
        $rslt = $objDAL->Save();
        if($rslt){
            $this->_data['strConfigKey'] = $objDAL->pkConfigKey;
        }

        return $rslt;
    }

    protected function _delete(\ADODB_Active_Record $objDAL){
        return false;
    }

    protected function _load(\ADODB_Active_Record $objDAL){
        $this->_data['strConfigKey'] = $objDAL->pkConfigKey;
        $this->_data['intModuleID'] = ($objDAL->fkModuleID == null)? -1 : $objDAL->fkModuleID;
        $this->_data['strSection'] = $objDAL->fldSection;
        $this->_data['strCaption'] = $objDAL->fldCaption;
        $this->_data['strConfigValue'] = $objDAL->fldConfigValue;
        $this->_data['intUseQuotes'] = $objDAL->fldUseQuotes;
        $this->_data['strComments'] = $objDAL->fldComments;
        $this->_data['intIsEdit'] = $objDAL->fldIsEdit;
        $this->_data['intIsOptional'] = $objDAL->fldIsOptional;
    }


    public function LoadByID($strConfigKey){
        $objFilter = new \NsFWK\ClsFilter();
        $objFilter->intID = "pkConfigKey = '$strConfigKey'";
        return $this->Load($objFilter);
    }

    public function GetConfigsBySection(\NsFWK\ClsFilter $objFilter=null){
        $arrRslt = array();
        if(empty($objFilter)){
            $objFilter = new \NsFWK\ClsFilter();
        }

        $arrConfig = $this->GetData($objFilter, 'fldSection, fldCaption, fkModuleID ASC');
        if($arrConfig){
            $strLastSection = $arrConfig[0]->strSection;
            $arrItems = array();
            foreach($arrConfig as $config){
                if($config->strSection != $strLastSection){
                    // New Section
                    // 1.Save the old section
                    $arrRslt[] = array('section'=>$strLastSection, 'items'=>$arrItems);
                    // 2.Hold the new section name
                    $strLastSection = $config->strSection;
                    // 3.Reset the items array
                    $arrItems = array();
                }

                $arrItems[] = $config->ToArray();
            }

            // Save the last item
            $arrRslt[] = array('section'=>$strLastSection, 'items'=>$arrItems);
        }

        return $arrRslt;
    }

    public function GetAllConfig(){
        $objFilter = new \NsFWK\ClsFilter();
        return $this->GetData($objFilter, 'fkModuleID, fldSection, fldCaption ASC');
    }


    static public function GetSections(){
        $DB = &\ADODB_Connection_Manager::GetConnection('customer');
        $arrSections = $DB->GetArray("SELECT DISTINCT fldSection FROM cmn_config");
        if(empty($arrSections)){
            return array();
        }
        $arrResult = array();
        foreach($arrSections as $item){
            $arrResult[] = $item['fldSection'];
        }
        return $arrResult;
    }

    static public function GetAssignedModules(){
        $DB = &\ADODB_Connection_Manager::GetConnection('customer');
        $arrModuleIDs = $DB->GetArray("SELECT DISTINCT fkModuleID FROM cmn_config WHERE fkModuleID IS NOT NULL");
        if(empty($arrModuleIDs)){
            return array();
        }
        $arrResult = array();
        foreach($arrModuleIDs as $item){
            $arrResult[] = $item['fkModuleID'];
        }
        $strModuleIDs = implode(',',$arrResult);

        $objFilter = new \NsFWK\ClsFilter();
        $objFilter->intModuleID = "pkModuleID IN($strModuleIDs)";
        $objModule = new ClsBllModule();
        $arrModules = $objModule->GetDataAssociative($objFilter);

        $obj = new \stdClass();
        $obj->intID = -1;
        $obj->strTitle = 'General';
        $arrModules[] = $obj;
        return $arrModules;
    }

    static public function GetSectionsByModule(){
        $DB = &\ADODB_Connection_Manager::GetConnection('customer');
        $arrData = $DB->GetArray("SELECT DISTINCT fldSection,fkModuleID FROM cmn_config");
        if(empty($arrData)){
            return array();
        }
        $arrResult = array();
        foreach($arrData as $item){
            if($item['fkModuleID'] == null){
                $arrResult[-1][] = $item['fldSection'];
                continue;
            }
            $arrResult[$item['fkModuleID']][] = $item['fldSection'];
        }
        return $arrResult;
    }
}