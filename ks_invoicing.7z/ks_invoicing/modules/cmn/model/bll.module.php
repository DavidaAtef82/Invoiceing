<?php
namespace NsCMN;

class ClsBllModule extends \NsFWK\ClsBll{
    const MODULE_HR = 5;
    const MODULE_CMN = 6;
    const MODULE_REC = 7;
    const MODULE_TSK = 8;
    const MODULE_SF = 11;
    const MODULE_ACC = 12;
    const MODULE_CAB = 13;
    
    static protected $_arrEnabledModulesIDs = array();

    public function __set($name, $value){
        switch($name){
            case 'intDisabled':
                return false;
        }
        return parent::__set($name, $value);
    }
    
    public function __get($name){
        switch($name){
            case 'intDisabled':
                $arr = self::GetEnabledModulesIDs();
                $this->_data[$name] = (in_array($this->_data['intID'], $arr))? 0 : 1;
                break;
            case 'arrUserLevels':
                if(!key_exists($name, $this->_data)){
                    $this->_data[$name] = $this->getUserLevels();
                }
                break;
        }
        return parent::__get($name);
    }

    public function __construct(){
        $this->_strClsDalLoad = '\NsCMN\ClsDalModule';
        $this->_strClsDalSave = '\NsCMN\ClsDalModule';
        $this->_data = array(
            'intID'=>-1,
            'strModule'=>'',
            'strTitle'=>'',
            'strURL'=>''
        );
        @parent::__construct(func_get_args());
    }


    protected function _save(\ADODB_Active_Record $objDAL){
        if($this->getIsLoaded()){
            $rslt = $objDAL->Load('pkModuleID=?',array($this->_data['intID']));
            if(!$rslt){
                return 'Could not load object!';
            }
        }

        $objDAL->fldModule = $this->_data['strModule'];
        $objDAL->fldTitle = $this->_data['strTitle'];
        $objDAL->fldURL = $this->_data['strURL'];
        $rslt = $objDAL->Save();
        if($rslt){
            $this->_data['intID'] = $objDAL->pkModuleID;
        }

        return $rslt;
    }

    protected function _delete(\ADODB_Active_Record $objDAL){
        return true;
    }

    protected function _load(\ADODB_Active_Record $objDAL){
        $this->_data['intID'] = $objDAL->pkModuleID;
        $this->_data['strTitle'] = $objDAL->fldTitle;
        $this->_data['strModule'] = $objDAL->fldModule;
        $this->_data['strURL'] = $objDAL->fldURL;
        $this->intDisabled;
    }


    protected function getUserLevels(){
        $objFilter = new \NsFWK\ClsFilter();
        $objFilter->intModuleID = "fkModuleID = {$this->_data['intID']}";

        $obj = new ClsBllUserLevel();
        return $obj->GetData($objFilter, '');
    }
    

    public function LoadByID($intID){
        $objFilter = new \NsFWK\ClsFilter();
        $objFilter->intID = "pkModuleID = $intID";
        return $this->Load($objFilter);
    }

    public function GetModulesAssociative($objFilter=false, $strOrder='', $boolLoadUserLevels=false){
        if(!$objFilter){
            $objFilter = new \NsFWK\ClsFilter();
        }
        
        $arrData = $this->GetDataAssociative($objFilter, $strOrder);
        if(empty($arrData)){
            return $arrData;
        }
        
        if($boolLoadUserLevels){
            $arrModulesID = self::GetEnabledModulesIDs();
            $strModulesID = implode(',', $arrModulesID);
            
            $DB_COMMON = &\ADODB_Connection_Manager::GetConnection('common');
            $strSQL = "SELECT pfUserLevelID AS intID,
                            pfModuleID AS intModuleID,
                            fldDefaultModule AS intDefaultModule,
                            mod_user_level.fldUserLevel AS strUserLevel
                       FROM mod_user_level_default_page
                       LEFT JOIN mod_user_level
                        ON mod_user_level.pkUserLevelID = pfUserLevelID
                       WHERE fldDefaultModule = 1
                        AND pfModuleID IN ($strModulesID)";
            $arrUserLevels = $DB_COMMON->GetArray($strSQL);
            
            $arrUserLevelsByModuleID = \NsFWK\ClsHlpHelper::IndexObjectArrayAssoc($arrUserLevels, array('intModuleID'), true);
            foreach($arrData as &$data){
                $arrUserLevels = array();
                if(isset($arrUserLevelsByModuleID[$data['intID']])){
                    $arrUserLevels = $arrUserLevelsByModuleID[$data['intID']];    
                }
                $data['arrUserLevels'] = $arrUserLevels;        
            }
        }

        return $arrData;
    }
        

    static public function Disable($intModuleID){
        // Customer database;
        $DB = &\ADODB_Connection_Manager::GetConnection('customer');
        $rslt = $DB->Execute("UPDATE cmn_module SET fldDisabled=1 WHERE pfModuleID = $intModuleID");
        if ($rslt) {
            //self::GetEnabledModulesIDs();
            // Remove module id from $_arrEnabledModulesIDs
            if (($key = array_search($this->_data['intID'], self::$_arrEnabledModulesIDs)) !== false) {
                unset(self::$_arrEnabledModulesIDs[$key]);
            }
            return true;
        } else {
            return false;
        }
    }
    
    static public function Enable($arrModuleIDs){
        // Customer database;
        $DB = &\ADODB_Connection_Manager::GetConnection('customer');
        $strModuleIDs = implode(",",$arrModuleIDs);
        $rslt = $DB->Execute("UPDATE cmn_module SET fldDisabled=0 WHERE pfModuleID IN($strModuleIDs)");
        if ($rslt) {
            //self::GetEnabledModulesIDs();
            // Add module id to $_arrEnabledModulesIDs
            if (!in_array($this->_data['intID'], self::$_arrEnabledModulesIDs)) {
                self::$_arrEnabledModulesIDs[] = $this->_data['intID'];
            }
            return true;
        } else {
            return false;
        }
    }
    
    static public function GetEnabledModulesIDs(){
        if(empty(self::$_arrEnabledModulesIDs)){
            $DB = &\ADODB_Connection_Manager::GetConnection('customer');
            self::$_arrEnabledModulesIDs = $DB->GetCol('SELECT pfModuleID FROM cmn_module WHERE fldDisabled = 0');
        }
        
        return self::$_arrEnabledModulesIDs;
    }

    static public function GetUsage(){
        // Init $arrUsage
        $arrUsage = array('HR'=>0, 'CAB'=>0, 'TSK'=>0, 'SF'=>0, 'FP'=>0, 'Files'=>0);

        // Get active modules
        $arrEnabledModuleID = self::GetEnabledModulesIDs();
        if(empty($arrEnabledModuleID)){
            return $arrUsage;
        }
        
        $arrEnabledModuleUserLevel = self::getUsageModuleUserLevels($arrEnabledModuleID);
        foreach($arrEnabledModuleUserLevel as $intEnabledModuleID => $arrUserLevel){
            switch($intEnabledModuleID){
                case self::MODULE_HR:
                    $arrUsage["HR"] = self::getUsageHR();
                    $arrUsage["FP"] = self::getUsageFP();
                    break;
                case self::MODULE_CAB:
                    $arrUsage["CAB"] = self::getUsageHR();
                    break;
                case self::MODULE_TSK:
                    $arrUsage["TSK"] = self::getUsageUsers($arrUserLevel);
                    break;
                case self::MODULE_SF:
                    $arrUsage["SF"] = self::getUsageUsers($arrUserLevel);
                    break;
            }
        }
        $arrUsage["Files"] = self::getUsageFiles();
        return $arrUsage;
    }


    static protected function getUsageModuleUserLevels($arrEnabledModule){
        $DB_COMMON = &\ADODB_Connection_Manager::GetConnection('common');
        
        $strEnabledModule = implode(',', $arrEnabledModule);
        $SQL = "SELECT pfModuleID, GROUP_CONCAT(pfUserLevelID) AS fldUserLevelIDs
                FROM mod_user_level_default_page
                WHERE pfModuleID IN ($strEnabledModule)
                GROUP BY pfModuleID";
        $arrRow = $DB_COMMON->GetArray($SQL);
        if(empty($arrRow)){
            return array();
        }
        
        $arrRslt = array();
        foreach($arrRow as $row){
            $intModuleID = $row['pfModuleID'];
            $arrUserLevel = explode(',', $row['fldUserLevelIDs']);
            $arrRslt["$intModuleID"] = $arrUserLevel;
        }
        
        return $arrRslt;
    }

    static protected function getUsageUsers($arrUserLevel){
        $DB = &\ADODB_Connection_Manager::GetConnection('customer');

        $strUserLevel = implode(',', $arrUserLevel);
        $SQL = "SELECT COUNT(*)
                FROM cmn_user
                WHERE pkUserID IN (SELECT pfUserID FROM cmn_user_user_level WHERE pfUserLevelID IN ($strUserLevel))
                AND fldDisabled = 0;";
        $rslt = $DB->GetOne($SQL);
        if($rslt === false){
            return 0;
        }
        return $rslt;
    }

    static protected function getUsageHR(){
        $DB = &\ADODB_Connection_Manager::GetConnection('customer');
        $SQL = "SELECT COUNT(*) FROM hr_employee_info_employment WHERE fldEmploymentStatus = ?";
        $rslt = $DB->GetOne($SQL, array(\NsHR\ClsBllEmployeeInfoEmployment::STATUS_WORKING));
        return $rslt;
    }

    static protected function getUsageFP(){
        $DB = &\ADODB_Connection_Manager::GetConnection('customer');
        $SQL = "SELECT COUNT(*) FROM hr_attendance_device WHERE fldDisabled = 0";
        $rslt = $DB->GetOne($SQL);
        return $rslt;
    }

    static protected function getUsageFiles(){
        // Note that trashed files are included until
        // they get removed by the EmptyRecycleBin cron
        $DB = &\ADODB_Connection_Manager::GetConnection('customer');
        $SQL = "SELECT SUM(fldSize) FROM cmn_file";
        $rslt = $DB->GetOne($SQL);
        return $rslt;
    }
}