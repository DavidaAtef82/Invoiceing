<?php
namespace NsCMN;

class ClsBllUser extends \NsFWK\ClsBll{
    const TOP_UNREAD_COUNT = 5;
    
    const ERR_BLANK_USERNAME = 1173;
    const ERR_SHORT_USERNAME = 1174;
    const ERR_INVALID_CHAR = 1175;
    const ERR_NO_USER_LEVEL = 1177;
    const ERR_CANNOT_CREATE = 1178;
    const ERR_CANNOT_ASSIGN_USER_LEVEL = 1179;
    const ERR_UNKNOWN = 1180;
    const ERR_USERNAME_UNAVAILABLE = 1181;
    const ERR_NO_EMPLOYEE = 1182;
    const ERR_NO_SALES_TEAM = 1183;

    public function __set($name, $value){
        switch($name){
            case 'arrUserLevelIDs':
                return false;
        }
        return parent::__set($name, $value);
    }

    public function __get($name){
        switch($name){
            case 'arrUserLevelIDs':
                if(!key_exists($name, $this->_data)){
                    $this->getUserLevels();
                }
                break;
            case 'arrUserLevels':
                if(!key_exists($name, $this->_data)){
                    $this->getUserLevels();
                }
                break;
            case 'objUserLevel':
                if(!key_exists($name, $this->_data)){
                    $arrUserLevels = $this->arrUserLevels;
                    if(!empty($arrUserLevels)){
                        $this->_data[$name] = $arrUserLevels[0];
                    }else{
                        $this->_data[$name] = null;
                    }
                }
                break;
            case 'objEmployee':
                if(!key_exists($name, $this->_data)){
                    $this->_data[$name] = \NsHR\ClsBllEmployee::GetEmployeeByUserID($this->_data['intID']);
                }
                break;
            case 'intUnreadNotificationCount':
                if(!key_exists($name, $this->_data)){
                    $this->_data[$name] = ClsBllNotification::Count($this->_data['intID'], 0);
                }
                break;
            case 'arrTopUnreadNotification':
                if(!key_exists($name, $this->_data)){
                    $obj = new ClsBllNotification();
                    $this->_data[$name] = $obj->GetDataAssociativeUserNotifications($this->_data['intID'], 0, self::TOP_UNREAD_COUNT);
                }
                break;
            case 'arrActions':
                if(!key_exists($name, $this->_data)){
                    $this->getActions();
                }
                break;
            case 'arrActionsIDs':
                if(!key_exists($name, $this->_data)){
                    $this->getActions();
                }
                break;
            case 'arrMenuItems':
                if(!key_exists($name, $this->_data)){
                    $this->_data[$name] = $this->getMenuItems();
                }
                break;
            case 'arrDefaultPages':
                if(!key_exists($name, $this->_data)){
                    $this->_data[$name] = $this->getDefaultPages();
                }
                break;
            case 'objUserDialog':
                if(!key_exists($name, $this->_data)){
                    $this->_data[$name] = $this->getStartupDialog();
                }
                break;
        }
        return parent::__get($name);
    }

    public function __construct(){
        if(empty($this->_strClsDalLoad)){
            $this->_strClsDalLoad = '\NsCMN\ClsDalUser';
        }
        if(empty($this->_strClsDalSave)){
            $this->_strClsDalSave = '\NsCMN\ClsDalUser';
        }

        $arrProperties = array('intID'=>-1,
                             'strUserName'=>'',
                             'strDisplayName'=>'',
                             'strEmail'=>'',
                             'intPhotoID'=>-1,
                             'intDisabled'=>0);

        $this->_data = array_merge($this->_data, $arrProperties);
        @parent::__construct(func_get_args());
    }


    protected function _save(\ADODB_Active_Record $objDAL){
        if($this->getIsLoaded()){
            // Updating an existing user
            $rslt = $objDAL->Load('pkUserID=?',array($this->_data['intID']));
            if(!$rslt){
                return 'Could not load object!';
            }
        }else{
            // Creating a new user => Password cannot be editted using regular Save() method
            // User with empty password is not allowed
            if(!isset($this->_data['strPassword']) || empty($this->_data['strPassword'])){
                return false;
            }

            $objDAL->fldPassword = md5($this->_data['strPassword']);
        }
        
        if (preg_match("/\\s/", $this->_data['strUserName'])) {
           // there are spaces
           return false;
        }

        $objDAL->fldUserName = $this->_data['strUserName'];
        $objDAL->fldDisplayName = $this->_data['strDisplayName'];
        $objDAL->fldEmail = $this->_data['strEmail'];
        $objDAL->fkPhotoID = ($this->_data['intPhotoID'] == -1)?null:$this->_data['intPhotoID'];
        $objDAL->fldDisabled = $this->_data['intDisabled'];
        $rslt = $objDAL->Save();
        if($rslt){
            $this->_data['intID'] = $objDAL->pkUserID;
        }
        
        if(isset($this->_data['strPassword'])){
            unset($this->_data['strPassword']);
        }
        return $rslt;
    }

    protected function _delete(\ADODB_Active_Record $objDAL){}

    protected function _load(\ADODB_Active_Record $objDAL){
        $this->_data['intID'] = (int)$objDAL->pkUserID;
        $this->_data['strUserName'] = $objDAL->fldUserName;
        $this->_data['strDisplayName'] = $objDAL->fldDisplayName;
        $this->_data['strEmail'] = $objDAL->fldEmail;
        $this->_data['intPhotoID'] = ($objDAL->fkPhotoID == null)? -1:$objDAL->fkPhotoID;
        $this->_data['intDisabled'] = $objDAL->fldDisabled;
    }


    protected function getActions(){
        $arrUserLevelIDs = $this->arrUserLevelIDs;
        if(empty($arrUserLevelIDs)){
            return array();
        }

        $arrRslt = array();
        
        $arrEnabledModulesIDs = ClsBllModule::GetEnabledModulesIDs();
        $strModuleIDs = implode(',', $arrEnabledModulesIDs);
        
        $strUserLevelIDs = implode(',', $arrUserLevelIDs);
        $objDAL = new ClsDalUserLevelActionDetails();
        $arr = $objDAL->Find("fkModuleID IN ($strModuleIDs) AND pfUserLevelID IN($strUserLevelIDs)");
        
        $arrActionsIDs = array();
        if($arr){
            foreach($arr as $item){
                $strKey = $item->fldModule . '-' . $item->fldControllerType . '-' . $item->fldControllerClass . '-' . $item->fldAction;
                $strKey = strtolower($strKey);
                if(isset($arrRslt[$strKey])){
                    $arrRslt[$strKey] .= ',' . $item->fldPermissions;
                }else{
                    $arrActionsIDs[] = $item->pfActionID;
                    $arrRslt[$strKey] = $item->fldPermissions;
                }
            }
        }
        $this->_data['arrActionsIDs'] = $arrActionsIDs;
        $this->_data['arrActions'] = $arrRslt;
    }  
    
    protected function getMenuItems(){
        $arrMenuGroup = array();
        $arrActions = $this->arrActions;
        $objSitemap = new ClsBllSitemap();
        $arr = $objSitemap->GetMenu();

        if($arr){
            foreach($arr as $item){
                $strKey = $item->strModule;
                $strKey .= '-' . $item->strControllerType;
                $strKey .= '-' . $item->strControllerClass;
                $strKey .= '-' . $item->strAction;
                $strKey = strtolower($strKey);
                
                if(empty($item->intActionID) || isset($arrActions[$strKey])){
                    // This is either a menu group, or a menu-item that user has permission on
                    
                    $arrMenuGroup[(int)$item->intGroupOrder][] = array(
                        'intMenuItemID'=>$item->intID,
                        'intModuleID'=>$item->intModuleID,
                        'intActionID'=>$item->intActionID,
                        'strModule'=>$item->strModule,
                        'strControllerType'=>$item->strControllerType,
                        'strControllerClass'=>$item->strControllerClass,
                        'strAction'=>$item->strAction,
                        'strMenuText'=>$item->strItemText,
                        'strMenuStyle'=>$item->strItemStyle,
                        'intOrder'=>$item->intItemOrder,
                        'intLevel'=>$item->intItemLevel,
                        'boolShowInMenu'=>$item->boolShowInMenu
                    );
                }
            }
        }

        $arrRslt = $this->removeEmptyMenuGroups($arrMenuGroup);
        return $arrRslt;
    }
    
    protected function removeEmptyMenuGroups($arrMenuGroup){
        $arrRslt = array();
        foreach($arrMenuGroup as $group=>$menu){
            $l = count($menu) - 1;
            for($i=$l; $i>=0; $i--){
                $ok1 = is_null($menu[$i]['intActionID']) && $this->hasMenuItems($menu, $i);
                $ok2 = !is_null($menu[$i]['intActionID']);
                if($ok1 || $ok2){
                    if(!isset($arrRslt[$group])){
                        $arrRslt[$group] = array();
                    }

                    array_unshift($arrRslt[$group], $menu[$i]);
                }
            }
        }

        return $arrRslt;
    }
                                                                             
    protected function hasMenuItems(&$arrMenuItems, $intGroupIndex){
        $l = count($arrMenuItems);
        for($i=$intGroupIndex+1; $i<$l; $i++){
            if($arrMenuItems[$i]['intLevel'] <= $arrMenuItems[$intGroupIndex]['intLevel']){
                break;
            }

            if(!is_null($arrMenuItems[$i]['intActionID']) && $arrMenuItems[$i]['boolShowInMenu']){
                return true;
            }
        }

        return false;
    }

    protected function getUserLevels(){
        $objDAL = new ClsDalUserUserLevel();
        $arrDALUserLevels = $objDAL->Find("pfUserID = {$this->_data['intID']}");
        if(empty($arrDALUserLevels)){
            return array();
        }
        
        $arrUserLevelIDs = array();
        foreach($arrDALUserLevels as $userlevel){
            $arrUserLevelIDs[] = $userlevel->pfUserLevelID;
        }
        
        $objFilter = new ClsFilterUserLevel();
        $objFilter->arrID = $arrUserLevelIDs;
        $objUserLevel = new ClsBllUserLevel();
        $this->_data['arrUserLevels'] = $objUserLevel->GetData($objFilter);
        $this->_data['arrUserLevelIDs'] = $arrUserLevelIDs;
    }

    protected function getDefaultPages(){
        $strUserLevelIDs = implode(',', $this->arrUserLevelIDs);
        
        $strSql = "SELECT
                        pfUserLevelID AS intUserLevelID,
                        pfModuleID AS intModuleID,
                        fldDefaultModule AS intDefaultModule,
                        fldDefaultPage AS strDefaultPage
                   FROM mod_user_level_default_page WHERE pfUserLevelID IN ($strUserLevelIDs)";
        $DB_COMMON = &\ADODB_Connection_Manager::GetConnection('common');
        $arrData = $DB_COMMON->GetArray($strSql);
        
        $arrDefaultPages = array();
        foreach($arrData as $page){
            // value not set yet
            if(!isset($arrDefaultPages[$page['intModuleID']])){
                $arrDefaultPages[$page['intModuleID']] = $page['strDefaultPage'];    
            }
            // default module
            if($page['intDefaultModule']){
                $arrDefaultPages[$page['intModuleID']] = $page['strDefaultPage'];    
            }
        }
        return $arrDefaultPages;
    }
    
    protected function getStartupDialog(){
        $objUserDialog = new ClsBllUserStartupDialog();
        $ok = $objUserDialog->LoadNextDialog($this->_data['intID']);
        if($ok){
            $objUserDialog->Start();
            return $objUserDialog;   
        }

        return null;
    }


    public function Delete(){
        $DB = &\ADODB_Connection_Manager::GetConnection('customer');
        $rslt = $DB->Execute('DELETE FROM cmn_user WHERE pkUserID = ?', array($this->_data['intID']));
        if($rslt)
            return 1;
        else{
            $rslt = $DB->Execute('UPDATE cmn_user SET fldDisabled = 1 WHERE pkUserID = ?', array($this->_data['intID']));
            if($rslt){
                $this->_data['intDisabled'] = 1;
                return 2;
            }else{
                return 0;
            }
        }
    }

    public function Enable(){
        if(!$this->getIsLoaded()){
            return false;
        }
        
        $this->_data['intDisabled'] = 0;
        return  $this->Save();
    }
    

    public function UploadImage($strCaption, $strDescription, $strContent, $intModuleID, $strFileName, $strType, $intSize, $intUserID){
        $DB = &\ADODB_Connection_Manager::GetConnection('customer');
        $DB->StartTrans();
        
        $obj = ClsBllFile::Create($intModuleID, $strCaption, $strDescription, $strFileName, $strContent, $intUserID);
        if(!$obj){
            return $DB->CompleteTrans(false);
        }
        
        $this->_data['intPhotoID'] = $obj->intID;
        $ok = $this->Save();
        
        $rslt = $DB->CompleteTrans($ok);
        return $rslt;
    }
    
    public function UpdateUserLevels($arrUserLevelIDs, $intEmployeeID = -1, $intTeamID = -1){
        if(!$this->getIsLoaded()){
            return false;
        }
        if(empty($arrUserLevelIDs)){
            return false;
        }
        
        $DB = &\ADODB_Connection_Manager::GetConnection('customer');
        $DB->StartTrans();
        
        // Employee checks
        if(in_array(\NsCMN\ClsBllUserLevel::USER_LEVEL_EMPLOYEE,$arrUserLevelIDs) || in_array(\NsCMN\ClsBllUserLevel::USER_LEVEL_HEAD,$arrUserLevelIDs)){
            // Employee ID is must
            if($intEmployeeID == -1 && is_null($this->objEmployee)){
                return false;
            }
            if($intEmployeeID != -1 || (!is_null($this->objEmployee) && $intEmployeeID != -1 && $intEmployeeID != $this->objEmployee->intID)){
                // Employee ID changed or new employee
                // record created only in case there is employee id
                $strSQL = "INSERT INTO hr_user(pfUserID, fkEmployeeID) 
                           VALUES({$this->intID}, $intEmployeeID) ON DUPLICATE KEY UPDATE fkEmployeeID = $intEmployeeID";
            }                                                                                                            
        }else{
            $strSQL = "DELETE FROM hr_user 
                       WHERE pfUserID = {$this->intID}";
        }
        $rslt = $DB->Execute($strSQL); 
        if(!$rslt){
            return $DB->CompleteTrans(false);
        }
        
        // Team checks
        if(in_array(\NsCMN\ClsBllUserLevel::USER_LEVEL_SALES_PERSON,$arrUserLevelIDs)){
            $objSFUser = ClsBllUser::GetUserByID($this->intID, ClsBllModule::MODULE_SF); 
            if($intTeamID == -1 && $objSFUser->intTeamID == -1){
                // Team ID is must
                return false;
            }
            if($intTeamID != -1 || ($objSFUser->intTeamID != -1 && $intTeamID != -1 && $intTeamID != $objSFUser->intTeamID)){
                // record created only in case there is team id
                $strSQL = "INSERT INTO sf_user(pfSalespersonID, fkTeamID) 
                           VALUES({$this->intID}, $intTeamID) ON DUPLICATE KEY UPDATE fkTeamID = $intTeamID";
            }
        }else{
            $strSQL = "DELETE FROM sf_user
                       WHERE pfSalespersonID = {$this->intID}";
        }
        $rslt = $DB->Execute($strSQL); 
        if(!$rslt){
            return $DB->CompleteTrans(false);
        }
            
        if(!empty($this->arrUserLevelIDs)){
            // check if arrUserlevels haven't been changed
            $arrSavedUserlevels = $this->arrUserLevelIDs;
            $arrIntersection = array_intersect($arrSavedUserlevels,$arrUserLevelIDs);
            if(count($arrIntersection) == count($arrSavedUserlevels) && count($arrIntersection) == count($arrUserLevelIDs)){
                return $DB->CompleteTrans(true);                   
            }    
        }
            
        // Delete existing user levels
        $strSQL = "DELETE FROM cmn_user_user_level WHERE pfUserID = {$this->intID};";    
        $rslt = $DB->Execute($strSQL); 
        if(!$rslt){
            return $DB->CompleteTrans(false);
        }
        
        $rslt = true;
        if(!empty($arrUserLevelIDs)){
            // insert new user levels
            $arrUserLevelIDs = array_unique($arrUserLevelIDs);
            $strSQL = "INSERT INTO cmn_user_user_level VALUES ";    
            for($i=0;$i<count($arrUserLevelIDs);$i++){
                $strSQL .= "({$this->intID},{$arrUserLevelIDs[$i]}),";
            }
            $strSQL = substr($strSQL, 0, -1);
            $rslt = $DB->Execute($strSQL);
        }
        return $DB->CompleteTrans($rslt);
    }
    
    public function GetModules($boolAssoc = false) {
        $DB_COMMON = &\ADODB_Connection_Manager::GetConnection('common');

        $strUserLevelIDs = implode(',', $this->arrUserLevelIDs);
        $strSQL = "SELECT pfModuleID
                    FROM mod_user_level_default_page
                    WHERE fldDefaultModule = 1
                    AND pfUserLevelID IN ($strUserLevelIDs)";
        $arrModuleID = $DB_COMMON->GetCol($strSQL, $this->_data['intID']);
        if (empty($arrModuleID)) {
            return array();
        }

        $objFilter = new ClsFilterModule();
        $objFilter->arrID = $arrModuleID;
        $objModule = new ClsBllModule();
        if ($boolAssoc) {
            return $objModule->GetData($objFilter);
        } else {
            return $objModule->GetDataAssociative($objFilter);
        }
    }


    public function Login($strUserName, $strPassword){
        $strPasswordHashed = md5($strPassword);
        $objFilter = new \NsFWK\ClsFilter();
        $objFilter->strUserName = "fldUserName = '$strUserName'";
        $objFilter->strPassword = "fldPassword = '$strPasswordHashed'";
        $objFilter->intDisabled = "fldDisabled = 0";
        $rslt = $this->Load($objFilter);
        if(!$rslt){
            return false;
        }else{
            return true;
        }
    }
    
    public function ChangePassword($strOldPassword, $strNewPassword){
        if(!$this->getIsLoaded()){
            return false;
        }

        if(empty($strNewPassword)){
            // Empty passwords are not allowed
            return false;
        }
        
        if($strOldPassword == $strNewPassword){
            return true;
        }

        $DB = &\ADODB_Connection_Manager::GetConnection('customer');
        
        $strOldPasswordMD5 = md5($strOldPassword);
        $strNewPasswordMD5 = md5($strNewPassword);
        
        $SQL = "UPDATE cmn_user SET fldPassword = ? WHERE pkUserID = ? AND fldPassword = ?;";
        $ok = $DB->Execute($SQL, array($strNewPasswordMD5, $this->_data['intID'], $strOldPasswordMD5)); 
        if(!$ok){
            return false;
        }
        
        // Update failed => the provided old password does not match the existing one
        $intAffectedRows = $DB->Affected_Rows();
        if($intAffectedRows == 0){
            return false;
        }

        return true;
    }

    public function ResetPassword($strNewPassword, $intPasswordResetID){
        if(!$this->getIsLoaded()){
            return false;
        }

        if(empty($strNewPassword)){
            // Empty passwords are not allowed
            return false;
        }

        $DB = &\ADODB_Connection_Manager::GetConnection('customer');
        $DB->StartTrans();

        if($intPasswordResetID != -1){
            $SQL = "UPDATE cmn_user_reset_password SET fldUsed = ? WHERE pkID = ? AND fkUserID = ? AND fldUsed = ?;";
            $ok = $DB->Execute($SQL, array(1, $intPasswordResetID, $this->_data['intID'], 0)); 
            if(!$ok){
                return $DB->CompleteTrans(false);
            }
            
            $intAffectedRows = $DB->Affected_Rows();
            if($intAffectedRows == 0){
                return $DB->CompleteTrans(false);
            }
        }

        $strPasswordHashed = md5($strNewPassword);
        
        $SQL = 'UPDATE cmn_user SET fldPassword = ? WHERE pkUserID = ?';
        $ok = $DB->Execute($SQL, array($strPasswordHashed, $this->_data['intID']));
        $rslt = $DB->CompleteTrans($ok);
        return $rslt;
    }

    public function AssignAutoPassword($intLength = 8){
        if(!$this->getIsLoaded()){
            return false;
        }

        $DB = &\ADODB_Connection_Manager::GetConnection('customer');

        $strPassword = \NsFWK\ClsHlpHelper::GeneratePassword($intLength);
        $strPasswordHashed = md5($strPassword);
        
        $SQL = 'UPDATE cmn_user SET fldPassword = ? WHERE pkUserID = ?';
        $ok = $DB->Execute($SQL, array($strPasswordHashed, $this->_data['intID']));
        if($ok){
            return $strPassword;
        }else{
            return false;
        }
    }
    

    public function LoadByID($intID){
        $objFilter = new \NsFWK\ClsFilter();
        $objFilter->intID = "pkUserID = $intID";
        return $this->Load($objFilter);
    }

    public function LoadByEmployeeID($intEmployeeID){
        $objFilter = new \NsFWK\ClsFilter();
        $objFilter->intUserID = "pkUserID IN (SELECT pfUserID FROM hr_user WHERE fkEmployeeID = $intEmployeeID)";
        return $this->Load($objFilter);
    }

    public function LoadByUserName($strUserName){
        $objFilter = new \NsFWK\ClsFilter();
        $objFilter->strUserName = "fldUserName LIKE '$strUserName'";
        return $this->Load($objFilter);
    }
    

    public function GetUsersByUserLevel($intUserLevel, $boolActive=false){
        $objFilter = new ClsFilterUser();
        $objFilter->intUserLevelID = $intUserLevel;    
        if($boolActive){
            $objFilter->intDisabled =  0;    
        }
        
        $arrData = parent::GetDataAssociative($objFilter, 'fldDisplayName ASC', '');
        if(empty($arrData)){
            return $arrData;
        }
        
        
        return $arrData;
    }

    public function GetActiveUsers(){
        $objFilter = new \NsFWK\ClsFilter();
        $objFilter->intDisabled = 'fldDisabled = 0';
        
        $arrData = parent::GetDataAssociative($objFilter, 'fldDisplayName ASC', '');
        if(empty($arrData)){
            return $arrData;
        }
        
        return $arrData;
    }                                                                                                      
    

    static public function ValidateUsernameString($strUsername) {
        if (empty($strUsername)) {
            return self::ERR_BLANK_USERNAME;                   
        }
        
        $intMin = \NsFWK\ClsConfiguration::GetInstance()->cmn_UsernameMinChars;
        $intMax = \NsFWK\ClsConfiguration::GetInstance()->cmn_UsernameMaxChars;
        if (strlen($strUsername) < $intMin) {
            return self::ERR_SHORT_USERNAME;                   
        }
        
        $intMin -= 2;   // As validation statically checks for first and last chars
        $intMax -= 2;   // As validation statically checks for first and last chars

        // Username string length must be between UsernameMinChars and UsernameMaxChars
        // It can only include: english letters, numbers, '.' and '_'
        // It must start with an english letter
        // It must end with an an english letter or a number
        // Successive '.' or '_' or both is not allowed
        $strRegEx = '/^[a-zA-Z]((?:[a-zA-Z0-9]|([._])(?![._])){' . "$intMin,$intMax" . '})[a-zA-Z0-9]$/';
        $rslt = preg_match($strRegEx, $strUsername, $arrMatches);
        if (!$rslt) {
            return self::ERR_INVALID_CHAR;                   
        }
        
        return true;
    }

    static public function IsUsernameAvailable($strUserName){
        $DB = &\ADODB_Connection_Manager::GetConnection('customer');
        $strSQL = "SELECT * FROM cmn_user WHERE fldUserName LIKE ? LIMIT 1";
        $arr = $DB->GetArray($strSQL, $strUserName);
        if (empty($arr)) {
            return true;
        } else {
            return self::ERR_USERNAME_UNAVAILABLE;
        }
    }


    static public function GetUserByID($intID, $intModuleID){
        $objModule = new ClsBllModule();
        $rslt = $objModule->LoadByID($intModuleID);
        if(!$rslt){
            return null;
        }
        
        $strClassName = '\Ns' .strtoupper($objModule->strModule). '\ClsBllUser';
        $objUser = new $strClassName();
        $objUser->LoadByID($intID);
        return $objUser;
    }
    
    static public function GetUsersNames(){
        $DB = &\ADODB_Connection_Manager::GetConnection('customer');
        $strSQL = "SELECT pkUserID, fldUserName FROM cmn_user";
        $arr = $DB->GetAssoc($strSQL);
        return $arr;
    }


    static public function Create($strUsername, $strDisplayName, $strPassword, $strEmail, $arrUserlLevelIDs, $intEmployeeID = -1, $intTeamID = -1){
        if (empty($arrUserlLevelIDs)) {
            return self::ERR_NO_USER_LEVEL;
        }
        
        foreach ($arrUserlLevelIDs as $intUserLevelID) {
            if (in_array($intUserLevelID, array(ClsBllUserLevel::USER_LEVEL_EMPLOYEE , ClsBllUserLevel::USER_LEVEL_HEAD)) && $intEmployeeID == -1) {
                return self::ERR_NO_EMPLOYEE;
            } elseif (in_array($intUserLevelID, array(ClsBllUserLevel::USER_LEVEL_SALES_PERSON)) && $intTeamID == -1) {
                return self::ERR_NO_SALES_TEAM;
            }
        }
        
        $ok = ClsBllUser::ValidateUsernameString($strUsername);
        if ($ok !== true) {
            // $ok contains error message
            return $ok;
        }
        
        $ok = ClsBllUser::IsUsernameAvailable($strUsername);
        if ($ok !== true) {
            // $ok contains error message
            return $ok;
        }
        
        $DB = &\ADODB_Connection_Manager::GetConnection('customer');
        $DB->StartTrans();
        
        $objUser = new ClsBllUser();
        $objUser->_data['strUserName'] = $strUsername;
        $objUser->_data['strDisplayName'] = $strDisplayName;
        $objUser->_data['strPassword'] = $strPassword;
        $objUser->_data['strEmail'] = $strEmail;
        $ok = $objUser->Save();
        if(!$ok){
            $DB->CompleteTrans($ok);
            return self::ERR_CANNOT_CREATE;
        }

        $ok = $objUser->UpdateUserLevels($arrUserlLevelIDs, $intEmployeeID, $intTeamID);
        if(!$ok){
            $DB->CompleteTrans($ok);
            return self::ERR_CANNOT_ASSIGN_USER_LEVEL;
        }

        $ok = $DB->CompleteTrans();
        if(!$ok){
            return self::ERR_UNKNOWN;
        }

        return $objUser;
    }
    
    static public function CreatePasswordResetRecord($intUserID, $dtDateTime){
        $DB = &\ADODB_Connection_Manager::GetConnection('customer');

        $strChars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        $strKey = substr(str_shuffle($strChars), 0, 8);
        $strKey = md5(date("YmdHis").$strKey);
        
        $strSQL = "INSERT INTO cmn_user_reset_password(fkUserID, fldDateTime, fldKey) VALUES(?, ?, ?)";
        
        $rslt = $DB->Execute($strSQL, array($intUserID, $dtDateTime, $strKey)); 
        if(!$rslt){
            return false;
        }
        
        $intID = $DB->Insert_ID();
        $arrResult = array("intID"=>$intID, 'strKey'=>$strKey);
        return $arrResult;
    }
    
    static public function CheckPasswordExpiration($intID, $strKey){
        // Check if link has been used before or not
        // Check if id and key are right
        // Check link expiration
        $DB = &\ADODB_Connection_Manager::GetConnection('customer');
        $strSQL = "SELECT fldDateTime FROM cmn_user_reset_password WHERE pkID = ? AND fldKey = ? AND fldUsed = ?";
        $dtDateTime = $DB->GetOne($strSQL, array($intID, $strKey, 0));
        if(is_null($dtDateTime) || $dtDateTime == false){
            // invalid id or key or link has been used before
            return false;
        }
        
        $intResetPasswordExpirationHours = \NsFWK\ClsConfiguration::GetInstance()->ResetPasswordExpirationHours;
        $dtExpirationDateTime = date("Y-m-d H:i", strtotime($dtDateTime . " +$intResetPasswordExpirationHours hour"));
        if(date("Y-m-d H:i") > $dtExpirationDateTime){
            // Link expired
            return false;
        }

        return true;
    }
    
    static public function ValidatePasswordResetID($intID, $strKey, $intUserID){
        // Validate id, key and user is the same as the inserted user
        $DB = &\ADODB_Connection_Manager::GetConnection('customer');

        $strSQL = "SELECT * FROM cmn_user_reset_password WHERE pkID = ? AND fldKey = ? AND fkUserID = ? AND fldUsed = ?";
        $rslt = $DB->GetOne($strSQL, array($intID, $strKey, $intUserID, 0));
        if(is_null($rslt) || $rslt == false){
            // invalid id or key or user or link has been used before
            return false;
        }

        return true;
    }
}