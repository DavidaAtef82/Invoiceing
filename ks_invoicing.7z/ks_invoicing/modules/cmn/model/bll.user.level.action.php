<?php
namespace NsCMN;

class ClsBllUserLevelAction extends \NsFWK\ClsBll{
    public function __get($name) {
        return parent::__get($name);
    }

    public function __construct(){
        $this->_strClsDalLoad = '\NsCMN\ClsDalUserLevelActionDetails';
        $this->_strClsDalSave = '\NsCMN\ClsDalUserLevelAction';   
        $this->_data = array(
            'intUserLevelID'=>'',
            'strUserLevel'=>'',
            'intActionID'=>'',
            'intModuleID'=>'',
            'strModuleName'=>'',
            'strAction'=>'',
            'strControllerClass'=>'',
            'strControllerType'=>'',
            'strPermission'=>'');
        @parent::__construct(func_get_args());
    }


    protected function _save(\ADODB_Active_Record $objDAL){
        if($this->getIsLoaded()){
            $rslt = $objDAL->Load('pfUserLevelID=? AND pfActionID = ?',array($this->_data['intUserLevelID'],$this->_data['intActionID']));
            if(!$rslt){
                return 'Could not load object!';
            }
        }else{
            $objDAL->pfUserLevelID = $this->_data['intUserLevelID'];
            $objDAL->pfActionID = $this->_data['intActionID'];            
        } 

        $objDAL->fldPermissions = $this->_data['strPermission'];
        $rslt = $objDAL->Save();
        if($rslt){
            $this->_data['intUserLevelID'] = $objDAL->pfUserLevelID;
            $this->_data['intActionID'] = $objDAL->pfActionID;
        }  
        return $rslt;
    }

    protected function _delete(\ADODB_Active_Record $objDAL){  
        $DB = $objDAL->DB();                                                     
        $rslt = $DB->Execute('DELETE FROM mod_user_level_action WHERE pfUserLevelID = ? AND pfActionID = ?', array($this->_data['intUserLevelID'], $this->_data['intActionID']));
        return $rslt;
    }

    protected function _load(\ADODB_Active_Record $objDAL){
        $this->_data['intUserLevelID'] = $objDAL->pfUserLevelID;
        $this->_data['strUserLevel'] = $objDAL->fldUserLevel;
        $this->_data['intActionID'] = $objDAL->pfActionID;
        $this->_data['intModuleID'] = $objDAL->fkModuleID;
        $this->_data['strModuleName'] = $objDAL->fldModule;
        $this->_data['strAction'] = $objDAL->fldAction;
        $this->_data['strControllerClass'] = $objDAL->fldControllerClass;
        $this->_data['strControllerType'] = $objDAL->fldControllerType;
        $this->_data['strPermission'] = $objDAL->fldPermissions;
    } 


    public function LoadByID($intUserLevelID, $intActionID){
        $objFilter = new \NsFWK\ClsFilter();
        $objFilter->intUserLevelID = "pfUserLevelID = $intUserLevelID";
        $objFilter->intActionID = "pfActionID = $intActionID";
        return $this->Load($objFilter);
    }  

    public function GetByUserLevel($intUserLevelID){
        $objFilter = new \NsFWK\ClsFilter();
        $objFilter->intUserLevelID = "pfUserLevelID = $intUserLevelID";        
        return $this->GetDataAssociative($objFilter, 'fldModule, fldControllerClass, fldAction ASC');
    }

    public function GetByAction($intActionID){
        $objFilter = new \NsFWK\ClsFilter();
        $objFilter->intAction = "pfActionID = $intActionID";        
        return $this->GetDataAssociative($objFilter, 'fldModule, fldControllerClass, fldAction ASC');
    }

    public function GetDataAssociative(\NsFWK\ClsFilter $objFilter, $strOrder = 'fkModuleID, fldControllerClass, fldControllerType, fldAction', $strGroup = '', $intOffset = false, $intCount = false){
        $arrData = parent::GetDataAssociative($objFilter, $strOrder, $strGroup, $intOffset, $intCount);
        return $arrData;
    }

    public function GetData(\NsFWK\ClsFilter $objFilter, $strOrder = 'fkModuleID, fldControllerType, fldControllerClass, fldAction', $strGroup = '', $intOffset = false, $intCount = false){
        $arrData = parent::GetData($objFilter, $strOrder, $strGroup);
        return $arrData;
    }

}