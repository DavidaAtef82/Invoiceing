<?php
namespace NsCMN;

class ClsBllMail extends \NsFWK\ClsBll{
    
    private $_smarty = null;
    
    public function __construct(){
        $this->_strClsDalLoad = '\NsCMN\ClsDalMailTemplate';
        $this->_strClsDalSave = '\NsCMN\ClsDalMailTemplate';
        $this->_data = array('intID'=>-1, 
                                'strTemplateName'=>'', 
                                'strSubject'=>'', 
                                'strBody'=>'', 
                                'strNotes'=>'');
        @parent::__construct(func_get_args());
    }

    
    protected function _save(\ADODB_Active_Record $objDAL){
        if($this->_boolLoaded){
            $rslt = $objDAL->Load('pkTemplateID=?',array($this->_data['intID']));
            if(!$rslt){
                return 'Could not load object!';
            }
        }
        $objDAL->fldTemplateName =  $this->_data['strTemplateName'];
        $objDAL->fldSubject = $this->_data['strSubject'];
        $objDAL->fldBody = $this->_data['strBody'];
        $objDAL->fldNotes = $this->_data['strNotes'];
        $rslt = $objDAL->Save();
        if($rslt){
            $this->_data['intID'] = $objDAL->pkTemplateID;
        }  
        return $rslt;
    }
    
    protected function _delete(\ADODB_Active_Record $objDAL){
        return true;
    }
    
    protected function _load(\ADODB_Active_Record $objDAL){
        $this->_data['intID'] = $objDAL->pkTemplateID;
        $this->_data['strTemplateName'] = $objDAL->fldTemplateName;
        $this->_data['strSubject'] = $objDAL->fldSubject;
        $this->_data['strBody'] = $objDAL->fldBody;
        $this->_data['strNotes'] = $objDAL->fldNotes;
    }

    
    private function initSmarty($template=SMARTY_TEMPLATE_DIR, $config=SMARTY_CONFIG_DIR, $cache=SMARTY_CACHE_DIR, $compile=SMARTY_COMPILE_DIR){
        $this->_smarty = new \Smarty();
        $this->_smarty->setTemplateDir($template);
        $this->_smarty->setConfigDir($config) ;
        $this->_smarty->setCacheDir($cache);
        $this->_smarty->setCompileDir($compile);
        $this->_smarty->force_compile = true;
        $this->_smarty->debugging = false;
    }
    
    /***
    * Load Template and make the subject and body presonalized and ready for sending.
    * 
    * @param mixed $strTemplateName: Template name as stored in the database
    * @param mixed $arr: Associative array with keys as Smarty Variable Name, and the value with Object that will be assigned to the smarty variable.
    */
    public function LoadByTemplate($strTemplateName,$arr){
        $this->initSmarty();

        $objFilter = new \NsFWK\ClsFilter();
        $objFilter->intID = "fldTemplateName='$strTemplateName'";
        $rslt = $this->Load($objFilter);
        if ($rslt){
            foreach($arr as $key=>$value){
                $this->_smarty->assign($key,$value);
            }
            $this->strSubject = $this->_smarty->fetch('eval:'.$this->strSubject);
            $this->strBody = $this->_smarty->fetch('eval:'.$this->strBody);
        }
        $this->_smarty->assign('Subject',$this->strSubject);
        $this->_smarty->assign('Body',$this->strBody);
        return $rslt;
    }
    
    public function PrintEmailProva($boolPrintToPage=false){
        $strTemp = "<h1>{$this->strSubject}</h1>";
        $strTemp .=  "<p>{$this->strBody}</p>";
        $strTemp .=  "</hr>";
        if ($boolPrintToPage){
            print $strTemp;
        }
        return $strTemp;
    }
    
    /**
    * Send the email with the subject and body already
    * 
    * @param mixed $strEmailTo: Email address of the guy you would like to send the email to
    */
    public function Send($strEmailTo){
        // The following two lines will wrap the template around the email.
        $template = file_get_contents(LOCAL__THEME__MAIL . '/' . MAIL_TEMPLATE);
        $body = $this->_smarty->fetch('eval:'.$template);
        return \NsFWK\ClsHlpHelper::SendEmail($this->strSubject, $body, $strEmailTo);
    }

    /**
    * Send the email with the subject and body already
    * 
    * @param mixed $strEmailTo: Email address of the guy you would like to send the email to
    * @param $arrCC: 
    */
    public function SendMultipleCC($strEmailTo, $arrCC){
        $template = file_get_contents(LOCAL__THEME__MAIL . '/' . MAIL_TEMPLATE);
        $body = $this->_smarty->fetch('eval:'.$template);
        return \NsFWK\ClsHlpHelper::SendEmail($this->strSubject, $body, $strEmailTo, $arrCC);
    }
}