<?php
namespace NsCMN;
class ClsFilterUser extends \NsFWK\ClsFilter{
    public function __construct(){
        $this->_data = array('intUserLevelID'=>-1,
                             'strUserName'=>'',
                             'strDisplayName'=>'',
                             'intDisabled'=>-1,
                             'intTeamID'=>-1,
                             'strEmail'=>'');
    }

    public function GetWhereStatement(){
        $strWhere = '';

        if($this->_data['intUserLevelID'] != -1){
            $strWhere .= (($strWhere == '')? '' : ' AND ');
            $strWhere .= "pkUserID IN (SELECT pfUserID FROM cmn_user_user_level WHERE pfUserLeveLID = {$this->_data['intUserLevelID']})";
        }

        if($this->_data['strUserName'] != ''){
            $strWhere .= (($strWhere == '')? '' : ' AND ');
            $strKeyword = str_replace(' ', '%', $this->_data['strUserName']);
            $strWhere .= "fldUserName LIKE '%$strKeyword%'";
        }

        if($this->_data['strDisplayName'] != ''){
            $strWhere .= (($strWhere == '')? '' : ' AND ');
            $strKeyword = str_replace(' ', '%', $this->_data['strDisplayName']);
            $strWhere .= "fldDisplayName LIKE '%$strKeyword%'";
        }

        if($this->_data['strEmail'] != ''){
            $strWhere .= (($strWhere == '')? '' : ' AND ');
            $strKeyword = str_replace(' ', '%', $this->_data['strEmail']);
            $strWhere .= "fldEmail LIKE '%$strKeyword%'";
        }

        if($this->_data['intDisabled'] != -1){
            $strWhere .= (($strWhere == '')? '' : ' AND ');
            $strWhere .= "fldDisabled = {$this->_data['intDisabled']}";
        }

        if($this->_data['intTeamID'] != -1){
            $strWhere .= (($strWhere == '')? '' : ' AND ');
            $strWhere .= "pkUserID IN (SELECT pfSalespersonID 
                                       FROM sf_user 
                                       WHERE fkTeamID = {$this->_data['intTeamID']})";
        }

        $strWhere = (($strWhere == '')? '1=1' : $strWhere);
        return $strWhere;
    }
}