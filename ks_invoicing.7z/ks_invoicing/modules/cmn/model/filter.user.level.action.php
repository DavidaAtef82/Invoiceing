<?php
namespace NsCMN;

class ClsFilterUserLevelAction extends \NsFWK\ClsFilter{
    public function __construct(){
        $this->_data = array(
            'intUserLevelID'=>-1,
            'intActionID'=>-1,
            'intModuleID'=>-1,
            'strModule'=>'',
            'strControllerType'=>'',
            'strControllerClass'=>'',
            'strAction'=>'',
            'strPermission'=>'');
    }
    
    public function GetWhereStatement(){
        $strWhere = '';
        
        if($this->_data['intUserLevelID'] != -1){
            $strWhere .= (($strWhere == '')? '' : ' AND ');
            $strWhere .= "pfUserLevelID = '{$this->_data['intUserLevelID']}'";
        }
        
        if($this->_data['intActionID'] != -1){
            $strWhere .= (($strWhere == '')? '' : ' AND ');
            $strWhere .= "pfActionID = '{$this->_data['intActionID']}'";
        }
        
        if($this->_data['intModuleID'] != -1){
            $strWhere .= (($strWhere == '')? '' : ' AND ');
            $strWhere .= "fkModuleID = '{$this->_data['intModuleID']}'";
        }

        if($this->_data['strModule'] != ''){
            $strWhere .= (($strWhere == '')? '' : ' AND ');
            $strWhere .= "fldModule = '{$this->_data['strModule']}'";
        }

        if($this->_data['strControllerType'] != ''){
            $strWhere .= (($strWhere == '')? '' : ' AND ');
            $strWhere .= "fldControllerType LIKE '{$this->_data['strControllerType']}'";
        }
        
        if($this->_data['strControllerClass'] != ''){
            $strWhere .= (($strWhere == '')? '' : ' AND ');
            $strWhere .= "fldControllerClass LIKE '{$this->_data['strControllerClass']}'";
        }
        
        if($this->_data['strAction'] != ''){
            $strWhere .= (($strWhere == '')? '' : ' AND ');
            $strWhere .= "fldAction LIKE '{$this->_data['strAction']}'";
        }
        
        if($this->_data['strPermission'] != ''){
            $strWhere .= (($strWhere == '')? '' : ' AND ');
            $strKeyword = str_replace(' ', '%', $this->_data['strPermission']);
            $strWhere .= "fldPermission LIKE '%$strKeyword%'";
        }
        
        $strWhere = (($strWhere == '')? '1=1' : $strWhere);
        return $strWhere;
    }            
}