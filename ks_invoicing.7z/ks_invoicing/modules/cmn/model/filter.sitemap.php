<?php
namespace NsCMN;

class ClsFilterSitemap extends \NsFWK\ClsFilter{
    public function __construct(){
        $this->_data = array(
            'boolGroup'=>true,
            'arrModuleID'=>array(),
            'intItemLevel'=>-1
        );
    }

    public function GetWhereStatement(){
        $strWhere = '';

        if(!empty($this->_data['arrModuleID'])){
            $strModuleID = implode(',', $this->_data['arrModuleID']);

            $strWhere .= (($strWhere == '')? '' : ' AND ');
            $strWhere .= "(fkModuleID IN ($strModuleID)";
            if ($this->_data['boolGroup']) {
                $strWhere .= " OR fkModuleID IS NULL";
            }
            $strWhere .= ")";
        }

        if($this->_data['intItemLevel'] != -1){
            $strWhere .= (($strWhere == '')? '' : ' AND ');
            $strWhere .= "fldItemLevel = {$this->_data['intItemLevel']}";
        }

       $strWhere = (($strWhere == '')? '1=1' : $strWhere);
        return $strWhere;
    }
}