<?php
namespace NsCMN;
class ClsBllCronJob extends \NsFWK\ClsBll{
    const RUN_CHECK_MINUTES_FROM = 0;
    const RUN_CHECK_MINUTES_TO = 10;
    
    const STATUS_STOPPED = 'stopped';
    const STATUS_RUNNING = 'running';

    public function __construct(){
        $this->_strClsDalLoad = '\NsCMN\ClsDalCronJob';
        $this->_strClsDalSave = '\NsCMN\ClsDalCronJob';
        $this->_data = array('intID'=>-1,
            'strCron'=>'',
            'intModuleID'=>-1,
            'strStatus'=>self::STATUS_STOPPED,
            'strDescription'=>'',
            'intYear'=>null,
            'intMonth'=>null,
            'intDay'=>null,
            'intHour'=>null,
            'intDisabled'=>0);
        @parent::__construct(func_get_args());
    }

    public function __get($name){
        switch($name){
            case 'objModule':
                if(!key_exists($name, $this->_data)){
                    $this->_data[$name] = $this->getModule();
                }
                break;
            case 'objDetails':
                $this->_data[$name] = json_decode($this->_data['strDescription']);
                break;
        }
        return parent::__get($name);
    }


    protected function _save(\ADODB_Active_Record $objDAL){
        if($this->getIsLoaded()){
            $rslt = $objDAL->Load('pkCronID=?',array($this->_data['intID']));
            if(!$rslt){
                return 'Could not load object!';
            }
        }
        $objDAL->fldCron = $this->_data['strCron'];
        $objDAL->fkModuleID = $this->_data['intModuleID'];
        $objDAL->fldStatus = ($this->_data['strStatus'] == '') ? self::STATUS_STOPPED : $this->_data['strStatus'];
        $objDAL->fldDescription = $this->_data['strDescription'];
        $objDAL->fldYear = ($this->_data['intYear'] === '' || $this->_data['intYear'] === null)? null : $this->_data['intYear'];
        $objDAL->fldMonth = ($this->_data['intMonth'] === '' || $this->_data['intMonth'] === null)? null : $this->_data['intMonth'];
        $objDAL->fldDay = ($this->_data['intDay'] === '' || $this->_data['intDay'] === null)? null : $this->_data['intDay'];
        $objDAL->fldHour = ($this->_data['intHour'] === '' || $this->_data['intHour'] === null)? null : $this->_data['intHour'];
        $objDAL->fldDisabled = $this->_data['intDisabled'] ;
        $rslt = $objDAL->Save();
        if($rslt){
            $this->_data['intID'] = $objDAL->pkCronID;
            $this->_data['strStatus'] = $objDAL->fldStatus;
        }

        return $rslt;
    }

    protected function _delete(\ADODB_Active_Record $objDAL){
        return false;
    }

    protected function _load(\ADODB_Active_Record $objDAL){
        $this->_data['intID'] = $objDAL->pkCronID;
        $this->_data['strCron'] = $objDAL->fldCron;
        $this->_data['intModuleID'] = $objDAL->fkModuleID;
        $this->_data['strStatus'] = $objDAL->fldStatus;
        $this->_data['strDescription'] = $objDAL->fldDescription;
        $this->_data['intYear'] = $objDAL->fldYear;
        $this->_data['intMonth'] = $objDAL->fldMonth;
        $this->_data['intDay'] = $objDAL->fldDay;
        $this->_data['intHour'] = $objDAL->fldHour;
        /*
        $this->_data['intYear'] = ($objDAL->fldYear == null)?'':(int)$objDAL->fldYear;
        $this->_data['intMonth'] = ($objDAL->fldMonth == null)?'':(int)$objDAL->fldMonth;
        $this->_data['intDay'] = ($objDAL->fldDay == null)?'':(int)$objDAL->fldDay;
        $this->_data['intHour'] = ($objDAL->fldHour == null)?'':(int)$objDAL->fldHour;
        */
        $this->_data['intDisabled'] = (int)$objDAL->fldDisabled;
        $this->objDetails;
    }


    protected function getModule(){            
        $obj = new ClsBllModule();
        $rslt = $obj->LoadByID($this->_data['intModuleID']);
        return $obj->ToArray();
    }


    public function LoadByID($intID){
        $objFilter = new \NsFWK\ClsFilter();
        $objFilter->intID = "pkCronID = $intID";
        return $this->Load($objFilter);
    }
    
    public function GetEnabledCron($boolDisabled = false){
        $arrEnabledModulesIDs = \NsCMN\ClsBllModule::GetEnabledModulesIDs();
        $strEnabledModules = implode(',', $arrEnabledModulesIDs);
        
        $objFilter = new \NsFWK\ClsFilter();
        $objFilter->intModuleID = "fkModuleID IN($strEnabledModules)";
        if(!$boolDisabled){
            $objFilter->intDisabled = 'fldDisabled = 0';
        }
        return $this->GetData($objFilter);
    }

    public function GetEnabledCronAssoc($boolDisabled = false){
        $arrEnabledModulesIDs = \NsCMN\ClsBllModule::GetEnabledModulesIDs();
        $strEnabledModules = implode(',', $arrEnabledModulesIDs);
        
        $objFilter = new \NsFWK\ClsFilter();
        $objFilter->intModuleID = "fkModuleID IN($strEnabledModules)";
        if(!$boolDisabled){
            $objFilter->intDisabled = 'fldDisabled = 0';
        }
        return $this->GetDataAssociative($objFilter);
    }

    public function GetDataAssociative(\NsFWK\ClsFilter $objFilter, $strOrder = '', $strGroup = '', $intOffset = false, $intCount = false){
        $arrData = parent::GetDataAssociative($objFilter, $strOrder, $strGroup);
        if(empty($arrData)){
            return $arrData;
        }
        
        $this->loadBindingAssociative($arrData, 'intModuleID', 'objModule', new ClsBllModule(), 'pkModuleID', 'intID'); 

        return $arrData;
    }

    
    public function AutoRun(){
        if($this->strStatus == ClsBllCronJob::STATUS_RUNNING || $this->intDisabled == 1){
            return false;
        }

        $intYear = date("Y");
        $intMonth = date("n"); // using "n" to avoid leading zeros in "m"
        $intDay = date("j");   // using "j" to avoid leading zeros in "d"
        $intHour = date("G");  // using "G" to avoid leading zeros in "H"
        $intMin = (int)date("i");  // minutes without leading zeros in "i"

        if (($this->intYear === null || $this->intYear === '' || $this->intYear == $intYear)
            && ($this->intMonth === null || $this->intMonth === '' || $this->intMonth == $intMonth)
            && ($this->intDay === null || $this->intDay === '' || $this->intDay == $intDay)
            && ($this->intHour === null || $this->intHour === '' || $this->intHour == $intHour)
            && ($intMin >= self::RUN_CHECK_MINUTES_FROM && $intMin < self::RUN_CHECK_MINUTES_TO)){
            // Note that crons are adjusted to run every 10 minutes
            // We need to make sure that the cron is run only once in its due Hour
            \NsFWK\ClsHlpHelper::CallCron($this->objModule['strModule'], $this->strCron, array());
            return true;
        }else{
            return false;
        }
    }
}