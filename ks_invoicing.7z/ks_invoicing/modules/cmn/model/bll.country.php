<?php
namespace NsCMN;

class ClsBllCountry extends \NsFWK\ClsBll{
    public function __construct(){
        $this->_strClsDalLoad = '\NsCMN\ClsDalCountry';
        $this->_strClsDalSave = '\NsCMN\ClsDalCountry';
        $this->_data = array(
            'intID'=>-1,
            'strCountry'=>''
        );
        parent::__construct(func_get_args());
    }

    public function __get($name){
        switch($name){
            case 'arrCities':
                if(!key_exists($name, $this->_data)){
                    $this->_data[$name] = $this->GetCities();
                }
                break;
            case 'arrLocations':
                if(!key_exists($name, $this->_data)){
                    $this->_data[$name] = $this->GetLocations();
                }
                break;
        }

        return parent::__get($name);
    }

    protected function _save(\ADODB_Active_Record $objDAL){
        if($this->getIsLoaded()){
            $rslt = $objDAL->Load('pkCountryID = ?',array($this->_data['intID']));
            if(!$rslt){
                return 'Could not load object!';
            }
        }
        $objDAL->fldCountry = $this->_data['strCountry'];
        $rslt = $objDAL->Save();
        if($rslt){
            $this->_data['intID'] = $objDAL->pkCountryID;
        }
        return $rslt;
    }

    protected function _delete(\ADODB_Active_Record $objDAL){
        $DB = &\ADODB_Connection_Manager::GetConnection('customer');
        $rslt = $DB->GetArray("SELECT fkCountryID FROM cmn_city WHERE fkCountryID = {$this->_data['intID']}");
        if($rslt === false){
            return false;
        }elseif(is_array($rslt) && !empty($rslt)){
            return false;
        }else{
            return $DB->Execute('DELETE FROM cmn_country WHERE pkCountryID = ? ', array($this->_data['intID']));
        }
    }

    protected function _load(\ADODB_Active_Record $objDAL){
        $this->_data['intID'] = $objDAL->pkCountryID;
        $this->_data['strCountry'] = $objDAL->fldCountry;
    }


    public function LoadByID($intID){
        $objFilter = new \NsFWK\ClsFilter();
        $objFilter->intID = "pkCountryID = $intID";
        return $this->Load($objFilter);
    }
    public function GetCountries(){
        $objFilter = new \NsFWK\ClsFilter();
        $strWhere = $objFilter->GetWhereStatement();
        $arrData = $this->GetDataAssociative($objFilter, 'fldCountry ASC');
        //$this->loadBindingAssociative($arrData, 'intID', 'arrDistricts', new ClsBllDistrict(), 'fkCityID', 'intCityID', true); 
        return $arrData;
    }
    public function GetCities(){
        $objFilter = new \NsFWK\ClsFilter();
        $objFilter->intID = 'fkCountryID = '.$this->_data['intID'];

        $objDistrict = new ClsBllCity();
        return $objDistrict->GetDataAssociative($objFilter, 'fldCity ASC');
    }
    public function UpdateCountry($intCountryID, $strCountryName){
        $DB = &\ADODB_Connection_Manager::GetConnection('customer');
        $strSQL = 'UPDATE cmn_country SET fldCountry = "'.$strCountryName.'" WHERE pkCountryID = '.$intCountryID;
        $result = $DB->Execute($strSQL);
        if (!$result) {
            print($DB->errorMsg());
            $objResult['result'] = false;
            $objResult['title'] = 'Failure';
            $objResult['message'] = $DB->errorMsg();
            return $objResult;                
        }else{
            $objResult['result'] = true;
            $objResult['title'] = 'Success';
            $objResult['message'] = 'Data updated successfully!';
            return $objResult; 
        }
    }
}