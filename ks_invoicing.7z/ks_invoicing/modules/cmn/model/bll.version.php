<?php
namespace NsCMN;

class ClsBllVersion extends \NsFWK\ClsBll{

    public function __construct(){
        $this->_strClsDalLoad = '\NsCMN\ClsDalVersion';
        $this->_strClsDalSave = '\NsCMN\ClsDalVersion';

        $this->_data = array('strVersion'=>'',
                             'dmLastUpdateDateTime'=>'',
                             'intLocked'=>0);
        @parent::__construct(func_get_args());
    }


    protected function _save(\ADODB_Active_Record $objDAL){
        if($this->getIsLoaded()){
            $rslt = $objDAL->Load('pkVersion=?',array($this->_data['strVersion']));
            if(!$rslt){
                return 'Could not load object!';
            }
        }else{
            $objDAL->pkVersion = $this->_data['strVersion'];
        }

        $this->_data['dmLastUpdateDateTime'] = date('Y-m-d H:i:s');

        $objDAL->fldLastUpdateDateTime = $this->_data['dmLastUpdateDateTime'];
        $objDAL->fldLocked = $this->_data['intLocked'];
        $rslt = $objDAL->Save();
        return $rslt;
    }

    protected function _delete(\ADODB_Active_Record $objDAL){
        return false;
    }

    protected function _load(\ADODB_Active_Record $objDAL){
        $this->_data['strVersion'] = $objDAL->pkVersion;
        $this->_data['dmLastUpdateDateTime'] = $objDAL->fldLastUpdateDateTime;
        $this->_data['intLocked'] = $objDAL->fldLocked;
    }


    public function LoadByID($strVersion){
        $objFilter = new \NsFWK\ClsFilter();
        $objFilter->intID = "pkVersion = '$strVersion'";
        return $this->Load($objFilter);
    }

    public function Lock(){
        // Need more advanced handling
        if($this->_data['intLocked'] == 1){
            return true;
        }

        $this->_data['intLocked'] = 1;
        return $this->Save();
    }

    public function Unlock(){
        // Need more advanced handling
        if($this->_data['intLocked'] == 0){
            return true;
        }

        $this->_data['intLocked'] = 0;
        return $this->Save();
    }

    public function GetCurrentVersion(){
        $objFilter = new \NsFWK\ClsFilter();
        $arr = $this->GetData($objFilter, 'fldLastUpdateDateTime DESC', '', false, 1);
        if(empty($arr)){
            // No version
            return false;
        }else{
            return $arr[0];
        }
    }
}