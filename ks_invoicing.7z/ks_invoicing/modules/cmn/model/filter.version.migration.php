<?php
namespace NsCMN;

class ClsFilterVersionMigration extends \NsFWK\ClsFilter{

    public function __construct(){
        $this->_data = array('strVersion'=>'', 
                             'strMethod'=>'', 
                             'intResult'=>-1, 
                             'dmDateTimeFrom'=>'', 
                             'dmDateTimeTo'=>'');
    }
    
    public function GetWhereStatement(){
        $strWhere = '';

        if(!empty($this->_data['strVersion'])){
            $strWhere .= (($strWhere == '')? '' : ' AND ');
            $strWhere .= "fkVersion = '{$this->_data['strVersion']}'";
        }
        
        if(!empty($this->_data['strMethod'])){
            $strWhere .= (($strWhere == '')? '' : ' AND ');
            $strWhere .= "fldMethod = '{$this->_data['strMethod']}'";
        }
        
        if($this->_data['intResult'] != -1){
            $strWhere .= (($strWhere == '')? '' : ' AND ');
            $strWhere .= "fldResult = '{$this->_data['intResult']}'";
        }
        
        if(!empty($this->_data['dmDateTimeFrom'])){
            $strWhere .= (($strWhere == '')? '' : ' AND ');
            $strWhere .= "fldDateTime >= '{$this->_data['dmDateTimeFrom']}'";
        }

        if(!empty($this->_data['dmDateTimeTo'])){
            $strWhere .= (($strWhere == '')? '' : ' AND ');
            $strWhere .= "fldDateTime <= '{$this->_data['dmDateTimeTo']}'";
        }

        $strWhere = (($strWhere == '')? '1=1' : $strWhere);
        return $strWhere;
    }            
}