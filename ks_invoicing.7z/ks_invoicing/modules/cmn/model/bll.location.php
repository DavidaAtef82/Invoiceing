<?php
namespace NsCMN;
    class ClsBllLocation extends \NsFWK\ClsBll{
        const TYPE_BRANCH = 'location';
        const TYPE_OFFICE = 'office';
 
        public function __set($name, $value){
            switch($name){
                case 'objCity':
                case 'objDistrict':
                    // READ ONLY
                    return;
            }
            return parent::__set($name, $value);
        }
        
        public function __construct(){
            $this->_strClsDalLoad = '\NsCMN\ClsDalLocationDetails';
            $this->_strClsDalSave = '\NsCMN\ClsDalLocation';
            $this->_data =array_merge($this->_data, array('intID'=>-1, 
                                                            'strName'=>'', 
                                                            'intDistrictID'=>-1, 
                                                            'strAddress'=>'', 
                                                            'strPhone'=>'', 
                                                            'strLongitude'=>'', 
                                                            'strLatitude'=>'',
                                                            'strNotes'=>''));
            @parent::__construct(func_get_args());
        }

        protected function _save(\ADODB_Active_Record $objDAL){ 
            if($this->getIsLoaded()){
                $rslt = $objDAL->Load('pkLocationID=?',array($this->_data['intID']));
                if(!$rslt){
                    return 'Could not load object!';
                }
            }
            $objDAL->fldName = $this->_data['strName'];
            $objDAL->fkDistrictID = $this->_data['intDistrictID'];
            $objDAL->fldAddress = $this->_data['strAddress'];
            $objDAL->fldPhone = $this->_data['strPhone'];
            $objDAL->fldLongitude = $this->_data['strLongitude'];
            $objDAL->fldLatitude = $this->_data['strLatitude'];
            $objDAL->fldNotes = $this->_data['strNotes'];
            $rslt = $objDAL->Save();
            if($rslt){  
                $this->LoadByID($objDAL->pkLocationID);              
            }
            return $rslt;
        }
        
        protected function _delete(\ADODB_Active_Record $objDAL){
            $conn = $objDAL->DB();                                
            $rslt = $conn->Execute('DELETE FROM cmn_location WHERE pkLocationID = ?', array($this->_data['intID']));
            if($rslt)
                return true;
            else
                return false;
        }
        
        protected function _load(\ADODB_Active_Record $objDAL){
            $this->_data['intID'] = $objDAL->pkLocationID;
            $this->_data['strName'] = $objDAL->fldName;
            $this->_data['intDistrictID'] = $objDAL->fkDistrictID;
            $this->_data['strAddress'] = $objDAL->fldAddress;
            $this->_data['strPhone'] = $objDAL->fldPhone;
            
            $objCity = new ClsBllCity($objDAL->fkCityID, $objDAL->fldCity);
            $objDistrict->_data['objCity'] = $objCity;

            $objDistrict = new ClsBllDistrict($objDAL->fkDistrictID, $objDAL->fkCityID, $objDAL->fldDistrict);
            $this->_data['objDistrict'] = $objDistrict;
            
            $this->_data['strLongitude'] = $objDAL->fldLongitude;
            $this->_data['strLatitude'] = $objDAL->fldLatitude;            
            $this->_data['strNotes'] = $objDAL->fldNotes;
        }
        
        
        public function LoadByID($intID){
            $objFilter = new \NsFWK\ClsFilter();
            $objFilter->intID = "pkLocationID = $intID";
            return $this->Load($objFilter);
        }

        
        public function GetAllLocations(){
            $objFilter = new \NsFWK\ClsFilter();
            return $this->GetDataAssociative($objFilter, 'fldName ASC');
        }
        
    }