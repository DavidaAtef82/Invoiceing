<?php
namespace NsCMN;
class ClsBllDistrict extends \NsFWK\ClsBll{
    public function __set($name, $value){
        switch($name){
            case 'objCity':
                if($value->getIsLoaded()){
                    $this->_data['intCityID'] = $value->intID;
                }else{
                    return;
                }
        }

        return parent::__set($name, $value);
    }

    public function __get($name){
        switch($name){
            case 'objCity':
                if(!key_exists('objCity', $this->_data)){
                    $objCity = new ClsBllCity();
                    $rslt = $objCity->LoadByID($this->_data['intCityID']);
                    if($rslt)
                        $this->_data['objCity'] = $objCity;
                }
        }
        return parent::__get($name);
    }

    public function __construct(){
        $this->_strClsDalLoad = '\NsCMN\ClsDalDistrict';
        $this->_strClsDalSave = '\NsCMN\ClsDalDistrict';
        $this->_data = array('intID'=>-1, 'intCityID'=>-1, 'strDistrict'=>'');
        @parent::__construct(func_get_args());
    }

    protected function _save(\ADODB_Active_Record $objDAL){
        if($this->getIsLoaded()){
            $rslt = $objDAL->Load('pkDistrictID=?', array($this->_data['intID']));
            if(!$rslt){
                return 'Could not load object!';
            }

            if($this->getIsModified('intCityID'))
                unset($this->_data['objCity']);                

        }
        $objDAL->fkCityID = $this->_data['intCityID'];
        $objDAL->fldDistrict = $this->_data['strDistrict'];
        $rslt = $objDAL->Save();
        if($rslt){
            $this->_data['intID'] = $objDAL->pkDistrictID;
        }

        return $rslt;
    }

    protected function _delete(\ADODB_Active_Record $objDAL){
        $DB = &\ADODB_Connection_Manager::GetConnection('customer');
        $rslt = $DB->GetArray("SELECT fkDistrictID FROM cmn_location WHERE fkDistrictID = {$this->_data['intID']}");
        if($rslt === false){
            return false;
        }elseif(is_array($rslt) && !empty($rslt)){
            return false;
        }else{
            return $DB->Execute('DELETE FROM cmn_district WHERE pkDistrictID = ? ', array($this->_data['intID']));
        }
    }

    protected function _load(\ADODB_Active_Record $objDAL){
        $this->_data['intID'] = $objDAL->pkDistrictID;
        $this->_data['intCityID'] = $objDAL->fkCityID;
        $this->_data['strDistrict'] = $objDAL->fldDistrict;
    }

    public function LoadByID($intID){
        $objFilter = new \NsFWK\ClsFilter();
        $objFilter->intID = "pkDistrictID = $intID";
        return $this->Load($objFilter);
    }

    public function GetAllDistricts(){
        $objFilter = new \NsFWK\ClsFilter();
        //return $this->GetDataAssociative($objFilter, 'fkCityID ASC, fldDistrict ASC');
        $arrData = parent::GetDataAssociative($objFilter, 'fkCityID ASC, fldDistrict ASC'); 

        $this->loadBindingAssociative($arrData, 'intCityID', 'objCity', new ClsBllCity(), 'pkCityID', 'intID'); 
        return $arrData;
    }

    public function GetDataAssociative(\NsFWK\ClsFilter $objFilter, $strOrder = '', $strGroup = '', $intOffset = false, $intCount = false){
        $arrData = parent::GetDataAssociative($objFilter, $strOrder, $strGroup);
        if(empty($arrData)){
            return $arrData;
        }

        $this->loadBindingAssociative($arrData, 'intCityID', 'objCity', new ClsBllCity(), 'pkCityID', 'intID'); 

        return $arrData;
    }
}
