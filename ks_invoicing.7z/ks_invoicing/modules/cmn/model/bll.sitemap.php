<?php
namespace NsCMN;

class ClsBllSitemap extends \NsFWK\ClsBll{
    public function __set($name, $value){
        switch($name){
            case 'intDisabled':
                return false;
        }
        return parent::__set($name, $value);
    }

    public function __get($name){
        switch($name){
            case 'arrUserLevels':
                if(!key_exists($name, $this->_data)){
                    $this->_data[$name] = $this->getUserLevels();
                }
        }
        return parent::__get($name);
    }

    public function __construct(){
        $this->_strClsDalLoad = '\NsCMN\ClsDalSiteMapDetails';
        $this->_strClsDalSave = '\NsCMN\ClsDalSiteMap';
        $this->_data = array(
            'intID'=>-1,
            'decGroupOrder'=>-1,
            'decItemOrder'=>-1,
            'intItemLevel'=>-1,
            'intModuleID'=>-1,
            'intActionID'=>-1,
            'strModule'=>'',
            'strControllerType'=>'',
            'strControllerClass'=>'',
            'strAction'=>'',
            'strItemText'=>'',
            'strItemStyle'=>'',
            'boolShowInMenu'=>''
        );
        @parent::__construct(func_get_args());
    }


    protected function _save(\ADODB_Active_Record $objDAL){
        if($this->getIsLoaded()){
            $rslt = $objDAL->Load('pkItemID=?',array($this->_data['intID']));
            if(!$rslt){
                return 'Could not load object!';
            }
        }

        $objDAL->fldGroupOrder= $this->_data['decGroupOrder'];
        $objDAL->fldItemOrder= $this->_data['decItemOrder'];
        $objDAL->fldItemLevel= $this->_data['intItemLevel'];
        $objDAL->fkActionID= $this->_data['intActionID'];
        $objDAL->fldItemText= $this->_data['strItemText'];
        $objDAL->fldItemStyle= $this->_data['strItemStyle'];
        $objDAL->fldShowInMenu = $this->_data['boolShowInMenu'];
        $rslt = $objDAL->Save();
        if($rslt){
            $this->_data['intID'] = $objDAL->pkItemID;
        }

        return $rslt;
    }

    protected function _delete(\ADODB_Active_Record $objDAL){
        $DB = $objDAL->DB();  
        $rslt = $DB->Execute("DELETE FROM mod_site_map WHERE pkItemID = {$this->_data['intID']}");
        return $rslt;
    }

    protected function _load(\ADODB_Active_Record $objDAL){
        $this->_data['intID'] = $objDAL->pkItemID;
        $this->_data['decGroupOrder'] = $objDAL->fldGroupOrder;
        $this->_data['decItemOrder'] = $objDAL->fldItemOrder;
        $this->_data['intItemLevel'] = $objDAL->fldItemLevel;
        $this->_data['intModuleID'] = $objDAL->fkModuleID;
        $this->_data['intActionID'] = $objDAL->fkActionID;
        $this->_data['strModule'] = $objDAL->fldModule;
        $this->_data['strControllerType'] = $objDAL->fldControllerType;
        $this->_data['strControllerClass'] = $objDAL->fldControllerClass;
        $this->_data['strAction'] = $objDAL->fldAction;
        $this->_data['strItemText'] = $objDAL->fldItemText;
        $this->_data['strItemStyle'] = $objDAL->fldItemStyle;
        $this->_data['boolShowInMenu'] = (bool)((int)$objDAL->fldShowInMenu);
    }


    public function LoadByID($intID){
        $objFilter = new \NsFWK\ClsFilter();
        $objFilter->intID = "pkItemID = $intID";
        return $this->Load($objFilter);
    }

    public function GetAll(){
        $objFilter = new \NsFWK\ClsFilter();
        $arrData = $this->GetDataAssociative($objFilter,'fldGroupOrder, fldItemOrder, fldItemLevel ASC');
        return $arrData;
    }
    
    public function GetMenu(){
        $arrEnabledModulesIDs = ClsBllModule::GetEnabledModulesIDs();
        
        $objFilter = new ClsFilterSitemap();
        $objFilter->arrModuleID = $arrEnabledModulesIDs;
        $objFilter->boolGroup = true;
        $arrData = $this->GetData($objFilter, "fldGroupOrder, fldItemOrder ASC");
        return $arrData;
    }
    
    public function GetTopMenu(){
        $objFilter = new ClsFilterSitemap();
        $objFilter->intItemLevel = 0;
        $arrData = $this->GetDataAssociative($objFilter, 'fldGroupOrder, fldItemOrder ASC');
        return $arrData;
    }

}