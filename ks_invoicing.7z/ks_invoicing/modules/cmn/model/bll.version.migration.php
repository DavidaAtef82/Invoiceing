<?php
namespace NsCMN;

class ClsBllVersionMigration extends \NsFWK\ClsBll{

    public function __set($name, $value){
        return false;
    }

    public function __construct(){
        $this->_strClsDalLoad = '\NsCMN\ClsDalVersionMigration';
        $this->_strClsDalSave = '\NsCMN\ClsDalVersionMigration';

        $this->_data = array('intID'=>'',
                             'strVersion'=>'',
                             'strMethod'=>'',
                             'intResult'=>0,
                             'dmDateTime'=>'');
        @parent::__construct(func_get_args());
    }
    

    protected function _save(\ADODB_Active_Record $objDAL){
        if($this->getIsLoaded()){
            $rslt = $objDAL->Load('pkID = ?', array($this->_data['intID']));
            if(!$rslt){
                return 'Could not load object!';
            }
        }else{
            $this->_data['dmDateTime'] = date('Y-m-d H:i:s');
        }

        $objDAL->fkVersion = $this->_data['strVersion'];
        $objDAL->fldMethod = $this->_data['strMethod'];
        $objDAL->fldResult = $this->_data['intResult'];
        $objDAL->fldDateTime = $this->_data['dmDateTime'];
        $rslt = $objDAL->Save();
        if($rslt){
            $this->_data['intID'] = $objDAL->pkID;
        }

        return $rslt;
    }
    
    protected function _delete(\ADODB_Active_Record $objDAL){
        return false;
    }
    
    protected function _load(\ADODB_Active_Record $objDAL){
        $this->_data['intID'] = $objDAL->pkID;
        $this->_data['strVersion'] = $objDAL->fkVersion;
        $this->_data['strMethod'] = $objDAL->fldMethod;
        $this->_data['intResult'] = $objDAL->fldResult;
        $this->_data['dmDateTime'] = $objDAL->fldDateTime;
    }

    
    public function LoadByID($intID){
        $objFilter = new \NsFWK\ClsFilter();
        $objFilter->intID = "pkID = $intID";
        return $this->Load($objFilter);
    }
    
    public function GetLastRun($strVersion, $strMethod){
        $objFilter = new ClsFilterVersionMigration();
        $objFilter->strVersion = $strVersion;
        $objFilter->strMethod = $strMethod;

        $arr = $this->GetData($objFilter, 'fldDateTime DESC', '', 0, 1);
        if($arr){
            return $arr[0];
        }else{
            return null;
        }
    }
        
    
    static public function Create($strVersion, $strMethod, $intResult){
        $obj = new static();
        $obj->_data['strVersion'] = $strVersion;
        $obj->_data['strMethod'] = $strMethod;
        $obj->_data['intResult'] = $intResult;
        $ok = $obj->Save();
        if($ok){
            return $obj;
        }else{
            return false;
        }
    }
}