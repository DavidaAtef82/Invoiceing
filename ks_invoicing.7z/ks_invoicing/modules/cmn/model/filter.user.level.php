<?php
namespace NsCMN;
class ClsFilterUserLevel extends \NsFWK\ClsFilter{
    public function __construct(){
        $this->_data = array(
            'intID'=>-1,
            'arrID'=>array(),
            'strUserLevel'=>'',
            'intModuleID'=>-1
        );
    }

    public function GetWhereStatement(){
        $strWhere = '';

        if($this->_data['intID'] != -1){
            $strWhere .= (($strWhere == '')? '' : ' AND ');
            $strWhere .= "pkUserLevelID = {$this->_data['intID']}";
        }
        if(!empty($this->_data['arrID'])){
            $strID = implode(',', $this->_data['arrID']);
            $strWhere .= (($strWhere == '')? '' : ' AND ');
            $strWhere .= "pkUserLevelID IN ($strID)";
        }
        if($this->_data['strUserLevel'] != ''){
            $strWhere .= (($strWhere == '')? '' : ' AND ');
            $strWhere .= "fldUserLevel LIKE '%{$this->_data['strUserLevel']}%'";
        }
        if($this->_data['intModuleID'] != -1){
            $strWhere .= (($strWhere == '')? '' : ' AND ');
            $strWhere .= "pkUserLevelID IN (
                SELECT DISTINCT pfUserLevelID
                FROM mod_user_level_action
                WHERE pfActionID IN (
                    SELECT pkActionID
                    FROM mod_module_action
                    WHERE fkModuleID = {$this->_data['intModuleID']}
                )
            )";
        }

        $strWhere = (($strWhere == '')? '1=1' : $strWhere);
        return $strWhere;
    }
}