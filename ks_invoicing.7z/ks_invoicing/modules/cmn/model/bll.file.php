<?php
namespace NsCMN;

class ClsBllFile extends \NsFWK\ClsBll{
    
    public function __set($name, $value){
        switch($name){
            case 'dtTrashDateTime':
                return false;
        }

        return parent::__set($name, $value);
    }

    public function __construct(){
        $this->_strClsDalLoad = '\NsCMN\ClsDalFile';
        $this->_strClsDalSave = '\NsCMN\ClsDalFile';
        $this->_data = array('intID'=>-1, 
                            'intModuleID'=>-1, 
                            'strCaption'=>'', 
                            'strDescription'=>'', 
                            'intSize'=>-1, 
                            'strFileName'=>'',
                            'strType'=>'',
                            'dtCreateDateTime'=>'',
                            'dtTrashDateTime'=>NULL,
                            'intCreatorID'=>-1);
        @parent::__construct(func_get_args());
    }


    protected function _save(\ADODB_Active_Record $objDAL){ 
        if($this->getIsLoaded()){
            $rslt = $objDAL->Load('pkFileID=?',array($this->_data['intID']));
            if(!$rslt){
                return 'Could not load object!';
            }
        }

        $objDAL->fkModuleID = $this->_data['intModuleID'];
        $objDAL->fldCaption = $this->_data['strCaption'];
        $objDAL->fldDescription = $this->_data['strDescription'];
        $objDAL->fldSize = $this->_data['intSize'];
        $objDAL->fldFileName = $this->_data['strFileName'];
        $objDAL->fldCreateDateTime = date("Y-m-d H:i:s");
        $objDAL->fldTrashDateTime = $this->_data['dtTrashDateTime'];
        $objDAL->fkCreatorID = ($this->_data['intCreatorID'] == -1) ? NULL : $this->_data['intCreatorID'];
        $rslt = $objDAL->Save();
        if($rslt){  
            $this->_data['intID'] = $objDAL->pkFileID;
            $this->_data['strType'] = $this->getType();
        }
        return $rslt;
    }
    
    protected function _delete(\ADODB_Active_Record $objDAL){
        $intFileID = $this->_data['intID'];
        $strFileExt = pathinfo($this->_data['strFileName'], PATHINFO_EXTENSION);

        $conn = $objDAL->DB();
        $rslt = $conn->Execute('DELETE FROM cmn_file WHERE pkFileID = ?', array($intFileID));
        if($rslt){
            $strFileName = $intFileID . '.' . $strFileExt;
            $strFilePath = LOCAL__FILES . "/$strFileName";
            if(file_exists($strFilePath)){
                unlink($strFilePath);
            }
            return true;
        }else{
            return false;
        }    
    }
    
    protected function _load(\ADODB_Active_Record $objDAL){
        $this->_data['intID'] = $objDAL->pkFileID;
        $this->_data['intModuleID'] = $objDAL->fkModuleID;
        $this->_data['strCaption'] = $objDAL->fldCaption;
        $this->_data['strDescription'] = $objDAL->fldDescription;
        $this->_data['intSize'] = $objDAL->fldSize;
        $this->_data['strFileName'] = $objDAL->fldFileName;
        $this->_data['dtCreateDateTime'] = $objDAL->fldCreateDateTime;
        $this->_data['dtTrashDateTime'] = $objDAL->fldTrashDateTime;
        $this->_data['intCreatorID'] = $objDAL->fkCreatorID;
        
        $this->_data['strType'] = $this->getType();
    }
    

    protected function getPath(){
        $strType = pathinfo($this->_data['strFileName'], PATHINFO_EXTENSION);
        $strFileName = "{$this->_data['intID']}.{$strType}";
        $strFilePath = LOCAL__FILES . "/$strFileName";
        return $strFilePath;
    }

    protected function getType(){
        $strFilePath = $this->getPath();
        $strType = \NsFWK\ClsHlpHelper::GetMimeType($strFilePath);
        return $strType;
    }
    
    
    public function Trash(){
        $this->_data['dtTrashDateTime'] = date("Y-m-d H:i:s");
        $ok = $this->Save();
        if(!$ok){
            return false;
        }
        return true;
    }
    
    public function LoadByID($intID){
        $objFilter = new \NsFWK\ClsFilter();
        $objFilter->intID = "pkFileID = $intID";
        $objFilter->dtTrashDateTime = "fldTrashDateTime IS NULL";
        return $this->Load($objFilter);
    }
    
    public function GetFileContent(){
        $strFilePath = $this->getPath();
        if(file_exists($strFilePath)){
            $strContent = file_get_contents($strFilePath);            
        }else{
            $strContent = false;
        }
        return $strContent;
    }

    
    public function GetDeletedData(\NsFWK\ClsFilter $objFilter, $strOrder = '', $strGroup = '', $intOffset = false, $intCount = false){
        $objFilter->dtTrashDateTime = "fldTrashDateTime IS NOT NULL";
        $arrData = parent::GetData($objFilter, $strOrder, $strGroup, $intOffset, $intCount);
        if(empty($arrData)){
            return $arrData;
        }
        return $arrData;
    }
    
    public function GetDeletedDataAssociative(\NsFWK\ClsFilter $objFilter, $strOrder = '', $strGroup = '', $intOffset = false, $intCount = false){
        $objFilter->dtTrashDateTime = "fldTrashDateTime IS NOT NULL";
        $arrData = parent::GetDataAssociative($objFilter, $strOrder, $strGroup);
        if(empty($arrData)){
            return $arrData;
        }
        
        return $arrData;
    }
        
    public function GetDeletedDataPageAssociative($intPageNo, $intPageSize, $strWhere, $strOrder, &$intPageCount, &$intRowCount){
        $strWhere .= " AND fldTrashDateTime IS NOT NULL";
        $arrData = parent::GetDataPageAssociative($intPageNo, $intPageSize, $strWhere, $strOrder, $intPageCount, $intRowCount);
        if(empty($arrData)){
            return $arrData;
        }

        return $arrData;
    }
    
    public function GetData(\NsFWK\ClsFilter $objFilter, $strOrder = '', $strGroup = '', $intOffset = false, $intCount = false){
        $objFilter->dtTrashDateTime = "fldTrashDateTime IS NULL";
        $arrData = parent::GetData($objFilter, $strOrder, $strGroup, $intOffset, $intCount);
        if(empty($arrData)){
            return $arrData;
        }
        return $arrData;
    }
    
    public function GetDataAssociative(\NsFWK\ClsFilter $objFilter, $strOrder = '', $strGroup = '', $intOffset = false, $intCount = false){
        $objFilter->dtTrashDateTime = "fldTrashDateTime IS NULL";
        $arrData = parent::GetDataAssociative($objFilter, $strOrder, $strGroup);
        if(empty($arrData)){
            return $arrData;
        }
        
        return $arrData;
    }
        
    public function GetDataPageAssociative($intPageNo, $intPageSize, $strWhere, $strOrder, &$intPageCount, &$intRowCount){
        $strWhere .= " AND fldTrashDateTime IS NULL";
        $arrData = parent::GetDataPageAssociative($intPageNo, $intPageSize, $strWhere, $strOrder, $intPageCount, $intRowCount);
        if(empty($arrData)){
            return $arrData;
        }

        return $arrData;
    }


    static public function Create($intModuleID, $strCaption, $strDescription, $strFileName, $strContent, $intCreatorID){
        if(empty($strFileName)){
            return false;
        }
        
        $arrPart = explode('.', $strFileName);
        $strExt = end($arrPart);
        $strTempName = '_' . microtime(true) . '.' . $strExt;
        $strTempPath = LOCAL__FILES . "/$strTempName";

        $index = stripos($strContent,'base64');
        if ($index !== false){
            // File is base64 encoded
            $newIndex = $index + strlen('base64') + 1;
            $strFileContent = base64_decode(substr($strContent, $newIndex));
        }else{
            // File is not base64 encoded
            $strFileContent = $strContent;
        }
        
        $ok = file_put_contents($strTempPath, $strFileContent);
        if(!$ok){
            // Could not write file to path
            return false;
        }
        
        $obj = new ClsBllFile();
        $obj->_data['intModuleID'] = $intModuleID;
        $obj->_data['strCaption'] = $strCaption;
        $obj->_data['strDescription'] = $strDescription;
        $obj->_data['strFileName'] = $strFileName; 
        $obj->_data['intSize'] = filesize($strTempPath);
        $obj->_data['intCreatorID'] = $intCreatorID;
        $rslt = $obj->Save();
        if(!$rslt){
            // Could not save file record in DB
            // Delete the temp file before return
            unlink($strTempPath);
            return false;
        }
        
        $strFinalName = $obj->intID . '.' . $strExt;
        $strFinalPath = LOCAL__FILES . "/$strFinalName";
        rename($strTempPath, $strFinalPath);

        return $obj;
    }

    static public function EmptyRecycleBin($objFilter = null){
        if(is_null($objFilter)){
            $objFilter = new \NsFWK\ClsFilter();    
        }
        $objFilter->dtTrashDateTime = "fldTrashDateTime IS NOT NULL";
        $conn = &\ADODB_Connection_Manager::GetConnection('customer');

        $strSQL = "SELECT pkFileID,fldFileName FROM cmn_file WHERE {$objFilter->GetWhereStatement()}";
        $arrFiles = $conn->GetAssoc($strSQL);
        if(empty($arrFiles)){
            return 0; // Number of affected rows
        }
        
        $rslt = $conn->Execute("DELETE FROM cmn_file WHERE {$objFilter->GetWhereStatement()}"); 
        if($rslt){
            foreach($arrFiles as $intFileID=>$strFileName){
                $strFileExt = pathinfo($strFileName, PATHINFO_EXTENSION);
                $strFileName = $intFileID . '.' . $strFileExt;
                $strFilePath = LOCAL__FILES . "/$strFileName";
                if(file_exists($strFilePath)){
                    unlink($strFilePath);
                }    
            }
            return $conn->affected_rows();
        }
        return false;   
    }

}