<?php
namespace NsCMN;
class ClsFilterModule extends \NsFWK\ClsFilter{
    public function __construct(){
        $this->_data = array(
            'arrID'=>array()
        );
    }

    public function GetWhereStatement(){
        $strWhere = '';

        if(!empty($this->_data['arrID'])){
            $strID = implode(',', $this->_data['arrID']);
            $strWhere .= (($strWhere == '')? '' : ' AND ');
            $strWhere .= "pkModuleID IN ($strID)";
        }

       $strWhere = (($strWhere == '')? '1=1' : $strWhere);
        return $strWhere;
    }
}