<?php
namespace NsCMN;

class ClsBllUserPermission{
    // Start of User Level Permissions //
    const PERMISSION_DELETE = 'delete';
    const PERMISSION_PRINT = 'print';
    const PERMISSION_EDIT = 'edit';
    const PERMISSION_ADD = 'add';
    const PERMISSION_LIST = 'list';
    const PERMISSION_VIEW = 'view';
    const PERMISSION_VIEW_PROFILE = 'view profile';
    const PERMISSION_ADD_PAYMENT = 'add payment';
    const PERMISSION_ADD_MEMBER = 'add member'; //Sales Force
    const PERMISSION_ASSIGN_ACTIVITY = 'assign activity'; //Sales Force
    const PERMISSION_SET_TEAM_LEAD = 'set team lead'; //Sales Force
    const PERMISSION_FILTER_TEAM = 'filter team'; //Sales Force filter,assign activity all
    const PERMISSION_ASSIGN_ACTIVITY_ALL = 'assign activity all'; //Sales Force

    const PERMISSION_ADD_PERMISSION = 'add permission';
    const PERMISSION_ADD_VACATION = 'add vacation';
    
    const PERMISSION_SPLIT_SANCTION = 'split';
    const PERMISSION_BREAK_VACATION = 'break';
    const PERMISSION_REQUEST_RESPONSE = 'respond';
    //Belongs to employee
    const PERMISSION_VIEW_NATIONAL = 'view national';
    const PERMISSION_VIEW_FAMILY = 'view family';
    const PERMISSION_VIEW_EMPLOYMENT = 'view employment';
    const PERMISSION_VIEW_FINANCIALS = 'view financials';
    const PERMISSION_VIEW_CALENDAR = 'view calendar';
    const PERMISSION_VIEW_SUBORDINATES = 'view subordinates';
    const PERMISSION_VIEW_SALARY_LOG = 'view salary log';
    const PERMISSION_VIEW_INSURANCE = 'view insurance';
    const PERMISSION_VIEW_ATTACHMENT = 'view attachment';
    const PERMISSION_ADD_ATTACHMENT = 'add attachment';
    const PERMISSION_VIEW_SALARY_SLIP = 'view salary slip';
    const PERMISSION_VIEW_ALERT = 'view alert';
    const PERMISSION_VIEW_NOTE = 'view note';
    const PERMISSION_ADD_ALERT = 'add alert';
    const PERMISSION_DELETE_ALERT = 'delete alert';
    const PERMISSION_EDIT_FINANCIALS = 'edit financials';

    const PERMISSION_VIEW_LEAVES = 'view leaves';
    const PERMISSION_VIEW_PERMISSIONS = 'view permissions';
    const PERMISSION_EDIT_SCHEDULE = 'edit schedule';
    const PERMISSION_VIEW_ATTENDANCE_REPORT = 'view attendance report';
    const PERMISSION_SET_OVERTIME = 'set overtime';      
    const PERMISSION_ADD_ERRAND = 'add errand'; 
    const PERMISSION_ASSIGN_TEMPLATE = 'assign template'; 
    
    const PERMISSION_MANAGE_LOG = 'manage log';     
    const PERMISSION_ATTACH_FILE = 'attach file';     

    // Sanction
    const PERMISSION_VIEW_ADD = 'view add';
    const PERMISSION_VIEW_LIST = 'view list';

    const PERMISSION_LIST_INSTALLMENTS = 'list installments';

    // Interviews
    const PERMISSION_EDIT_RESULT = 'edit result';                
    const PERMISSION_CANCEL = 'cancel';                
    const PERMISSION_VIEW_VACANCY = 'view vacancy';                
    const PERMISSION_VIEW_APPLICANT = 'view applicant';   

    //Applications
    const PERMISSION_LIST_INTERVIEWS = 'list interviews';             
    const PERMISSION_APPLY_APPLICATION = 'apply application';             
    // pending list
    const PERMISSION_MOVE_TO_SHORT_LIST = 'move to short list';             
    const PERMISSION_MOVE_TO_ANOTHER_VACANCY = 'move to another vacancy';             
    const PERMISSION_REJECT_FROM_PENDING_LIST = 'reject from pending list';             
    const PERMISSION_FAVORITE_FROM_PENDING_LIST = 'favorite from pending list';             

    // short list
    const PERMISSION_MOVE_TO_INTERVIEW_FROM_SHORT_LIST = 'move to interview from short list';             
    const PERMISSION_REJECT_FROM_SHORT_LIST = 'reject from short list'; 
    const PERMISSION_FAVORITE_FROM_SHORT_LIST = 'favorite from short list'; 

    // interview list
    const PERMISSION_SET_INTERVIEW = 'set interview';
    const PERMISSION_REJECT_FROM_INTERVIEW_LIST = 'reject from interview list';             
    const PERMISSION_FAVORITE_FROM_INTERVIEW_LIST = 'favorite from interview list';             

    // interviewed
    const PERMISSION_PROPOSE = 'propose';             
    const PERMISSION_REJECT_FROM_INTERVIEWED = 'reject from interviewed';             
    const PERMISSION_FAVORITE_FROM_INTERVIEWED = 'favorite from interviewed';

    // proposed             
    const PERMISSION_ACCEPT_PROPOSAL = 'accept proposal';             
    const PERMISSION_REJECT_PROPOSAL = 'reject proposal';             

    // Accepted
    const PERMISSION_CREATE_EMPLOYEE = 'create employee';
    // Rejected
    const PERMISSION_MOVE_TO_INTERVIEW_FROM_REJECTED_LIST = 'move to interview from rejected list';             
    // Favorite
    const PERMISSION_MOVE_TO_INTERVIEW_FROM_FAVORITE_LIST = 'move to interview from favorite list';             
    //Applicant
    const PERMISSION_DOWNLOAD_OFFER_LETTER = 'download offer letter';             
    //Vacancy Request
    const PERMISSION_SEND_VACANCY_REQUEST = 'send request';             
    const PERMISSION_RESPOND_VACANCY_REQUEST = 'respond'; 
    //Formal vacation
    const PERMISSION_DELETE_FORMAL_VACATION = "delete formal vacation";            
    
    //TASK
    const PERMISSION_ADD_TASK_GROUP = 'add task group';
    
    //CAB
    const PERMISSION_DISABLE = 'disable';
    const PERMISSION_ENABLE = 'enable';
    
    // End of User Level Permissions //
}