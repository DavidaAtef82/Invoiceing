<?php
namespace NsCMN;

class ClsBllNotification extends \NsFWK\ClsBll{

    public function __set($name, $value){
        // Read Only
        return;
    }
    
    public function __get($name){
        switch($name){
            //case 'strTitleEncoded':
            //  $this->_data[$name] = urlencode($this->_data['strTitle']);
            case 'strNotificationEncoded':
                $this->_data[$name] = base64_encode($this->_data['strNotification']);
        }

        return parent::__get($name);
    }
    
    public function __construct(){
        $this->_strClsDalLoad = '\NsCMN\ClsDalNotification';
        $this->_strClsDalSave = '\NsCMN\ClsDalNotification';
        $this->_data = array('intID'=>-1, 
                            'intUserID'=>-1, 
                            'strTitle'=>'', 
                            'strNotification'=>'', 
                            'dtNotificationDateTime'=>'', 
                            'intIsRead'=>0);
        @parent::__construct(func_get_args());
    }


    public function _save(\ADODB_Active_Record $objDAL){
        if($this->_boolLoaded){
            // Update
            $rslt = $objDAL->Load('pkNotificationID = ?',array($this->_data['intID']));
            if(!$rslt){
                return 'Could not load object!';
            }
        }else{
            // New
            $objDAL->fkUserID = $this->_data['intUserID'];
            $objDAL->fldNotificationDateTime = date('Y-m-d H:i:s');
            $objDAL->fldTitle = $this->_data['strTitle'];
            $objDAL->fldNotification = $this->_data['strNotification'];
        }

        $objDAL->fldIsRead = $this->_data['intIsRead'];
        $rslt = $objDAL->Save();
        if($rslt){
            $this->_data['intID'] = $objDAL->pkNotificationID;
            $this->_data['dtNotificationDateTime'] = $objDAL->fldNotificationDateTime;

            //$this->strTitleEncoded;
            $this->strNotificationEncoded;
        }
        return $rslt;
    }
    
    public function _delete(\ADODB_Active_Record $objDAL){
        $DB = $objDAL->DB();                                                    
        $rslt = $DB->Execute("DELETE FROM cmn_notification WHERE pkNotificationID = {$this->_data['intID']}");
        return $rslt;
    }
    
    public function _load(\ADODB_Active_Record $objDAL){
        $this->_data['intID'] = $objDAL->pkNotificationID;
        $this->_data['intUserID'] = $objDAL->fkUserID;
        $this->_data['strTitle'] = $objDAL->fldTitle;
        $this->_data['strNotification'] = $objDAL->fldNotification;
        $this->_data['dtNotificationDateTime'] = $objDAL->fldNotificationDateTime;
        $this->_data['intIsRead'] = $objDAL->fldIsRead;
        
        //$this->strTitleEncoded;
        $this->strNotificationEncoded;
    }  
    
    
    public function LoadByID($intID){
        $objFilter = new \NsFWK\ClsFilter();
        $objFilter->intID = "pkNotificationID = $intID";
        return $this->Load($objFilter); 
    }

    public function SetRead(){
        if($this->_data['intIsRead'] == 1){
            // Already set Read
            return true;
        }
        
        $this->_data['intIsRead'] = 1;
        $rslt = $this->Save();
        return $rslt;
    }
    
    public function SetUnRead(){
        if($this->_data['intIsRead'] == 0){
            // Already set Read
            return true;
        }
        
        $this->_data['intIsRead'] = 0;
        $rslt = $this->Save();
        return $rslt;
    }
    
    
    public function GetDataAssociativeUserNotifications($intUserID, $intIsRead=-1, $intCount=false){
        $objFilter = new \NsFWK\ClsFilter();
        $objFilter->intUserID = "fkUserID = $intUserID";
        if($intIsRead != -1){
            $objFilter->intIsRead = "fldIsRead = $intIsRead";
        }
        
        return $this->GetDataAssociative($objFilter, 'fldNotificationDateTime DESC', '', 0, $intCount);
    }
    

    static public function Count($intUserID, $intIsRead=-1){
        $DB = &\ADODB_Connection_Manager::GetConnection('customer');

        $SQL = "SELECT COUNT(*) FROM cmn_notification WHERE fkUserID = ?";
        if($intIsRead != -1){
            $SQL .= " AND fldIsRead = $intIsRead";
        }

        $rslt = $DB->GetOne($SQL, array($intUserID));
        return $rslt;
    }

    static public function CreateUserNotification($intUserID, $strTitle, $strNotification){
        $obj = new ClsBllNotification();
        $obj->_data['intUserID'] = $intUserID;
        $obj->_data['strTitle'] = $strTitle;
        $obj->_data['strNotification'] = $strNotification;
        $obj->_data['intIsRead'] = 0;
        $rslt = $obj->Save();
        if($rslt){
            return $obj;
        }else{
            return false;
        }
    }
   
    static public function CreateUserNotificationBulk($arrUserIDs, $strTitle, $strNotification){
        $arrUserIDs = array_unique($arrUserIDs);
        if(!empty($arrUserIDs)){
           $dmDateTime = date('Y-m-d H:i:s');
           $strSql = "INSERT INTO cmn_notification(fkUserID, fldTitle, fldNotification, fldNotificationDateTime, fldIsRead) VALUES ";
           foreach($arrUserIDs as $intUserID){
               $param1 = \NsFWK\ClsHlpHelper::StripMySQLSpecialChar($strTitle);
               $param2 = \NsFWK\ClsHlpHelper::StripMySQLSpecialChar($strNotification);
               
               $strSql .= " ($intUserID, '$param1', '$param2', '$dmDateTime', 0),";    
           }
           $strSql = trim($strSql, ',');
           $DB = &\ADODB_Connection_Manager::GetConnection('customer');
           $rslt = $DB->Execute($strSql);
           return $rslt;
       } 
       return false;
    }
   
    static public function DeleteNotifications($arrNotificationIDs){
        if(empty($arrNotificationIDs)){
            return false;
        }
        
        $strIDs = implode(',', $arrNotificationIDs);
        $DB = &\ADODB_Connection_Manager::GetConnection('customer');
        $rslt = $DB->Execute("DELETE FROM cmn_notification WHERE pkNotificationID IN($strIDs)");
        return $rslt;
    }
}