<?php 
namespace NsCMN;

class ClsBllLog extends \NsFWK\ClsBll{
    public function __construct (){
        $this->_strClsDalLoad = '\NsCMN\ClsDalLog';
        $this->_strClsDalSave = '\NsCMN\ClsDalLog';
        $this->_data = array(
            'intID'=>-1,
            'strObjectType'=>'',
            'strAction'=>'',
            'objObjectID'=>null,
            'strObject'=>'',
            'intUserID'=>-1,
            'tsTimeStamp'=>'', 
        );
        parent::__construct(func_get_args());
    }
    public function __get($name){
        switch($name){

        }
        return parent::__get($name);
    }
    protected function _save(\ADODB_Active_Record $objDal){
        if($this->getIsLoaded()){
            $rslt = $objDal->Load('pkLogID = ?',array($this->_data['intID']));
            if(!$rslt){
                return 'could not load object';
            }
        }else{
            $objDal->fldTimeStamp = date("Y-m-d H:i:s");
        }
        $objDal->fldObjectType = $this->_data['strObjectType'];
        $objDal->fldAction = $this->_data['strAction'];
        $objDal->fldObjectID = $this->_data['objObjectID'];
        $objDal->fldObject = $this->_data['strObject'];
        $objDal->fkUserID = $this->_data['intUserID'];

        $rslt = $objDal->Save();
        if($rslt){
            $this->_data['intID'] = $objDal->pkLogID;
        }
        return $rslt;        
    }

    protected function _delete(\ADODB_Active_Record $objDall){
        return true;
    }

    protected function _load(\ADODB_Active_Record $objDal){
        $this->_data['intID'] = $objDal->pkLogID;
        $this->_data['strObjectType'] = $objDal->fldObjectType;
        $this->_data['strAction'] = $objDal->fldAction;
        $this->_data['strObject'] = $objDal->fldObject;
        $this->_data['intUserID'] = $objDal->fkUserID;
        $this->_data['tsTimeStamp'] = $objDal->fldTimeStamp;
    }

    public function LoadByID($intID){
        $objFilter = new \NsFWK\ClsFilter();
        $objFilter->intID = "pkLogID = $intID";
        return $this->Load($objFilter);
    }
    public function LoadByObjectID($strObjectID){
        $objFilter = new \NsFWK\ClsFilter();
        $objFilter->strObjectID = "fldObjectID = '$strObjectID'";
        $this->Load($objFilter);
        return $this->_data;
    }
}
