<?php
namespace NsCMN;

// Common connection
class ClsDalApiApp extends \ADODB_Active_Record{
    var $_dbat = 'common'; var $_table = 'api_app';
}
class ClsDalApiAppDetails extends \ADODB_Active_Record{
    var $_dbat = 'common'; var $_table = 'vw_api_app_details';
    public function __construct(){
        parent::__construct('vw_api_app_details', array('pkAppID'));
    }
}
class ClsDalApiMethod extends \ADODB_Active_Record{
    var $_dbat = 'common'; var $_table = 'api_method';
}
class ClsDalApiMethodDetails extends \ADODB_Active_Record{
    var $_dbat = 'common'; var $_table = 'vw_api_method_details';
    public function __construct(){
        parent::__construct('vw_api_method_details', array('pkMethodID'));
    }
}
class ClsDalApiAppMethod extends \ADODB_Active_Record{
    var $_dbat = 'common'; var $_table = 'api_app_method';
}
class ClsDalApiToken extends \ADODB_Active_Record{
    var $_dbat = 'common'; var $_table = 'api_token';
}

class ClsDalCusAccount extends \ADODB_Active_Record{
    var $_dbat = 'common'; var $_table = 'cus_account';
}

class ClsDalMailTemplate extends \ADODB_Active_Record{
    var $_dbat = 'common'; var $_table = 'lng_mail_template';
}

class ClsDalModule extends \ADODB_Active_Record{
    var $_dbat = 'common'; var $_table = 'mod_module';
}
class ClsDalModuleAction extends \ADODB_Active_Record{
    var $_dbat = 'common'; var $_table = 'mod_module_action';
}

class ClsDalSiteMap extends \ADODB_Active_Record{
    var $_dbat = 'common'; var $_table = 'mod_site_map';
}
class ClsDalSiteMapDetails extends \ADODB_Active_Record{
    var $_dbat = 'common'; var $_table = 'vw_mod_site_map_details';
    public function __construct(){
        parent::__construct('vw_mod_site_map_details', array('pkItemID'));
    }
}

class ClsDalUserLevel extends \ADODB_Active_Record{
    var $_dbat = 'common'; var $_table = 'mod_user_level';
}
class ClsDalUserLevelAction extends \ADODB_Active_Record{
    var $_dbat = 'common'; var $_table = 'mod_user_level_action';
}
class ClsDalUserLevelActionDetails extends \ADODB_Active_Record{
    var $_dbat = 'common'; var $_table = 'vw_mod_user_level_action_details';
    public function __construct(){
        parent::__construct('vw_mod_user_level_action_details', array('pfUserLevelID','pfActionID'));
    }
}
class ClsDalUserLevelDefaultPage extends \ADODB_Active_Record{
    var $_dbat = 'common'; var $_table = 'mod_user_level_default_page';
}

// Customer connection
class ClsDalAPIClient extends \ADODB_Active_Record{
    var $_dbat = 'customer'; var $_table = 'cmn_api_client';
}

class ClsDalCronJob extends \ADODB_Active_Record{
    var $_dbat = 'customer'; var $_table = "cmn_cron";
}

class ClsDalConfig extends \ADODB_Active_Record{
    var $_dbat = 'customer'; var $_table = 'cmn_config';
}

class ClsDalLog extends \ADODB_Active_Record{
    var $_dbat = 'customer'; var $_table = 'cmn_log';
}

class ClsDalFile extends \ADODB_Active_Record{
    var $_dbat = 'customer'; var $_table = 'cmn_file';
}
class ClsDalFileInfo extends \ADODB_Active_Record{
    var $_dbat = 'customer'; var $_table = 'vw_cmn_file_info';
}

class ClsDalSession extends \ADODB_Active_Record{
    var $_dbat = 'customer'; var $_table = 'aux_session';

    public function ClearSession(){
        $DB = $this->DB();
        $rslt = $DB->Execute('TRUNCATE TABLE aux_session');
        return $rslt;
    }
}

class ClsDalUser extends \ADODB_Active_Record{
    var $_dbat = 'customer'; var $_table = 'cmn_user';
}
class ClsDalUserUserLevel extends \ADODB_Active_Record{
    var $_dbat = 'customer'; var $_table = 'cmn_user_user_level';
}

class ClsDalCountry extends \ADODB_Active_Record{
    var $_dbat = 'customer'; var $_table = 'cmn_country';
}
class ClsDalCity extends \ADODB_Active_Record{
    var $_dbat = 'customer'; var $_table = 'cmn_city';
}
class ClsDalDistrict extends \ADODB_Active_Record{
    var $_dbat = 'customer'; var $_table = 'cmn_district';
}

class ClsDalLocation extends \ADODB_Active_Record{
    var $_dbat = 'customer'; var $_table = 'cmn_location';
}
class ClsDalLocationDetails extends \ADODB_Active_Record{
    var $_dbat = 'customer'; var $_table = 'vw_cmn_location_details';
    public function __construct(){
        parent::__construct('vw_cmn_location_details', array('pkLocationID'));
    }
}

class ClsDalNotification extends \ADODB_Active_Record{
    var $_dbat = 'customer'; var $_table = "cmn_notification";
}

class ClsDalVersion extends \ADODB_Active_Record{
    var $_dbat = 'customer'; var $_table = 'cmn_version';
}
class ClsDalVersionMigration extends \ADODB_Active_Record{
    var $_dbat = 'customer'; var $_table = 'cmn_version_migration';
}

class ClsDalStartupDialog extends \ADODB_Active_Record{
    var $_dbat = 'common'; var $_table = 'mod_startup_dialog';
}
class ClsDalUserStartupDialog extends \ADODB_Active_Record{
    var $_dbat = 'common'; var $_table = 'mod_user_startup_dialog';
}