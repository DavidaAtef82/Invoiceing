<?php
namespace NsCMN;

class ClsBllUserLevel extends \NsFWK\ClsBll{
    const USER_LEVEL_ADMIN = 1;
    const USER_LEVEL_SYSTEM = 47;
    
    const USER_LEVEL_HR_SUPERVISOR = 23;
    const USER_LEVEL_CAB_SUPERVISOR = 53;

    const USER_LEVEL_HEAD = 21;
    const USER_LEVEL_EMPLOYEE = 27;
    
    const USER_LEVEL_RECRUITMENT_SUPERVISOR = 45;
    
    const USER_LEVEL_TASK = 46;
    
    const USER_LEVEL_SALES_PERSON = 48;
    const USER_LEVEL_SALES_MANAGER = 49;
    const USER_LEVEL_DATA_MANAGER = 52;
    
    const USER_LEVEL_TASK_USER = 46;
    
    const ERR_BLANK_USER_LEVEL = 1195;
    const ERR_SHORT_USER_LEVEL = 1196;
    const ERR_INVALID_CHAR = 1197;
    const ERR_USER_LEVEL_UNAVAILABL = 1198;
    
    static private $_arrModule = array();

    
    public function __set($name, $value) {
        switch ($name) {
            //case 'objModule':
            case 'intModuleID':
            case 'strDefaultPage':
                // read-only attributes
                return;
                break;
        }
        
        return parent::__set($name, $value);
    }

    public function __construct(){
        $this->_strClsDalLoad = '\NsCMN\ClsDalUserLevel';
        $this->_strClsDalSave = '\NsCMN\ClsDalUserLevel';   
        $this->_data = array(
            'intID'=>-1,
            'strUserLevel'=>'',
            //'objModule'=>null,
            'intModuleID'=>-1,
            'strDefaultPage'=>'',
            'arrModule'=>array(),
            'arrDefaultPage'=>array()
        );
        @parent::__construct(func_get_args());
    }
   

    protected function _save(\ADODB_Active_Record $objDAL){
        if($this->getIsLoaded()){
            $rslt = $objDAL->Load('pkUserLevelID=?',array($this->_data['intID']));
            if(!$rslt){
                return 'Could not load object!';
            }
        } 
        $objDAL->fldUserLevel = $this->_data['strUserLevel'];
        $rslt = $objDAL->Save();
        if($rslt){
            $this->_data['intID'] = $objDAL->pkUserLevelID;
        }  
        return $rslt;
    }
    
    protected function _delete(\ADODB_Active_Record $objDAL){
        $DB_COMMON = &\ADODB_Connection_Manager::GetConnection('common');
        $DB_COMMON->StartTrans();

        $strSQL = "DELETE FROM mod_user_level_default_page WHERE pfUserLevelID = ?;";
        $ok = $DB_COMMON->Execute($strSQL, array($this->_data['intID']));
        if (!$ok) {
            return $DB_COMMON->CompleteTrans(false);
        }
        
        $strSQL = "DELETE FROM mod_user_level WHERE pkUserLevelID = ?;";
        $ok = $DB_COMMON->Execute($strSQL, $this->_data['intID']);
        return $DB_COMMON->CompleteTrans($ok);
    }
    
    protected function _load(\ADODB_Active_Record $objDAL){
        $this->_data['intID'] = $objDAL->pkUserLevelID;
        $this->_data['strUserLevel'] = $objDAL->fldUserLevel;
        
        // XXX 1 -c review: We need to make this more effecient from performance perspective
        $this->loadDefaultPages();
        $this->loadModules();
        
        // Populate modules' default pages
        // Good to know which modules the user has actions on but has no default page
        foreach ($this->_data['arrModule'] as &$objModule) {
            if (array_key_exists($objModule->intID, $this->_data['arrDefaultPage'])) {
                $objModule->strDefaultPage = $this->_data['arrDefaultPage'][$objModule->intID]['strDefaultPage'];
            } else {
                $objModule->strDefaultPage = '';
            }
        }
    } 
    
    
    protected function loadDefaultPages() {
        $this->_data['arrDefaultPage'] = array();

        $DB_COMMON = &\ADODB_Connection_Manager::GetConnection('common');

        $strSQL = "SELECT
                        pfModuleID AS intModuleID,
                        fldDefaultPage AS strDefaultPage,
                        fldDefaultModule AS intDefaultModule
                   FROM mod_user_level_default_page
                   WHERE pfUserLevelID = ?";
        $arrDefaultPage = $DB_COMMON->GetArray($strSQL, array($this->_data['intID']));
        if (empty($arrDefaultPage)) {
            return;
        }
        
        $arrModule = self::getModules();
        foreach ($arrDefaultPage as $item) {
            $item['intDefaultModule'] = (int)$item['intDefaultModule'];
            $item['strTitle'] = $arrModule[$item['intModuleID']]->strTitle;
            $this->_data['arrDefaultPage'][$item['intModuleID']] = $item;

            if ($item['intDefaultModule']) {
                $this->_data['strDefaultPage'] = $item['strDefaultPage'];
                $this->_data['intModuleID'] = $item['intModuleID'];
                //$this->_data['objModule'] = $arrModule[$item['intModuleID']];
            }
        }
    }

    protected function loadModules() {
        $this->_data['arrModule'] = array();
        
        $DB_COMMON = &\ADODB_Connection_Manager::GetConnection('common');

        // Get permitted modules
        $strSQL = "SELECT DISTINCT fkModuleID
                    FROM mod_module_action
                    WHERE pkActionID IN (
                        SELECT pfActionID
                        FROM mod_user_level_action
                        WHERE pfUserLevelID = ?
                    );";
        $arrModuleID = $DB_COMMON->GetCol($strSQL, $this->_data['intID']);
        if (empty($arrModuleID)) {
            return ;
        }
        
        $arrModule = self::getModules();
        foreach ($arrModule as $objModule) {
            if (in_array($objModule->intID, $arrModuleID)) {
                $this->_data['arrModule'][] = $objModule;
            }
        }
    }


    public function AddDefaultPage($intModuleID, $strDefaultPage, $intDefaultModule) {
        $DB_COMMON = &\ADODB_Connection_Manager::GetConnection('common');
        $DB_COMMON->StartTrans();
        
        if ($intDefaultModule) {
            // New default page
            // Reset the existing default one
            $strSQL = "UPDATE mod_user_level_default_page
                        SET fldDefaultModule = 0
                        WHERE pfUserLevelID = ?;";
            $ok = $DB_COMMON->Execute($strSQL, array($this->_data['intID']));
            if (!$ok) {
                return $DB_COMMON->CompleteTrans(false);
            }
        }
        
        $strSQL = "INSERT INTO mod_user_level_default_page (pfUserLevelID, pfModuleID, fldDefaultModule, fldDefaultPage)
                    VALUES (?, ?, ?, ?)
                    ON DUPLICATE KEY UPDATE fldDefaultModule = ?, fldDefaultPage = ?;";
        $arrParam = array(
            $this->_data['intID'],
            $intModuleID,
            $intDefaultModule,
            $strDefaultPage,
            $intDefaultModule,
            $strDefaultPage
        );
        $ok = $DB_COMMON->Execute($strSQL, $arrParam);

        $ok = $DB_COMMON->CompleteTrans($ok);
        if (!$ok) {
            return false;
        }

        // Reflect to local attributes
        $boolNew = true;
        foreach ($this->_data['arrDefaultPage'] as &$item) {
            if ($intDefaultModule) {
                // Reset default page if a new default page is assigned
                $item['intDefaultModule'] = 0;
            }

            if ($item['intModuleID'] == $intModuleID) {
                // Page already exists
                // Update existing page
                $boolNew = false;
                $item['strDefaultPage'] = $strDefaultPage;
                $item['intDefaultModule'] = $intDefaultModule;
            }
        }
        
        if ($boolNew) {
            // New page
            $this->_data['arrDefaultPage'][$intModuleID] = array(
                'intModuleID'=>$intModuleID,
                'strDefaultPage'=>$strDefaultPage,
                'intDefaultModule'=>$intDefaultModule,
                'strTitle'=> self::getModules()[$intModuleID]->strTitle
            );
        }
        
        if ($intDefaultModule) {
            // Updated other class attributes
            $this->_data['strDefaultPage'] = $strDefaultPage;
            $this->_data['intModuleID'] = $intModuleID;
            //$this->_data['objModule'] = self::getModules()[$intModuleID];
        }
        return true;
    }
    
    public function DeleteDefaultPage($intModuleID) {
        // Remove from DB
        $DB_COMMON = &\ADODB_Connection_Manager::GetConnection('common');
        $strSQL = "DELETE FROM mod_user_level_default_page
                    WHERE pfUserLevelID = ? AND pfModuleID = ?;";
        $arrParam = array(
            $this->_data['intID'],
            $intModuleID,
        );
        $ok = $DB_COMMON->Execute($strSQL, $arrParam);
        if (!$ok) {
            return false;
        }
        
        // Reflect to local attributes
        if (isset($this->_data['arrDefaultPage'][$intModuleID])) {
            unset($this->_data['arrDefaultPage'][$intModuleID]);
        }
        
        return true;
    }
    

    public function LoadByID($intID){
        $objFilter = new \NsFWK\ClsFilter();
        $objFilter->intID = "pkUserLevelID = $intID";
        return $this->Load($objFilter);
    }  

    public function GetAllUserLevel(){
        $objFilter = new \NsFWK\ClsFilter();
        return $this->GetData($objFilter, 'fldUserLevel ASC');
    }
    
    /*
    public function GetDataAssociatives(\NsFWK\ClsFilter $objFilter, $strOrder = '', $strGroup = '', $intOffset = false, $intCount = false){
        $arrData = parent::GetDataAssociative($objFilter, $strOrder, $strGroup);
        if(empty($arrData)){
            return $arrData;
        }
        
        $arrUserLevelIDs = array_keys(\NsFWK\ClsHlpHelper::IndexObjectArrayAssoc($arrData, array('intID')));
        $strUserLevelIDs = implode(',', $arrUserLevelIDs);
        
        
        $objDAL = new ClsDalUserLevelDefaultPage();
        $arr = $objDAL->Find("pfUserLevelID IN ($strUserLevelIDs)");
        
        $arr = \NsFWK\ClsHlpHelper::IndexObjectArray($arr, array('pfUserLevelID'), true);
        
        foreach($arrData as &$Data){
            
            $strDefaultPage = $arr[$Data['intID']][0]->fldDefaultPage;
            $intModuleID = $arr[$Data['intID']][0]->intModuleID;
            $arrDefaultPages = array();
            foreach($arr[$Data['intID']] as $objDefaultPage){
                $obj = array(); 
                $obj['intUserLevelID'] = $objDefaultPage->pfUserLevelID;  
                $obj['intModuleID'] = $objDefaultPage->pfModuleID;  
                $obj['boolDefaultModule'] = (bool)$objDefaultPage->fldDefaultModule;  
                $obj['strDefaultPage'] = $objDefaultPage->fldDefaultPage;
                if($obj['boolDefaultModule']){
                    $strDefaultPage = $obj['strDefaultPage'];    
                    $intModuleID = $obj['intModuleID'];    
                } 
                $arrDefaultPages[] = $obj; 
            }
            $Data['arrDefaultPages'] = $arrDefaultPages;   
            $Data['strDefaultPage'] = $strDefaultPage;   
            $Data['intModuleID'] = $intModuleID;   
        }

        return $arrData;
    }
    
    public function GetData(\NsFWK\ClsFilter $objFilter, $strOrder = '', $strGroup = '', $intOffset = false, $intCount = false){
        $arrData = parent::GetData($objFilter, $strOrder, $strGroup);
        if(empty($arrData)){
            return $arrData;
        }
        
        $arrUserLevelIDs = array_keys(\NsFWK\ClsHlpHelper::IndexObjectArray($arrData, array('intID')));
        $strUserLevelIDs = implode(',', $arrUserLevelIDs);
        

        $objDAL = new ClsDalUserLevelDefaultPage();
        $arr = $objDAL->Find("pfUserLevelID IN ($strUserLevelIDs)");
        
        $arr = \NsFWK\ClsHlpHelper::IndexObjectArray($arr, array('pfUserLevelID'), true);
        
        foreach($arrData as &$objData){
            $strDefaultPage = $arr[$objData->intID][0]->fldDefaultPage;
            $intModuleID = $arr[$objData->intID][0]->intModuleID;
            $arrDefaultPages = array();
            foreach($arr[$objData->intID] as $objDefaultPage){
                $obj = new \stdClass(); 
                $obj->intUserLevelID = $objDefaultPage->pfUserLevelID;  
                $obj->intModuleID = $objDefaultPage->pfModuleID;  
                $obj->boolDefaultModule = (bool)$objDefaultPage->fldDefaultModule;  
                $obj->strDefaultPage = $objDefaultPage->fldDefaultPage;
                if($obj->boolDefaultModule){
                    $intModuleID = $obj->intModuleID;    
                    $strDefaultPage = $obj->strDefaultPage;    
                } 
                $arrDefaultPages[] = $obj; 
            }
            $objData->arrDefaultPages = $arrDefaultPages;   
            $objData->strDefaultPage = $strDefaultPage;   
            $objData->intModuleID = $intModuleID;   
        }
        
        //$this->loadBinding($arrData, 'intID', 'arrDefaultPages', new ClsBllUserLevelDefaultPage(), 'pfUserLevelID', 'intUserLevelID', true); 

        return $arrData;
    }
    */
    
    static public function CreateCopy($objUserLevel, $strNewUserLevelName) {
        $DB = &\ADODB_Connection_Manager::GetConnection('common');
        $DB->StartTrans();
        
        // Create new user level
        $objCopy = new static();
        $objCopy->strUserLevel = $strNewUserLevelName;
        $objCopy->Save();
        
        // Copy permissions
        $strSQL = "INSERT INTO mod_user_level_action
                    SELECT ? AS pfUserLevelID, pfActionID, fldPermissions
                    FROM mod_user_level_action
                    WHERE pfUserLevelID = ?;";
        $ok = $DB->Execute($strSQL, array($objCopy->intID, $objUserLevel->intID));
        if (!$ok) {
            return $DB->CompleteTrans(false);
        }
        
        // Copy default module pages
        $strSQL = "INSERT INTO mod_user_level_default_page
                    SELECT ? AS pfUserLevelID, pfModuleID, fldDefaultModule, fldDefaultPage 
                    FROM mod_user_level_default_page
                    WHERE pfUserLevelID = ?;";
        $ok = $DB->Execute($strSQL, array($objCopy->intID, $objUserLevel->intID));
        
        // Finalize and return
        $ok = $DB->CompleteTrans($ok);
        if ($ok) {
            $objCopy->loadDefaultPages();
            $objCopy->loadModules();
            return $objCopy;
        } else {
            return false;
        }
    }
    
    //static public function ValidateUserLevel($strUserLevel, $intExcludeID=-1) {
    static public function ValidateUserLevelString($strUserLevel) {
        if (empty($strUserLevel)) {
            return self::ERR_BLANK_USER_LEVEL;                   
        }
        
        $intMin = 5;
        $intMax = 50;
        if (strlen($strUserLevel) < $intMin) {
            return self::ERR_SHORT_USER_LEVEL;                   
        }
        
        $intMin -= 2;   // As validation statically checks for first and last chars
        $intMax -= 2;   // As validation statically checks for first and last chars

        // UserLevel string length must be between 5 and 50
        // It can only include: english letters, numbers, '.' and '_'
        // It must start with an english letter
        // It must end with an an english letter or a number
        // Successive '.' or '_' or both is not allowed
        $strRegEx = '/^[a-zA-Z]((?:[a-zA-Z0-9]|([._])(?![._])){' . "$intMin,$intMax" . '})[a-zA-Z0-9]$/';
        $rslt = preg_match($strRegEx, $strUserLevel, $arrMatches);
        if (!$rslt) {
            return self::ERR_INVALID_CHAR;                   
        }
        
        return true;
    }
    
    static public function IsUserLevelAvailable($strUserLevel, $intExcludeID=-1) {
        $DB_COMMON = &\ADODB_Connection_Manager::GetConnection('common');

        $strSQL = "SELECT * FROM mod_user_level WHERE fldUserLevel LIKE ? AND pkUserLevelID <> ? LIMIT 1";
        $arr = $DB_COMMON->GetArray($strSQL, array($strUserLevel, $intExcludeID));
        if (empty($arr)) {
            return true;
        } else {
            return self::ERR_USER_LEVEL_UNAVAILABL;
        }
    }
    
    static private function getModules() {
        if (empty(self::$_arrModule)) {
            $objFilter = new ClsFilterModule();
            $objModule = new ClsBllModule();
            $arrModule = $objModule->GetData($objFilter);
            self::$_arrModule = \NsFWK\ClsHlpHelper::IndexObjectArray($arrModule, array('intID'));
        }
        
        return self::$_arrModule;
    }
}