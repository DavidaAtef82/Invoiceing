<?php

define('MODULE_NAME', 'cmn');
define('MODULE_ID', '6');
define('MODULE_WEB_PATH', WEB__MODULES . '/' . MODULE_NAME);
define('MODULE_LOCAL_PATH', LOCAL__MODULES . '/' . MODULE_NAME);

define('PATH__CSS', MODULE_WEB_PATH . '/view/css');
define('PATH__IMAGE', MODULE_WEB_PATH . '/view/images');
define('PATH__JS', MODULE_WEB_PATH . '/view/js');
define('PATH__LANG', MODULE_WEB_PATH . '/view/lang');

define('SMARTY_TEMPLATE_DIR', MODULE_LOCAL_PATH . '/view/templates');
define('SMARTY_CONFIG_DIR', MODULE_LOCAL_PATH . '/view/lang');
define('SMARTY_CACHE_DIR', LOCAL__TMP . '/' . THEME . '/' . MODULE_NAME . '/cache');
define('SMARTY_COMPILE_DIR', LOCAL__TMP . '/' . THEME . '/' . MODULE_NAME . '/compile');

define('PATH_UPLOAD_FINGER_PRINT', LOCAL__UPLOAD . '/hr/templates/finger_print.csv');
define('PATH_UPLOAD_EMPLOYEES_CSV', LOCAL__UPLOAD . '/hr/templates/employees.csv');
define('PATH_UPLOAD_EMPLOYEES_EXCEL', LOCAL__UPLOAD . '/hr/templates/employees.xlsx');
define('PATH_UPLOAD_VACATION_BALANCE', LOCAL__UPLOAD . '/hr/templates/vacation_balance.xlsx');
define('PATH_UPLOAD_VACATION_BALANCE_SAMPLE', LOCAL__UPLOAD . '/hr/templates/vacation_balance_sample.xlsx');

define('PATH_UPLOAD_SETTLEMENTS', LOCAL__UPLOAD . '/cab/templates/settlements.csv');
define('PATH_UPLOAD_SALARIES', LOCAL__UPLOAD . '/cab/templates/salaries_import.xlsx');
define('PATH_UPLOAD_PAYMENT', LOCAL__UPLOAD . '/cab/templates/employees_payment_method.xlsx');

define('PATH_UPLOAD_CHART_OF_ACCOUNT', LOCAL__UPLOAD . '/bk/templates/CoA.xlsx');