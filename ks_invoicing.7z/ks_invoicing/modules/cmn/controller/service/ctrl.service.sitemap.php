<?php
namespace NsCMN;

class ClsCtrlServiceSitemap extends \NsCMN\ClsCtrlServiceCmn {

    protected function do_Default(){}

    protected function do_List(){
        $obj = new ClsBllSitemap();
        $arrData = $obj->GetAll();

        $arr['result'] = true;
        $arr['title'] = 'Success';
        $arr['message'] = 'Modules successfully listed';
        $arr['object'] = $arrData;
        print json_encode($arr);
    }

    protected function do_ListTopMenu(){
        $obj = new ClsBllSitemap();
        $arrData = $obj->GetTopMenu();

        $arr['result'] = true;
        $arr['title'] = 'Success';
        $arr['message'] = 'Top menu successfully listed';
        $arr['object'] = $arrData;
        print json_encode($arr);

    }

    protected function do_Update(){
        $arrData = $this->_payload['objMenu'];
        $obj = new ClsBllSitemap();
        $rslt = $obj->LoadByID($arrData['intID']);
        if (!$rslt){
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = 'Could not load menu';
            print json_encode($arr);
            return ;            
        }


        $obj->decGroupOrder = $arrData['decGroupOrder'];
        $obj->decItemOrder = $arrData['decItemOrder'];
        $obj->intItemLevel = $arrData['intItemLevel'];
        $obj->intActionID = $arrData['intActionID'];
        $obj->strItemText = $arrData['strItemText'];
        if (isset($arrData['strItemStyle'])){
            $obj->strItemStyle = $arrData['strItemStyle'];
        }
        $obj->boolShowInMenu = $arrData['boolShowInMenu'];
        $rslt = $obj->Save();
        if ($rslt){
            $arr['result'] = true;
            $arr['title'] = 'Success';
            $arr['message'] = 'Top menu successfully listed';
            $arr['object'] = $obj->ToArray();
        }else{
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = 'Could not load menu';
        }
        print json_encode($arr);
    }

    protected function do_Save(){
        $arrData = $this->_payload['objMenu'];
        $obj = new ClsBllSitemap();
        $obj->decGroupOrder = $arrData['decGroupOrder'];
        $obj->decItemOrder = $arrData['decItemOrder'];
        $obj->intItemLevel = $arrData['intItemLevel'];
        $obj->intActionID = $arrData['intActionID'];
        $obj->strItemText = $arrData['strItemText'];
        if (isset($arrData['strItemStyle'])){
            $obj->strItemStyle = $arrData['strItemStyle'];
        }
        $obj->boolShowInMenu = $arrData['boolShowInMenu'];
        $rslt = $obj->Save();
        if ($rslt){
            $arr['result'] = true;
            $arr['title'] = 'Success';
            $arr['message'] = 'Top menu successfully listed';
            $arr['object'] = $obj->ToArray();
        }else{
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = 'Error while saving menu ' . $obj->getLastTrace();
        }
        print json_encode($arr);
    }
    
    protected function do_Delete(){
        $intMenuID = $this->_data['menu_id'];
        $obj = new ClsBllSitemap();
        $rslt = $obj->LoadByID($intMenuID);
        if (!$rslt){
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = 'Could not load menu';
            print json_encode($arr);
            return ;            
        }
        $rslt = $obj->Delete();
        if ($rslt){
            $arr['result'] = true;
            $arr['title'] = 'Success';
            $arr['message'] = 'menu item successfully deleted';
        }else{
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = 'Could not delete menu item';
        }
        print json_encode($arr);
    }    
}
