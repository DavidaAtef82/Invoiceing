<?php
namespace NsCMN;

class ClsCtrlServiceNotification extends \NsCMN\ClsCtrlServiceCmn {

    protected function do_Default(){}
    
    protected function do_List(){
        $intUserID = $this->_data['user_id'];
        $obj = new \NsCMN\ClsBllNotification();
        $rslt = $obj->GetDataAssociativeUserNotifications($intUserID);

        $arr['result'] = true;
        $arr['title'] = 'Success';
        $arr['message'] = 'Notifications retrieved successfully';
        $arr['object'] = $rslt;
        print json_encode($arr);
        return $rslt;
    }

    protected function do_Update(){
        $intNotification = $this->_data['notification_id'];
        $strStatus = $this->_data['status'];

        $obj = new \NsCMN\ClsBllNotification();
        $rslt = $obj->LoadByID($intNotification);
        if ($rslt){
            switch($strStatus){
                case 1:
                    $ok = $obj->SetRead();
                    break;
                case 0:
                    $ok = $obj->SetUnRead();
                    break;
            }
            if ($ok){
                $intCount = $this->objUser->intUnreadNotificationCount;
                $arr['result'] = true;
                $arr['title'] = $this->cLang('LNG_5669');
                $arr['message'] = $this->cLang('LNG_5671');
                $arr['object'] = $intCount;
            }else{
                $arr['result'] = false;
                $arr['title'] = $this->cLang('LNG_5670');
                $arr['message'] = $this->cLang('LNG_5672');
            }
        }else{
            $arr['result'] = false;
            $arr['title'] = $this->cLang('LNG_5670');
            $arr['message'] = $this->cLang('LNG_5673');
        }

        print json_encode($arr);
        return $arr['result'];
    }

    protected function do_Delete(){
        $intNotificationsID = $this->_data['notification_id'];

        if(!empty($intNotificationsID)){
            $rslt = \NsCMN\ClsBllNotification::DeleteNotifications(array($intNotificationsID));
            if($rslt){
                $arr['result'] = true;
                $arr['message'] = "Notification deleted successfully!";
                $arr['object'] = $this->objUser->intUnreadNotificationCount;
            }else{
                $arr['result'] = false;
                $arr['message'] = "Error in deleting notification!";
            }
        }else{
            $arr['result'] = true;
            $arr['message'] = "No notification has been selected!";
            $arr['object'] = $this->objUser->intUnreadNotificationCount;
        }

        print json_encode($arr);
        return $arr['result'];
    }


    protected function do_SetNotificationsRead(){
        $strNotificationsIDs = $this->_data['notifiction_ids'];
        $arrNotificationsIDs = array();
        if(!empty($strNotificationsIDs)){
            $arrNotificationsIDs = explode("|", $strNotificationsIDs);
        }
        $DB = &\ADODB_Connection_Manager::GetConnection('customer');
        $DB->StartTrans();
        if(!empty($arrNotificationsIDs)){
            foreach($arrNotificationsIDs as $intNotificationID){
                $objNotification = new \NsCMN\ClsBllNotification();
                $rslt = $objNotification->LoadByID($intNotificationID);
                $objNotification->SetRead();
            }
            $rslt = $DB->CompleteTrans();
            if($rslt){
                $arr['result'] = true;
                $arr['message'] = "Data has been updated successfully!";
            }else{
                $arr['result'] = false;
                $arr['message'] = "Error in Updating Data!";
            }
        }else{
            $arr['result'] = true;
            $arr['message'] = "No notifications have been selected!";
        }
        $arr['count'] = $this->objUser->intUnreadNotificationCount;
        print json_encode($arr);
    }

    protected function do_SetNotificationsUnRead(){
        $strNotificationsIDs = $this->_data['notifiction_ids'];
        $arrNotificationsIDs = array();
        if(!empty($strNotificationsIDs)){
            $arrNotificationsIDs = explode("|", $strNotificationsIDs);
        }
        $DB = &\ADODB_Connection_Manager::GetConnection('customer');
        $DB->StartTrans();
        if(!empty($arrNotificationsIDs)){
            foreach($arrNotificationsIDs as $intNotificationID){
                $objNotification = new \NsCMN\ClsBllNotification();
                $rslt = $objNotification->LoadByID($intNotificationID);
                $objNotification->SetUnRead();
            }
            $rslt = $DB->CompleteTrans();
            if($rslt){
                $arr['result'] = true;
                $arr['message'] = "Data has been updated successfully!";
            }else{
                $arr['result'] = false;
                $arr['message'] = "Error in Updating Data!";
            }
        }else{
            $arr['result'] = true;
            $arr['message'] = "No notifications have been selected!";
        }
        $arr['count'] = $this->objUser->intUnreadNotificationCount;
        print json_encode($arr);
    }

    protected function do_DeleteNotifications(){
        $strNotificationsIDs = $this->_data['notifiction_ids'];
        $arrNotificationsIDs = explode("|", $strNotificationsIDs);
        if(!empty($arrNotificationsIDs)){
            $rslt = \NsCMN\ClsBllNotification::DeleteNotifications($arrNotificationsIDs);
            if($rslt){
                $arr['result'] = true;
                $arr['message'] = "Notifications have been Deleted successfully!";
            }else{
                $arr['result'] = false;
                $arr['message'] = "Error in Deleting Notifications!";
            }
        }else{
            $arr['result'] = true;
            $arr['message'] = "No notifications have been selected!";
        }
        $arr['count'] = $this->objUser->intUnreadNotificationCount;
        print json_encode($arr);
    }
}