<?php 
namespace NsCMN;

class ClsCtrlServiceLang extends ClsCtrlServiceCmn {

    private function writeConfFiles(){
        $arrLang = ClsBllLang::GetLanguages();

        $objFilter = new \NsFWK\ClsFilter();
        $objMod = new ClsBllModule();
        $arrMod = $objMod->GetData($objFilter);

        foreach ($arrLang as $objLang) {
            $arrLangCommonKeys = $objLang->GetCommonLangKeys();
            foreach($arrMod as $objModule){
                $arrLangModuleKeys = $objLang->GetModuleLangKeys($objModule->intID);
                $arrContent = array_merge($arrLangCommonKeys, $arrLangModuleKeys);
                $strContent = ClsBllLang::GetINIFormat($arrContent);
                
                $strModule = strtolower($objModule->strModule);
                $strLangFilePath = LOCAL__MODULES . "/{$strModule}/view/lang/lang.{$objLang->strLang}.conf";
                $rslt = file_put_contents($strLangFilePath, $strContent);
            }
        }
    }

    private function writeJsFiles(){
        $arrLang = ClsBllLang::GetLanguages();

        $objFilter = new \NsFWK\ClsFilter();
        $objMod = new ClsBllModule();
        $arrMod = $objMod->GetData($objFilter);

        foreach($arrLang as $objLang){
            foreach($arrMod as $objModule){
                $arrLangKeys = $objLang->GetModuleLangKeys($objModule->intID);
                $strContent = ClsBllLang::GetJSONFormat($arrLangKeys);
                
                $strModule = strtolower($objModule->strModule);
                $strContent = 'var objLang = {"' . $strModule . '":' . $strContent . '}';
                
                $strLangFilePath = LOCAL__MODULES . "/{$strModule}/view/lang/lang.{$objLang->strLang}.js";
                $rslt = file_put_contents($strLangFilePath, $strContent);
            }
        }
    }

    protected function do_Reload(){
        $this->writeConfFiles();
        $this->writeJsFiles();
        
        $arr['result'] = true;
        $arr['title'] = $this->cLang('LNG_6592');
        $arr['message'] = $this->cLang('LNG_6593');
        
        print json_encode($arr);
        return $arr['result'];
    }    
}