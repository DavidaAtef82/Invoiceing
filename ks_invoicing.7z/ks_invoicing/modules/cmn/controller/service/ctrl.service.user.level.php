<?php 
namespace NsCMN;

class ClsCtrlServiceUserLevel extends \NsCMN\ClsCtrlServiceCmn {

    protected function do_Default(){}

    protected function do_List(){
        $objFilter = new ClsFilterUserLevel();
        if (isset($this->_payload['objFilter'])) {
            if (!empty($this->_payload['objFilter']['strUserLevel'])){
                $objFilter->strUserLevel = $this->_payload['objFilter']['strUserLevel'];
            }
            if (!empty($this->_payload['objFilter']['intModuleID'])){
                $objFilter->intModuleID = $this->_payload['objFilter']['intModuleID'];
            }
        }
        
        $obj = new ClsBllUserLevel();
        $arrData = $obj->GetDataAssociative($objFilter);

        $arr['result'] = true;
        $arr['title'] = $this->cLang('LNG_6659');
        $arr['message'] = $this->cLang('LNG_6663');
        $arr['object'] = $arrData;
        print json_encode($arr);
        return true;
    }

    protected function do_ValidateUserLevel(){
        $ok = ClsBllUserLevel::ValidateUserLevelString($this->_data['user_level']);
        if ($ok !== true){
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = $this->cLangError($ok);
            print json_encode($arr);
            return false;
        }
        
        $ok = ClsBllUserLevel::IsUserLevelAvailable($this->_data['user_level']);
        if ($ok !== true){
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = $this->cLangError($ok);
            print json_encode($arr);
            return false;
        }

        $arr['result'] = true;
        $arr['title'] = 'Success';
        $arr['message'] = 'User Level available';
        print json_encode($arr);
        return $arr['result'];
    }

    protected function before_AddUserLevel(){
        if (!isset($this->_data['user_level'])) {
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = 'There is no user level name defined';
            print json_encode($arr);
            return false;
        }
        
        $ok = ClsBllUserLevel::ValidateUserLevelString($this->_data['user_level']);
        if ($ok !== true){
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = $this->cLangError($ok);
            print json_encode($arr);
            return false;
        }
        
        $ok = ClsBllUserLevel::IsUserLevelAvailable($this->_data['user_level']);
        if ($ok !== true){
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = $this->cLangError($ok);
            print json_encode($arr);
            return false;
        }

        return true;
    }
    protected function do_AddUserLevel(){
        $strUserLevel = $this->_data['user_level'];
        if (isset($this->_data['src_user_level_id']) && !is_null($this->_data['src_user_level_id'])) {
            $objScrUserLevel = new ClsBllUserLevel();
            $rslt = $objScrUserLevel->LoadByID($this->_data['src_user_level_id']);
            if (!$rslt){
                $arr['result'] = false;
                $arr['title'] = 'Error';
                $arr['message'] = 'Error while creating user level';
                print json_encode($arr);
                return false;
            }
            
            $objNewUserLevel = ClsBllUserLevel::CreateCopy($objScrUserLevel, $strUserLevel);
            if ($objNewUserLevel === false){
                $arr['result'] = false;
                $arr['title'] = 'Error';
                $arr['message'] = 'Error while creating user level';
            }else{
                $arr['result'] = true;
                $arr['title'] = 'Success';
                $arr['message'] = 'User Level Successfully Created';
                $arr['object'] = $objNewUserLevel->ToArray();
            }
        }else{
            $obj = new ClsBllUserLevel();
            $obj->strUserLevel = $strUserLevel;
            $rslt = $obj->Save();
            if ($rslt){
                $arr['result'] = true;
                $arr['title'] = 'Success';
                $arr['message'] = 'User Level Successfully Created';
                $arr['object'] = $obj->ToArray();
            }else{
                $arr['result'] = false;
                $arr['title'] = 'Error';
                $arr['message'] = 'Error while creating user level';
            }
        }

        print json_encode($arr);
        return $arr['result'];
    }
    
    protected function before_EditUserLevel(){
        if (!isset($this->_payload['objUserLevel'])){
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = 'User level is not defined';
            print json_encode($arr);
            return false;
        }

        $ok = ClsBllUserLevel::ValidateUserLevelString($this->_data['user_level']);
        if ($ok !== true){
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = $this->cLangError($ok);
            print json_encode($arr);
            return false;
        }
        
        $ok = ClsBllUserLevel::IsUserLevelAvailable($this->_data['user_level'], $this->_payload['objUserLevel']['intID']);
        if ($ok !== true){
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = $this->cLangError($ok);
            print json_encode($arr);
            return false;
        }

        return true;
    }
    protected function do_EditUserLevel(){
        $arrInputUserLevel = $this->_payload['objUserLevel'];

        $obj = new ClsBllUserLevel();
        $obj->LoadByID($arrInputUserLevel['intID']);
        $obj->strUserLevel = $arrInputUserLevel['strUserLevel'];
        $rslt = $obj->Save();
        if ($rslt){
            $arr['result'] = true;
            $arr['title'] = 'Success';
            $arr['message'] = 'User Level Successfully updated';
            $arr['object'] = $obj->ToArray();
        }else{
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = 'Error while updating user level';
        }

        print json_encode($arr);
        return $arr['result'];
    }
    
    protected function before_DeleteUserLevel(){
        if (!isset($this->_data['user_level_id'])){
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = 'User level is not defined';
            print json_encode($arr);
            return false;
        }

        return true;
    }
    protected function do_DeleteUserLevel(){
        $intUserLevelID = $this->_data['user_level_id'];
        $obj = new \NsCMN\ClsBllUserLevel();
        $rslt = $obj->LoadByID($intUserLevelID);
        if (!$rslt){
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = 'Failed to load user level';            
            print json_encode($arr);            
            return false;
        }
        
        $rslt = $obj->Delete();
        if ($rslt){
            $arr['result'] = true;
            $arr['title'] = 'Success';
            $arr['message'] = 'User level successfully deleted';
        }else{
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = 'Failed to delete user level';            
        }

        print json_encode($arr);
        return $arr['result'];
    }

    protected function before_AddDefaultPage(){
        if (!isset($this->_payload['objDefaultPage'])){
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = 'Default page details are missing.';
            print json_encode($arr);
            return false;
        }

        return true;
    }
    protected function do_AddDefaultPage(){
        $intUserLevelID = $this->_payload['objDefaultPage']['intUserLevelID'];
        $intModuleID = $this->_payload['objDefaultPage']['intModuleID'];
        $intDefaultModule = $this->_payload['objDefaultPage']['intDefaultModule'];
        $strDefaultPage = $this->_payload['objDefaultPage']['strDefaultPage'];
        
        $objUserLevel = new ClsBllUserLevel();
        $ok = $objUserLevel->LoadByID($intUserLevelID);
        if (!$ok) {
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = 'Could not load user level';
            print json_encode($arr);
            return false;
        }

        $ok = $objUserLevel->AddDefaultPage($intModuleID, $strDefaultPage, $intDefaultModule);
        if ($ok){
            $arr['result'] = true;
            $arr['title'] = 'Success';
            $arr['message'] = 'Default page successfully created';
            $arr['object'] = $objUserLevel->ToArray();
        }else{
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = 'Could not create default page';
        }

        print json_encode($arr);
        return $arr['result'];
    }
    
    protected function before_EditDefaultPage(){
        if (!isset($this->_payload['objDefaultPage'])){
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = 'Default page details are missing.';
            print json_encode($arr);
            return false;
        }

        return true;
    }
    protected function do_EditDefaultPage(){
        $intUserLevelID = (int)$this->_payload['objDefaultPage']['intUserLevelID'];
        $intModuleID = (int)$this->_payload['objDefaultPage']['intModuleID'];
        $intDefaultModule = (int)$this->_payload['objDefaultPage']['intDefaultModule'];
        $strDefaultPage = $this->_payload['objDefaultPage']['strDefaultPage'];
        
        $objUserLevel = new ClsBllUserLevel();
        $ok = $objUserLevel->LoadByID($intUserLevelID);
        if (!$ok) {
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = 'Could not load user level';
            print json_encode($arr);
            return false;
        }

        $ok = $objUserLevel->AddDefaultPage($intModuleID, $strDefaultPage, $intDefaultModule);
        if ($ok){
            $arr['result'] = true;
            $arr['title'] = 'Success';
            $arr['message'] = 'Default page successfully updated';
            $arr['object'] = $objUserLevel->ToArray();
        }else{
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = 'Could not update default page';
        }

        print json_encode($arr);
        return $arr['result'];
    }
    
    protected function before_DeleteDefaultPage(){
        if (!isset($this->_data['user_level_id'])) {
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = 'User level is missing';
            print json_encode($arr);
            return false;
        }

        if (!isset($this->_data['module_id'])) {
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = 'Module is missing';
            print json_encode($arr);
            return false;
        }

        return true;
    }
    protected function do_DeleteDefaultPage(){
        $intUserLevelID = $this->_data['user_level_id'];
        $intModuleID = $this->_data['module_id'];
        
        $objUserLevel = new ClsBllUserLevel();
        $ok = $objUserLevel->LoadByID($intUserLevelID);
        if (!$ok) {
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = 'Could not load user level';
            print json_encode($arr);
            return false;
        }

        $ok = $objUserLevel->DeleteDefaultPage($intModuleID);
        if ($ok){
            $arr['result'] = true;
            $arr['title'] = 'Success';
            $arr['message'] = 'Default page successfully deleted';
            $arr['object'] = $objUserLevel->ToArray();
        }else{
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = 'Could not delete default page';
        }

        print json_encode($arr);
        return $arr['result'];
    }
    
}