<?php 
namespace NsCMN;

class ClsCtrlServiceUserLevelPermission extends \NsCMN\ClsCtrlServiceCmn {

    protected function do_Default(){}

    protected function before_ListPermissions(){
        if (!isset($this->_payload['objFilter'])) {
            $arr['result'] = false;
            $arr['title'] = $this->cLang('LNG_6674');
            $arr['message'] = $this->cLang('LNG_6675');            
            print json_encode($arr);            
            return $arr['result'];
        }
        
        return true;
    }
    protected function do_ListPermissions(){
        $arrFilter = $this->_payload['objFilter'];
        
        $objFilter = new ClsFilterUserLevelAction();
        if (isset($arrFilter['intUserLevelID']) && !empty($arrFilter['intUserLevelID'])) {
            $objFilter->intUserLevelID = $arrFilter['intUserLevelID'];
        }
        
        if (isset($arrFilter['intModuleID']) && !empty($arrFilter['intModuleID'])) {
            $objFilter->intModuleID = $arrFilter['intModuleID'];
        }
        
        if (isset($arrFilter['strType']) && !empty($arrFilter['strType'])) {
            $objFilter->strControllerType = $arrFilter['strType'];
        }
        
        if (isset($arrFilter['strClass']) && !empty($arrFilter['strClass'])) {
            $objFilter->strControllerClass = $arrFilter['strClass'];
        }
        
        if (isset($arrFilter['strAction']) && !empty($arrFilter['strAction'])) {
            $objFilter->strAction = $arrFilter['strAction'];
        }
        
        if (isset($arrFilter['strPermission']) && !empty($arrFilter['strPermission'])) {
            $objFilter->strPermission = $arrFilter['strPermission'];
        }
        
        $obj = new \NsCMN\ClsBllUserLevelAction();
        $arrData = $obj->GetDataAssociative($objFilter);
        if ($arrData === false) {
            $arr['result'] = false;
            $arr['title'] = $this->cLang('LNG_6674');
            $arr['message'] = $this->cLang('LNG_6676');
        } else {
            $arr['result'] = true;
            $arr['title'] = $this->cLang('LNG_6660');
            $arr['message'] = $this->cLang('LNG_6664');
            $arr['object'] = $arrData;
        }
        
        print json_encode($arr);
        return $arr['result'];
    }

    protected function before_ListPermissionsNotInUserLevel(){
        if (!isset($this->_data['user_level_id'])) {
            $arr['result'] = false;
            $arr['title'] = $this->cLang('LNG_6661');
            $arr['message'] = $this->cLang('LNG_6665');            
            print json_encode($arr);            
            return $arr['result'];
        }
        
        return true;
    }
    protected function do_ListPermissionsNotInUserLevel(){
        $intUserLevelID = $this->_data['user_level_id'];
        $obj = new \NsCMN\ClsBllModuleAction();
        $arrData = $obj->GetActionsNotInUserLevel($intUserLevelID);
        if ($arrData === false) {
            $arr['result'] = false;
            $arr['title'] = $this->cLang('LNG_6661');
            $arr['message'] = $this->cLang('LNG_6677');
        } else {
            $arr['result'] = true;
            $arr['title'] = $this->cLang('LNG_6662');
            $arr['message'] = $this->cLang('LNG_6666');
            $arr['object'] = $arrData;
        }
        
        print json_encode($arr);
        return $arr['result'];
    }

    protected function before_AddPermission(){
        if (!isset($this->_payload['objUserLevelAction'])) {
            $arr['result'] = false;
            $arr['title'] = $this->cLang('LNG_6669');
            $arr['message'] = $this->cLang('LNG_6672');            
            print json_encode($arr);            
            return $arr['result'];
        }
        
        switch (true) {
            case (!isset($this->_payload['objUserLevelAction']['intUserLevelID'])):
            case (!isset($this->_payload['objUserLevelAction']['intActionID'])):
            case (!isset($this->_payload['objUserLevelAction']['strPermission'])):
                $arr['result'] = false;
                $arr['title'] = $this->cLang('LNG_6669');
                $arr['message'] = $this->cLang('LNG_6673');
                print json_encode($arr);            
                return $arr['result'];
        }
        
        return true;
    }
    protected function do_AddPermission(){
        $intUserLevelID = $this->_payload['objUserLevelAction']['intUserLevelID'];
        $intActionID = $this->_payload['objUserLevelAction']['intActionID'];
        $strPermission = $this->_payload['objUserLevelAction']['strPermission'];

        $obj = new \NsCMN\ClsBllUserLevelAction();
        $obj->intActionID = $intActionID;
        $obj->intUserLevelID = $intUserLevelID;
        $obj->strPermission = $strPermission;
        $rslt = $obj->Save();
        if ($rslt){
            $obj->LoadByID($intUserLevelID,$intActionID);
            $arr['result'] = true;
            $arr['title'] = $this->cLang('LNG_6667');
            $arr['message'] = $this->cLang('LNG_6668');
            $arr['object'] = $obj->ToArray();
        }else{
            $arr['result'] = false;
            $arr['title'] = $this->cLang('LNG_6669');
            $arr['message'] = $this->cLang('LNG_6670');            
        }
        
        print json_encode($arr);
        return $arr['result'];
    }

    protected function before_EditPermission(){
        if (!isset($this->_payload['objUserLevelAction'])) {
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = 'Permission object is missing';            
            print json_encode($arr);            
            return $arr['result'];
        }
        
        switch (true) {
            case (!isset($this->_payload['objUserLevelAction']['intUserLevelID'])):
            case (!isset($this->_payload['objUserLevelAction']['intActionID'])):
            case (!isset($this->_payload['objUserLevelAction']['strPermission'])):
                $arr['result'] = false;
                $arr['title'] = 'Error';
                $arr['message'] = 'Invalid permission object';
                print json_encode($arr);            
                return $arr['result'];
        }
        
        return true;
    }
    protected function do_EditPermission(){
        $intUserLevelID = $this->_payload['objUserLevelAction']['intUserLevelID'];
        $intActionID = $this->_payload['objUserLevelAction']['intActionID'];
        $strPermission = $this->_payload['objUserLevelAction']['strPermission'];

        $obj = new \NsCMN\ClsBllUserLevelAction();
        $ok = $obj->LoadByID($intUserLevelID, $intActionID);
        if (!$ok){
            $arr['result'] = false;
            $arr['title'] = 'Fail';
            $arr['message'] = 'Failed to load permission';            
            print json_encode($arr);            
            return $arr['result'];
        }

        $obj->strPermission = $strPermission;
        $ok = $obj->Save();
        if ($ok){
            $obj->LoadByID($intUserLevelID, $intActionID);
            $arr['result'] = true;
            $arr['title'] = 'Success';
            $arr['message'] = 'Permission successfully updated';
            $arr['object'] = $obj->ToArray();
        }else{
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = 'Failed to update permission';            
        }
        
        print json_encode($arr);
        return $arr['result'];
    }

    protected function do_DeleteAction(){
        $intUserLevelID = $this->_data['user_level_id'];
        $intActionID = $this->_data['action_id'];

        $obj = new \NsCMN\ClsBllUserLevelAction();
        $ok = $obj->LoadByID($intUserLevelID,$intActionID);
        if (!$ok){
            $arr['result'] = false;
            $arr['title'] = 'Fail';
            $arr['message'] = 'Failed to load permission';            
            print json_encode($arr);            
            return $arr['result'];
        }

        $ok = $obj->Delete();
        if ($ok){
            $arr['result'] = true;
            $arr['title'] = 'Success';
            $arr['message'] = 'Permission successfully deleted';
        }else{
            $arr['result'] = false;
            $arr['title'] = 'Fail';
            $arr['message'] = 'Failed to delete permission';            
        }

        print json_encode($arr);            
        return $arr['result'];
    }
}