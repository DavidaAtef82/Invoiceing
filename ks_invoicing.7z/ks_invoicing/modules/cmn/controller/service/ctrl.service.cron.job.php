<?php
namespace NsCMN;

class ClsCtrlServiceCronJob extends \NsCMN\ClsCtrlServiceCmn {

    protected function do_Default(){}

    protected function do_List(){
        $objFilter = new \NsFWK\ClsFilter();            
        $obj = new ClsBllCronJob();
        $objFilter->intModuleID = "";
        $arrData = $obj->GetEnabledCronAssoc(true);
        $arr['result'] = true;
        $arr['title'] = 'Success';
        $arr['message'] = 'Jobs successfully listed';
        $arr['object'] = $arrData;
        print json_encode($arr);
    }
    
    protected function do_Add(){
        $obj = new ClsBllCronJob();
        $arrCronJob = $this->_payload['objAddCronJob'];
        
        $obj->strCron = $arrCronJob['strCron'];
        $obj->intModuleID = $arrCronJob['intModuleID'];
        $obj->strDescription = $arrCronJob['strDescription'];
        $obj->intYear = $arrCronJob['intYear'];
        $obj->intMonth = $arrCronJob['intMonth'];
        $obj->intDay = $arrCronJob['intDay'];
        $obj->intHour = $arrCronJob['intHour'];
        $rslt = $obj->Save();
        if(!$rslt){
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = 'Failed to save Cron Job';
            print json_encode($arr); 
            return;   
        }
        $arr['result'] = true;
        $arr['title'] = 'Success';
        $arr['message'] = 'Cron jobs successfully listed';
        $obj->objModule;
        $arr['object'] = $obj->ToArray();
        print json_encode($arr);
    }

    protected function do_Update(){
        $arrCronJob = $this->_payload['objCronJob'];
        
        $obj = new ClsBllCronJob();
        $rslt = $obj->LoadByID($arrCronJob['intID']);
        if(!$rslt){
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = 'Failed to load object';
            print json_encode($arr); 
            return;    
        }
        $obj->strCron = $arrCronJob['strCron'];
        $obj->intModuleID = $arrCronJob['intModuleID'];
        $obj->strDescription = $arrCronJob['strDescription'];
        $obj->intYear = $arrCronJob['intYear'];
        $obj->intMonth = $arrCronJob['intMonth'];
        $obj->intDay = $arrCronJob['intDay'];
        $obj->intHour = $arrCronJob['intHour'];
        $rslt = $obj->Save();
        if(!$rslt){
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = 'Failed to Update Cron Job';
            print json_encode($arr); 
            return;   
        }
        $arr['result'] = true;
        $arr['title'] = 'Success';
        $arr['message'] = 'Cron Job updated successfully';
        $obj->objModule;
        $arr['object'] = $obj->ToArray();
        print json_encode($arr);
    }

    protected function do_Run(){
        $arrParams = $this->_payload['parameters'];
        $intID = $this->_data['cron_id'];
        $obj = new ClsBllCronJob();
        $rslt = $obj->LoadByID($intID);
        if (!$rslt){
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = 'Cron job does not exist';
            print json_encode($arr);
            return;
        }
        
        \NsFWK\ClsHlpHelper::CallCron($obj->objModule['strModule'], $obj->strCron, $arrParams);
        $arr['result'] = true;
        $arr['title'] = 'Success';
        $arr['message'] = 'Cron job has been successfully triggered';

        print json_encode($arr);
    }
    
    protected function do_Disable(){
        $intID = $this->_data['cron_id'];
        $obj = new ClsBllCronJob();
        $rslt = $obj->LoadByID($intID);
        if (!$rslt){
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = 'Cron job does not exist';
            print json_encode($arr);
            return;
        }
        
        $obj->intDisabled = $this->_data['disable'];
        $rslt = $obj->Save();
        
        if(!$rslt){
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = 'Can not update cron job';
            print json_encode($arr);
            return;    
        }

        $arr['result'] = true;
        $arr['title'] = 'Success';
        $arr['message'] = 'Cron job updated successufuly';
        $obj->objModule;
        $arr['object'] = $obj->ToArray();
        print json_encode($arr);


    }
}