<?php
namespace NsCMN;

class ClsCtrlServiceCountry extends \NsCMN\ClsCtrlServiceCmn {

    protected function do_Default(){}
    
    private function validate($field, $value){
        $objFilter = new \NsFWK\ClsFilter();
        if($field == "name"){
            $objFilter->fldCountry = "fldCountry = '$value'";
            $objCountry = new \NsCMN\ClsBllCountry();
            $arrCountry = $objCountry->GetData($objFilter,'');
            if(empty($arrCountry)){
                return true;
            }
            return false;
        }
        else{
            $objFilter->intID = "pkCountryID = '$value'";
            $objCountry = new \NsCMN\ClsBllCountry();
            $arrCountry = $objCountry->GetData($objFilter,'');
            if(!empty($arrCountry)){
                return true;
            }
            return false;
        }


    }
    
    protected function do_List(){
        $obj = new \NsCMN\ClsBllCountry();
        $arrData = $obj->GetCountries();
        $arr['result'] = true;
        $arr['title'] = 'Success';
        $arr['message'] = 'Countries successfully listed';
        $arr['object'] = $arrData;
        print json_encode($arr);
    }
    
    protected function before_Add(){
        if(!isset($this->_data['country'])){
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = 'Country not specified';
            print json_encode($arr);
            return false;
        }
        return true;
    }
    protected function do_Add(){

        $strName = $this->_data['country'];
        if(!$this->validate("name", $strName)){
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = 'Country name already taken';
            print json_encode($arr);
            return;
        }
        $objCountry = new \NsCMN\ClsBllCountry();   
        $objCountry->strCountry = $strName;
        $rslt = $objCountry->Save();
        if ($rslt){
            $arr['result'] = true;
            $arr['title'] = 'Success';
            $arr['message'] = 'New country has been successfully added';
            $arr['object'] = $objCountry->ToArray();
        }else{
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = 'Error while adding a new country';
        }
        print json_encode($arr);
    }
    
    protected function before_Update(){
        if(!isset($this->_data['country']) || !isset ($this->_data['country_id'])){
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = 'Please specify country id and new country name!';
            print json_encode($arr);
            return false;
        }
        if(!$this->validate("name", $this->_data['country'])){
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = 'Country name already taken!';
            print json_encode($arr);
            return false;
        }
        if(!$this->validate("id", $this->_data['country_id'])){
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = 'Country id is not valid!';
            print json_encode($arr);
            return false;
        }
        return true;
    }
    protected function do_Update(){
        $intCountryID = $this->_data['country_id'];
        $strName = $this->_data['country'];
        $objCountry = new \NsCMN\ClsBllCountry();
        $objCountry->strCountry = $strName;
        $objCountry->intID = $intCountryID;
        $rslt = $objCountry->UpdateCountry($intCountryID, $strName);
        if ($rslt){
            $arr['result'] = true;
            $arr['title'] = 'Success';
            $arr['message'] = "Country with id '$intCountryID' is successfully updated!";
            $arr['object'] = $objCountry->ToArray();
        }else{
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = 'Error while updating country';
        }
        print json_encode($arr);      
    }

    protected function before_Delete(){
        if(!isset($this->_data['country_id']) or !is_numeric($this->_data['country_id'])){
            $arr['result'] = false;
            $arr['message'] = "No Country Specified";
            print json_encode($arr);
            return false;
        }
        return true;
    }
    protected function do_Delete(){
        $intCountryID = $this->_data['country_id'];

        $objCountry = new \NsCMN\ClsBllCountry();
        $rslt = $objCountry->LoadByID($intCountryID);
        if (!$rslt){
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = "No Country found with ID #$intCountryID";
            print json_encode($arr);
            return false;
        }
        $rslt = $objCountry->Delete();
        if($rslt){
            $arr['result'] = true;
            $arr['title'] = 'Success';
            $arr['message'] = 'Country deleted Successfully';
        }else{
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = "Country couldn't be deleted as there is another data related to it";
        }
        print json_encode($arr);
    }

}