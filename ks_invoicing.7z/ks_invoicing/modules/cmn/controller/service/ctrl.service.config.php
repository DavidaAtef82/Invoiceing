<?php 
namespace NsCMN;

class ClsCtrlServiceConfig extends \NsCMN\ClsCtrlServiceCmn {

    protected function do_Default(){}

    protected function do_Load(){
        $strConfigKey = $this->_data['config_key'];
        $objConfig = new \NsCMN\ClsBllConfig();
        $ok = $objConfig->LoadByID($strConfigKey);
        if(!$ok){
            $arr['result'] = false;    
        }else{
            $arr['result'] = true;
            $arr['object'] = $objConfig->ToArray();
        }
        print json_encode($arr);
    }

    protected function do_List(){
        $objFilter = new \NsFWK\ClsFilter();
        $objFilter->IsEdit = "fldIsEdit = 1";

        $objConfig = new \NsCMN\ClsBllConfig();
        $arrConfigs = $objConfig->GetConfigsBySection($objFilter);

        $arr['result'] = true;
        $arr['object'] = $arrConfigs;
        print json_encode($arr);
    }

    protected function do_ListModule(){
        $arrModules = ClsBllConfig::GetAssignedModules();

        $arr['result'] = true;
        $arr['object'] = $arrModules;
        print json_encode($arr);
    }
    
    protected function do_ListSectionsByModule(){
        $arrModuleSections = ClsBllConfig::GetSectionsByModule();

        $arr['result'] = true;
        $arr['object'] = $arrModuleSections;
        print json_encode($arr);
    }

    /**
    * Get configuration from Session
    * 
    */
    protected function do_GetConfigurations(){
        $arrConfig = $this->_config; 
        $arr['result'] = true;
        $arr['title'] = 'Success';
        $arr['message'] = 'Configurations successfully loaded';
        $arr['object'] = $arrConfig;
        print json_encode($arr);
    }

    protected function do_Update(){
        $arrItem = $this->_payload['objItem'];
        $strValue = $arrItem['strConfigValue'];
        $strConfigKey = $arrItem['strConfigKey'];
        $objConfig =  new \NsCMN\ClsBllConfig();
        $rslt = $objConfig->LoadByID($strConfigKey);
        if(!$rslt){
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = "Couldn't load config with key $strConfigKey";
            print json_encode($arr);
            return;
        }
        $objConfig->strConfigValue = $strValue;
        $rslt = $objConfig->Save();                                    
        if ($rslt){                                     
            $this->do_Default();
            $arr['result'] = true;
            $arr['title'] = 'Success';
            $arr['message'] = "Data has been updated successfully";
        }else{
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = 'Error in editing config';
        }
        print json_encode($arr);
    }
}