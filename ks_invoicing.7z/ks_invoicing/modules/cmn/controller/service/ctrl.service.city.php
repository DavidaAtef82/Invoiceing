<?php
namespace NsCMN;

class ClsCtrlServiceCity extends \NsCMN\ClsCtrlServiceCmn {

    protected function do_Default(){}
    private function validate($operation){

        $strCityName = $this->_data['city'];
        $objFilter = new \NsFWK\ClsFilter();
        $objFilter2 = new \NsFWK\ClsFilter();
        if($operation == "update"){
            $intCityID = $this->_data['city_id'];
            $intCountryID = $this->_data['country_id'];

            $objFilter->intID = "pkCityID = '$intCityID'";
            $objFilter->intCountryID =" fkCountryID = '$intCountryID'";
            $objCity = new \NsCMN\ClsBllCity();
            $arrCity = $objCity->GetData($objFilter,'');
            if(empty($arrCity)){
                return false;
            }
        }
        $intCountryID = $this->_data['country_id'];
        $objFilter2->strCity = "fldCity = '$strCityName'";
        $objFilter2->intCountryID =" fkCountryID = '$intCountryID'";
        $objCity = new \NsCMN\ClsBllCity();
        $arrCity = $objCity->GetData($objFilter2,'');
        if(empty($arrCity)){
            return true;
        }
        return false;
    }
    
    protected function do_List(){
        $obj = new \NsCMN\ClsBllCity();
        $arrData = $obj->GetAllCities();
        $arr['result'] = true;
        $arr['title'] = 'Success';
        $arr['message'] = 'Cities successfully listed';
        $arr['object'] = $arrData;
        print json_encode($arr);
    }
    protected function do_ListByCountryID(){
        $arrData = [];
        if(isset($this->_data['country_id'])){
            $intCountryID = $this->_data['country_id'];
            $objCountry = new \NsCMN\ClsBllCountry();
            $rslt = $objCountry->LoadByID($intCountryID);
            if(!$rslt){
                $arr['result'] = false;
                $arr['title'] = 'Error';
                $arr['message'] = "Error in loading cities for city id #$intCountryID";
                print json_encode($arr);
                return;
            }
            $arrData = $objCountry->arrCities;
        }else{
            $obj = new \NsCMN\ClsBllCity();
            $arrData = $obj->GetAllCities();
        }
        $arr['result'] = true;
        $arr['title'] = 'Success';
        $arr['message'] = 'Cities successfully listed!';
        $arr['object'] = $arrData;
        print json_encode($arr);
    }
    
    protected function before_Add(){
        if(!isset($this->_data['city']) || !isset ($this->_data['country_id'])){
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = 'Please specify city name and country id!';
            print json_encode($arr);
            return false;
        }
        if(!$this->validate("add", $this->_data['city'])){
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = 'City name already taken!';
            print json_encode($arr);
            return false;
        }
        return true;
    }
    protected function do_Add(){
        $strCity = $this->_data['city'];
        $intCountryID = $this->_data['country_id'];
        $objCity = new \NsCMN\ClsBllCity();   
        $objCity->strCity = $strCity;
        $objCity->intCountryID = $intCountryID;
        $rslt = $objCity->Save();
        if ($rslt){
            $arr['result'] = true;
            $arr['title'] = 'Success';
            $arr['message'] = 'New city has been successfully added!';
            $arr['object'] = $objCity->ToArray();
        }else{
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = 'Error while adding a new city!';
        }
        print json_encode($arr);
    }

    protected function before_Delete(){
        if(!isset($this->_data['city_id']) or !is_numeric($this->_data['city_id'])){
            $arr['result'] = false;
            $arr['message'] = "No City Specified";
            print json_encode($arr);
            return false;
        }
        return true;
    }
    protected function do_Delete(){
        $intCityID = $this->_data['city_id'];

        $objCity = new \NsCMN\ClsBllCity();
        $rslt = $objCity->LoadByID($intCityID);
        if (!$rslt){
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = "No City found with ID #$intCityID";
            print json_encode($arr);
            return false;
        }

        $rslt = $objCity->Delete();
        if($rslt){
            $arr['result'] = true;
            $arr['title'] = 'Success';
            $arr['message'] = 'City deleted Successfully';
        }else{
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = "City couldn't be deleted as there is another data related to it";
        }
        print json_encode($arr);
    }
    
    protected function before_Update(){
        if(!isset($this->_data['city']) || !isset ($this->_data['city_id']) || !isset ($this->_data['country_id'])){
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = 'Please specify city id and new city name and country id!';
            print json_encode($arr);
            return false;
        }
        if(!$this->validate("update")){
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = 'Can not update this country!';
            print json_encode($arr);
            return false;
        }
        return true;
    }
    protected function do_Update(){
        $intCityID = $this->_data['city_id'];
        $strName = $this->_data['city'];
        $objCity = new \NsCMN\ClsBllCity();   
        $rslt = $objCity->UpdateCity($intCityID, $strName);
        if ($rslt){
            $arr['result'] = true;
            $arr['title'] = 'Success';
            $arr['message'] = "City with id '$intCityID' is successfully updated!";
        }else{
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = 'Error while updating city';
        }
        print json_encode($arr);      
    }
}