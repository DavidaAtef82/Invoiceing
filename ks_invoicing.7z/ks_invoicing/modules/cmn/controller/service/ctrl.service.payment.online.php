<?php
namespace NsCMN;

class ClsCtrlServicePaymentOnline extends \NsFWK\ClsCtrlServicePublic {

    protected function do_Default(){}

    protected function do_Notify(){
        $requestPhrase = PAYFORT__SHA__REQUEST__PHRASE;
        $responsePhrase = PAYFORT__SHA__RESPONSE__PHRASE;
        $merchantIdentifier = PAYFORT__MERCHANT__IDENTIFIER;
        $access_code = PAYFORT__ACCESS__CODE;

        //$strReference = 'InvoiceNo_17';
        $strReference = $this->_data['reference'];
        $strAmount = $this->_data['amount']; //450
        $strCurrency = 'EGP';
        $strCustomerEmail = $this->_data['email'];
        $strReturnUrl = '';
        $strLanguage = 'en';
        $strCommand = 'PURCHASE';

            
        $arrData['command'] = $strCommand;
        $arrData['merchant_reference'] = $strReference;//$_GET['reference']; //'Test110'
        $arrData['amount'] = $strAmount*100;//$_GET['amount'];//300
        $arrData['access_code'] = $access_code;
        $arrData['merchant_identifier'] = $merchantIdentifier;
        $arrData['currency'] = $strCurrency; //'EGP';
        $arrData['language'] = $strLanguage;
        $arrData['customer_email'] = $strCustomerEmail;
        $arrData['return_url'] = $strReturnUrl; //$_GET['return_url']; //$_GET['customer_email']

        ksort($arrData,SORT_ASC);

        $data = "";
        foreach($arrData as $key=>$value){
            $data.="$key=$value";
        }
        $signature = $requestPhrase.$data.$requestPhrase;
        $signature = hash('sha256',$signature);

        $objPayment = new \stdClass();
        $objPayment->strSignature = $signature;
        $objPayment->strAccessCode =  $arrData['access_code'];
        $objPayment->decAmount = $arrData['amount'];
        $objPayment->strCommand = $arrData['command'];
        $objPayment->strCurrency = $arrData['currency'];
        $objPayment->strCustomerEmail = $arrData['customer_email'];
        $objPayment->strLanguage = $arrData['language'];
        $objPayment->strMerchantIdentifier = $arrData['merchant_identifier'];
        $objPayment->strMerchantReference = $arrData['merchant_reference'];
        $objPayment->strReturnUrl = $arrData['return_url'];
        $objPayment->decAmountDisplay = $objPayment->decAmount/100;

        $obj = new \NsCMN\ClsBllMail();
        $obj->LoadByTemplate('payfort',array('Payment'=>$objPayment));
        $arr['object']['email'] = $obj->PrintEmailProva();
        $rslt = $obj->Send($objPayment->strCustomerEmail);
        if (!$rslt){
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = 'Could not send an email to the customer';
        }else{
            $arr['result'] = true;
            $arr['title'] = 'Success';
            $arr['message'] = 'Email successfully sent to the customer';            
        }

        print json_encode($arr);
    }

    protected function before_ResetPassword(){
        if(!isset($this->_payload['username']) or trim($this->_payload['username'])==''){
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = "invalid user name!";
            print json_encode($arr);
            return false;                   
        }
        return true;
    }
    protected function do_ResetPassword(){
        $strUserName = $this->_payload['username'];
        $objUser =  new ClsBllUser();
        $rslt = $objUser->LoadByUserName($strUserName);
        if($rslt){
            if($objUser->intDisabled == 1){
                // User account is disabled
                $arr['result'] = false;
                $arr['title'] = "Error";
                $arr['message'] = "The provided email is of an inactive user account!, Kindly contact your system admin.";
                print json_encode($arr);
                return false;                   
            }

            $strPassword = $objUser->ResetPassword();
            if($strPassword !== false){
                $arrData['User'] = $objUser;
                $arrData['Password'] = $strPassword;
                $objEmail = new \NsCMN\ClsBllMail();
                $objEmail->LoadByTemplate('reset_password',$arrData);
                $ok = $objEmail->Send($objUser->strEmail);

                $arr['result'] = true;
                $arr['title'] = "Success";
                $arr['message'] = "Your password has been reset and sent to your email!, Kindly check your inbox!";
                print json_encode($arr);
                return true;                   
            }else{
                // Failed to reset password!
                $arr['result'] = false;
                $arr['title'] = "Error";
                $arr['message'] = "Password reset failed!, Kindly contact your system admin.";
                print json_encode($arr);
                return false;                   
            }
        }else{
            // Email account not found or could not be loaded
            $arr['result'] = false;
            $arr['title'] = "Error";
            $arr['message'] = "The provided user name is not found in the system.";
            print json_encode($arr);
            return false;                   
        }
    }
}