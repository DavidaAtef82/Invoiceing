<?php 
namespace NsCMN;

class ClsCtrlServiceUser extends \NsCMN\ClsCtrlServiceCmn {

    protected function do_Default(){}

    protected function do_List(){
        $arrPage = $this->_payload['objPage'];
        $arrFilter = $this->_payload['objFilter'];

        $intPageNo = 1;
        if (isset($arrPage['intPageNo'])){
            $intPageNo = $arrPage['intPageNo'];
        }

        $intPageSize = $this->_config['ListingPageSize'];
        if (isset($arrPage['intPageSize'])){
            $intPageSize = $arrPage['intPageSize'];
        }

        $objFilter = new \NsCMN\ClsFilterUser();
        if(isset($arrFilter['strUserName']) && $arrFilter['strUserName'] != ''){
            $objFilter->strUserName = $arrFilter['strUserName'];
        }
        if(isset($arrFilter['strDisplayName']) && $arrFilter['strDisplayName'] != ''){
            $objFilter->strDisplayName = $arrFilter['strDisplayName'];
        }
        if(isset($arrFilter['strEmail']) && $arrFilter['strEmail'] != ''){
            $objFilter->strEmail = $arrFilter['strEmail'];
        }
        if(isset($arrFilter['intUserLevelID']) && $arrFilter['intUserLevelID'] != ''){
            $objFilter->intUserLevelID = $arrFilter['intUserLevelID'];
        }
        if(isset($arrFilter['intTeamID']) && $arrFilter['intTeamID'] != ''){
            $objFilter->intTeamID = $arrFilter['intTeamID'];
        }
        
        $objUser = new ClsBllUser();
        $arrPage = $objUser->GetDataPageAssociative($intPageNo, $intPageSize,$objFilter->GetWhereStatement(), '', $intPageCount, $intRowCount);
        $arrData = array('arrData'=>$arrPage, 'intTotal'=>$intRowCount);

        $arr['result'] = true;
        $arr['title'] = 'Success';
        $arr['message'] = 'Users filtered successfully';
        $arr['object'] = $arrData;
        print json_encode($arr);
        return true;
    }
    
    protected function do_ListAll(){
        $objFilter = new ClsFilterUser();
        if(isset($this->_data['disabled'])){
            $objFilter->intDisabled = $this->_data['disabled'];
        }
        $objUser = new ClsBllUser();
        $arrData = $objUser->GetDataAssociative($objFilter);

        $arr['result'] = true;
        $arr['title'] = 'Success';
        $arr['message'] = 'Users filtered successfully';
        $arr['object'] = $arrData;
        print json_encode($arr);
        return true;
    }
    
    protected function do_ListUsersNames(){
       $arrUsersname = ClsBllUser::GetUsersNames();
       if ($arrUsersname == false) {
           $arr['result'] = false;
           $arr['title'] = 'Error';
           $arr['message'] = 'Could not list usernames';
       } else {
           $arr['result'] = true;
           $arr['title'] = 'Success';
           $arr['message'] = 'Usernames successfully listed';
           $arr['object'] = $arrUsersname;
       }
       
       print json_encode($arr);
       return $arr['result'];
    }

    protected function do_Load(){
        $intUserID = $this->objUser->intID;
        if (isset($this->_data['user_id'])) {
            $intUserID = $this->_data['user_id'];
        }
        
        $objUser = new ClsBllUser();
        $rslt = $objUser->LoadByID($intUserID);
        if(!$rslt){
            $arr['title'] = "Error";
            $arr['result'] = false;
            $arr['message'] = 'User not found';
            print json_encode($arr);
            return;
        }
        
        $arrUserLevel = $objUser->arrUserLevels;

        // consruct module user level array
        $arrModuleUserLevels = array();
        $arrModules = array();
        foreach($arrUserLevel as $userlevel){
            /*if(!key_exists($userlevel->intModuleID, $arrModuleUserLevels)){
                $arrModules[] = $userlevel->objModule->ToArray();
            }*/                                           

            $arrModuleUserLevels[$userlevel->intModuleID][] = $userlevel->ToArray();
        }

        // only modules and userlevels this user included in
        //$objUser->arrModules = $arrModules; 
        // Used in account.tpl, user.list.tpl
        $objUser->arrModules = $objUser->GetModules(true); 
        $objUser->arrModuleUserLevels = $arrModuleUserLevels;

        // Load objEmployee if employee id exist
        if($objUser->objEmployee != null){
            $objUser->intEmployeeID = $objUser->objEmployee->intID;    
            $objUser->objEmployee->ToArray();    
        }

        // Load objTeam if team id exist
        $objSalesPerson = new \NsSF\ClsBllUser();
        $rslt = $objSalesPerson->LoadByID($objUser->intID);
        if($rslt && $objSalesPerson->intTeamID != -1){
            // sales person user exist
            $objUser->intTeamID = $objSalesPerson->objTeam->intID;    
            $objUser->objTeam = $objSalesPerson->objTeam->ToArray();    
        }

        $objUser->arrUserLevelIDs;
        
        $arr['result'] = true;
        $arr['title'] = 'Success';
        $arr['message'] = 'User loaded successfully';
        $arr['object'] = $objUser->ToArray();
        print json_encode($arr);
    }
    
    protected function do_GetNotAssignedEmployees(){
        $intUserID = $this->_data['user_id'];
        $objUser = new ClsBllUser();
        $objUser->LoadByID($intUserID);

        $objEmployee = new \NsHR\ClsBllEmployee();
        $arrEmployees = $objEmployee->GetEmployeesWithNoUserAccount();

        $arrJsonEmployees = array();                                                             
        $arrJsonEmployees[-1] = 'No Employee';    
        if(!is_null($objUser->objEmployee)){
            //updated to include the currently assigned employee
            //array_unshift($arrEmployees, $objUser->objEmployee);
            $arrJsonEmployees[$objUser->objEmployee->intID] = $objUser->objEmployee->strName;    
        }
        if(!empty($arrEmployees)){
            foreach($arrEmployees as $employee){
                $arrJsonEmployees[$employee->intID] = $employee->strName;    
            }
        }    
        print json_encode($arrJsonEmployees);
    }

    protected function do_Update(){
        $arrUser = $this->_payload['objUser'];
        $arrModules = $this->_payload['objModule'];

        $objUser =  new ClsBllUser();
        $rslt = $objUser->LoadByID($arrUser['intID']);
        if(!$rslt){
            $arr['result'] = false;
            $arr['message'] = 'User not found';
            print json_encode($arr);
            return;
        }
        $objUser->strUserName = $arrUser['strUserName'];
        $objUser->strDisplayName = $arrUser['strDisplayName'];
        $objUser->strEmail = $arrUser['strEmail'];
        $rslt = $objUser->Save();
        if($rslt){
            $strMsg = 'User has been updated successfully';
            // saving file
            if(isset($arrUser['objFile']) && !empty($arrUser['objFile'])){
                $strContent = $arrUser['objFile']['content'];
                $strType = $this->_data['type'];
                $strSize = $this->_data['size'];
                $filename = "{$objUser->intID}.User.Photo";
                $rslt = $objUser->UploadImage('','',$strContent,MODULE_ID,$filename,$strType,$strSize,$this->objUser->intID);
                if(!$rslt){
                    $strMsg .= "\n Image not uploaded";        
                }
            }
            
            // manage user levels 
            $intEmployeeID = -1;
            if(isset($arrUser['intEmployeeID']) && $arrUser['intEmployeeID'] != ''){
                $intEmployeeID = $arrUser['intEmployeeID'];
            }
            $intTeamID = -1;
            if(isset($arrUser['intTeamID']) && $arrUser['intTeamID'] != ''){
                $intTeamID = $arrUser['intTeamID'];
            }

            $arrUserLevelIDs = array();
            foreach($arrModules as $module){
                if(isset($module['arrUserLevels']) && !empty($module['arrUserLevels'])){
                    foreach($module['arrUserLevels'] as $userlevel){
                        if(isset($userlevel['intChecked']) && $userlevel['intChecked'] == 1){
                            $arrUserLevelIDs[] = $userlevel['intID']; 
                        }    
                    }
                }
            }
            
            if((in_array(\NsCMN\ClsBllUserLevel::USER_LEVEL_EMPLOYEE,$arrUserLevelIDs) || in_array(\NsCMN\ClsBllUserLevel::USER_LEVEL_HEAD,$arrUserLevelIDs)) && $intEmployeeID == -1){
                $arr['result'] = false;
                $arr['title'] = 'Error';
                $arr['message'] = 'You have to select employee as long as you selected employee/head user levels';    
                print json_encode($arr);
                return;
            }
            
            if(in_array(\NsCMN\ClsBllUserLevel::USER_LEVEL_SALES_PERSON,$arrUserLevelIDs) && $intTeamID == -1){
                $arr['result'] = false;
                $arr['title'] = 'Error';
                $arr['message'] = 'You have to select team as long as you selected sales person user level';    
                print json_encode($arr);
                return;
            }
            
            $rslt = $objUser->UpdateUserLevels($arrUserLevelIDs, $intEmployeeID, $intTeamID);
            if(!$rslt){
                $strMsg .= "\n Image not uploaded"; 
            }                                                                                                      
            $arr['title'] = 'Success';
            $arr['result'] = true;
            $arr['message'] = $strMsg;
            $arr['object'] = $objUser->ToArray();
        }else{
            $arr['title'] = 'Error';
            $arr['result'] = false;
            $arr['message'] = 'Error in updating user';
        }
        print json_encode($arr);
    }
    
    protected function before_Add(){
        if (!isset($this->_payload['objUser'])) {
            $arr['result'] = false;
            $arr['title'] = $this->cLang('LNG_6616');
            $arr['message'] = $this->cLang('LNG_6613');
            print json_encode($arr);
            return false;                   
        } else {
            $arrUser = $this->_payload['objUser'];
            if (!isset($arrUser['strUsername'])) {
                $arr['result'] = false;
                $arr['title'] = $this->cLang('LNG_6616');
                $arr['message'] = $this->cLang('LNG_6614');
                print json_encode($arr);
                return false;                   
            }
        }

        return true;
    }
    protected function do_Add(){
        $arrUser = $this->_payload['objUser'];
        $arrUserLevelIDs = $this->_payload['arrUserLevelIDs'];
        
        $objUser = ClsBllUser::Create($arrUser['strUsername'],
                                      $arrUser['strDisplayName'],
                                      $arrUser['strPassword'],
                                      $arrUser['strEmail'],
                                      $arrUserLevelIDs,
                                      $arrUser['intEmployeeID'],
                                      $arrUser['intTeamID']);
        if (!is_object($objUser)) {
            // User is not created -> Error code returned
            $arr['result'] = false;
            $arr['title'] = $this->cLang('LNG_6616');
            $arr['message'] = $this->cLangError($objUser);
        } else {
            // User account successfully created
            if (isset($arrUser['intSendWelcomeEmail']) && $arrUser['intSendWelcomeEmail'] == 1) {
                // Send welcome email once user account created
                $objUser->strPasswordBeforeHashing = $arrUser['strPassword'];
                $arrData['User'] = $objUser;
                $arrData['URL'] = WEB__ROOT__PATH;

                $objEmail = new \NsCMN\ClsBllMail();
                $objEmail->LoadByTemplate('new_user', $arrData);
                $rsltSendMail = $objEmail->Send($objUser->strEmail);
            }

            $arr['result'] = true;
            $arr['title'] = $this->cLang('LNG_6617');
            $arr['message'] = $this->cLang('LNG_6623');
            $arr['object'] = $objUser->ToJson();
        }

        print json_encode($arr);
        return $arr['result'];
    }

    protected function before_Delete(){
        if (!isset($this->_data['user_id']) or !is_numeric($this->_data['user_id'])){
            $arr['result'] = false;
            $arr['message'] = 'No user id specified.';
            print json_encode($arr);
            return false;                  
        }
        return true;
    }
    protected function do_Delete(){
        $objUser =  new ClsBllUser();
        $rslt = $objUser->LoadByID($this->_data['user_id']);
        if($rslt){         
            $rslt = $objUser->Delete();
            if($rslt == 1){
                $arr['result'] = 1;
                $arr['title'] = "Success";
                $arr['message'] = 'User deleted successfully.';
            }else if($rslt == 2){
                $arr['result'] = 2;
                $arr['title'] = "Success";
                $arr['message'] = "User is used so it's disabled";
            }else {
                $arr['result'] = false;
                $arr['title'] = "Error";
                $arr['message'] = "User coulnd't be deleted";
            }
            print json_encode($arr);
        }
    }

    protected function before_Enable(){
        if (!isset($this->_data['user_id']) or !is_numeric($this->_data['user_id'])){
            $arr['result'] = false;
            $arr['message'] = 'No user id specified.';
            print json_encode($arr);
            return false;                  
        }
        return true;
    }
    protected function do_Enable(){
        $objUser =  new \NsCMN\ClsBllUser();
        $rslt = $objUser->LoadByID($this->_data['user_id']);
        if($rslt){
            $rslt = $objUser->Enable();
            if ($rslt){
                $arr['result'] = true;
                $arr['title'] = "Success";
                $arr['message'] = "User is enabled successfully";
            }else{
                $arr['result'] = false;
                $arr['title'] = "Error";
                $arr['message'] = "Error in enabling user";
            }
        }else{
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = "Invalid user ID";
        } 
        print json_encode($arr); 
    }

    protected function do_UpdateMyAccount(){ 
        $arrUser = $this->_payload['objUser'] ;
        
        $objUser =  new \NsCMN\ClsBllUser();
        $rslt = $objUser->LoadByID($arrUser['intID']);
        if($rslt){
            $objUser->strDisplayName = $arrUser['strDisplayName'];
            $objUser->strEmail = $arrUser['strEmail'];
            $rslt = $objUser->Save();
            if($rslt){
                $strMsg = 'User updated successfully';
                if(isset($arrUser['objFile']) && !empty($arrUser['objFile'])){
                    $strContent = $arrUser['objFile']['content'];
                    $strType = $this->_data['type'];
                    $strSize = $this->_data['size'];
                    $filename = "{$objUser->intID}.User.Photo";
                    $rslt = $objUser->UploadImage('','',$strContent,MODULE_ID,$filename,$strType,$strSize,$this->objUser->intID);
                    if(!$rslt){
                        $strMsg .= "\n Image not uploaded";        
                    }
                }
                
                $objSessionUser = $this->objUser;
                $objSessionUser->strDisplayName = $objUser->strDisplayName;
                $objSessionUser->strEmail = $objUser->strEmail;
                //$this->_session->Set("objUser", $objSessionUser);
                $this->_session->objUser = $objSessionUser;
                
                $arr['result'] = true;
                $arr['message'] = $strMsg;
            }else{
                $arr['result'] = false;
                $arr['message'] = 'Error in updating user';
            }
            print json_encode($arr);
        }
    }

    protected function before_ValidateUsername(){
        if(!isset($this->_data['username']) or trim($this->_data['username']) == ''){
            $arr['result'] = false;
            $arr['message'] = $this->cLang('LNG_6625');
            print json_encode($arr);
            return false;                   
        }

        return true;
    }
    protected function do_ValidateUserName(){
        $strUsername = $this->_data['username'];
        $objUser =  new \NsCMN\ClsBllUser();
        if(isset($this->_data['user_id'])){
            $rslt = $objUser->LoadByID($this->_data['user_id']);
            if($rslt){
                if(strtolower($objUser->strUserName) == strtolower($strUsername)){
                    $arr['result'] = true;
                    $arr['message'] = $this->cLang('LNG_6615');
                    print json_encode($arr);
                    return;   
                }
            }
        }

        $ok = ClsBllUser::ValidateUsernameString($strUsername);
        if ($ok !== true) {
            // $ok contains error code
            $arr['result'] = false;
            $arr['message'] = $this->cLangError($ok);
            print json_encode($arr);
            return false;                   
        }

        $ok = ClsBllUser::IsUsernameAvailable($strUsername);
        if ($ok !== true) {
            // $ok contains error code
            $arr['result'] = false;
            $arr['message'] = $this->cLangError($ok);
            print json_encode($arr);
            return false;
        }

        $arr['result'] = true;
        $arr['message'] = $this->cLang('LNG_6624');
        print json_encode($arr);
        return true;
    }

    protected function do_ChangePassword(){
        $arrChangePassword = $this->_payload['objChangePassword'];
        
        $intUserID = $this->_data['user_id'];
        $objUser =  new ClsBllUser();
        $rslt = $objUser->LoadByID($intUserID);
        if(!$rslt){
            $arr['result'] = false;
            $arr['message'] = 'User not found';
            print json_encode($arr);
            return false;
        }    
        
        $rslt = $objUser->ChangePassword($arrChangePassword['strOldPassword'], $arrChangePassword['strNewPassword']);
        if(!$rslt){
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = 'Incorrect old password.';
        }else{
            $arr['result'] = true;
            $arr['title'] = 'Success';
            $arr['message'] = 'Password has been changed successfully.';
        }

        print json_encode($arr);
        return $arr['result'];   
   }

}