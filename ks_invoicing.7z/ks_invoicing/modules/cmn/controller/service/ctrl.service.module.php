<?php
namespace NsCMN;

class ClsCtrlServiceModule extends \NsCMN\ClsCtrlServiceCmn {

    protected function do_Default(){}

    protected function do_List(){
        $objModule = new \NsCMN\ClsBllModule();
        $arrData = $objModule->GetModulesAssociative(false, '', true);

        $arr['result'] = true;
        $arr['title'] = $this->cLang('LNG_6586');
        $arr['message'] = $this->cLang('LNG_6585');
        $arr['object'] = $arrData;
        
        print json_encode($arr);
        return $arr['result'];
    }

    protected function do_ListModuleActions(){
        $intModuleID = $this->_data['module_id'];
        $obj = new \NsCMN\ClsBllModule();
        $rslt = $obj->LoadByID($intModuleID);
        if (!$rslt){
            $arr['result'] = false;
            $arr['title'] = $this->cLang('LNG_6580');
            $arr['message'] = $this->cLang('LNG_6582');
            
            print json_encode($arr);            
            return $arr['result'];
        }

        $obj = new ClsBllModuleAction();
        $arrAction = $obj->GetActionsByModule($intModuleID);
        if (is_array($arrAction)){
            $arr['result'] = true;
            $arr['title'] = $this->cLang('LNG_6581');
            $arr['message'] = $this->cLang('LNG_6584');
            $arr['object'] = $arrAction;
        }else{
            $arr['result'] = false;
            $arr['title'] = $this->cLang('LNG_6580');
            $arr['message'] = $this->cLang('LNG_6583');
        }

        print json_encode($arr);
        return $arr['result'];
    }

    protected function do_AddModuleAction(){
        $arrModuleAction = $this->_payload['objModuleAction'];

        $obj = new ClsBllModuleAction();
        $obj->intModuleID = $arrModuleAction['intModuleID'];
        $obj->strControllerType = $arrModuleAction['strControllerType'];
        $obj->strControllerClass = $arrModuleAction['strControllerClass'];
        $obj->strAction = $arrModuleAction['strAction'];
        $rslt = $obj->Save();
        if ($rslt){
            $arr['result'] = true;
            $arr['title'] = $this->cLang('LNG_6594');
            $arr['message'] = $this->cLang('LNG_6596');
            $arr['object'] = $obj->ToArray();
        }else{
            $arr['result'] = false;
            $arr['title'] = $this->cLang('LNG_6595');
            $arr['message'] = $this->cLang('LNG_6597');
        }
 
        print json_encode($arr);
        return $arr['result'];
    }

    protected function do_DeleteModuleAction(){
        $intActionID = $this->_data['action_id'];
        $obj = new ClsBllModuleAction();
        $rslt = $obj->LoadByID($intActionID);
        if (!$rslt){
            $arr['result'] = false;
            $arr['title'] = $this->cLang('LNG_6587');
            $arr['message'] = $this->cLang('LNG_6588');
            
            print json_encode($arr);            
            return $arr['result'];
        }

        $rslt = $obj->Delete();
        if ($rslt){
            $arr['result'] = true;
            $arr['title'] = $this->cLang('LNG_6589');
            $arr['message'] = $this->cLang('LNG_6590');
        }else{
            $arr['result'] = false;
            $arr['title'] = $this->cLang('LNG_6587');
            $arr['message'] = $this->cLang('LNG_6591');
        }
        
        print json_encode($arr);
        return $arr['result'];
    }
    
}