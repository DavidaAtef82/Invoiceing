<?php
namespace NsCMN;

class ClsCtrlServiceDistrict extends \NsCMN\ClsCtrlServiceCmn {

    protected function do_Default(){}


    protected function do_List(){
        $arrData = [];
        if(isset($this->_data['city_id'])){
            $intCityID = $this->_data['city_id'];
            $objCity = new \NsCMN\ClsBllCity();
            $rslt = $objCity->LoadByID($intCityID);
            if(!$rslt){
                $arr['result'] = false;
                $arr['title'] = 'Error';
                $arr['message'] = "Error in loading districts for city id #$intCityID";
                print json_encode($arr);
                return;
            }
            $arrData = $objCity->arrDistricts;
        }else{
            $obj = new \NsCMN\ClsBllDistrict();
            $arrData = $obj->GetAllDistricts();
        }
        $arr['result'] = true;
        $arr['title'] = 'Success';
        $arr['message'] = 'Districts successfully listed';
        $arr['object'] = $arrData;
        print json_encode($arr);
    }

    protected function before_Add(){
        if (!isset($this->_data['city_id']) or !is_numeric($this->_data['city_id'])){
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = 'No city id specified.';
            print json_encode($arr);
            return false;
        }

        if (!isset($this->_data['district']) or trim($this->_data['district'])==''){
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = 'No district specified.';
            print json_encode($arr);
            return false;
        }
        return true;
    }
    protected function do_Add(){
        $intCityID = $this->_data['city_id'];
        $strDistrict = $this->_data['district'];
        if(!$this->validate($strDistrict)){
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = 'District name already taken';
            print json_encode($arr);
            return;
        }
        $objDistrict = new \NsCMN\ClsBllDistrict();
        $objDistrict->intCityID = $intCityID;
        $objDistrict->strDistrict = $strDistrict;
        $rslt = $objDistrict->Save();
        if ($rslt){
            $arr['result'] = true;
            $arr['title'] = 'Success';
            $arr['message'] = "District has been added successfully";
            $arr['object'] = $objDistrict->ToArray();
        }else{
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = "Error while adding new district";
        }
        print json_encode($arr);
    }

    protected function before_Delete(){
        if (!isset($this->_data['district_id']) or !is_numeric($this->_data['district_id'])){
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = 'No District id specified.';
            print json_encode($arr);
            return false;
        }
        return true;
    }
    protected function do_Delete(){
        $intDistrictID = $this->_data['district_id'];
        $objDistrict = new \NsCMN\ClsBllDistrict();
        $rslt = $objDistrict->LoadByID($intDistrictID);
        if($rslt){
            $rslt = $objDistrict->Delete();
            if($rslt){
                $arr['result'] = true;
                $arr['title'] = 'Success';
                $arr['message'] = "District <strong>{$objDistrict->strDistrict}</strong> deleted Successfully";
            }else {
                $arr['result'] = false;
                $arr['title'] = 'Error';
                $arr['message'] = "District <strong>{$objDistrict->strDistrict}</strong> couldn't be deleted as there is another data related to it";
            }
        }else{
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = "District with ID #$intDistrictID doesn't exist";
        }
        print json_encode($arr);

    }

    private function validate($strCityName){
        $intCityID = $this->_data['city_id'];
        $strDistrict = $this->_data['district'];

        $objFilter = new \NsFWK\ClsFilter();
        $objFilter->fkCityID = "fkCityID = $intCityID";
        $objFilter->fldDistrict = "fldDistrict = '$strDistrict'";

        $objDistrict = new \NsCMN\ClsBllDistrict();
        $arrDistricts = $objDistrict->GetData($objFilter,'');
        if(!is_array($arrDistricts) or empty($arrDistricts)){
            return true;
        }else{
            return false;
        }
    }
}
