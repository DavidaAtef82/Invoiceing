<?php
namespace NsCMN;

class ClsCtrlServiceLocation extends \NsCMN\ClsCtrlServiceCmn {

    protected function do_Default(){}

    protected function do_List(){            
        $obj = new \NsCMN\ClsBllLocation();
        $arrData = $obj->GetAllLocations();
        $arr['result'] = true;
        $arr['title'] = 'Success';
        $arr['message'] = 'Locations successfully listed';
        $arr['object'] = $arrData;
        print json_encode($arr);
    }

    protected function before_Add(){
        $arrData = $this->_payload['objLocation'];

        if (!isset($arrData['strName']) or $arrData['strName']==''){
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = 'No Location name specified.';
            print json_encode($arr);
            return false;                 
        }

        if (!isset($arrData['intDistrictID']) or $arrData['intDistrictID']==-1){
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = 'No District specified.';
            print json_encode($arr);
            return false;                 
        }

        if (!isset($arrData['strAddress']) or $arrData['strAddress']==""){
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = 'No Address specified.';
            print json_encode($arr);
            return false;                 
        }

        if (!isset($arrData['strPhone']) or $arrData['strPhone']==""){
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = 'No Phone specified.';
            print json_encode($arr);
            return false;                 
        }
        return true;            
    }
    protected function do_Add(){
        $arrData = $this->_payload['objLocation'];
        $obj = new \NsCMN\ClsBllLocation();
        $obj->strName = $arrData['strName'];
        $obj->intDistrictID = $arrData['intDistrictID'];
        $obj->strAddress = $arrData['strAddress'];
        $obj->strPhone = $arrData['strPhone'];
        $obj->strLongitude = $arrData['strLongitude'];
        $obj->strLatitude = $arrData['strLatitude'];     
        $obj->strNotes = $arrData['strNotes'];     
        $rslt = $obj->Save();
        if ($rslt){
            $obj->objDistrict;    
            $arr['result'] = true;
            $arr['title'] = 'Success';
            $arr['message'] = 'Location successfully updated';
            $arr['object'] = $obj->ToArray();
        }else{
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = "Error in adding new location";
        }
        print json_encode($arr);
    }

    protected function before_Delete(){
        if(!isset($this->_data['location_id']) or !is_numeric($this->_data['location_id'])){
            $arr['result'] = false;
            $arr['message'] = "No Location Specified";
            print json_encode($arr);                
            return false;
        }
        return true;
    }
    protected function do_Delete(){
        $objLocation = new \NsCMN\ClsBllLocation();
        $rslt = $objLocation->LoadByID($this->_data['location_id']); 
        if($rslt){
            $rslt = $objLocation->Delete();
            if($rslt){
                $arr['result'] = true;
                $arr['message'] = 'Location has been deleted Successfully';
                print json_encode($arr);
            }
            else {
                $arr['result'] = false;
                $arr['message'] = "Location can't be deleted because it's used.";
                print json_encode($arr);
            }
        }else{
            $arr['result'] = false;
            $arr['message'] = "Error in loading this barnch";
            print json_encode($arr);
        }
    }

    protected function before_Update(){
        if(!isset($this->_data['location_id']) or !is_numeric($this->_data['location_id'])){
            $arr['result'] = false;
            $arr['result'] = 'Error';
            $arr['message'] = "No Location id specified";
            print json_encode($arr);                
            return false;                 
        }
        return true;

    }
    protected function do_Update(){
        $intLocationID = $this->_data['location_id'];
        $strAttributeName = $this->_data['name'];
        $strValue = $this->_data['value'];

        $obj = new \NsCMN\ClsBllLocation();
        $rslt = $obj->LoadByID($intLocationID);
        if(!$rslt){
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = "Couldn't load Location with ID #$intLocation";
            print json_encode($arr);
            return;
        }
        $obj->$strAttributeName = $strValue;
        $rslt = $obj->Save();
        if ($rslt){
            $arr['result'] = true;
            $arr['title'] = 'Success';
            $arr['message'] = "Location has been updated successfully";
            $arr['object'] = $obj->ToArray();
        }else{
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = "Error while trying to update location {$objLocation->strName}";
        }
        print json_encode($arr);
    }

}