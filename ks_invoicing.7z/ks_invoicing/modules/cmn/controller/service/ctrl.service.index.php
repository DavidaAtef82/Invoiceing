<?php
namespace NsCMN;

class ClsCtrlServiceIndex extends \NsFWK\ClsCtrlServicePublic {

    protected function do_Default(){}

    protected function do_Login(){
        $strUserName = $this->_payload['username'];
        $strPassword = $this->_payload['password'];
        $objUser = new ClsBllUser();
        $rslt = $objUser->Login($strUserName,$strPassword);
        if ($rslt){
            $this->initSession($objUser);

            if(isset($this->_data['url']) && $this->_data['url']!=''){
                $strUrl = $this->_data['url'];
                $strUrl = urldecode($this->_data['url']);
            }else{
                $strUrl = $objUser->objUserLevel->strDefaultPage;
            }
            $arr['url'] = $strUrl;
            $arr['result'] = true;
            $arr['reason'] = '';
        }else{
            $arr['result'] = false;
            $arr['reason'] = 'Login failed, please try again!';
        }
        print json_encode($arr);
    }
    private function initSession($objUser){
        $objUser->arrActions;
        $objUser->arrMenuItems;
        $objUser->arrUserLevels;

        // Set User in Session
        $objSession = \NsFWK\ClsSession::GetInstance();
        //$objSession->Set('objUser', $objUser);
        $objSession->objUser = $objUser;
        //$objSession->Set('intUserID', $objUser->intID);
        $objSession->intUserID = $objUser->intID;
        //$objSession->Set('strDefaultPage', $objUser->objUserLevel->strDefaultPage);
        $objSession->strDefaultPage = $objUser->objUserLevel->strDefaultPage;

        // Set Config in Session
        $arrConfig = \NsFWK\ClsConfiguration::GetInstance()->ToArray();
        //$objSession->Set('arrConfig', $arrConfig);
        $objSession->arrConfig = $arrConfig;
    }


    protected function before_CreatePasswordResetRecord(){
        if(!isset($this->_payload['username']) or trim($this->_payload['username'])==''){
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = "invalid user name!";
            print json_encode($arr);
            return false;                   
        }
        return true;
    }
    protected function do_CreatePasswordResetRecord(){
        $strUserName = $this->_payload['username'];
        $objUser =  new \NsCMN\ClsBllUser();
        $rslt = $objUser->LoadByUserName($strUserName);
        if($rslt){
            if($objUser->intDisabled == 1){
                // User account is disabled
                $arr['result'] = false;
                $arr['title'] = $this->cLang('LNG_5788');
                $arr['message'] = $this->cLang('LNG_5790');
                print json_encode($arr);
                return false;                   
            }

            $arrResult = \NsCMN\ClsBllUser::CreatePasswordResetRecord($objUser->intID, date("Y-m-d H:i"));
            if($arrResult !== false){
                $arrData['User'] = $objUser;
                $intID = $arrResult['intID'];
                $strKey = $arrResult['strKey'];
                $arrData['URL'] = WEB__ROOT__PATH."/index.php?module=cmn&page=Index&action=ResetPassword&id=$intID&key=$strKey";
                
                $objEmail = new \NsCMN\ClsBllMail();
                $objEmail->LoadByTemplate('reset_password_confirmation',$arrData);
                $ok = $objEmail->Send($objUser->strEmail);

                $arr['result'] = true;
                $arr['title'] = $this->cLang('LNG_5789');
                $arr['message'] = $this->cLang('LNG_5791');
                print json_encode($arr);
                return true;                   
            }else{
                // Failed to reset password!
                $arr['result'] = false;
                $arr['title'] = $this->cLang('LNG_5788');
                $arr['message'] = $this->cLang('LNG_5792');
                print json_encode($arr);
                return false;                   
            }
        }else{
            // Email account not found or could not be loaded
            $arr['result'] = false;
            $arr['title'] = $this->cLang('LNG_5788');
            $arr['message'] = $this->cLang('LNG_5793');
            print json_encode($arr);
            return false;                   
        }
    }
    
    protected function do_ResetPassword(){
        $arrReset = $this->_payload['objReset'];
        
        $objUser =  new ClsBllUser();
        $rslt = $objUser->LoadByUserName($arrReset['strUserName']);
        if(!$rslt){
            $arr['result'] = false;
            $arr['title'] = $this->cLang('LNG_5794');
            $arr['message'] = $this->cLang('LNG_5795');
            print json_encode($arr);
            return false;
        }    
        
        $rslt = ClsBllUser::ValidatePasswordResetID($arrReset['intID'], $arrReset['strKey'], $objUser->intID);
        if(!$rslt){
            $arr['result'] = false;
            $arr['title'] = $this->cLang('LNG_5794');
            $arr['message'] = $this->cLang('LNG_5796');
            print json_encode($arr);
            return false;
        }
        
        $rslt = $objUser->ResetPassword($arrReset['strPassword'], $arrReset['intID']);
        if(!$rslt){
            $arr['result'] = false;
            $arr['title'] = $this->cLang('LNG_5794');
            $arr['message'] = $this->cLang('LNG_5797');
        }else{
            $arr['result'] = true;
            $arr['title'] = $this->cLang('LNG_5798');
            $arr['message'] = $this->cLang('LNG_5799');
        }
        print json_encode($arr);
        return true;   
   }
}