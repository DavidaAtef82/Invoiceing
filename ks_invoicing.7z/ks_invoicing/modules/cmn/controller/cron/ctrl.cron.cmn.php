<?php
namespace NsCMN;

class ClsCtrlCronCmn extends \NsFWK\ClsCtrlCron{

}