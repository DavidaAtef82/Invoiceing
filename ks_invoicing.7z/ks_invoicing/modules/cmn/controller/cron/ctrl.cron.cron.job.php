<?php
namespace NsCMN;

class ClsCtrlCronCronJob extends ClsCtrlCronCmn{
    protected function do_Default(){
        $strFunctionName = __METHOD__ . ' @ ' . __FILE__;
        $this->verbose("$strFunctionName ... Execution Started");

        $objCron = new ClsBllCronJob();
        $arrCronJobs = $objCron->GetEnabledCron();

        $this->verbose("$strFunctionName ... Cron jobs retrieved: " . count($arrCronJobs));

        foreach($arrCronJobs as $objCronJob){
            $this->verbose("Executing CronJob: " . $objCronJob->objModule['strModule'] . "::" . $objCronJob->strCron);

            $rslt = $objCronJob->AutoRun();
            if($rslt){
                $this->verbose("Cron execution triggered ...");
            } else {
                $this->verbose("Cron execution is not scheduled ...");
            }
        }
    }
}