<?php
namespace NsCMN;

class ClsCtrlCronResetAccountCron extends ClsCtrlCronCmn{
    /***
    * The CRON takes the user Ids in Comma Separated fashion. 
    * 
    */
    protected function do_Default(){
        $strFunctionName = __METHOD__ . ' @ ' . __FILE__;
        $this->verbose("$strFunctionName ... Execution Started");

        $arrParams = $this->_data['params'];
        if(!empty($arrParams)){
            $arrAccountsUserNames = explode(',',$arrParams[0]);
            if (empty($arrAccountsUserNames)){
                $this->verbose('No usernames were sent to the cron. The cron terminated without resetting any users');
                return false;
            }
            $this->verbose("Resetting password for User IDs " . implode(',', $arrAccountsUserNames));
            
            $strUserNames = implode("','", $arrAccountsUserNames);
            $strUserNames = "'$strUserNames'";
            
            $DB = &\ADODB_Connection_Manager::GetConnection('customer');
            $strSQL = "SELECT pkUserID,fldUserName FROM cmn_user WHERE fldUserName IN ($strUserNames)";
            $arrAccountss = $DB->GetAssoc($strSQL);
            if(empty($arrAccountss)){
                $this->verbose('No usernames were sent to the cron. The cron terminated without resetting any users');
                return false;    
            } 
        }else{
            $this->verbose('No usernames were sent to the cron. The cron terminated without resetting any users');
            return false;
        }

        foreach($arrAccountss as $intUserID=>$strUserName){
            $this->verbose("Resetting password and emailing User ID #$intUserID [$strUserName]");
            $rslt = $this->resetUser($intUserID);
        }

        $this->verbose("$strFunctionName ... Execution Completed");
    }

    private function resetUser($intUserID){
        $objUser = new ClsBllUser();
        $rslt = $objUser->LoadByID($intUserID);
        if (!$rslt){
            return false;
        }

        $strPassword = $objUser->AssignAutoPassword();
        if($strPassword === false){
            $this->verbose("Could not update user new password for user {$objUser->strDisplayName} [{$objUser->intID}]");            
            return false;
        }
        
        // Save password to object before passing it to email template
        $objUser->strPasswordBeforeHashing = $strPassword;
        $this->verbose("Password successfully reset for user: {$objUser->strDisplayName}, email:{$objUser->strEmail} [{$objUser->intID}]");

        $rslt = $this->sendEmail($objUser);
        if (!$rslt){
            $this->verbose("Could not send email to user after reseting his password - display name: {$objUser->strDisplayName}, email:{$objUser->strEmail} [{$objUser->intID}]");            
            return false;
        } else {
            $this->verbose("User has been successfully notified by email");
            return true;        
        }
    }
    
    private function sendEmail(\NsCMN\ClsBllUser $objUser){
        $arrData['User'] = $objUser;
        $arrData['URL'] = WEB__ROOT__PATH;

        $obj = new \NsCMN\ClsBllMail();
        $rslt = $obj->LoadByTemplate('reset_passowrd', $arrData);
        if(!$rslt){
            $this->verbose('Could not load template new_user');
            return false;
        }
        
        $rslt = $obj->Send($objUser->strEmail);
        return $rslt;
    }
}