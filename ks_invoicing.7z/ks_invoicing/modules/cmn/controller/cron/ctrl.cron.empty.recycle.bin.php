<?php
namespace NsCMN;

class ClsCtrlCronEmptyRecycleBin extends ClsCtrlCronCmn{
    protected function do_Default(){
        $strFunctionName = __METHOD__ . ' @ ' . __FILE__;
        $this->verbose("$strFunctionName ... Execution Started");

        $arrParams = $this->_data['params'];
        $dtDate = date("Y-m-d", strtotime( date( "Y-m-d", strtotime( date("Y-m-d") ) ) . "-1 month" ) );
        if(isset($arrParams[0]) && !empty($arrParams[0])){
            $dtDate = $arrParams[0];
        }
        $this->verbose("Delete files before $dtDate");
        
        $objFilter = new \NsFWK\ClsFilter();
        $objFilter->dtDeletedDate = "DATE(fldTrashDateTime) <= '$dtDate'";
        $ok = ClsBllFile::EmptyRecycleBin($objFilter);
        if($ok === false){
            $this->verbose('Failed while trying to empty recycle bin');
            return false;    
        }
        $this->verbose("$ok file(s) deleted successfully");
        return true; 
    }
}