<?php
namespace NsCMN;

class ClsCtrlApiCmn extends \NsFWK\ClsCtrlApi{

    protected function do_Default(){}

    public function __construct($arrParameters){
        parent::__construct($arrParameters);
    }

}