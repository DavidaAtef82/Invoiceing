<?php
namespace NsCMN;

class ClsCtrlApiDisableModule extends ClsCtrlApiCmn {
    
    function __construct($arrParameters){
        $this->_boolRequireKey = false;
        parent::__construct($arrParameters);
    }
    
    protected function do_Default(){
        try{
            $intModuleID = $this->_data['module_id'];
            $rslt = ClsBllModule::Disable($intModuleID);
            print $rslt;
        }catch(Exception $e){
            \NsFWK\ClsCtrlApi::SetResponse(\NsFWK\ClsCtrlApi::HTTP_STATUS_400,'Exception Thrown',$e);
        }
    }

}