<?php

namespace NsCMN;
class ClsCtrlApiUsers extends ClsCtrlApiCmn{
    
    function __construct($arrParameters){
        $this->_boolRequireKey = true;
        parent::__construct($arrParameters);
    }
    
    protected function do_Default(){
        try{
            
            $obj = new ClsBllUser();
            if (isset($this->_data['user_level_id'])){
                $intUserLevel = $this->_data['user_level_id'];
                $arrUsers = $obj->GetUsersByUserLevel($intUserLevel);
            }else{
                $arrUsers = $obj->GetActiveUsers();
            }
            $strOutput = json_encode($arrUsers);
            print $strOutput;
        }catch(Exception $e){
            \NsFWK\ClsCtrlApi::SetResponse(\NsFWK\ClsCtrlApi::HTTP_STATUS_400,'Exception Thrown',$e);
        }
    }
}