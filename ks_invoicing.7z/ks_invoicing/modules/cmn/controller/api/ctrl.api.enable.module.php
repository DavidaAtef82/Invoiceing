<?php
namespace NsCMN;

class ClsCtrlApiEnableModule extends ClsCtrlApiCmn {
    
    function __construct($arrParameters){
        $this->_boolRequireKey = false;
        parent::__construct($arrParameters);
    }
    
    protected function do_Default(){
        try{
            $arrModuleIDs = explode("|",$this->_data['module_ids']);
            $rslt = ClsBllModule::Enable($arrModuleIDs);
            print $rslt;
        }catch(Exception $e){
            \NsFWK\ClsCtrlApi::SetResponse(\NsFWK\ClsCtrlApi::HTTP_STATUS_400,'Exception Thrown',$e);
        }
    }

}