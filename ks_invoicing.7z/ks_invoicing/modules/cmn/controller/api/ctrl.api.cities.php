<?php
namespace NsCMN;

class ClsCtrlApiCities extends ClsCtrlApiCmn {
    
    public function __construct($arrParameters){
        $this->_boolRequireKey = true;
        parent::__construct($arrParameters);
    }
    
    protected function do_Default(){
        try{
            $obj = new ClsBllCity();
            $arrCities = $obj->GetAllCities();
            
            $arr['result'] = true;
            $arr['title'] = 'Success';
            $arr['message'] = 'Cities listed successfully.';
            $arr['object'] = $arrCities;
            
            $strOutput = json_encode($arr);
            print $strOutput;
        }catch(Exception $e){
            \NsFWK\ClsCtrlApi::SetResponse(\NsFWK\ClsCtrlApi::HTTP_STATUS_400,'Exception Thrown',$e);
        }
    }

}