<?php
namespace NsCMN;

class ClsCtrlApiUser extends ClsCtrlApiCmn {
    
    function __construct($arrParameters){
        $this->_boolRequireKey = true;
        parent::__construct($arrParameters);
    }
    
    protected function do_Default(){
        try{
            $objUser = $this->objUser;
            $strOutput = $objUser->ToJson();
            print $strOutput;
        }catch(Exception $e){
            \NsFWK\ClsCtrlApi::SetResponse(\NsFWK\ClsCtrlApi::HTTP_STATUS_400,'Exception Thrown',$e);
        }
    }

}