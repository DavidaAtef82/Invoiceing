<?php
namespace NsCMN;

class ClsCtrlApiLocations extends ClsCtrlApiCmn {
    public function __construct($arrParameters){
        $this->_boolRequireKey = true;
        parent::__construct($arrParameters);
    }
    
    protected function do_Default(){
        try{
            $objFilter = new \NsFWK\ClsFilter();
            $obj = new ClsBllLocation();
            $arrLocations = $obj->GetDataAssociative($objFilter);
            
            $arr['result'] = true;
            $arr['title'] = 'Success';
            $arr['message'] = 'Locations successfully loaded';
            $arr['object'] = $arrLocations;
            
            $strOutput = json_encode($arr);
            
            print $strOutput;
        }catch(Exception $e){
            \NsFWK\ClsCtrlApi::SetResponse(\NsFWK\ClsCtrlApi::HTTP_STATUS_400,'Exception Thrown',$e);
        }
    }

}