<?php
namespace NsCMN;

class ClsCtrlApiSendEmail extends ClsCtrlApiCmn {
    
    /**
    * put your comment there...
    *     
    * @deprecated
    * @param mixed $arrParameters
    * @return apply
    */
    public function __construct($arrParameters){
        parent::__construct($arrParameters);
        $this->_boolRequireKey = true;
    }
    
    protected function do_Default(){
        $strFunctionName = __METHOD__ . ' @ ' . __FILE__;
        $objLog = \NsFWK\ClsLogger::GetInstance();
        $objLog->LogDebug("$strFunctionName ... Execution Started");

        try{
            $strSubject = $this->_data['subject'];
            $strBody = $this->_data['body'];
            $strEmail = $this->_data['to'];
            
            \NsFWK\ClsHlpHelper::SendEmail($strSubject, $strBody, $strEmail);

            $arr['root']['result'] = true;
            $arr['root']['title'] = 'Success';
            $arr['root']['message'] = 'Email sent successfully.';
            
            $strOutput = json_encode($arr);
            print $strOutput;
            $objLog->LogDebug("$strFunctionName ... Response: $strOutput");
        }catch(Exception $e){
            \NsFWK\ClsCtrlApi::SetResponse(\NsFWK\ClsCtrlApi::HTTP_STATUS_400,'Exception Thrown',$e);
        }
    }

}