<?php
namespace NsCMN;

class ClsCtrlApiConsumption extends ClsCtrlApiCmn {
    
    function __construct($arrParameters){
        $this->_boolRequireKey = false;
        parent::__construct($arrParameters);
    }
    
    protected function do_Default(){
        try{
            $arrUsage = ClsBllModule::GetUsage();
            $strOutput = json_encode($arrUsage);
            print $strOutput;
        }catch(Exception $e){
            \NsFWK\ClsCtrlApi::SetResponse(\NsFWK\ClsCtrlApi::HTTP_STATUS_400,'Exception Thrown',$e);
        }
    }

}