<?php
namespace NsCMN;

class ClsCtrlPageIndex extends \NsFWK\ClsCtrlPagePublic {

    protected function do_Default(){
        header("location:index.php?module=cmn&page=Index&action=Login");
        return false;
    }

    protected function do_Export(){
        $dtDate = date("YmdHis");
        $strFileName = "data-$dtDate.csv";
        header('Content-type: application/octet-stream; charset=UFT-8');
        header('Content-Disposition: attachment; filename="' . $strFileName . '"');

        $data = stripslashes($this->_data['hdCSV']);
        $data = htmlspecialchars_decode($data);
        print $data;
    }

    protected function before_Login(){
        if($this->boolIsLogged){
            $strDefaultPageUrl = $this->_session->strDefaultPage;
            header("location:$strDefaultPageUrl");
            return false;
        }
        return true;
    }
    protected function do_Login(){
        if(defined('BROWSER_AGENT') && BROWSER_AGENT != ''){
            $arrUserAgent = \NsFWK\ClsHlpHelper::GetBrowserAgent();
            $strName = strtolower($arrUserAgent['name']);
            if(!strpos($strName, BROWSER_AGENT)){
                $this->_template = 'pages/invalid.browser.tpl';
                return;
            }
        }
        $strURL = '';
        if(isset($this->_data['url'])){
            $strURL = urldecode($this->_data['url']);
        }
        $this->_smarty->assign('URL', $strURL);
        $this->_template = 'pages/login.tpl';
    }
    protected function after_Login(){
        $this->_smarty->display($this->_template);
    }

    protected function do_LogMeOut(){
        $this->_session->Destroy();
        header("location:index.php?module=cmn&page=Index&action=Login");
    }
    
    protected function do_ResetPassword(){
        $intID = $this->_data['id'];
        $strKey = $this->_data['key'];
        
        $rslt = \NsCMN\ClsBllUser::CheckPasswordExpiration($intID, $strKey);
        if(!$rslt){
            header("location: index.php?module=cmn&page=Index&action=Error&reason=Sorry! Your link is expired or has been used before, You have to repeat 'reset password' process.");
            return false;
        }
        $this->_smarty->assign('ID', $intID);
        $this->_smarty->assign('Key', $strKey);
        $this->_template = 'pages/reset.password.tpl';
    }
    protected function after_ResetPassword(){
        $this->_smarty->display($this->_template);
    }

    protected function do_Unauthorized(){
        header("HTTP/1.0 401 Unauthorized");
        if(isset($this->_data['reason'])){
            $this->_smarty->assign('Reason', $this->_data['reason']);
        }
        $this->_template = 'pages/unauthorized.tpl';
    }
    protected function after_Unauthorized(){
        $this->_smarty->display($this->_template);
    }

    protected function do_PageNotFound(){
        header("HTTP/1.0 404 Not Found");
        $this->_template = 'pages/page.not.found.tpl';
    }
    protected function after_PageNotFound(){
        $this->_smarty->display($this->_template);
    }

    protected function do_ServiceUnavailable(){
        header("HTTP/1.0 503 Service Unavailable");
        $this->_template = 'pages/service.unavailable.tpl';
    }
    protected function after_ServiceUnavailable(){
        $this->_smarty->display($this->_template);
    }

    public function do_Error(){
        header("HTTP/1.0 500 Internal Server Error");
        $this->_template = 'pages/error.tpl';
    }
    public function after_Error(){
        $this->_smarty->display($this->_template);
    }

    public function do_Success(){
        header("HTTP/1.0 200 OK");
        $this->_template = 'pages/success.tpl';
    }
    public function after_Success(){
        $this->_smarty->display($this->_template);
    }

    protected function do_Download(){
        $intFileID = $this->_data['file_id'];
        $obj = new ClsBllFile();
        $rslt = $obj->LoadByID($intFileID);
        if (!$rslt){
            $arr['result'] = false;
            $arr['title'] = 'Error';
            $arr['message'] = "File #$intFileID does not exist in our database.";
            print json_encode($arr);
            return;
        }
        header('Content-Disposition: attachment; filename="' . $obj->strFileName . '"'); 
        $strContent = $obj->GetFileContent();

        print $strContent;
    }
    
    protected function do_QRCode(){
        $strData = $this->_data['data'];
        \NsFWK\ClsHlpHelper::QRCode($strData);
    }
    
    protected function do_DownloadSample(){
        $strFileName = $this->_data['file_name'];
        $file = null;
        switch($strFileName){
            case 'finger_print' :
                $file = PATH_UPLOAD_FINGER_PRINT;
                break;
            case 'settlements':
                $file = PATH_UPLOAD_SETTLEMENTS;
                break;
            case 'employeesCsv':
                $file = PATH_UPLOAD_EMPLOYEES_CSV;
                break;
            case 'employeesExcel':
                $file = PATH_UPLOAD_EMPLOYEES_EXCEL;
                break;
            case 'salaries_import':
                $file = PATH_UPLOAD_SALARIES;
                break;
            case 'chart_account_import':
                $file = PATH_UPLOAD_CHART_OF_ACCOUNT;
                break;
            case 'payment_method_import':
                $file = PATH_UPLOAD_PAYMENT;
                break;
            case 'vacation_balance_import':
                $file = PATH_UPLOAD_VACATION_BALANCE_SAMPLE;
                break;
        }
        if(is_file($file)) {
            header('Pragma: public');     // required
            header('Expires: 0');        // no cache
            header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
            header('Last-Modified: '.gmdate ('D, d M Y H:i:s', filemtime ($file)).' GMT');
            header('Cache-Control: private',false);
            header('Content-Type: '.filetype($file));
            header('Content-Disposition: attachment; filename="' . basename($file) . '"');
            header('Content-Transfer-Encoding: binary');
            header('Content-Length: '.filesize($file));    // provide file size
            header('Connection: close');
            readfile($file);
        }                   
        
    }

    private function getBrowser(){
        $u_agent = $_SERVER['HTTP_USER_AGENT'];
        $bname = 'Unknown';
        $platform = 'Unknown';
        $version= "";

        //First get the platform?
        if (preg_match('/linux/i', $u_agent)) {
            $platform = 'linux';
        }
        elseif (preg_match('/macintosh|mac os x/i', $u_agent)) {
            $platform = 'mac';
        }
        elseif (preg_match('/windows|win32/i', $u_agent)) {
            $platform = 'windows';
        }

        // Next get the name of the useragent yes seperately and for good reason
        if(preg_match('/MSIE/i',$u_agent) && !preg_match('/Opera/i',$u_agent))
        {
            $bname = 'Internet Explorer';
            $ub = "MSIE";
        }
        elseif(preg_match('/Firefox/i',$u_agent))
        {
            $bname = 'Mozilla Firefox';
            $ub = "Firefox";
        }
        elseif(preg_match('/Chrome/i',$u_agent))
        {
            $bname = 'Google Chrome';
            $ub = "Chrome";
        }
        elseif(preg_match('/Safari/i',$u_agent))
        {
            $bname = 'Apple Safari';
            $ub = "Safari";
        }
        elseif(preg_match('/Opera/i',$u_agent))
        {
            $bname = 'Opera';
            $ub = "Opera";
        }
        elseif(preg_match('/Netscape/i',$u_agent))
        {
            $bname = 'Netscape';
            $ub = "Netscape";
        }

        // finally get the correct version number
        $known = array('Version', $ub, 'other');
        $pattern = '#(?<browser>' . join('|', $known) .
        ')[/ ]+(?<version>[0-9.|a-zA-Z.]*)#';
        if (!preg_match_all($pattern, $u_agent, $matches)) {
            // we have no matching number just continue
        }

        // see how many we have
        $i = count($matches['browser']);
        if ($i != 1) {
            //we will have two since we are not using 'other' argument yet
            //see if version is before or after the name
            if (strripos($u_agent,"Version") < strripos($u_agent,$ub)){
                $version= $matches['version'][0];
            }
            else {
                $version= $matches['version'][1];
            }
        }
        else {
            $version= $matches['version'][0];
        }

        // check if we have a number
        if ($version==null || $version=="") {$version="?";}

        return array(
            'userAgent' => $u_agent,
            'name'      => $bname,
            'version'   => $version,
            'platform'  => $platform,
            'pattern'    => $pattern
        );
    }
}