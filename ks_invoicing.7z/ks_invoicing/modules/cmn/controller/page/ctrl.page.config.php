<?php
namespace NsCMN;

class ClsCtrlPageConfig extends \NsCMN\ClsCtrlPageCmn {

    protected function do_Default(){
        $this->do_Load();
    }

    protected function after_Default(){
        $this->after_Load();
    }

    protected function do_List(){
        $this->_template = "pages/config.list.tpl";
    }                                 

    protected function after_List(){
        $this->_smarty->display($this->_template);
    }
}