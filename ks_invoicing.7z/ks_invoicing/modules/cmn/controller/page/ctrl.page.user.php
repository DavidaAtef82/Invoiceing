<?php
namespace NsCMN;

class ClsCtrlPageUser extends \NsCMN\ClsCtrlPageCmn {

    protected function do_Default(){
        $this->do_Load();
    }
    protected function after_Default(){
        $this->after_Load();
    }

    protected function do_List(){
        $this->_template = "pages/user.list.tpl";
    }                                 
    protected function after_List(){
        $this->_smarty->display($this->_template);
    }

    protected function do_Load(){
        $this->_template = 'pages/account.tpl';
    }
    protected function after_Load(){
        $this->_smarty->display($this->_template);
    }
    
    protected function do_New(){
        $this->_template = "pages/user.new.tpl";
    }                                 
    protected function after_New(){
        $this->_smarty->display($this->_template);
    }

    protected function do_Edit(){
        $this->_template = "pages/user.edit.tpl";
    }                                 
    protected function after_Edit(){
        $this->_smarty->display($this->_template);
    }

}