<?php
namespace NsCMN;

class ClsCtrlPageModule extends \NsCMN\ClsCtrlPageCmn {

    protected function do_Default(){
        $this->do_Load();
    }
    protected function after_Default(){
        $this->after_Load();
    }

    protected function do_ListActions(){
        $this->_template = "pages/module.action.tpl";
    }                                 
    protected function after_ListActions(){
        $this->_smarty->display($this->_template);
    }

}