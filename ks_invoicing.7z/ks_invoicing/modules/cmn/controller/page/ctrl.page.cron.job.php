<?php
namespace NsCMN;

class ClsCtrlPageCronJob extends \NsCMN\ClsCtrlPageCmn {

    protected function do_Default(){
    }

    protected function do_List(){
        $this->_template = "pages/cron.job.list.tpl";   
    }
    protected function after_List(){
        $this->_smarty->display($this->_template);
    }
}