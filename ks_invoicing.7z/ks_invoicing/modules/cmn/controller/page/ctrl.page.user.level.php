<?php
namespace NsCMN;

class ClsCtrlPageUserLevel extends \NsCMN\ClsCtrlPageCmn {

    protected function do_Default(){
        $this->do_List();
    }
    protected function after_Default(){
        $this->after_List();
    }

    protected function do_List(){
        $this->_template = "pages/user.level.list.tpl";
    }                                 
    protected function after_List(){
        $this->_smarty->display($this->_template);
    }

}