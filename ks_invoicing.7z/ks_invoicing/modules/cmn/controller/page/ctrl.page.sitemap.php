<?php
namespace NsCMN;

class ClsCtrlPageSitemap extends \NsCMN\ClsCtrlPageCmn {

    protected function do_Default(){
    }
    protected function after_Default(){
    }

    protected function do_List(){
        $this->_template = "pages/sitemap.tpl";
    }                                 
    protected function after_List(){
        $this->_smarty->display($this->_template);
    }



}