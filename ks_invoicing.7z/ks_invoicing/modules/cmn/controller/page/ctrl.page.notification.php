<?php
namespace NsCMN;

class ClsCtrlPageNotification extends \NsCMN\ClsCtrlPageCmn {

    protected function do_Default(){
    }

    protected function do_ViewNotification(){
        $this->_template = "pages/notification.tpl";   
    }
    protected function after_ViewNotification(){
        $this->_smarty->display($this->_template);
    }
}