<?php
namespace NsCMN;

class ClsCtrlPageCity extends \NsCMN\ClsCtrlPageCmn {

    protected function do_Default(){
        header("location:index.php?module=cmn&page=index&action=Unauthorized");
    }

    protected function do_List(){
        $this->_template = "pages/city.list.tpl";
    }

    protected function after_List(){
        $this->_smarty->display($this->_template);
    }

}