controllers.Country  = ['$scope','SrvCountry','SrvCity',function($scope,SrvCountry,SrvCity){
    $scope.arrCountries = [];
    $scope.objCurrentCountry = {index:-1 ,intID:-1 ,strCountry:'' ,arrCities:[]};
    $scope.objSelectedCity = {index:-1 ,intID:-1 ,strCity:''};
    $scope.objNewCountry = {strCountry:''};
    $scope.objNewCity = {strCity:''};

    function init(){
        SrvCountry.List().then(function(response){
            if (response.data.result){
                $scope.arrCountries = response.data.object;
                if($scope.arrCountries.length > 0){
                    $scope.listCity($scope.arrCountries[0],0);
                }                
            }else{
                AlertError(response.data.title, response.data.message);
            }
        });
    }

    $scope.addCountry = function(){
        SrvCountry.Add($scope.objNewCountry.strCountry).then(function(response){
            if(response.data.result == false){
                AlertError("Error", response.data.message);
                return;
            }else{
                AlertSuccess("Success", response.data.message);
                $scope.objNewCountry = {strCountry:''};
                $scope.arrCountries.push(response.data.object);
            }
        });
    }

    $scope.editCountry = function(){
        $("#dlgEditCountry").modal("show");
    }

    $scope.updateCountry = function(strNewCountryName){
        SrvCountry.Update($scope.objCurrentCountry.intID,strNewCountryName).then(function(response){
            if(response.data.result == false){
                AlertError("Error",response.data.message);
            }else{
                AlertSuccess("Success", response.data.message);
                $scope.arrCountries[$scope.objCurrentCountry.index].strCountry = strNewCountryName;
                $scope.objCurrentCountry.strCountry = strNewCountryName;
            }
            $scope.isDisableCountryUpdate = true;
            $("#dlgEditCountry").modal("hide");
        });     
    }

    $scope.deleteCountry = function(){
        SrvCountry.Delete($scope.objCurrentCountry.intID).then(function(response){
            if(response.data.result){
                AlertSuccess("Success", response.data.message);
                angular.forEach($scope.arrCountries,function(objCountry,key){
                    if(objCountry.intID == $scope.objCurrentCountry.intID){
                        $scope.arrCountries.splice(key,1);
                        if($scope.arrCountries.length > 0){
                            $scope.listCity($scope.arrCountries[0],0);
                        }
                    }
                });
            }else{
                AlertError("Error", response.data.message);
            }
        });
    }
    // City Functions
    $scope.listCity = function(objCountry,intCountryIndex){
        $scope.objCurrentCountry.index = intCountryIndex;
        $scope.objCurrentCountry.intID = objCountry.intID;
        $scope.objCurrentCountry.strCountry = objCountry.strCountry;

        SrvCity.ListByCountryID(objCountry.intID).then(function(response){
            if(response.data.result == false){
                AlertError("Error",response.data.message);
                return;
            }
            $scope.objCurrentCountry.arrCities = response.data.object;
        });    
    }

    $scope.addCity = function(){
        SrvCity.Add($scope.objCurrentCountry.intID,$scope.objNewCity.strCity).then(function(response){
            if(response.data.result == false){
                AlertError("Error", response.data.message);
                return;
            }else{
                AlertSuccess("Success", response.data.message);
                $scope.objNewCity = {strCity:''};
                $scope.objCurrentCountry.arrCities.push(response.data.object);
            }
        });
    }

    $scope.editCity = function(objCity, intCityIndex){
        $scope.objSelectedCity = objCity;
        $scope.objSelectedCity.index =  intCityIndex;
        $("#dlgEditCity").modal("show");
    }

    $scope.updateCity = function(strNewCityName){
        SrvCity.Update($scope.objCurrentCountry.intID, $scope.objSelectedCity.intID, strNewCityName).then(function(response){
            if(response.data.result == false){
                AlertError("Error",response.data.message);
            }else{
                AlertSuccess("Success", response.data.message);
                $scope.objCurrentCountry.arrCities [$scope.objSelectedCity.index ].strCity = strNewCityName;
            }
            $scope.isDisableCityUpdate = true;
            $("#dlgEditCity").modal("hide");
        });     
    }

    $scope.deleteCity = function(intCityID ,intCityIndex){
        SrvCity.Delete(intCityID).then(function(response){
            if(response.data.result){
                AlertSuccess("Success", response.data.message);
                $scope.objCurrentCountry.arrCities.splice(intCityIndex,1);
            }else{
                AlertError("Error",response.data.message);
            }
        });
    }
    // the begining of the script 
    init();
}];

app.controller(controllers);