
controllers.Login = ['$scope','$rootScope','$http','SrvLogin',function($scope,$rootScope,$http,SrvLogin){

    $scope.mode = {login: true};
    $scope.objLogin = {strUserName: '', strUrl:'', strPassword:'', boolResult:false, strMessage: ''};
    $scope.objReset = {strUserName: '', boolResult:false, strMessage: ''};
    
    $scope.init=function(){
        $scope.objLogin.strUrl = $("#url").val();
    }
    $scope.ForgetPassword = function(){
        $scope.mode = {login: false};    
        $scope.objReset = {strUserName: '', boolResult:false, strMessage: ''};
    };    
    $scope.CreatePasswordResetRecord = function(isValid){
        if(isValid){
            SrvLogin.CreatePasswordResetRecord($scope.objReset.strUserName).then(function(response){
                $scope.objReset.boolResult = response.data.result;
                if(response.data.result==true){
                    $scope.Login();
                    $scope.objReset = {strUserName: '', boolResult:false, strMessage: ''};
                    $scope.objLogin.strMessage = response.data.message;
                    $scope.objLogin.boolResult = true;
                }else{
                    $scope.objReset.strMessage = response.data.message;
                }
            })
        }else{
            AlertError('Oops', 'Please fix the errors and try again.');
        }
        
    };    
    $scope.Login = function(){
        $scope.mode = {login: true};
    };    
    $scope.LogMeIn = function(isValid){
        if (isValid){
            SrvLogin.LogIn($scope.objLogin.strUserName, $scope.objLogin.strPassword, $scope.objLogin.strUrl).then(function(data){
                $scope.objLogin.strMessage = '';
                $scope.objLogin.boolResult = SrvLogin.objLogin.boolResult;
                $scope.objLogin.strUrl = SrvLogin.objLogin.strUrl;
                if (SrvLogin.objLogin.boolResult==true){
                    localStorage.clear();
                    window.location = SrvLogin.objLogin.strUrl;
                }else{
                    $scope.objLogin.strMessage = SrvLogin.objLogin.strMessage;
                }
            })
        }else{
            AlertError('Oops', 'Please fix the errors and try again.');
        }
    };
    $scope.init();       
}];

app.controller(controllers);