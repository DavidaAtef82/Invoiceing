
controllers.User = ['$scope','SrvUser','SrvUserLevel',function($scope,SrvUser,SrvUserLevel){

    $scope.objUser = {arrData: [], intTotal: 0}
    $scope.objPaging = {intPageNo: 1,intPageSize: $scope.$parent.arrConfig.ListingPageSize,intMaxSize: $scope.$parent.arrConfig.MaxPaginationNumber};
    $scope.objFilter = {
        strUserName: '',
        strDisplayName : '',
        strEmail: '',
        intUserLevelID: '',
    };
    
    $scope.objCurrentUser = null;
    
    $scope.arrUserLevels = [];
    
    function init(){

        SrvUserLevel.List().then(function(response){
            $scope.arrUserLevels = response.data.object;                
        });
        
        $scope.nextPage();
    };

    $scope.filter = function(){
        $scope.objPaging.intPageNo = 1;
        $scope.nextPage();
    }
    
    $scope.nextPage = function (){
        SrvUser.List($scope.objFilter, $scope.objPaging).then(function(response){
            if (response.data.result){
                $scope.objUsers = response.data.object;
            }else{
                $scope.objUsers = {arrData: [], intTotal: 0}
                AlertError(response.data.title, response.data.message);
            }
        })
    };
    
    $scope.reset = function(){
        $scope.objPaging = {intPageNo: 1,intPageSize: $scope.$parent.arrConfig.ListingPageSize,intMaxSize: $scope.$parent.arrConfig.MaxPaginationNumber};
        $scope.objFilter = {
            strUserName: '',
            strDisplayName : '',
            strEmail: '',
            intUserLevelID: '',
        };
        
        $scope.nextPage();                 
    }
    
    $scope.viewDetails = function(intID){
        SrvUser.Load(intID).then(function(response){
            if(response.data.result == false){
                AlertError(response.data.title,response.data.message);
                return;
            }
            $scope.objCurrentUser = response.data.object;    
        });    
    }
    
    $scope.deleteUser = function(intID,index){
        SrvUser.Delete(intID).then(function(response){
            if(response.data.result == 1){
                AlertSuccess(response.data.title,response.data.message);
                $scope.objUsers.arrData.splice(index,1);
            }else if(response.data.result == 2){
                $scope.objUsers.arrData[index].intDisabled = 1;
                AlertSuccess(response.data.title,response.data.message);    
            }else{
                AlertError(response.data.title,response.data.message);
            }    
        });    
    }
    
    $scope.enable = function(intID,index){
        SrvUser.Enable(intID).then(function(response){
            if(response.data.result){
                AlertSuccess(response.data.title,response.data.message);
                $scope.objUsers.arrData[index].intDisabled = 0;
            }else{
                AlertError(response.data.title,response.data.message);    
            }    
        });    
    }
    
    init();
}];

app.controller(controllers);

