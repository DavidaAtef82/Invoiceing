controllers.StartupDialog = ['$scope','SrvStartupDialog','SrvUser',function($scope,SrvStartupDialog,SrvUser){
    
    function init(){
        SrvUser.ListAll().then(function(response){
            if (response.data.result){
                $scope.arrAllUsers = [];
                angular.forEach(response.data.object, function(obj){
                    $scope.arrAllUsers[obj.intID] = obj;    
                });    
            }
        });
        
        SrvStartupDialog.List().then(function(response){
            if (response.data.result){
                $scope.arrDialogs = response.data.object;
            }
        });
    }
    
    $scope.loadDialogUsers = function(intDialogID){
        SrvStartupDialog.loadUsers(intDialogID).then(function(response){
            if(response.data.result){
                $scope.arrDialogUsers = response.data.object;
                $scope.arrNonDialogUsers = angular.copy($scope.arrAllUsers);
                angular.forEach($scope.arrDialogUsers, function(obj){
                    $scope.arrNonDialogUsers.splice(obj.intUserID, 1);
                })    
            }
        });        
    }
    
    $scope.objDialog = {intHeight:0, intWidth:0, strBody:''};
    $scope.view = function(objDialog){
        $scope.objDialog = objDialog;    
    }
    
    $scope.addDialogUser = function(intUserID){
        SrvStartupDialog.addUser().then(function(response){
            if(response.data.result){
                AlertSuccess(response.data.title, response.data.message);
                $scope.arrNonDialogUsers.splice(response.data.object.intUserID, 1);
                $scope.arrDialogUsers.push(response.data.object);
            }else{
                AlertError(response.data.title, response.data.message);
            }
        });    
    }
    
    init();
}];

app.controller(controllers);