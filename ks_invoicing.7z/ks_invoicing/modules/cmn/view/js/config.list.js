controllers.Config  = ['$scope','SrvConfig','SrvLang',function($scope,SrvConfig,SrvLang){
    $scope.arrConfigs = [];
    $scope.arrModules = [];
    $scope.arrModuleSections = null;
    $scope.objCurrentConfig = null;

    function init(){
        SrvConfig.ListModule().then(function(response){
            if(response.data.result){
                $scope.arrModules = response.data.object;             
            }else{
                AlertError(response.data.title, response.data.message);
            }
        });
        
        SrvConfig.ListSectionsByModule().then(function(response){
            if(response.data.result){
                $scope.arrModuleSections = response.data.object; 
            }else{
                AlertError(response.data.title, response.data.message);
            }
        });
        
        SrvConfig.List().then(function(response){
            if(response.data.result){
                $scope.arrConfigs = response.data.object;             
            }else{
                AlertError(response.data.title, response.data.message);
            }
        });
    }

    $scope.$watchGroup(['arrModuleSections', 'arrConfigs', 'arrModules'], function(newValues, oldValues, scope) {
        if($scope.arrModuleSections != null && $scope.arrConfigs.length > 0 && $scope.arrModules.length > 0){
            $scope.listSections($scope.arrModules[0]);
        }
    });
    
    $scope.listSections = function(objModule){
        $scope.arrSections = $scope.arrModuleSections[objModule.intID]; 
        $scope.intCurrentModuleID = objModule.intID;
    }
    
    $scope.validate = function(intIsOptional, strConfigValue){
        if(intIsOptional == '0' && strConfigValue == ''){
            return 'Required!';
        }
    }
    
    $scope.update = function(objItem){
        if(objItem.strConfigKey == 'PayrollCycleStartDay'){
            if(objItem.strConfigValue < 1 || objItem.strConfigValue> 28){
                AlertError('Error','Error in editing config');
                return;
            }                    
        }
        SrvConfig.Update(objItem).then(function(response){
            if(response.data.result == false){
                AlertError("Error", response.data.message);
                return;
            }else{
                AlertSuccess("Success", response.data.message);
            }
        });
    }
    
    $scope.reloadLanguage = function(){
        SrvLang.Reload().then(function(response){
            if(response.data.result == false){
                AlertError(response.data.title, response.data.message);
            }else{
                AlertSuccess(response.data.title, response.data.message);
            }
        });
    }

    init();
}];

app.controller(controllers);