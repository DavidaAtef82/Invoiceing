controllers.UserLevelPermission = ['$scope','$filter','SrvUserLevelPermission','SrvUserLevel','SrvModule',function($scope,$filter,SrvUserLevelPermission,SrvUserLevel,SrvModule){
    $scope.arrUserLevels = [];
    $scope.arrModules = [];
    $scope.arrTypes = ['page', 'service'];
    $scope.arrPermission = [];
    $scope.boolFiltered = false;
    $scope.objFilter = {
        intUserLevelID: null,
        intModuleID: null,
        strType: '',
        strClass: '',
        strAction: '',
        strPermission: ''
    }


    function init(){
        listModules();
        listUserLevels();
    }

    function listModules(){
        $scope.arrModules = [];
        SrvModule.List().then(function(response){
            if(response.data.result){
                $scope.arrModules = response.data.object;
            }
        })
    }

    function listUserLevels(){
        $scope.arrUserLevels = [];
        SrvUserLevel.List().then(function(response){
            if(response.data.result){
                $scope.arrUserLevels = response.data.object;
            }
        })
    }


    $scope.Tags = function(entry){
        if (entry == undefined){
            return '';
        }
        return entry.split(',');
    }

    $scope.Filter = function(){
        $scope.boolFiltered = true;
        SrvUserLevelPermission.ListPermissions($scope.objFilter).then(function(response){
            if (response.data.result){
                $scope.arrPermission = response.data.object;   
            }
        })
    }

    $scope.Reset = function(){
        $scope.boolFiltered = false;
        $scope.arrPermission = [];
        $scope.objFilter = {
            intUserLevelID: null,
            intModuleID: null,
            strType: '',
            strClass: '',
            strAction: '',
            strPermission: ''
        }
    }

    $scope.Edit = function(objPermission, intPermissionIndex){
        $scope.$broadcast('evtPermissionEditStarted', {'objPermission': objPermission, 'intPermissionIndex': intPermissionIndex});
    }

    $scope.Delete = function(objPermission, intPermissionIndex){
        if (window.confirm('Are you sure to delete this permission?') == false){
            return;
        }

        SrvUserLevelPermission.DeletePermission(objPermission.intUserLevelID, objPermission.intActionID).then(function(response) {
            if (response.data.result){
                AlertSuccess(response.data.title,response.data.message);
                $scope.arrPermission.splice(intPermissionIndex, 1);
            }else{
                AlertError(response.data.title,response.data.message);
            }
        })
    }


    $scope.$on('evtPermissionUpdated', function(event, arg) {
        $scope.arrPermission[arg.intPermissionIndex].strPermission = arg.objPermission.strPermission;
    });

    
    init();
}];

controllers.AddPermission = ['$scope','$filter','SrvUserLevelPermission','SrvModule',function($scope,$filter,SrvUserLevelPermission){
    var arrActionsNotInUserLevel = [];

    $scope.boolActionsLoaded = false;
    $scope.arrActions = [];
    $scope.objPermission = {
        intUserLevelID: null,
        intModuleID: null,
        intActionID: null,
        strPermission: ''
    };
    
    $scope.LoadActions = function(){
        $scope.boolActionsLoaded = false;
        arrActionsNotInUserLevel = [];
        SrvUserLevelPermission.ListPermissionsNotInUserLevel($scope.objPermission.intUserLevelID).then(function(response){
            if (response.data.result){
                arrActionsNotInUserLevel = response.data.object;
                $scope.boolActionsLoaded = true;
                // filter loaded actions in case a module is selected
                $scope.FilterActions();
            }
        })
    };

    $scope.FilterActions = function(){
        $scope.arrActions = [];
        if ($scope.objPermission.intModuleID != null) {
            $scope.arrActions = $filter('filter')(
                arrActionsNotInUserLevel, 
                {intModuleID: $scope.objPermission.intModuleID}
            );            
        }
    };

    $scope.AddPermission = function(){
        SrvUserLevelPermission.AddPermission($scope.objPermission).then(function(response){
            if (response.data.result){
                $("#dlgAddPermission").modal('hide');
                $scope.ResetAddPermission();
                AlertSuccess(response.data.title, response.data.message);
            }else{
                AlertError(response.data.title,response.data.message);
            }
        })
    };

    $scope.ResetAddPermission = function() {
        $scope.boolActionsLoaded = false;
        $scope.objPermission = {
            intUserLevelID: null,
            intModuleID: null,
            intActionID: null,
            strPermission: ''
        };
        arrActionsNotInUserLevel = [];
    }

}];

controllers.EditPermission = ['$scope','SrvUserLevelPermission','SrvModule',function($scope,SrvUserLevelPermission,SrvModule){
    $scope.objPermission = null;
    $scope.intPermissionIndex = null;

    $scope.EditPermission = function(){
        SrvUserLevelPermission.EditPermission($scope.objPermission).then(function(response){
            if (response.data.result){
                $("#dlgEditPermission").modal('hide');
                AlertSuccess(response.data.title, response.data.message);
                $scope.$emit('evtPermissionUpdated', {'objPermission': response.data.object, 'intPermissionIndex': $scope.intPermissionIndex});
                $scope.ResetEdit();
            }else{
                AlertError(response.data.title,response.data.message);
            }
        })
    }

    $scope.ResetEdit = function() {
        $scope.objPermission = null;
        $scope.intPermissionIndex = null;
    }

    $scope.$on('evtPermissionEditStarted', function(event, arg){
        $scope.objPermission = JSON.parse(JSON.stringify(arg.objPermission));
        $scope.intPermissionIndex = arg.intPermissionIndex;
    });

}];

app.controller(controllers);