controllers.UserLevel = ['$scope','$filter','SrvUserLevel','SrvModule',function($scope,$filter,SrvUserLevel,SrvModule){
    $scope.arrUserLevelLookup = [];
    $scope.arrUserLevels = [];
    $scope.arrModules = [];
    $scope.objFilter = {
        boolFiltered: false,
        strUserLevel: '',
        intModuleID: ''
    }

    function init(){
        loadModules();
        loadUserLevelLookup();
    }

    function loadModules(){
        $scope.arrModules = [];
        SrvModule.List().then(function(response){
            if(response.data.result){
                $scope.arrModules = response.data.object;
            }
        })
    }

    function loadUserLevelLookup() {
        SrvUserLevel.List().then(function(response){
            if(response.data.result){
                $scope.arrUserLevelLookup = response.data.object;
            }
        })
    }

    function addUserLevelLookup(objUserLevel) {
        $scope.arrUserLevelLookup.push(objUserLevel);
    }

    function updateUserLevelLookup(objUserLevel) {
        $scope.arrUserLevelLookup.forEach(function(item) {
            if (item.intID == objUserLevel.intID) {
                item.strUserLevel = objUserLevel.strUserLevel;
            }
        });
    }

    function removeUserLevelLookup(objUserLevel) {
        var cnt = 0;
        var index = -1;
        $scope.arrUserLevelLookup.forEach(function(item) {
            if (item.intID == objUserLevel.intID) {
                index = cnt;
            }
            cnt++;
        });
        
        if (index != -1) {
            $scope.arrUserLevelLookup.splice(index, 1);
        }
    }


    $scope.validateUserLevel = function(strNewUserLevel, intExecludeID) {
        var boolFound = false;
        $scope.arrUserLevelLookup.forEach(function(objUserLevel) {
            if (objUserLevel.intID != intExecludeID) {
                if (objUserLevel.strUserLevel.toLowerCase() == strNewUserLevel.toLowerCase()){
                    boolFound = true;
                }
            }
        });
        
        if (boolFound) {
            return false;
        } else {
            return true;
        }
    }

    $scope.Filter = function(){
        $scope.objFilter.boolFiltered = true;
        SrvUserLevel.List($scope.objFilter).then(function(response){
            if (response.data.result){
                $scope.arrUserLevels = response.data.object;   
            }
        })
    }

    $scope.Reset = function(){
        $scope.objFilter = {
            boolFiltered: false,
            strUserLevel: '',
            intModuleID: ''
        }
    }


    $scope.EditUserLevel = function(objUserLevel, intUserLevelIndex){
        $("#dlgEditUserLevel").modal('show');
        $scope.$broadcast('evtUserLevelEditStarted', {'objUserLevel': objUserLevel, 'intUserLevelIndex': intUserLevelIndex});
    }

    $scope.DeleteUserLevel = function(objUserLevel, intUserLevelIndex){
        if(!window.confirm('Are you sure you want to delete ' + objUserLevel.strUserLevel + '?')){
            return;
        }

        SrvUserLevel.DeleteUserLevel(objUserLevel.intID).then(function(response){
            if (response.data.result){
                AlertSuccess(response.data.title,response.data.message);
                $scope.arrUserLevels.splice(intUserLevelIndex, 1);
                removeUserLevelLookup(objUserLevel);
            }else{
                AlertError(response.data.title,response.data.message);
            }
        })
    }
    

    $scope.AddDefaultPage = function(objUserLevel, intUserLevelIndex) {
        $("#dlgAddDefaultPage").modal('show');
        $scope.$broadcast('evtDefaultPageAddStarted', {'objUserLevel': objUserLevel, 'intUserLevelIndex': intUserLevelIndex});
    }
    
    $scope.EditDefaultPage = function(objUserLevel, objEditDefaultPage, intUserLevelIndex) {
        $("#dlgEditDefaultPage").modal('show');
        $scope.$broadcast('evtDefaultPageEditStarted', {'objUserLevel': objUserLevel, 'objEditDefaultPage': objEditDefaultPage, 'intUserLevelIndex': intUserLevelIndex});
    }
    
    $scope.DeleteDefaultPage = function(objUserLevel, objEditDefaultPage, intUserLevelIndex) {
        if(!window.confirm('Are you sure you want to delete default page ' + objEditDefaultPage.strTitle + ' for user level ' + objUserLevel.strUserLevel + ' ?')){
            return;
        }

        SrvUserLevel.DeleteDefaultPage(objUserLevel.intID, objEditDefaultPage.intModuleID).then(function(response){
            if (response.data.result){
                AlertSuccess(response.data.title,response.data.message);
                $scope.arrUserLevels[intUserLevelIndex] = response.data.object;
            }else{
                AlertError(response.data.title,response.data.message);
            }
        })
    }


    $scope.$on('evtUserLevelAdded', function(event, arg) {
        $scope.arrUserLevels.push(arg.objUserLevel);
        addUserLevelLookup(arg.objUserLevel);
    });
    
    $scope.$on('evtUserLevelUpdated', function(event, arg) {
        $scope.arrUserLevels[arg.intUserLevelIndex].strUserLevel = arg.objUserLevel.strUserLevel;
        updateUserLevelLookup(arg.objUserLevel);
    });
    
    $scope.$on('evtDefaultPageAdded', function(event, arg) {
        $scope.arrUserLevels[arg.intUserLevelIndex] = arg.objUserLevel;
    });
    
    $scope.$on('evtDefaultPageUpdated', function(event, arg) {
        $scope.arrUserLevels[arg.intUserLevelIndex] = arg.objUserLevel;
    });
    
    init();
}];

controllers.AddUserLevel = ['$scope', 'SrvUserLevel', function($scope, SrvUserLevel){
    $scope.objNewUserLevel = {
        strUserLevel: '',
        intSrcUserLevelID: null
    };
    $scope.objError = {
        strUserLevel:''
    }
    
    function init() {
        
    }

    $scope.ValidateUserLevel = function() {
        $scope.frmAddUserLevel.txtUserLevel.$setValidity("user_level", null);
        $scope.objError.strUserLevel = '';
        
        var ok = $scope.$parent.validateUserLevel($scope.objNewUserLevel.strUserLevel);
        if (!ok){
            $scope.objError.strUserLevel = 'User Level already exists';
            $scope.frmAddUserLevel.txtUserLevel.$setValidity("user_level", false);
        }
    }

    $scope.AddUserLevel = function() {
        SrvUserLevel.AddUserLevel($scope.objNewUserLevel.strUserLevel, $scope.objNewUserLevel.intSrcUserLevelID).then(function(response){
            if (response.data.result){
                $("#dlgAddUserLevel").modal('hide');
                $scope.ResetAddUserLevel();
                AlertSuccess(response.data.title, response.data.message);
                $scope.$emit('evtUserLevelAdded', {'objUserLevel': response.data.object});
            }else{
                AlertError(response.data.title,response.data.message);
            }
        })
    }
    
    $scope.ResetAddUserLevel = function() {
        $scope.frmAddUserLevel.txtUserLevel.$setValidity("user_level", null);
        $scope.objError.strUserLevel = '';
        $scope.objNewUserLevel.strUserLevel = '';
        $scope.objNewUserLevel.intSrcUserLevelID = null;
    }
    
    init();
}];

controllers.EditUserLevel = ['$scope','SrvUserLevel',function($scope,SrvUserLevel){
    $scope.objEditUserLevel = {};
    $scope.intUserLevelIndex = null;
    $scope.objError = {
        strUserLevel:''
    }

    function init() {
        
    }

    $scope.ValidateUserLevel = function() {
        $scope.frmEditUserLevel.txtUserLevel.$setValidity("user_level", null);
        $scope.objError.strUserLevel = '';
        
        var ok = $scope.$parent.validateUserLevel($scope.objEditUserLevel.strUserLevel, $scope.objEditUserLevel.intID);
        if (!ok){
            $scope.objError.strUserLevel = 'User Level already exists';
            $scope.frmEditUserLevel.txtUserLevel.$setValidity("user_level", false);
        }
    }

    $scope.EditUserLevel = function(){
        SrvUserLevel.EditUserLevel($scope.objEditUserLevel).then(function(response){
            if (response.data.result){
                $("#dlgEditUserLevel").modal('hide');
                $scope.ResetEditUserLevel();
                AlertSuccess(response.data.title, response.data.message);
                $scope.$emit('evtUserLevelUpdated', {'objUserLevel': response.data.object, 'intUserLevelIndex': $scope.intUserLevelIndex});
            }else{
                AlertError(response.data.title,response.data.message);
            }
        })
    }

    $scope.ResetEditUserLevel = function() {
        $scope.frmEditUserLevel.txtUserLevel.$setValidity("user_level", null);
        $scope.objError.strUserLevel = '';
    }

    $scope.$on('evtUserLevelEditStarted', function(event, arg){
        $scope.objEditUserLevel = JSON.parse(JSON.stringify(arg.objUserLevel));
        $scope.intUserLevelIndex = arg.intUserLevelIndex;
    });

    init();
}];

controllers.AddDefaultPage = ['$scope', 'SrvUserLevel', function($scope, SrvUserLevel){
    $scope.objUserLevel = null;
    $scope.intUserLevelIndex = null;
    $scope.objNewDefaultPage = {
        intUserLevelID: null,
        intModuleID: null,
        intDefaultModule: '0',
        strDefaultPage: ''
    };
    
    function init() {
        
    }

    $scope.AddDefaultPage = function() {
        SrvUserLevel.AddDefaultPage($scope.objNewDefaultPage).then(function(response){
            if (response.data.result){
                $("#dlgAddDefaultPage").modal('hide');
                $scope.ResetAddDefaultPage();
                AlertSuccess(response.data.title, response.data.message);
                $scope.$emit('evtDefaultPageAdded', {'objUserLevel': response.data.object, 'intUserLevelIndex': $scope.intUserLevelIndex});
            }else{
                AlertError(response.data.title,response.data.message);
            }
        })
    }
    
    $scope.ResetAddDefaultPage = function() {
        $scope.objNewDefaultPage.intModuleID = null;
        $scope.objNewDefaultPage.intDefaultModule = 0;
        $scope.objNewDefaultPage.strDefaultPage = '';
    }
    
    $scope.$on('evtDefaultPageAddStarted', function(event, arg){
        $scope.objUserLevel = JSON.parse(JSON.stringify(arg.objUserLevel));
        $scope.intUserLevelIndex = arg.intUserLevelIndex;
        $scope.objNewDefaultPage.intUserLevelID = arg.objUserLevel.intID;
    });

    init();
}];

controllers.EditDefaultPage = ['$scope', 'SrvUserLevel', function($scope, SrvUserLevel){
    $scope.intUserLevelIndex = null;
    $scope.objEditDefaultPage = {
        intUserLevelID: null,
        strUserLevel: '',
        intModuleID: null,
        intDefaultModule: 0,
        strTitle: '',
        strDefaultPage: ''
    };
    
    $scope.EditDefaultPage = function() {
        SrvUserLevel.EditDefaultPage($scope.objEditDefaultPage).then(function(response){
            if (response.data.result){
                $("#dlgEditDefaultPage").modal('hide');
                $scope.ResetEditDefaultPage();
                AlertSuccess(response.data.title, response.data.message);
                $scope.$emit('evtDefaultPageUpdated', {'objUserLevel': response.data.object, 'intUserLevelIndex': $scope.intUserLevelIndex});
            }else{
                AlertError(response.data.title,response.data.message);
            }
        })
    }
    
    $scope.ResetEditDefaultPage = function() {

    }
    
    $scope.$on('evtDefaultPageEditStarted', function(event, arg){
        $scope.intUserLevelIndex = arg.intUserLevelIndex;

        $scope.objEditDefaultPage = JSON.parse(JSON.stringify(arg.objEditDefaultPage));
        $scope.objEditDefaultPage.intUserLevelID = arg.objUserLevel.intID;
        $scope.objEditDefaultPage.strUserLevel = arg.objUserLevel.strUserLevel;
    });

}];

app.controller(controllers);