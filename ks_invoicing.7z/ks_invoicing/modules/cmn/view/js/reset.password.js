controllers.PasswordReset = ['$scope','SrvLogin',function($scope,SrvLogin){
    $scope.objReset = {intID:'', strKey:'', strUserName: '', strPassword:'',strConfirmPassword:'', boolResult:false, strMessage: ''};
    
    function init(){
        $scope.objReset.intID = $("#txtID").val();
        $scope.objReset.strKey = $("#txtKey").val();
    }
    
    $scope.Reset = function(isValid){
        $scope.objReset;
        if(isValid){
            SrvLogin.ResetPassword($scope.objReset).then(function(response){
                $scope.objReset.strMessage = '';
                $scope.objReset.boolResult = response.data.result;
                if(response.data.result==true){
                    window.location.href = "index.php?module=cmn&page=Index&action=Login";
                }else{
                    $scope.objReset.strMessage = response.data.message;
                }
            })
        }else{
            AlertError('Oops', 'Please fix the errors and try again.');
        }
    };
    init();
}];

app.controller(controllers);