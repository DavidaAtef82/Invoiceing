controllers.CronJob = ['$scope','$rootScope','$http','SrvCronJob','SrvModule',function($scope,$rootScope,$http,SrvCronJob,SrvModule){
    
    $scope.objAddCronJob = { strCron: '', intModuleID: -1, strDescription: '', intYear: '', intMonth: '', intDay:'', intHour:''};
    $scope.objEnum = objEnum;
    $scope.boolIgnoreParam = false;
         
    function init(){
        SrvModule.List().then(function(response){
            if (response.data.result){
                $scope.arrModules = response.data.object;    
            }
        });
        
        SrvCronJob.List().then(function(response){
            if (response.data.result){
                $scope.arrCronJobs = response.data.object;    
                angular.forEach($scope.arrCronJobs, function(obj,index){
                    if(obj.intHour !== '' && obj.intHour !== null){
                        if(obj.intHour.length == 1){
                            obj.intHour = "0" + obj.intHour;    
                        }
                        
                        obj.dtTime = dateFormat('2015-02-02 '+obj.intHour+':00','HH:MM');
                    }else{
                        obj.dtTime = '';
                    }                                   
                })
            }
        });
    }
    
    $scope.toggle = function(){
        $scope.boolIgnoreParam = !$scope.boolIgnoreParam;
    }
    
    $scope.resetAdd = function(){
        $scope.objAddCronJob = { strCron: '', intModuleID: -1, strDescription: '', intYear: '', intMonth: '', intDay:'', intHour:''};
        $("#dlgAddCronJob").modal('hide');
    }
    
    $scope.add = function(){
        SrvCronJob.Add($scope.objAddCronJob).then(function(response){
            if (response.data.result){
                if(response.data.object.intHour !== ''){
                    response.data.object.dtTime = dateFormat('2015-02-02 '+response.data.object.intHour+':00','HH:MM');
                }else{
                    response.data.object.dtTime = '';
                }
                $scope.arrCronJobs.push(response.data.object);    
                AlertSuccess(response.data.title, response.data.message);
                $scope.resetAdd();
            }else{
                AlertError(response.data.title, response.data.message);
            }
        })
    };
    
    $scope.edit = function(obj,index){
        $scope.objEditCronJob = angular.copy(obj);
        $scope.objEditIndex = index;
        $("#dlgEditCronJob").modal("show");
    }
    
    $scope.update = function(){
        SrvCronJob.Update($scope.objEditCronJob).then(function(response){
            if(response.data.result){
                if(response.data.object.intHour !== ''){
                    response.data.object.dtTime = dateFormat('2015-02-02 '+response.data.object.intHour+':00','HH:MM');
                }else{
                    response.data.object.dtTime = '';
                }
                $scope.arrCronJobs[$scope.objEditIndex] = response.data.object;
                AlertSuccess(response.data.title,response.data.message);
                 $("#dlgEditCronJob").modal("hide");
            } else{
                AlertError(response.data.title,response.data.message);    
            }   
        });   
    }
    
    $scope.setRunningCron = function(obj){
        angular.forEach(obj.objDetails.param, function(objParam){
            objParam.value = '';    
        });
        $scope.objRunningCron = obj;    
    }
    
    $scope.run = function(){
        var arrParams = [];
        if ($scope.boolIgnoreParam==false){
            angular.forEach($scope.objRunningCron.objDetails.param,function(obj,index){
                arrParams.push(obj.value);
            });            
        }
        
        $("#dlgRunCronJob").modal('hide');
        SrvCronJob.Run($scope.objRunningCron.intID,arrParams).then(function(response){
            if(response.data.result){
                AlertSuccess(response.data.title,response.data.message);
                $scope.cancelRun();
            } else{
                AlertError(response.data.title,response.data.message);    
            }    
        });    
    }
    
    $scope.cancelRun = function(){
        $scope.arrParamItems = [];
    }
    
    $scope.disable = function(obj,intDisable,index){
        SrvCronJob.Disable(obj.intID,intDisable).then(function(response){
            if(response.data.result){
                $scope.arrCronJobs[index] = response.data.object;
                AlertSuccess(response.data.title,response.data.message);
            } else{
                AlertError(response.data.title,response.data.message);    
            }        
        });                          
    }
    
    init();
}];

app.controller(controllers);