

controllers.Location = ['$scope','$rootScope','$http','SrvLocation','SrvCity','SrvDistrict',function($scope,$rootScope,$http,SrvLocation,SrvCity,SrvDistrict){
    
    $scope.arrLocations = [];
    $scope.arrCities = [];
    $scope.arrDistricts = [];
    $scope.arrDistrictsInCity = [];
    
    $scope.objAddLocation = {strName: '', strPhone:'', intCityID:'',intDistrictID:'',strLongitude: '', strLatitude:'',strAddress:'',strPhone:'',strNotes:''}
        
    function init(){
        SrvCity.List().then(function(response){
            if (response.data.result){
                $scope.arrCities = response.data.object;    
            }else{
                AlertError(response.data.title, response.data.message);
            }
        });
        
        SrvDistrict.List().then(function(response){
            if (response.data.result){
                $scope.arrDistricts = response.data.object;    
            }else{
                AlertError(response.data.title, response.data.message);
            }            
        });
        
        SrvLocation.List().then(function(response){
            if (response.data.result){
                $scope.arrLocations = response.data.object;    
            }else{
                AlertError(response.data.title, response.data.message);
            }
        })
    }
    
    $scope.add = function(){
        SrvLocation.Add($scope.objAddLocation).then(function(response){
            if (response.data.result){
                $scope.arrLocations.push(response.data.object);    
                AlertSuccess(response.data.title, response.data.message);
                $("#dlgAddLocation").modal('hide');
            }else{
                AlertError(response.data.title, response.data.message);
            }
        })
    };
    
    $scope.update  = function(objLocation, name, value, index){
        SrvLocation.Update(objLocation.intID, name, value).then(function(response){
            if (response.data.result){
                AlertSuccess(response.data.title, response.data.message);
            }else{
                AlertError(response.data.title, response.data.message);
            }
        })        
    }
    
    $scope.$watch('objAddLocation.intCityID', function(e){
        if ($scope.objAddLocation.intCityID=='') return;
        SrvDistrict.List($scope.objAddLocation.intCityID).then(function(response){
            if (response.data.result){
                $scope.arrDistrictsInCity = response.data.object;
            }else{
                AlertError(response.data.title, response.data.message);
            }
        });
    })
    
    
    $scope.resetAdd = function(){
        $scope.objAddLocation = {strName: '', strPhone:'', intCityID:'',intDistrictID:'',strLongitude: '', strLatitude:'',strAddress:'',strPhone:'',strNotes:''}        
    }
    
    $scope.del = function(intID,index){
        SrvLocation.Delete(intID).then(function(response){
            if (response.data.result){
                $scope.arrLocations.splice(index,1);
                AlertSuccess(response.data.title, response.data.message);
            }else{
                AlertError(response.data.title, response.data.message);
            }
        })        
    }
    
    
    init();
}];

app.controller(controllers);