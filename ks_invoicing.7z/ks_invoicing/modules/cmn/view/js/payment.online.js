controllers.Payment = ['$scope','$sce','SrvPayment',function($scope,$sce,SrvPayment){

    $scope.objPayment = {strInvoiceReference: '', decAmount:0, strEmail: ''}
    
    function init(){
    }


    $scope.Send = function(){
        SrvPayment.Notify($scope.objPayment.strInvoiceReference, $scope.objPayment.decAmount, $scope.objPayment.strEmail).then(function(response){
            if (response.data.result){
                AlertSuccess(response.data.title, response.data.message);
            }else{
                AlertError(response.data.title, response.data.message);
            }
        })
    }
    
    init();
}]

app.controller(controllers);

