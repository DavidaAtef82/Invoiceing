controllers.City  = ['$scope','SrvCity','SrvDistrict',function($scope,SrvCity,SrvDistrict){
    $scope.arrCities = [];
    $scope.objCurrentCity = {intID:-1, strCity:'', arrDistricts:[]};
    $scope.objNewCity = {strCity:''};
    $scope.objNewDistrict = {strDistrict:''};

    function init(){
        SrvCity.List().then(function(response){
            if (response.data.result){
                $scope.arrCities = response.data.object;
                if($scope.arrCities.length > 0){
                    $scope.listDistrict($scope.arrCities[0]);
                }                
            }else{
                AlertError(response.data.title, response.data.message);
            }
        });
    }

    // City Functions
    $scope.listDistrict = function(objCity){
        $scope.objCurrentCity.intID = objCity.intID;
        $scope.objCurrentCity.strCity = objCity.strCity;
        SrvDistrict.List(objCity.intID).then(function(response){
            if(response.data.result == false){
                AlertError("Error",response.data.message);
                return;
            }
            $scope.objCurrentCity.arrDistricts = response.data.object;
        });    
    }

    $scope.addCity = function(){
        SrvCity.Add($scope.objNewCity.strCity).then(function(response){
            if(response.data.result == false){
                AlertError("Error", response.data.message);
                return;
            }else{
                AlertSuccess("Success", response.data.message);
                $scope.objNewCity = {strCity:''};
                $scope.arrCities.push(response.data.object);
            }
        });
    }

    $scope.deleteCity = function(){
        SrvCity.Delete($scope.objCurrentCity.intID).then(function(response){
            if(response.data.result){
                AlertSuccess("Success", response.data.message);
                angular.forEach($scope.arrCities,function(objCity,key){
                    if(objCity.intID == $scope.objCurrentCity.intID){
                        $scope.arrCities.splice(key,1);
                        if($scope.arrCities.length > 0){
                            $scope.listDistrict($scope.arrCities[0]);
                        }
                    }
                });
            }else{
                AlertError("Error", response.data.message);
            }
        });
    }
    
    // District Functions
    $scope.addDistrict = function(){
        SrvDistrict.Add($scope.objCurrentCity.intID, $scope.objNewDistrict.strDistrict).then(function(response){
            if(response.data.result == false){
                AlertError("Error", response.data.message);
                return;
            }else{
                AlertSuccess("Success", response.data.message);
                $scope.objCurrentCity.arrDistricts.push(response.data.object);
                $scope.objNewDistrict = {strDistrict:''};
            }
        });
    }

    $scope.deleteDistrict = function(intDistrictID, index){
        SrvDistrict.Delete(intDistrictID).then(function(response){
            if(response.data.result){
                AlertSuccess("Success", response.data.message);
                $scope.objCurrentCity.arrDistricts.splice(index,1);
            }else{
                AlertError("Error",response.data.message);
            }
        });
    }
    
    init();
}];

app.controller(controllers);