controllers.ModuleAction = ['$scope','SrvModule',function($scope,SrvModule){

    $scope.objCurrentModule = null;
    $scope.arrModules = [];
    $scope.arrActions = [];


    function init(){
        listModules();
    }

    function listModules(){
        $scope.arrModules = [];
        SrvModule.List().then(function(response){
            if(response.data.result){
                $scope.arrModules = response.data.object;
                $scope.objCurrentModule = $scope.arrModules[0];
                $scope.ListModuleActions($scope.objCurrentModule);
            }
        })

    }


    $scope.ListModuleActions = function(objModule){
        $scope.objCurrentModule = objModule;
        SrvModule.ListModuleActions(objModule.intID).then(function(response){
            if (response.data.result){
                $scope.arrActions = response.data.object;   
            }
        })
    }

    $scope.DeleteModuleAction = function(intActionID, index){
        if (window.confirm('Are you sure to delete this module action?') == false) {
            return;
        }

        SrvModule.DeleteModuleAction(intActionID).then(function(response){
            if (response.data.result) {
                AlertSuccess(response.data.title, response.data.message);
                $scope.arrActions.splice(index,1);
            } else {
                AlertError(response.data.title, response.data.message);
            }
        })
    }

    $scope.ViewModuleAction = function(objAction){
        $scope.$broadcast('evtViewModuleAction', {'objModule': $scope.objCurrentModule, 'objAction': objAction});
    }
    
    $scope.AddModuleAction = function(){
        $scope.$broadcast('evtAddModuleAction', {'objModule': $scope.objCurrentModule})
    }

    init();
}];

controllers.ViewModuleAction = ['$scope','SrvModule',function($scope,SrvModule){
    $scope.objModule = null;
    $scope.objAction = null;

    $scope.$on('evtViewModuleAction', function(event,arg){
        $scope.objModule = JSON.parse(JSON.stringify(arg.objModule));
        $scope.objAction = JSON.parse(JSON.stringify(arg.objAction));
    });
}];

controllers.AddModuleAction = ['$scope','SrvModule',function($scope,SrvModule){
    $scope.arrTypes = ["service", "page"];
    $scope.objModule = null;
    $scope.objModuleAction = {
        intModuleID: null,
        strControllerType: '',
        strControllerClass: '',
        strAction: ''
    }
    
    $scope.AddModuleAction = function(){
        SrvModule.AddModuleAction($scope.objModuleAction).then(function(response){
            if (response.data.result){
                $("#dlgAddModuleAction").modal('hide');
                AlertSuccess(response.data.title, response.data.message);
                $scope.$parent.arrActions.push(response.data.object);
            }else{
                AlertError(response.data.title, response.data.message);
            }
        })
    }
    
    $scope.ResetAddModuleAction = function() {
        $scope.objModuleAction = {
            intModuleID: null,
            strControllerType: '',
            strControllerClass: '',
            strAction: ''
        }

        $scope.frmAddModuleAction.$setPristine();
    }

    $scope.$on('evtAddModuleAction', function(event,arg){
        $scope.objModule = JSON.parse(JSON.stringify(arg.objModule));
        $scope.objModuleAction.intModuleID = arg.objModule.intID;
    });
}];

app.controller(controllers);