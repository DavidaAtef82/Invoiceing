controllers.User = ['$scope','$timeout','AngularShamNotification','SrvUser','SrvEmployee','SrvModule','SrvTeam', function($scope,$timeout,angularShamNotification,SrvUser,SrvEmployee,SrvModule,SrvTeam){
                    
    var arrModulesOriginal = [];

    $scope.objUser = {
        strUsername:'',
        strEmail:'',
        strDisplayName:'',
        strPassword:'',
        strConfirmPassword:'',
        intSendWelcomeEmail:0,
        intEmployeeID:null,
        intTeamID:null
    };
    
    $scope.objError = {
        strUsername:'',
        strPassword:'',
        strPasswordConfirm:''
    }

    $scope.arrEmployees = [];
    $scope.arrBranches = [];
    $scope.arrTeams = [];
    $scope.arrModules = [];
    $scope.objCmbDisabled = {
        'boolEmployee': true,
        'boolTeam': true
    };
    
    $scope.objEnum = objEnum;

    function init(){
        SrvModule.List().then(function(response) {
            if(response.data.result){
                $scope.arrModules = response.data.object; 
                // Avoid reference copy
                arrModulesOriginal = JSON.parse(JSON.stringify(response.data.object));
            }
        })
        
        SrvEmployee.List().then(function(response) {
            if(response.data.result){
                $scope.arrEmployees = response.data.object;    
            }
        })

        SrvTeam.List().then(function(response) {
            if(response.data.result){
                $scope.arrTeams = response.data.object;    
            }
        })            
    }
    
    function checkUsername(strUsername){
        var intUsernameMinChars = $scope.$parent.arrConfig['cmn_UsernameMinChars'] - 2;
        var intUsernameMaxChars = $scope.$parent.arrConfig['cmn_UsernameMaxChars'] - 2;
        
        var objRegEx = new RegExp("[a-zA-Z]+((?:[a-zA-Z0-9]|([._])(?![._])){" + intUsernameMinChars + "," + intUsernameMaxChars + "})[a-zA-Z0-9]+", "g");
        var arrResult = strUsername.match(objRegEx);

        if (!arrResult || arrResult.length != 1) {
            return false;
        } 

        if (arrResult[0] != strUsername) {
            return false;
        }
        
        return true;
    }
    
    function checkUserLevel(){
        var arrUserLevelIDs = [];
        var boolError = false;
        var strError = '';

        $scope.arrModules.forEach(function(objModule){
            objModule.arrUserLevels.forEach(function(objUserLevel){
                // Check only if error flag is not raised
                if (!boolError && objUserLevel.intChecked == 1) {
                    if (objUserLevel.intID == objEnum.ClsBllUserLevel.LEVEL_EMPLOYEE || objUserLevel.intID == objEnum.ClsBllUserLevel.LEVEL_HEAD) {
                        if (!$scope.objUser.intEmployeeID) {
                            strError = objLang.cmn.ERROR_CODE.ERR_1182;
                            boolError = true;
                        }
                    } else if (objUserLevel.intID == objEnum.ClsBllUserLevel.LEVEL_SALES_PERSON) {
                        if (!$scope.objUser.intTeamID) {
                            strError = objLang.cmn.ERROR_CODE.ERR_1183;
                            boolError = true;
                        }
                    }
                    arrUserLevelIDs.push(objUserLevel.intID);
                }
            });
        });

        if (arrUserLevelIDs.length == 0) {
            // No Userlevel selected
            strError = objLang.cmn.ERROR_CODE.ERR_1177;
            boolError = true;
        }

        if (boolError) {
            AlertError(objLang.cmn.PAGE_USER_NEW.LNG_6627, strError);
            return false;
        } else {
            return arrUserLevelIDs;
        }
    };
    
    function resetForm(){
        $scope.objUser = {
            strUsername:'',
            strEmail:'',
            strDisplayName:'',
            strPassword:'',
            strConfirmPassword:'',
            intSendWelcomeEmail:0,
            intEmployeeID:null,
            intTeamID:null
        };
        
        $scope.objError = {
            strUsername:'',
            strPassword:'',
            strPasswordConfirm:''
        }
        
        // Avoid reference copy
        $scope.arrModules = JSON.parse(JSON.stringify(arrModulesOriginal));
        
        // Reset form to initial status
        frmNewUser.reset();
        $scope.frmNewUser.$setUntouched();
    }
    

    $scope.ValidateUsername = function(){
        $scope.frmNewUser.txtUsername.$setValidity("username", null);
        $scope.objError.strUsername = '';

        if ($scope.objUser.strUsername == undefined || $scope.objUser.strUsername == '') {
            $scope.frmNewUser.txtUsername.$setValidity("username", false);
            $scope.objError.strUsername = objLang.cmn.PAGE_USER_NEW.LNG_6605;
            return;
        }
    
        // Try client side validation first
        var ok = checkUsername($scope.objUser.strUsername);
        if (ok == false) {
            $scope.frmNewUser.txtUsername.$setValidity("username", false);
            $scope.objError.strUsername = objLang.cmn.ERROR_CODE.ERR_1175;
            return;
        }

        // If passed client side validation -> proceeed to server side validation
        angularShamNotification.setDisabled(true, -1);
        SrvUser.ValidateUsername($scope.objUser.strUsername).then(function(response){
            angularShamNotification.setDisabled(false);
            
            if(response.data.result == false){
                $scope.frmNewUser.txtUsername.$setValidity("username", false);
                $scope.objError.strUsername = response.data.message;
            }
        });
    };
    
    $scope.ValidatePassword = function(){
        $scope.frmNewUser.txtPassword.$setValidity("password", null);
        $scope.objError.strPassword = '';

        if ($scope.objUser.strPassword == undefined || $scope.objUser.strPassword == '') {
            $scope.frmNewUser.txtPassword.$setValidity("password", false);
            $scope.objError.strPassword = objLang.cmn.PAGE_USER_NEW.LNG_6605;
            return;
        }

        var intPasswordMinChars = $scope.$parent.arrConfig['cmn_PasswordMinChars'];
        if ($scope.objUser.strPassword.length < intPasswordMinChars) {
            $scope.frmNewUser.txtPassword.$setValidity("password", false);
            $scope.objError.strPassword = objLang.cmn.ERROR_CODE.ERR_1176;
            return;
        }
    };

    $scope.ConfirmPassword = function(){
        $scope.frmNewUser.txtConfirmPassword.$setValidity("confirm", null);
        $scope.objError.strPasswordConfirm = '';

        if ($scope.objUser.strConfirmPassword != $scope.objUser.strPassword) {
            $scope.frmNewUser.txtConfirmPassword.$setValidity("confirm", false);
            $scope.objError.strPasswordConfirm = objLang.cmn.ERROR_CODE.ERR_1184;
        }
    };
    
    $scope.SetUserLevel = function(objUserlevel){
        if (objUserlevel.intID == objEnum.ClsBllUserLevel.LEVEL_EMPLOYEE || objUserlevel.intID == objEnum.ClsBllUserLevel.LEVEL_HEAD) {
            $scope.objCmbDisabled.boolEmployee = !objUserlevel.intChecked;
        }
        if (objUserlevel.intID == objEnum.ClsBllUserLevel.LEVEL_SALES_PERSON) {
            $scope.objCmbDisabled.boolTeam = !objUserlevel.intChecked;
        }
    };
    
    $scope.Add = function(boolContinue){
        var arrUserLevelIDs = checkUserLevel();
        if (arrUserLevelIDs == false) {
            return;
        }

        SrvUser.Add($scope.objUser, arrUserLevelIDs).then(function(response) {
            if(response.data.result){
                AlertSuccess(response.data.title, response.data.message);
                if (boolContinue) {
                    resetForm();
                } else {
                    window.location = "index.php?module="+_strModule+"&page=User&action=List";
                }
            }else{
                AlertError(response.data.title, response.data.message);
            }
        });
    };

    init(); 
}];

app.controller(controllers);