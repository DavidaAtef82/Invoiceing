var objEnum = {
    ClsBllModule: {
        MODULE_HR : 5,
        MODULE_CMN : 6,
        MODULE_REC : 7,
        MODULE_TSK : 8,
        MODULE_SF : 11,
        MODULE_ACC : 12,
    },
    ClsBllUserLevel: {
        // Common
        LEVEL_ADMINISTRATOR : 1,
        LEVEL_SYSTEM : 47,
        // HR
        LEVEL_EMPLOYEE : 27,
        LEVEL_HEAD : 21,
        LEVEL_HR_SUPERVISOR : 23,
        LEVEL_BENEFIT_SUPERVISOR : 24,
        LEVEL_TRAINING_SUPERVISOR : 25,
        // Recruitment
        LEVEL_RECRUITMENT_SUPERVISOR : 45,
        LEVEL_CHECKLIST_USER : 46,
        // Salesforce
        LEVEL_SALES_PERSON : 48,
        LEVEL_SALES_MANAGER : 49,
        LEVEL_DATA_MANAGER : 52,
    },
    ClsBllCronJob: {
        STATUS_STOPPED: 'stopped',
        STATUS_RUNNING: 'running'
    }
    
}