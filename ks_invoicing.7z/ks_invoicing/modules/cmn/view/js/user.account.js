controllers.User = ['$scope','SrvUser',function($scope,SrvUser){
    $scope.objChangePassword = {};

    function init(){
        SrvUser.Load().then(function(response){
            if(response.data.result == false){
                AlertError(response.data.title,response.data.message);
                return;
            }
            $scope.objUser = response.data.object; 
        }); 
    };

    $scope.update = function(){
        SrvUser.UpdateMyAccount($scope.objUser).then(function(response) {
            if(response.data.result == false){
                AlertError(response.data.title,response.data.message);
                return;
            }
            AlertSuccess(response.data.title,response.data.message);
            window.location.reload();
        });
    }

    $scope.changePassword = function(){
        SrvUser.ChangePassword($scope.objUser.intID, $scope.objChangePassword).then(function(response){
            if(response.data.result){
                AlertSuccess(response.data.title,response.data.message);
                $scope.closeChangePasswordDialog();
            }else{
                AlertError(response.data.title,response.data.message);
            }
        });
    }

    $scope.closeChangePasswordDialog = function(){
        $scope.objChangePassword = {};
        $("#dlgChangePassword").modal('hide');
    }

    init(); 
}];

app.controller(controllers);