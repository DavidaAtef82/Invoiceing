controllers.Notification = ['$scope','SrvUser','SrvNotification','$sce',function($scope,SrvUser,SrvNotification,$sce){
    $scope.objUser = null;
    $scope.arrNotifications = [];
    $scope.objFilter = {intIsRead:''};
    
    function init(){
        SrvUser.Load().then(function(response){
            if(response.data.result == false){
                AlertError(response.data.title,response.data.message);
                return;
            }

            $scope.objUser = response.data.object;
            SrvNotification.List($scope.objUser.intID).then(function(response){
                $scope.arrNotifications = response.data.object;
            });
        });
    }
    
    $scope.toHTML = function(strText){
        return $sce.trustAsHtml(strText);    
    }                
    
    $scope.Update = function(intNotificationID,intRead,index){
        SrvNotification.Update(intNotificationID,intRead).then(function(response){
            if(response.data.result == false){
                AlertError(response.data.title,response.data.message);
                return;
            }
            
            $scope.arrNotifications[index].intIsRead = intRead;
            var intNotificationCount = parseInt(response.data.object);

            $("#lblMasterNotificationCount").html(intNotificationCount);
            $("#lblDropDownNotificationCount").html(intNotificationCount);
        })
    }

    $scope.Delete = function(intNotificationID,index){
        SrvNotification.Delete(intNotificationID).then(function(response){
            if(response.data.result == false){
                AlertError(response.data.title,response.data.message);
                return;
            }
            AlertSuccess(response.data.title,response.data.message);
            $scope.arrNotifications.splice(index,1);
            $("#lblMasterNotificationCount").html(response.data.object);
        })
    }
    
    init();
}]

app.controller(controllers);