controllers.User = ['$scope','$location','SrvUser','SrvEmployee','SrvLocation','SrvModule','SrvTeam',
                    function($scope,$location,SrvUser,SrvEmployee,SrvLocation,SrvModule,SrvTeam){
                        
        $scope.objUser = {strUserName:'',strPassword:'',strConfirmPassword:'',strDisplayName:'',strEmail:'',
                            intEmployeeID:null,intTeamID:'',objFile:null};
        
        $scope.arrEmployees = [];
        $scope.arrBranches = [];
        $scope.arrModules = [];
        
        $scope.intUserID = $location.url($location.$$absUrl).search().user_id;
        
        $scope.objEnum = objEnum;

        function init(){
            SrvUser.Load($scope.intUserID).then(function(response){
                if(response.data.result == false){
                    AlertError(response.data.title,response.data.message);
                    return;
                }
                $scope.objUser = response.data.object; 
                $scope.objUser.strConfirmPassword = $scope.objUser.strPassword;
                SrvModule.List().then(function(response) {
                    if(response.data.result){
                        $scope.arrModules = response.data.object;
                        angular.forEach($scope.arrModules,function(objModule,index){
                            angular.forEach(objModule.arrUserLevels,function(obj,index){
                                if($scope.objUser.arrUserLevelIDs.indexOf(obj.intID) != -1){
                                    obj.intChecked = 1;   
                                }
                            })
                        })
                    }
                })
            }); 
            
            SrvTeam.List().then(function(response) {
                if(response.data.result){
                    $scope.arrTeams = response.data.object;    
                }
            })  
            
            SrvEmployee.List().then(function(response) {
                if(response.data.result){
                    $scope.arrEmployees = response.data.object;    
                }
            })
            
        };
        
        $scope.save = function(){
            SrvUser.Update($scope.objUser,$scope.arrModules).then(function(response){
                if(response.data.result == false){
                    AlertError(response.data.title,response.data.message);
                    return;
                }
                AlertSuccess(response.data.title,response.data.message);
                $scope.objUser.intPhotoID = response.data.object.intPhotoID;
                $scope.objUser.objFile = null;
            });
        }
        init(); 
}];

app.controller(controllers);