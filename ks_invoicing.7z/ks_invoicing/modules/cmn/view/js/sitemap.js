controllers.Sitemap = ['$scope','$filter','SrvSitemap',function($scope,$filter,SrvSitemap){

    $scope.objFilter = {
        strMenuText: ''
    }
    $scope.arrMenu = [];
    $scope.arrMenuRaw = [];

    function init(){
        SrvSitemap.List().then(function(response){
            if (response.data.result){
                $scope.arrMenu  = response.data.object;
                $scope.arrMenuRaw = angular.copy($scope.arrMenu);
            }
        })
    }

    $scope.RepeatNumber = function(chr,times) {
        var temp = '';
        for(i=0;i<times;i++){
            if (i==0){
                temp = "|";
            }
            temp += chr;
        }
        return temp;   
    }

    $scope.Filter = function(){
        $scope.arrMenu = $filter('filter')($scope.arrMenuRaw, {strItemText: $scope.objFilter.strMenuText});    
    }
    
    $scope.Reset = function(){
        $scope.arrMenu = angular.copy($scope.arrMenuRaw);
        $scope.objFilter.strMenuText = '';
    }

    $scope.Delete = function(intMenuID, index){
        SrvSitemap.Delete(intMenuID).then(function(response){
            if (response.data.result){
                AlertSuccess(response.data.title, response.data.message);
                $scope.arrMenu.splice(index,1);
                var tempIndex = $scope.arrMenuRaw.findIndex(function(element){
                    if (element.intID == intMenuID){
                        return element;
                    }
                });
                $scope.arrMenu.splice(tempIndex,1);
            }
        })
    }

    $scope.Edit = function(objMenu, index){
        $scope.$broadcast('edit', {'objMenu': objMenu, 'index': index});
    }

    $scope.Add = function(){
        $scope.$broadcast('add', {'objModule': $scope.objCurrentModule})
    }

    init();
}];

controllers.Edit = ['$scope','SrvSitemap','SrvModule',function($scope,SrvSitemap, SrvModule){

    $scope.objMenu = {};
    /*$scope.arrTopMenu = [];*/
    $scope.arrModules = [];
    $scope.arrActions = [];
    $scope.index = null;

    function init(){
        SrvSitemap.ListTopMenu().then(function(response){
            if (response.data.result){
                $scope.arrTopMenu = response.data.object;
            }
        });
        SrvModule.List().then(function(response){
            if (response.data.result){
                $scope.arrModules = response.data.object;    
            }
        })
    }
    
    /*$scope.ChangeGroupOrder = function(){
        $scope.objMenu.decGroupOrder = $scope.objMenu.objGroupOrder.decGroupOrder;
        $scope.objMenu.intItemLevel = $scope.objMenu.objGroupOrder.intItemLevel
    }*/

    $scope.ListActions = function(){
        $scope.arrActions = [];
        SrvModule.ListModuleActions($scope.objMenu.intModuleID).then(function(response){
            if (response.data.result){
                $scope.arrActions = response.data.object;
            }
        })
    },

    $scope.Save = function(){
        SrvSitemap.Update($scope.objMenu).then(function(response){
            if (response.data.result){
                AlertSuccess(response.data.title, response.data.message);
                $scope.$parent.arrMenu[$scope.index] = response.data.object;
                $("#dlgEdit").modal('hide');
            }else{
                AlertError(response.data.title, response.data.message);
            }
        })
    }

    init();

    $scope.$on('edit', function(event,arg){
        $scope.objMenu = arg.objMenu;
        $scope.intActionID = $scope.objMenu.intActionID;
        $scope.ListActions();
        /*var elementId = $scope.arrMenu.findIndex(function(element){
            if (element.decGroupOrder == $scope.objMenu.decGroupOrder){
                return element;
            }
        })
        $scope.objMenu.objGroupOrder = $scope.arrMenu[elementId];*/
    });

}];

controllers.Add = ['$scope','SrvSitemap','SrvModule',function($scope,SrvSitemap,SrvModule){
    $scope.objMenu = {
        decGroupOrder: null,
        decItemOrder: null,
        intItemLevel: null,
        intModuleID: null,
        intActionID: null,
        strItemText: null,
        strItemStyle: null,
        boolShowInMenu:false
    };
    
    $scope.arrTopMenu = [];
    $scope.arrModules = [];
    $scope.arrActions = [];

    function init(){
        SrvSitemap.ListTopMenu().then(function(response){
            if (response.data.result){
                $scope.arrTopMenu = response.data.object;
            }
        });

        SrvModule.List().then(function(response){
            if (response.data.result){
                $scope.arrModules = response.data.object;    
            }
        })
    }

    $scope.ListActions = function(){
        $scope.arrActions = [];
        SrvModule.ListModuleActions($scope.objMenu.intModuleID).then(function(response){
            if (response.data.result){
                $scope.arrActions = response.data.object;
            }
        })
    },

    $scope.Save = function(){
        SrvSitemap.Save($scope.objMenu).then(function(response){
            if (response.data.result){
                AlertSuccess(response.data.title, response.data.message);
                $scope.$parent.arrMenu.push(response.data.object);
                $scope.$parent.arrMenuRaw.push(response.data.object);
                $("#dlgAdd").modal('hide');
            }else{
                AlertError(response.data.title, response.data.message);
            }
        })
    }

    init();

}];

app.controller(controllers);