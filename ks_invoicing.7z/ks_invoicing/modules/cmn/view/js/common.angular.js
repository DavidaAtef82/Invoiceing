var _strModule = 'cmn';

var app = angular.module('CMN',['ui.bootstrap','xeditable','angularShamSpinner','bootstrap.wrapper','ui.select','mgo-angular-wizard']);

app.run(function(editableOptions) {
    editableOptions.theme = 'bs3'; 
    $('body').show();
});

app.directive('focus', function($timeout) {
    return {
        scope : {trigger : '@focus'},
        link : function(scope, element){
            scope.$watch('trigger', function(value) {
                if(value === "true"){
                    $timeout(function() {element[0].focus();});
                }
            });
        }
    };
});
app.directive('applyUniform',function($timeout){
    return {
        restrict:'A',
        require: 'ngModel',
        link: function(scope, element, attr, ngModel) {
            element.uniform({useID: false});
            scope.$watch(function() {return ngModel.$modelValue}, function() {
                $timeout(jQuery.uniform.update, 0);
            } );
        }
    };
});
app.directive('file', function(){
    return {
        scope: {
            file: '='
        },
        link: function(scope, el, attrs){
            el.bind('change', function(event){
                var files = event.target.files;
                var file = files[0];
                scope.file = file ? file : undefined;
                //scope.$apply();

                var reader = new FileReader();
                reader.onload = function(evntFile) {  
                    scope.file.content = evntFile.target.result;

                    scope.$apply();
                };
                if (scope.file==undefined){
                    return;
                }
                reader.readAsDataURL(scope.file)
            });
        }
    };
});
app.directive('ngConfirmClick', function(){
    //ng-confirm-click="Are you sure to delete?" confirmed-click="Delete(x)"
    return {
        link: function (scope, element, attr) {
            var strMessage = attr.ngConfirmClick || "Are you sure?";
            var clickAction = attr.confirmedClick;
            element.bind('click', function (event) {
                if (window.confirm(strMessage)) {
                    scope.$eval(clickAction)
                }
            });
        }
    };
});

app.filter('datetime', function() {
    return function(data, format){
        if (data == undefined || data == '' || format == undefined || format == '') {
            return data;
        }

        data = data.trim();
        var arrDateTime = data.match(/^(\d{4})\-(\d{2})\-(\d{2}) (\d{2}):(\d{2}):(\d{2})$/);
        var arrDate = data.match(/^(\d{4})\-(\d{2})\-(\d{2})$/);
        var arrTime = data.match(/^(\d{2}):(\d{2}):(\d{2})$/);
        var arrTimeNoSeconds = data.match(/^(\d{2}):(\d{2})$/);
        var date = null;

        if (arrDateTime !== null) {
            // Datetime string
            var year = parseInt(arrDateTime[1], 10);
            var month = parseInt(arrDateTime[2], 10) - 1; // months are 0-11
            var day = parseInt(arrDateTime[3], 10);
            var hour = parseInt(arrDateTime[4], 10);
            var minute = parseInt(arrDateTime[5], 10);
            var second = parseInt(arrDateTime[6], 10);
            date = new Date(year, month, day, hour, minute, second);
        } else if (arrDate !== null) {
            // Date string
            var year = parseInt(arrDate[1], 10);
            var month = parseInt(arrDate[2], 10) - 1; // months are 0-11
            var day = parseInt(arrDate[3], 10);
            date = new Date(year, month, day);
        } else if (arrTime !== null) {
            var hour = parseInt(arrTime[1], 10);
            var minute = parseInt(arrTime[2], 10);
            var second = parseInt(arrTime[3], 10);
            date = new Date(1900, 1, 1, hour, minute, second);
        } else if (arrTimeNoSeconds !== null) {
            var hour = parseInt(arrTimeNoSeconds[1], 10);
            var minute = parseInt(arrTimeNoSeconds[2], 10);
            date = new Date(1900, 1, 1, hour, minute);
        } else {
            return data;
        }

        return dateFormat(date, format);
    }
});
app.filter('numberFixedLen', function () {
    return function(a,b){
        return(1e4+a+"").slice(-b)
    }
});

app.service('SrvCountry', ['$rootScope','$http','$location',function($rootScope,$http) {
    var service = {
        List: function(){
            var strUrl = 'service.php?';
            strUrl+='module='+_strModule;
            strUrl+='&service=Country';
            strUrl+='&action=List';
            return $http.post(strUrl);
        },
        Add: function(strCountry){
            var strUrl = 'service.php?';
            strUrl+='module='+_strModule;
            strUrl+='&service=Country';
            strUrl+='&action=Add';
            strUrl+='&country='+strCountry;
            return $http.post(strUrl);
        },
        Update: function(intCountryID,strCountry){
            var strUrl = 'service.php?';
            strUrl+='module='+_strModule;
            strUrl+='&service=Country';
            strUrl+='&action=Update';
            strUrl+='&country_id='+intCountryID;
            strUrl+='&country='+strCountry;
            return $http.post(strUrl);
        },
        Delete: function(intCountryID){
            var strUrl = 'service.php?';
            strUrl+='module='+_strModule;
            strUrl+='&service=Country';
            strUrl+='&action=Delete';
            strUrl+='&country_id='+intCountryID;
            return $http.post(strUrl);
        }

    }
    return service;
}]);

app.service('SrvCity', ['$rootScope','$http','$location',function($rootScope,$http) {
    var service = {
        List: function(){
            var strUrl = 'service.php?';
            strUrl+='module='+_strModule;
            strUrl+='&service=City';
            strUrl+='&action=List';
            return $http.post(strUrl);
        },
        ListByCountryID: function(intCountryID){
            var strUrl = 'service.php?';
            strUrl+='module='+_strModule;
            strUrl+='&service=City';
            strUrl+='&action=ListByCountryID';
            strUrl+='&country_id='+intCountryID;
            return $http.post(strUrl);
        },
        Add: function(intCountryID, strCity){
            var strUrl = 'service.php?';
            strUrl+='module='+_strModule;
            strUrl+='&service=City';
            strUrl+='&action=Add';
            strUrl+='&country_id='+intCountryID;
            strUrl+='&city='+strCity;
            return $http.post(strUrl);
        },
        Update: function(intCountryID, intCityID, strCity){
            var strUrl = 'service.php?';
            strUrl+='module='+_strModule;
            strUrl+='&service=City';
            strUrl+='&action=Update';
            strUrl+='&country_id='+intCountryID;
            strUrl+='&city_id='+intCityID;
            strUrl+='&city='+strCity;
            return $http.post(strUrl);
        },
        Delete: function(intCityID){
            var strUrl = 'service.php?';
            strUrl+='module='+_strModule;
            strUrl+='&service=City';
            strUrl+='&action=Delete';
            strUrl+='&city_id='+intCityID;
            return $http.post(strUrl);
        }

    }
    return service;
}]);
app.service('SrvConfig', ['$rootScope','$http',function($rootScope,$http) {
    var service = {
        List: function(){
            var strUrl = 'service.php?';
            strUrl+='module=cmn';
            strUrl+='&service=Config';
            strUrl+='&action=List';
            return $http.post(strUrl);
        },
        ListModule: function(){
            var strUrl = 'service.php?';
            strUrl+='module=cmn';
            strUrl+='&service=Config';
            strUrl+='&action=ListModule';
            return $http.post(strUrl);
        },
        ListSectionsByModule: function(){
            var strUrl = 'service.php?';
            strUrl+='module=cmn';
            strUrl+='&service=Config';
            strUrl+='&action=ListSectionsByModule';
            return $http.post(strUrl);
        },
        Update: function(objItem){
            var strUrl = 'service.php?';
            strUrl+='module=cmn';
            strUrl+='&service=Config';
            strUrl+='&action=Update';
            return $http.post(strUrl, {'objItem':objItem});
        },
        GetConfigurations: function(){
            var strUrl= 'service.php?'
            strUrl+= "module=cmn";
            strUrl+= "&service=Config";
            strUrl+= "&action=GetConfigurations";
            return $http.post(strUrl);
        }
    }
    return service;
}]);
app.service('SrvCronJob', ['$rootScope','$http',function($rootScope,$http) {
    var service = {
        List: function(){
            var strUrl = 'service.php?';
            strUrl+='module=cmn';
            strUrl+='&service=CronJob';
            strUrl+='&action=List';
            return $http.post(strUrl);
        },
        Add: function(obj){
            var strUrl = 'service.php?';
            strUrl+='module=cmn';
            strUrl+='&service=CronJob';
            strUrl+='&action=Add';
            return $http.post(strUrl,{objAddCronJob:obj});
        },
        Update: function(obj){
            var strUrl = 'service.php?';
            strUrl+='module=cmn';
            strUrl+='&service=CronJob';
            strUrl+='&action=Update';
            return $http.post(strUrl,{objCronJob:obj});
        },
        Run: function(intID, arrParams){
            var strUrl = 'service.php?';
            strUrl+='module=cmn';
            strUrl+='&service=CronJob';
            strUrl+='&action=Run';
            strUrl+='&cron_id='+intID;
            return $http.post(strUrl,{parameters:arrParams});
        },
        Disable: function(intID, intDisable){
            var strUrl = 'service.php?';
            strUrl+='module=cmn';
            strUrl+='&service=CronJob';
            strUrl+='&action=Disable';
            strUrl+='&cron_id='+intID;
            strUrl+='&disable='+intDisable;
            return $http.post(strUrl);
        },
    }
    return service;
}]);
app.service('SrvDistrict', ['$rootScope','$http','$location',function($rootScope,$http) {
    var service = {
        List: function(intCityID){
            var strUrl = 'service.php?';
            strUrl+='module=cmn';
            strUrl+='&service=District';
            strUrl+='&action=List';
            if(intCityID!=undefined){
                strUrl+='&city_id='+intCityID;    
            }
            return $http.post(strUrl);
        },
        Add: function(intCityID, strDistrict){
            var strUrl = 'service.php?';
            strUrl+='module=cmn';
            strUrl+='&service=District';
            strUrl+='&action=Add';
            strUrl+='&city_id='+intCityID;
            strUrl+='&district='+strDistrict;
            return $http.post(strUrl);
        },
        Delete: function(intDistrictID){
            var strUrl = 'service.php?';
            strUrl+='module=cmn';
            strUrl+='&service=District';
            strUrl+='&action=Delete';
            strUrl+='&district_id='+intDistrictID;
            return $http.post(strUrl);
        }
    }
    return service;
}]);
app.service('SrvEmployee', ['$http',function($http) {
    var service = {
        List: function(){
            var strUrl = 'api.php?';
            strUrl+='module=hr';
            strUrl+='&api=Employees';
            strUrl+='&key='+localStorage.ApiKey;
            return $http.post(strUrl);
        },
    };
    return service;
}]);
app.service('SrvLang', ['$rootScope','$http',function($rootScope,$http) {
    var service = {
        Reload: function(){
            var strUrl = 'service.php?';
            strUrl+='module=cmn';
            strUrl+='&service=Lang';
            strUrl+='&action=Reload';
            return $http.post(strUrl);
        }
    }
    return service;
}]);
app.service('SrvLocation', ['$rootScope','$http','$location',function($rootScope,$http) {
    var service = {
        List: function(){
            var strUrl = 'service.php?';
            strUrl+='module=cmn';
            strUrl+='&service=Location';
            strUrl+='&action=List';
            return $http.post(strUrl);
        },
        Add: function(objAddLocation){
            var strUrl = 'service.php?';
            strUrl+='module=cmn';
            strUrl+='&service=Location';
            strUrl+='&action=Add';
            return $http.post(strUrl, {objLocation: objAddLocation});
        },
        Update: function(intLocationID, name, value){
            var strUrl = 'service.php?';
            strUrl+='module=cmn';
            strUrl+='&service=Location';
            strUrl+='&action=Update';
            strUrl+='&location_id='+intLocationID;
            strUrl+='&name='+name;
            strUrl+='&value='+value;
            return $http.post(strUrl);
        },
        Delete: function(intLocationID){
            var strUrl = 'service.php?';
            strUrl+='module=cmn';
            strUrl+='&service=Location';
            strUrl+='&action=Delete';
            strUrl+='&location_id='+intLocationID;
            return $http.post(strUrl);
        }

    }
    return service;
}]);
app.service('SrvLogin', ['$rootScope','$http','$location',function($rootScope,$http,$location) {
    var service = {

        objReset: {strMessage: '',boolResult: false},
        objLogin: {strMessage: '',boolResult: false, strUrl:''},

        LogIn: function(strUserName, strPassword, strPageUrl){
            var strUrl = 'service.php?';
            strUrl+='module=cmn';
            strUrl+='&service=Index';
            strUrl+='&action=Login';
            if(strPageUrl != undefined){
                strUrl+='&url='+encodeURIComponent(strPageUrl);    
            }                              
            return $http.post(strUrl, {username:strUserName, password: strPassword})
            .success(function(data){
                service.objLogin.boolResult = data.result;
                if(service.objLogin.boolResult == true){
                    service.objLogin.strUrl = data.url;
                }else{
                    service.objLogin.strUrl = strPageUrl;
                    service.objLogin.strMessage = data.reason;
                }
            });
        },
        CreatePasswordResetRecord: function(strUserName){
            var strUrl = 'service.php?';
            strUrl+='module=cmn';
            strUrl+='&service=Index';
            strUrl+='&action=CreatePasswordResetRecord';
            return $http.post(strUrl, {username: strUserName});
        },
        ResetPassword: function(objReset){
            var strUrl = 'service.php?';
            strUrl+='module='+_strModule;
            strUrl+='&service=Index';
            strUrl+='&action=ResetPassword';
            return $http.post(strUrl,{objReset: objReset});
        },
    }
    return service;
}]);
app.service('SrvModule', ['$http',function($http) {
    var service = {
        List: function(){
            var strUrl = 'service.php?';
            strUrl+='module=cmn';
            strUrl+='&service=Module';
            strUrl+='&action=List';
            return $http.post(strUrl);
        },
        ListModuleActions: function(intModuleID){
            var strUrl = 'service.php?';
            strUrl+='module='+_strModule;
            strUrl+='&service=Module';
            strUrl+='&action=ListModuleActions';
            strUrl+='&module_id='+intModuleID;
            return $http.post(strUrl);
        },
        DeleteModuleAction: function(intActionID){
            var strUrl = 'service.php?';
            strUrl+='module='+_strModule;
            strUrl+='&service=Module';
            strUrl+='&action=DeleteModuleAction';
            strUrl+='&action_id='+intActionID;
            return $http.post(strUrl);            
        },
        AddModuleAction: function(objModuleAction){
            var strUrl = 'service.php?';
            strUrl+='module='+_strModule;
            strUrl+='&service=Module';
            strUrl+='&action=AddModuleAction';
            return $http.post(strUrl, {'objModuleAction': objModuleAction});                        
        }
    }
    return service;
}]);
app.service('SrvNotification', ['$http',function($http) {
    var service = {
        List: function(intUserID){
            var strUrl = 'service.php?';
            strUrl+='module='+_strModule;
            strUrl+='&service=Notification';
            strUrl+='&action=List';
            strUrl+="&user_id="+intUserID;
            return $http.post(strUrl);
        },
        Update: function(intNotificationID,boolRead){
            var strUrl = 'service.php?';
            strUrl+='module='+_strModule;
            strUrl+='&service=Notification';
            strUrl+='&action=Update';
            strUrl+="&notification_id="+intNotificationID;
            strUrl+="&status="+boolRead;
            return $http.post(strUrl);
        },
        Delete: function(intNotificationID){
            var strUrl = 'service.php?';
            strUrl+='module='+_strModule;
            strUrl+='&service=Notification';
            strUrl+='&action=Delete';
            strUrl+="&notification_id="+intNotificationID;
            return $http.post(strUrl);
        },
    };
    return service;
}]);
app.service('SrvPayment', ['$http',function($http) {
    var service = {
        Notify: function(reference,amount,email){
            var strUrl = 'service.php?';
            strUrl+='module='+_strModule;
            strUrl+='&service=PaymentOnline';
            strUrl+='&action=Notify';
            strUrl+="&reference="+reference;
            strUrl+="&email="+email;
            strUrl+="&amount="+amount;
            return $http.post(strUrl);
        }
    };
    return service;
}]);
app.service('SrvSitemap', ['$http',function($http) {
    var service = {
        List: function(){
            var strUrl = 'service.php?';
            strUrl+='module=cmn';
            strUrl+='&service=Sitemap';
            strUrl+='&action=List';
            return $http.post(strUrl);
        },
        ListTopMenu: function(){
            var strUrl = 'service.php?';
            strUrl+='module=cmn';
            strUrl+='&service=Sitemap';
            strUrl+='&action=ListTopMenu';
            return $http.post(strUrl);
        },
        Delete: function(intMenuID){
            var strUrl = 'service.php?';
            strUrl+='module=cmn';
            strUrl+='&service=Sitemap';
            strUrl+='&action=Delete';
            strUrl+='&menu_id='+intMenuID;
            return $http.post(strUrl);
        },
        Update: function(objMenu){
            var strUrl = 'service.php?';
            strUrl+='module=cmn';
            strUrl+='&service=Sitemap';
            strUrl+='&action=Update';
            return $http.post(strUrl,{'objMenu': objMenu});
        },
        Save: function(objMenu){
            var strUrl = 'service.php?';
            strUrl+='module=cmn';
            strUrl+='&service=Sitemap';
            strUrl+='&action=Save';
            return $http.post(strUrl,{'objMenu': objMenu});
        }
    }
    return service;
}]);
app.service('SrvStartupDialog', ['$http',function($http) {
    var service = {
        List: function(){
            var strUrl = 'service.php?';
            strUrl+='module=cmn';
            strUrl+='&service=StartupDialog';
            strUrl+='&action=List';
            return $http.post(strUrl);
        },
        loadUsers: function(intDialogID){
            var strUrl = 'service.php?';
            strUrl+='module=cmn';
            strUrl+='&service=StartupDialog';
            strUrl+='&action=loadUsers';
            strUrl+='&dialog_id='+intDialogID;
            return $http.post(strUrl);
        },
        Stop: function(intDialogID){
            var strUrl = 'service.php?';
            strUrl+='module=cmn';
            strUrl+='&service=StartupDialog';
            strUrl+='&action=CloseStartupDialog';
            strUrl+='&dialog_id='+intDialogID;
            return $http.post(strUrl);
        }
    }
    return service;
}]);
app.service('SrvTeam', ['$http',function($http) {
    var service = {
        List: function(){
            var strUrl = 'api.php?';
            strUrl+='module=sf';
            strUrl+='&api=Teams';
            strUrl+='&key='+localStorage.ApiKey;
            return $http.post(strUrl);
        },
    };
    return service;
}]);
app.service('SrvUser', ['$http',function($http) {
    var service = {
        List: function(objFilter,objPage){
            var strUrl = 'service.php?';
            strUrl+='module='+_strModule;
            strUrl+='&service=User';
            strUrl+='&action=List';
            return $http.post(strUrl, {'objFilter':objFilter,'objPage':objPage});
        },
        ListAll: function(intDisabled){
            var strUrl = 'service.php?';
            strUrl+= "module="+_strModule;
            strUrl+= "&service=User";
            strUrl+= "&action=ListAll";
            if(intDisabled != undefined){
                strUrl+= "&disabled="+intDisabled;
            }
            return $http.post(strUrl);
        },
        Load: function(intUserID){
            var strUrl = 'service.php?';
            strUrl+='module='+_strModule;
            strUrl+='&service=User';
            strUrl+='&action=Load';
            if(intUserID != undefined){
                strUrl+='&user_id='+intUserID;    
            }                                 
            return $http.post(strUrl);
        },
        Add: function(objUser,arrUserLevelIDs){
            var strUrl = 'service.php?';
            strUrl+='module='+_strModule;
            strUrl+='&service=User';
            strUrl+='&action=Add';
            return $http.post(strUrl, {'objUser':objUser, 'arrUserLevelIDs':arrUserLevelIDs});
        },
        Update: function(objUser, arrModules){
            var strUrl = 'service.php?';
            strUrl+='module='+_strModule;
            strUrl+='&service=User';
            strUrl+='&action=Update';
            if(objUser.objFile != undefined){
                strUrl+='&type='+objUser.objFile.type;
                strUrl+='&size='+objUser.objFile.size;
            }
            return $http.post(strUrl, {'objUser':objUser, 'objModule':arrModules});
        },
        UpdateMyAccount: function(objUser){
            var strUrl = 'service.php?';
            strUrl+='module='+_strModule;
            strUrl+='&service=User';
            strUrl+='&action=UpdateMyAccount';
            if(objUser.objFile != undefined){
                strUrl+='&type='+objUser.objFile.type;
                strUrl+='&size='+objUser.objFile.size;
            }
            return $http.post(strUrl, {'objUser':objUser});
        },
        Delete: function(intUserID){
            var strUrl = 'service.php?';
            strUrl+='module='+_strModule;
            strUrl+='&service=User';
            strUrl+='&action=Delete';
            strUrl+='&user_id='+intUserID;
            return $http.post(strUrl);
        },
        Enable: function(intUserID){
            var strUrl = 'service.php?';
            strUrl+='module='+_strModule;
            strUrl+='&service=User';
            strUrl+='&action=Enable';
            strUrl+='&user_id='+intUserID;
            return $http.post(strUrl);
        },
        ChangePassword: function(intUserID, objChangePassword){
            var strUrl = 'service.php?';
            strUrl+='module='+_strModule;
            strUrl+='&service=User';
            strUrl+='&action=ChangePassword';
            strUrl+='&user_id='+intUserID;
            return $http.post(strUrl,{objChangePassword: objChangePassword});
        },
        ValidateUsername: function(strUserName){
            var strUrl = 'service.php?';
            strUrl+='module='+_strModule;
            strUrl+='&service=User';
            strUrl+='&action=ValidateUsername';
            strUrl+='&username='+strUserName;
            return $http.post(strUrl);
        },
    };
    return service;
}]);
app.service('SrvUserLevel', ['$http',function($http) {
    var service = {
        List: function(objFilter){
            var strUrl = 'service.php?';
            strUrl+='module='+_strModule;
            strUrl+='&service=UserLevel';
            strUrl+='&action=List';
            if (objFilter == undefined) {
                return $http.post(strUrl);
            } else {
                return $http.post(strUrl, {'objFilter':objFilter});
            }
        },
        ValidateUserLeve: function(strUserLevel){
            var strUrl = 'service.php?';
            strUrl+='module='+_strModule;
            strUrl+='&service=UserLevel';
            strUrl+='&action=ValidateUserLevel';
            strUrl+='&user_level='+strUserLevel;
            return $http.post(strUrl);
        },
        AddUserLevel: function(strUserlevel, intSrcUserlevel){
            var strUrl = 'service.php?';
            strUrl+='module='+_strModule;
            strUrl+='&service=UserLevel';
            strUrl+='&action=AddUserLevel';
            strUrl+='&user_level='+strUserlevel;
            if (intSrcUserlevel != undefined){
                strUrl+='&src_user_level_id='+intSrcUserlevel;    
            }
            return $http.post(strUrl);
        },
        DeleteUserLevel: function(intUserLevelID){
            var strUrl = 'service.php?';
            strUrl+='module='+_strModule;
            strUrl+='&service=UserLevel';
            strUrl+='&action=DeleteUserLevel';
            strUrl+='&user_level_id='+intUserLevelID;
            return $http.post(strUrl);
        },
        EditUserLevel: function(objUserLevel){
            var strUrl = 'service.php?';
            strUrl+='module='+_strModule;
            strUrl+='&service=UserLevel';
            strUrl+='&action=EditUserLevel';
            return $http.post(strUrl, {'objUserLevel': objUserLevel});
        },
        AddDefaultPage: function(objDefaultPage){
            var strUrl = 'service.php?';
            strUrl+='module='+_strModule;
            strUrl+='&service=UserLevel';
            strUrl+='&action=AddDefaultPage';
            return $http.post(strUrl, {'objDefaultPage': objDefaultPage});
        },
        EditDefaultPage: function(objDefaultPage){
            var strUrl = 'service.php?';
            strUrl+='module='+_strModule;
            strUrl+='&service=UserLevel';
            strUrl+='&action=EditDefaultPage';
            return $http.post(strUrl, {'objDefaultPage': objDefaultPage});
        },
        DeleteDefaultPage: function(intUserLevelID, intModuleID){
            var strUrl = 'service.php?';
            strUrl+='module='+_strModule;
            strUrl+='&service=UserLevel';
            strUrl+='&action=DeleteDefaultPage';
            strUrl+='&user_level_id='+intUserLevelID;
            strUrl+='&module_id='+intModuleID;
            return $http.post(strUrl);
        },
    };
    return service;
}]);
app.service('SrvUserLevelPermission', ['$http',function($http) {
    var service = {
        ListPermissions: function(objFilter) { //ok
            var strUrl = 'service.php?';
            strUrl+='module='+_strModule;
            strUrl+='&service=UserLevelPermission';
            strUrl+='&action=ListPermissions';
            return $http.post(strUrl, {'objFilter':objFilter});
        },
        ListPermissionsNotInUserLevel: function(intUserLevelID) {
            var strUrl = 'service.php?';
            strUrl+='module='+_strModule;
            strUrl+='&service=UserLevelPermission';
            strUrl+='&action=ListPermissionsNotInUserLevel';
            strUrl+='&user_level_id='+intUserLevelID;
            return $http.post(strUrl);
        },
        AddPermission: function(objPermission) {
            var strUrl = 'service.php?';
            strUrl+='module='+_strModule;
            strUrl+='&service=UserLevelPermission';
            strUrl+='&action=AddPermission';
            return $http.post(strUrl, {'objUserLevelAction': objPermission});
        },
        EditPermission: function(objPermission) {
            var strUrl = 'service.php?';
            strUrl+='module='+_strModule;
            strUrl+='&service=UserLevelPermission';
            strUrl+='&action=EditPermission';
            return $http.post(strUrl, {'objUserLevelAction': objPermission});
        },
        DeletePermission: function(intUserLevelID, intActionID) {
            var strUrl = 'service.php?';
            strUrl+='module='+_strModule;
            strUrl+='&service=UserLevelPermission';
            strUrl+='&action=DeleteAction';
            strUrl+='&user_level_id='+intUserLevelID;
            strUrl+='&action_id='+intActionID;
            return $http.post(strUrl);
        }
    };
    return service;
}]);

if(typeof controllers == 'undefined'){
    var controllers = {};    
}
controllers.Common = ['$scope','SrvConfig',function($scope,SrvConfig){
    $scope.objLang = objLang;
    $scope.arrConfig = [];

    function init(){
        if (localStorage.length==0){
            SrvConfig.GetConfigurations().then(function(response){
                if (response.data.result){
                    var arr = response.data.object;
                    angular.forEach(arr, function(value, key){
                        localStorage[key] = value;
                    })
                }
            })
        }
        $scope.arrConfig = localStorage;
    }

    init();
}];