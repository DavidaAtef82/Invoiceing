<?php

define('MODULE_NAME', 'mgr');
define('MODULE_ID', '0');
define('MODULE_WEB_PATH', WEB__MODULES . '/' . MODULE_NAME);
define('MODULE_LOCAL_PATH', LOCAL__MODULES . '/' . MODULE_NAME);