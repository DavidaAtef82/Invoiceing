<?php
namespace NsMGR;

class ClsCtrlCronMgrDemo extends ClsCtrlCronMgr2{

    protected function getSourceDBVersion(){
        $obj = $this->getCurrentDBVersion();
        return $obj->strVersion;
    }

    protected function getTargetDBVersion(){
        $obj = $this->getCurrentDBVersion();
        return $obj->strVersion;
    }

    protected function getSkipSucceeded(){return false;}

    protected function setDependency(){
        $this->addDependent('method_2', 'method_1');
        $this->addDependent('method_3', 'method_2');
    }
    
    
    protected function method_1(){
        return false;
    }

    protected function method_2(){
        return true;
    }

    protected function method_3(){
        return true;
    }
}