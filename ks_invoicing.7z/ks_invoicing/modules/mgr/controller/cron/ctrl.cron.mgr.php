<?php
namespace NsMGR;

abstract class ClsCtrlCronMgr extends \NsFWK\ClsCtrlCron{
    
    const FAILED = 0;
    const SUCCEEDED = 1;
    const SKIPPED = 2;
    
    private $_arrDependency = array();
    private $_arrMethods = array();
    private $_arrRslt = array();
    
    abstract protected function getSourceDBVersion();
    abstract protected function getTargetDBVersion();
    abstract protected function getSkipSucceeded();
    abstract protected function setDependency();

    protected function do_Default(){
        $strFunctionName = __METHOD__ . ' @ ' . __FILE__;
        $objLog = \NsFWK\ClsLogger::GetInstance();
        $objLog->LogDebug("$strFunctionName ... Execution Started");
        
        $objCurrentVersion = $this->getCurrentDBVersion();
        $strSourceVersion = $this->getSourceDBVersion();
        $strTargetVersion = $this->getTargetDBVersion();

        // Check if current version is the source version of the migration
        if($objCurrentVersion->strVersion != $strSourceVersion && $objCurrentVersion->strVersion != $strTargetVersion){
            print("\nInvalid source/target/current versions: $strSourceVersion/$strTargetVersion/{$objCurrentVersion->strVersion}.");
            $objLog->LogDebug("$strFunctionName ... Execution Terminated!");
            return false;
        }

        // Check if current version is locked
        if($objCurrentVersion->intLocked){
            print("\nExecution terminated as current version: {$objCurrentVersion->strVersion} is locked..");
            $objLog->LogDebug("$strFunctionName ... Execution Terminated!");
            return false;
        }
        
        // Create target version in locked
        if($objCurrentVersion->strVersion != $strTargetVersion){
            $objCurrentVersion = new \NsCMN\ClsBllVersion();
            $objCurrentVersion->strVersion = $strTargetVersion;
            $objCurrentVersion->intLocked = 1;
            $ok = $objCurrentVersion->Save();
            if(!$ok){
                return false;
            }
        }else{
            $ok = $objCurrentVersion->Lock();
            if(!$ok){
                return false;
            }
        }

        $this->loadMethods();
        $this->setDependency();

        // Sort array ASC by method name
        $cnt = count($this->_arrMethods);

        $this->write("Running $cnt migration methods started..", 2, 0);
        $this->write("=============================================", 1, 0);

        $intSucceeded = 0;
        $intFailed = 0;
        $intSkipped = 0;

        foreach($this->_arrMethods as $method){
            $this->write(">> Running $method", 3,1);

            // Check if method previously succeeded
            $ok = $this->getSkipSucceeded();
            if($ok){
                $ok = $this->getLastRunResult($method);
                if($ok){
                    // Method skipped but should not block dependencies because it already succeeded
                    $intSkipped++;
                    $this->_arrRslt[$method] = self::SUCCEEDED; // 1;

                    $this->write(">> $method is skipped as it already succeeded in a previous run.", 1, 1);
                    continue;
                }
            }

            // Check dependency
            $ok = $this->checkDependency($method);
            if($ok !== true){
                // Method skipped but should block dependencies because it did not run
                $intSkipped++;
                $this->_arrRslt[$method] = self::SKIPPED; // 2;

                $str = implode(',', $ok);
                $this->write(">> $method is skipped as the following dependencies have skipped or failed: $str.", 1, 1);
                continue;
            }

            // Execute method
            $ok = $this->$method();
            \NsCMN\ClsBllVersionMigration::Create($objCurrentVersion->strVersion, $method, $ok);

            if($ok){
                $intSucceeded++;
                $this->_arrRslt[$method] = self::SUCCEEDED; // 1;
                $ok = 'Succeeded';
            }else{
                $intFailed++;
                $this->_arrRslt[$method] = self::FAILED; // 0;
                $ok = 'Failed';
            }

            $this->write(">> $method $ok.", 1, 1);
        }

        // Unlock version
        $objCurrentVersion->Unlock();

        $this->write("===========================", 3, 1);
        $this->write("Migration script completed..");
        $this->write("Methods succeeded: $intSucceeded/$cnt");
        $this->write("Methods failed: $intFailed/$cnt");
        $this->write("Methods skipped: $intSkipped/$cnt", 1, 3);

        $objLog->LogDebug("$strFunctionName ... Execution Completed!");
        return true;
    }


    private function loadMethods(){
        $this->_arrMethods = array();

        $arrMethods = get_class_methods(get_called_class());
        foreach($arrMethods as $method){
            if(strpos($method, 'method_') === false){
                continue;
            }
            
            $this->_arrMethods[] = $method;
        }

        sort($this->_arrMethods, SORT_NATURAL);
    }


    protected function getCurrentDBVersion(){
        $objVersion = new \NsCMN\ClsBllVersion();
        $obj = $objVersion->GetCurrentVersion();
        if(empty($obj)){
            return new \NsCMN\ClsBllVersion();
        }else{
            return $obj;
        }
    }
    
    protected function getResult($method){
        if(isset($this->_arrRslt[$method])){
            // Result found
            return $this->_arrRslt[$method];
        }else{
            // No result found
            return null;
        }
    }
    
    protected function getLastRunResult($strMethod){
        $objMigration = new \NsCMN\ClsBllVersionMigration();
        $objLastRun = $objMigration->GetLastRun($this->getTargetDBVersion(), $strMethod);
        if($objLastRun){
            return $objLastRun->intResult;
        }else{
            return false;
        }
    }


    protected function addDependent($method, $dependsOn){
        $this->_arrDependency[$method][] = $dependsOn;
    }

    protected function removeDependent($method, $dependsOn){
        unset($this->_arrDependency[$method][$dependsOn]);
    }

    protected function checkDependency($method){
        if(!isset($this->_arrDependency[$method]) || empty($this->_arrDependency[$method])){
            return true;
        }

        $arrBlockedMethods = array();
        $arr = $this->_arrDependency[$method];
        foreach($arr as $fn){
            $rslt = $this->getResult($fn);
            if(is_null($rslt) || $rslt != self::SUCCEEDED){
                // Dependency function did not succeed (either skipped or failed)
                // OR Dependency function is not found in _arrRslt => its turn is not up yet
                $arrBlockedMethods[] = $fn;
            }
        }
        
        if(empty($arrBlockedMethods)){
            return true;
        }else{
            return $arrBlockedMethods;
        }
    }


    protected function write($strMessage, $intLinesBefore = 1, $intLinesAfter = 0){
        for($i=0; $i<$intLinesBefore; $i++){
            print("\n");
        }
        print($strMessage);
        for($i=0; $i<$intLinesAfter; $i++){
            print("\n");
        }
    }

    /**
    * This function is used to execute sql and print execution result
    * Do not use this function if you wish to get results other than true/false
    * @param string $strSQL: SQL string to execute
    * @param array $arrSQLParam: SQL param bind array
    * @param string $strMessage: Custom message to print along with Succeeded/Failed
    * @return bool: true for success, false for failure. In case of failure,
    * DB error message is written to standard output stream.
    */
    protected function executeSQL($strSQL, $arrSQLParam = array(), $strMessage = '') {
        $DB = &\ADODB_Connection_Manager::GetConnection('customer');
        if (!$DB) {
            // Invalid connection key
            return false;
        }

        if (!empty($arrSQLParam)) {
            $rslt = $DB->Execute($strSQL, $arrSQLParam);
        } else {
            $rslt = $DB->Execute($strSQL);
        }

        if ($rslt){
            $this->write("Succeeded: $strMessage");
            return true;
        }else{
            $this->write("Failed: $strMessage");
            $this->write($DB->ErrorMsg(), 1, 1);
            return false;
        }
    }

    protected function truncateTable($table){
        $strSQL = "SET FOREIGN_KEY_CHECKS = 0;";
        $this->executeSQL($strSQL, array(), "FOREIGN_KEY_CHECKS = 0;");
        $strSQL = "TRUNCATE $table";
        $this->executeSQL($strSQL, array(), $strSQL); 
        $strSQL = "SET FOREIGN_KEY_CHECKS = 1;";
        $this->executeSQL($strSQL, array(), "FOREIGN_KEY_CHECKS = 1;");
    }    

    protected function getReferentialConstraint($strReferencedTable, $strTable){
        $strSQL = "SELECT CONSTRAINT_NAME
                    FROM information_schema.REFERENTIAL_CONSTRAINTS
                    WHERE CONSTRAINT_SCHEMA = '" . DB_CATALOG . "'";
        if(!empty($strReferencedTable)){
            $strSQL .= " AND REFERENCED_TABLE_NAME = '$strReferencedTable'";
        }
        if(!empty($strTable)){
            $strSQL .= " AND TABLE_NAME = '$strTable'";
        }
        $strSQL .= ";";

        $DB = &\ADODB_Connection_Manager::GetConnection('customer');
        $arr = $DB->GetCol($strSQL);
        if($arr === false){
            $this->write($DB->errorMsg(), 1, 1);
        }
        return $arr;
    }
}