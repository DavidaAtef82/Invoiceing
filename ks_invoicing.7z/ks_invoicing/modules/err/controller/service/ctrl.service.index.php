<?php
namespace NsERR;

class ClsCtrlServiceIndex extends \NsFWK\ClsCtrlServicePublic {
    protected function do_Default() {
        $intResponse = 0;
        $strMessage = '';

        if (isset($this->_data['response'])) {
            if (in_array($this->_data['response'], ClsBllError::$arrHttpResponse)) {
                $intResponse = $this->_data['response'];
            }
        }
        if ($intResponse == 0) {
            $intResponse = 404;
        }
        
        if (isset($this->_data['message'])) {
            $strMessage = $this->_data['message'];
        } else {
            $strMessage = ClsBllError::$arrHttpResponse[$intResponse];
        }

        http_response_code($intResponse);
        header('Content-Type: application/json');
        $arr['result'] = false;
        $arr['title'] = ClsBllError::$arrHttpResponse[$intResponse];
        $arr['message'] = $strMessage;
        print(json_encode($arr));
    }
}