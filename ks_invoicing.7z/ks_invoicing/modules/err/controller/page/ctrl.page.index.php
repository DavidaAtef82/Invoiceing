<?php
namespace NsERR;

class ClsCtrlPageIndex extends \NsFWK\ClsCtrlPagePublic {
    protected function do_Default() {
        $intResponse = 0;
        $strMessage = '';

        if (isset($this->_data['response'])) {
            if (in_array($this->_data['response'], ClsBllError::$arrHttpResponse)) {
                $intResponse = $this->_data['response'];
            }
        }
        if ($intResponse == 0) {
            $intResponse = 404;
        }
        
        if (isset($this->_data['title'])) {
            $strTitle = $this->_data['title'];
        } else {
            $strTitle = ClsBllError::$arrHttpResponse[$intResponse];
        }

        if (isset($this->_data['message'])) {
            $strMessage = $this->_data['message'];
        } else {
            $strMessage = ClsBllError::$arrHttpResponse[$intResponse];
        }

        $this->_smarty->assign('Response', $intResponse);
        $this->_smarty->assign('Title', $strTitle);
        $this->_smarty->assign('Message', $strMessage);
        $this->_template = 'pages/error.tpl';
    }
    protected function after_Default(){
        $intResponse = $this->_smarty->getTemplateVars('Response');
        
        http_response_code($intResponse);
        $this->_smarty->display($this->_template);
    }

}