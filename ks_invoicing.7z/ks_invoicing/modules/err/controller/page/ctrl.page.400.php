<?php
namespace NsERR;

class ClsCtrlPage400 extends \NsFWK\ClsCtrlPagePublic {
    protected function do_Default() {

        $this->_smarty->assign('Response', 400);
        $this->_smarty->assign('Title', 'Bad Request');
        $this->_smarty->assign('Message', 'The request could not be understood by the server due to malformed syntax.');
        $this->_template = 'pages/error.tpl';

        http_response_code($intResponse);
        $this->_smarty->display($this->_template);
    }

}