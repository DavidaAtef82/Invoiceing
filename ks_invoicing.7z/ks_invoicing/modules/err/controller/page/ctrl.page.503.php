<?php
namespace NsERR;

class ClsCtrlPage503 extends \NsFWK\ClsCtrlPagePublic {
    protected function do_Default() {

        $this->_smarty->assign('Response', 503);
        $this->_smarty->assign('Title', 'Service Unavailable');
        $this->_smarty->assign('Message', 'The service is currently unavailable for maintenance or upgrades reasons. Please come back in a while or contact your technical support for more details.');
        $this->_template = 'pages/error.tpl';

        http_response_code($intResponse);
        $this->_smarty->display($this->_template);
    }

}