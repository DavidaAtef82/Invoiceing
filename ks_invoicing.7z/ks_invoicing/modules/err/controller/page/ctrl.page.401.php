<?php
namespace NsERR;

class ClsCtrlPage401 extends \NsFWK\ClsCtrlPagePublic {
    protected function do_Default() {

        $this->_smarty->assign('Response', 401);
        $this->_smarty->assign('Title', 'Unauthorized');
        $this->_smarty->assign('Message', 'You need to provide proper authorization to access this protected resource.');
        $this->_template = 'pages/error.tpl';

        http_response_code($intResponse);
        $this->_smarty->display($this->_template);
    }

}