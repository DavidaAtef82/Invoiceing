<?php
namespace NsERR;

class ClsCtrlPage403 extends \NsFWK\ClsCtrlPagePublic {
    protected function do_Default() {

        $this->_smarty->assign('Response', 403);
        $this->_smarty->assign('Title', 'Forbidden');
        $this->_smarty->assign('Message', 'You do not have the necessary permissions to access this protected resource.');
        $this->_template = 'pages/error.tpl';

        http_response_code($intResponse);
        $this->_smarty->display($this->_template);
    }

}