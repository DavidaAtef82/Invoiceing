<?php
namespace NsERR;

class ClsCtrlPage500 extends \NsFWK\ClsCtrlPagePublic {
    protected function do_Default() {

        $this->_smarty->assign('Response', 500);
        $this->_smarty->assign('Title', 'Internal Server Error');
        $this->_smarty->assign('Message', 'The server encountered an unexpected condition which prevented it from fulfilling the request. Please contact your technical support for more details.');
        $this->_template = 'pages/error.tpl';

        http_response_code($intResponse);
        $this->_smarty->display($this->_template);
    }

}