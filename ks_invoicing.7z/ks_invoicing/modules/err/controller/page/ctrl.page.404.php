<?php
namespace NsERR;

class ClsCtrlPage404 extends \NsFWK\ClsCtrlPagePublic {
    protected function do_Default() {

        $this->_smarty->assign('Response', 404);
        $this->_smarty->assign('Title', 'Not Found');
        $this->_smarty->assign('Message', 'Seems like lost. You are trying to access a resource that does not exist.');
        $this->_template = 'pages/error.tpl';

        http_response_code($intResponse);
        $this->_smarty->display($this->_template);
    }

}