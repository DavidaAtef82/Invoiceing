<?php

define('MODULE_NAME', 'inv');
define('MODULE_ID', '5');
define('MODULE_WEB_PATH', WEB__MODULES . '/' . MODULE_NAME);
define('MODULE_LOCAL_PATH', LOCAL__MODULES . '/' . MODULE_NAME);

define('PATH__CSS', MODULE_WEB_PATH . '/view/css');
define('PATH__IMAGE', MODULE_WEB_PATH . '/view/images');
define('PATH__JS', MODULE_WEB_PATH . '/view/js');
define('PATH__LANG', MODULE_WEB_PATH . '/view/lang');

define('SMARTY_TEMPLATE_DIR', MODULE_LOCAL_PATH . '/view/templates');
define('SMARTY_CONFIG_DIR', MODULE_LOCAL_PATH . '/view/lang');
define('SMARTY_CACHE_DIR', LOCAL__TMP . '/' . THEME . '/' . MODULE_NAME . '/cache');
define('SMARTY_COMPILE_DIR', LOCAL__TMP . '/' . THEME . '/' . MODULE_NAME . '/compile');