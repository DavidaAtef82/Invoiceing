<?php
namespace NsINV;

class ClsCtrlServiceInv extends \NsFWK\ClsCtrlService{

    protected function do_Default(){}

    public function __construct($arrParameters){
        parent::__construct($arrParameters);
    }     
}