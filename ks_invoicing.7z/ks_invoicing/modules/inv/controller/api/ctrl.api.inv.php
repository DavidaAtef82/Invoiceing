<?php
namespace NsINV;

class ClsCtrlApiInv extends \NsFWK\ClsCtrlApi{

    protected function do_Default(){
    }

    public function __construct($arrParameters){
        parent::__construct($arrParameters);
    }
}