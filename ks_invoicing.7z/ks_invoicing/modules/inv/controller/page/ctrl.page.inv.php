<?php
namespace NsINV;

class ClsCtrlPageInv extends \NsFWK\ClsCtrlPage {

    protected function do_Default(){}

    public function __construct($arrParameters){
        parent::__construct($arrParameters);

    }

}