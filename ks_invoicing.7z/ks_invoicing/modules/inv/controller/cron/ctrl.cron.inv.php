<?php
namespace NsINV;

class ClsCtrlCronInv extends \NsFWK\ClsCtrlCron{

}