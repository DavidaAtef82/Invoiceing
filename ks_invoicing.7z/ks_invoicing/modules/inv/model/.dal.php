<?php
namespace NsINV;

class ClsDalCustomer extends \ADODB_Active_Record{
    var $_dbat = 'customer'; var $_table = 'inv_customer';
}

class ClsDalContact extends \ADODB_Active_Record{
    var $_dbat = 'customer'; var $_table = 'inv_customer_contact';
}

class ClsDalInvoice extends \ADODB_Active_Record{
    var $_dbat = 'customer'; var $_table = 'inv_invoice';
}

class ClsDalInvoiceRow extends \ADODB_Active_Record{
    var $_dbat = 'customer'; var $_table = 'inv_invoice_row';
}

class ClsDalCatalogue extends \ADODB_Active_Record{
    var $_dbat = 'customer'; var $_table = 'inv_catalogue';
}
class ClsDalPaymentMethod extends \ADODB_Active_Record{
    var $_dbat = 'customer'; var $_table = 'inv_payment_method';
}
class ClsDalPaymentterm extends \ADODB_Active_Record{
    var $_dbat = 'customer'; var $_table = 'inv_payment_term';
}
class ClsDalTax extends \ADODB_Active_Record{
    var $_dbat = 'customer'; var $_table = 'inv_tax_type';
}
class ClsDalStatus extends \ADODB_Active_Record{
    var $_dbat = 'customer'; var $_table = 'inv_invoice_status';
}
class ClsDalPayment extends \ADODB_Active_Record{
    var $_dbat = 'customer'; var $_table = 'inv_payment';
}
class ClsDalInvoicePayment extends \ADODB_Active_Record{
    var $_dbat = 'customer'; var $_table = 'inv_invoice_payment';
}
