/**
Custom module for you to write your own javascript functions
**/
var Custom = function () {

    // public functions
    return {

        //main function
        init: function () {
            //initialize here something.
            $(document).ajaxSend(function(event, request, settings) {
            });

            $(document).ajaxComplete(function(event, request, settings) {
            });

            $('#dlgMasterNotification').on('shown', function (e) {
                var details = $("#dlgMasterNotification").data().modal.options.details;
                //details = window.atob(details);
                details = Base64DecodeUnicode(details);
                
                var title = $("#dlgMasterNotification").data().modal.options.title;
                $("#dlgMasterNotification .modal-header h3").html(title);
                $("#dlgMasterNotification .modal-body .col-md-12").html(details);
                var intNotificationID = $("#dlgMasterNotification").data().modal.options.notificationId;
                Custom.markNotificationAsRead(intNotificationID);            
            });

            if ($("#mnuCommon ul li").length==0){
                $("#mnuCommon").remove();
            }
            if ($("#mnuSetup ul li").length==0){
                $("#mnuSetup").remove();
            }
        },
        markNotificationAsRead: function(intNotificationID){
            var param="module=cmn";
            param += "&service=Notification";
            param += "&action=Update";
            param += "&notification_id="+intNotificationID;
            param += "&status=1";
            
            $.ajax({
                type:'post',
                url: 'service.php',
                data:param,
                dataType:'json',
                success:function(response){
                    if(response.result == false){
                        AlertError(response.title,response.message);
                        return;
                    }
                    $("ul.notification li #rNotification_"+intNotificationID).remove();
                    var intNotificationCount = response.object;
                     //parseInt($("#lblMasterNotificationCount").html())-1;
                    $("#lblMasterNotificationCount").html(intNotificationCount);
                    $("ul.notification li:first p").html("You have "+intNotificationCount+" new notifications");
                },
                error: function(msg){
                    AlertError('Error',msg.responseText);
                }
            })
        },
        wait: function(){
            if($(".modal-scrollable div.loading-spinner").length == 0){
                //If not EXIST, show
                $('body').modalmanager('loading');    
            }
        },
        hide: function(){
            if($(".modal-scrollable div.loading-spinner").length == 1){
                //If EXIST, hide
                $('body').modalmanager('removeLoading');    
            }
        },

    };

}();

var controllers = {};
controllers.StartupDialog = ['$scope','SrvStartupDialog',function($scope,SrvStartupDialog){
    function init(){
        $("#dlgHelpVideo").modal({backdrop: "static",keyboard: false});
        //$("#dlgHelpVideo").modal('show');
    }
    
    $scope.stop= function(intDialogID){
        SrvStartupDialog.Stop(intDialogID).then(function(response){
            if(response.data.result){
                
            }
            // we don't need to do any thing here         
        })
    }
    init();
}]