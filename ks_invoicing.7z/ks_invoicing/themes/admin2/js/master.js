var _strModule ='';
var _strTheme = 'default';
jQuery(document).ready(function($) {
    _strModule = $("#hdModuleName").val();
    Custom.init();
});

/***
* put your comment there...
* 
* @param title
* @param strBody: A string representing an extra content to display within the notification
* @param strIconUrl: The URL of an image to be used as an icon by the notification
*/
function DesktopNotification(title, strBody, strIconUrl){
    var obj = {body: strBody, icon: strIconUrl}    
    // Let's check if the browser supports notifications
    if (!("Notification" in window)) {
        AlertError("Error","This browser does not support desktop notification");
    }// Let's check if the user is okay to get some notification
    else if (Notification.permission === "granted") {
        //If it's okay let's create a notification
        var notification = new Notification(message, obj);
    }

    // Otherwise, we need to ask the user for permission
    // Note, Chrome does not implement the permission static property
    // So we have to check for NOT 'denied' instead of 'default'
    else if (Notification.permission !== 'denied') {
        Notification.requestPermission(
            function (permission) {
            // Whatever the user answers, we make sure we store the information
                if(!('permission' in Notification)) {
                    Notification.permission = permission;
                }

            // If the user is okay, let's create a notification
                if (permission === "granted") {
                    var notification = new Notification(message);
                }
            }
        );
    }
    // At last, if the user already denied any notification, and you 
    // want to be respectful there is no need to bother him any more.
}

function SwitchLang(lang){
    var strNewURL = '';
    var strURL = document.URL;
    
    if (strURL.search("#")>0){
        strURL = strURL.slice(0,strURL.search("#"))    
    }

    if(strURL.search('&lang=') > 0){
        strNewURL = strURL.replace(/&lang=en|&lang=ar/gi, '&lang='+lang);
    }else{
        strNewURL = strURL+'&lang='+lang;
    }
    sessionStorage.lang = lang;
    window.location = strNewURL;
}

function Base64EncodeUnicode(str) {
    return btoa(encodeURIComponent(str).replace(/%([0-9A-F]{2})/g, function(match, p1) {
        return String.fromCharCode('0x' + p1);
    }));
}

function Base64DecodeUnicode(str) {
    return decodeURIComponent(Array.prototype.map.call(atob(str), function(c) {
        return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
    }).join(''));
}

function RoundNumber(value, decimals) {
  return Number(Math.round(value+'e'+decimals)+'e-'+decimals);
}