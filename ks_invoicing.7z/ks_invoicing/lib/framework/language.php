<?php
namespace NsFWK;

class ClsLanguage extends ClsBase{
    
    /***
    * This array holds list of languages supported by the applicaiton.
    * It is not placed in DB for ease of use with parent ctrl classes
    * without the need to connect to DB
    * @var mixed
    */
    static private $_arrLanguages = array();

    /***
    * Overrides the default ClsBase::_set($name, $value) method
    * Class attributes are set to be readonly
    * @param mixed $name
    * @param mixed $value
    */
    public function __set($name, $value) {
        // Edit is not allowed
        return false;
    }
    
    public function __construct(){
        $this->_data = array(
            'strLang'=>'', 
            'strFld'=>'', 
            'strDir'=>''
        );
    }

    /***
    * Loads object
    * @param mixed $strLang: language to load
    */
    public function Load($strLang) {
        $ok = self::initLanguages();
        if (!$ok) {
            return false;
        }
        
        $this->_data['strLang'] = $strLang;
        $this->_data['strFld'] = self::$_arrLanguages[$strLang]['strFld'];
        $this->_data['strDir'] = self::$_arrLanguages[$strLang]['strDir'];
        return true;
    }
    

    /***
    * This method initiates the array self::$_arr
    * from LANGUAGES constant defined in ~/inc/.config.php file
    */
    static private function initLanguages() {
        if (!empty(self::$_arrLanguages)) {
            // Languages already initiated
            return true;
        }

        if (!defined('LANGUAGES')) {
            // Missing LANGUAGES constant in ~/inc/.config.php file
            return false;
        }
        
        $arr = explode(',', LANGUAGES);
        if (empty($arr)) {
            return false;
        }

        foreach ($arr as $item) {
            list($strLang, $strFld, $strDir) = explode('|', trim($item));
            if (!empty($strLang) && !empty($strFld) && !empty($strDir)) {
                self::$_arrLanguages[$strLang] = array('strFld'=>$strFld, 'strDir'=>$strDir);
            }
        }
        
        if (empty(self::$_arrLanguages)) {
            // No languages initiated
            return false;
        }
        
        return true;
    }

    /***
    * Retrieves object array of supported languages
    */
    static public function GetLanguages() {
        $arr = array();
        foreach(self::$_arrLanguages as $key=>$val) {
            $obj = new static();
            $ok = $obj->Load($key);
            if ($ok) {
                $arr[] = $obj;
            }
        }

        return $arr;
    }
}