<?php
namespace NsFWK;

abstract class ClsCtrlCron extends ClsBase{

    public function __construct($arrParameters){
        if(isset($arrParameters) && is_array($arrParameters)){
            if(isset($arrParameters['params']) && is_array($arrParameters['params'])){
                foreach($arrParameters['params'] as &$param){
                    $param = trim($param,"'");
                }
            }
        }

        $this->_data = $arrParameters;
        $this->logCtrlCall();
    }

    public function DoAction(){
        if(key_exists('action', $this->_data)){
            $fnAction = "do_".$this->_data['action'];
        }else{
            $fnAction = 'do_Default';
        }

        if(method_exists($this, $fnAction)){
            \NsFWK\ClsLogger::GetInstance()->LogDebug("Calling: $fnAction()");
            $this->$fnAction();
        }else{
            // Terminate execution and redirect to page not found controller
            $strLog = "Cron not found.";
            \NsFWK\ClsLogger::GetInstance()->LogDebug($strLog);
            print($strLog);
            return false;
        }
    }
    
    
    protected function logCtrlCall(){
        if(isset($_SERVER['HTTP_USER_AGENT']) && isset($_SERVER['REMOTE_ADDR'])){
            $strLog =  "New call by User Agent: [{$_SERVER['HTTP_USER_AGENT']}] - FROM IP Address [".$_SERVER['REMOTE_ADDR']."]";
        }else{
            $strLog =  "New call by command line";
        }
        \NsFWK\ClsLogger::GetInstance()->LogDebug($strLog);

        $strLog = "Parameters: " . json_encode($this->_data);
        \NsFWK\ClsLogger::GetInstance()->LogDebug($strLog);
    }

    protected function verbose($content){
        $this->print2Console($content);
        $this->print2Log($content);
    }

    protected function print2Console($content){
        if(PHP_SAPI == 'cli'){
            $break = "\n";
        }else{
            $break = "<br/>";
        }

        print $content;
        print $break;            
    }

    protected function print2Log($content){
        $objLog = \NsFWK\ClsLogger::GetInstance();
        $objLog->LogDebug($content);
    }
}