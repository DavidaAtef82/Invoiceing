<?php
namespace NsFWK;

abstract class ClsCtrlServicePublic extends ClsCtrl{

    public function DoAction(){
        header('Content-Type: application/json');

        if(RUN_MODE === 'PRODUCTION'){

        }

        if(key_exists('action', $this->_data)){
            $fnAction = "do_".$this->_data['action'];
            $fnBefore = "before_".$this->_data['action'];
            $fnAfter  = "after_".$this->_data['action'];
        }else{
            $fnAction = 'do_Default';
            $fnBefore = "before_Default";
            $fnAfter  = "after_Default";
        }

        if(method_exists($this, $fnBefore)){
            \NsFWK\ClsLogger::GetInstance()->LogDebug("Calling: $fnBefore()");
            $rslt = $this->$fnBefore();
            if(!$rslt){
                return true;
            }
        }

        if(method_exists($this, $fnAction)){
            \NsFWK\ClsLogger::GetInstance()->LogDebug("Calling: $fnAction()");
            $this->$fnAction();
        }else{
            // Terminate execution and redirect to page not found controller
            $strLog = "Service not found.";
            \NsFWK\ClsLogger::GetInstance()->LogDebug($strLog);
            ClsCtrlApi::SetResponse(ClsCtrlApi::HTTP_STATUS_404, '404 Not Found', $strLog);
            return false;
        }

        if(method_exists($this, $fnAfter)){
            \NsFWK\ClsLogger::GetInstance()->LogDebug("Calling: $fnAfter()");
            $this->$fnAfter();
        }

        return true;
    }
}