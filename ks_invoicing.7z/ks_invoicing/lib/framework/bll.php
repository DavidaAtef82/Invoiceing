<?php
namespace NsFWK;

abstract class ClsBll extends ClsBase{
    protected $_savedData = array();
    protected $_preSavedData = array();

    protected $_strClsDalLoad = '';
    protected $_strClsDalSave = '';

    protected $_boolLoaded = false;
    //protected $_boolSaved = false;

    protected $_arrTrace = array();

    abstract protected function _load(\ADODB_Active_Record $objDAL);
    abstract protected function _save(\ADODB_Active_Record $objDAL);
    abstract protected function _delete(\ADODB_Active_Record $objDAL);


    public function __get($name){
        switch($name){
            case '_enum':
                $objDAL = new $this->_strClsDalLoad;
                $tableName =  $objDAL->_table;
                $DB = &\ADODB_Connection_Manager::GetConnection('customer');
                $rslt = $DB->GetArray("SELECT TABLE_CATALOG, TABLE_SCHEMA, TABLE_NAME, COLUMN_NAME, COLUMN_TYPE
                                        FROM information_schema.`COLUMNS`
                                        WHERE  COLUMN_TYPE LIKE '%enum%'
                                        AND TABLE_SCHEMA='" . DB_CATALOG ."'
                                        AND TABLE_NAME LIKE '$tableName'");
                $arrResult = array();
                foreach($rslt as $item){
                    $strEnumName = str_replace("fld","", $item['COLUMN_NAME']);
                    $result = str_replace(array("enum('", "')"), array('', ''), $item['COLUMN_TYPE']);
                    $arrEnumValues = explode("','", $result);
                    $arrResult[$strEnumName] = $arrEnumValues;
                }
                $this->_data[$name]= $arrResult;
                break;
        }

        return parent::__get($name);
    }

    /***
    * By Mostafa Zakaria - Last Update 2011.12.22
    *
    * Constructor may accept:
    * 1. Array to be assigned to member variables -> must be of the same count of $_data
    * 2. $objDAL of the samy type of $_strDALClsLoad so that the object can be loaded from
    * 3. object of type BLLClsSearchParam
    * 
    * Updated By Mostafa Zakaria - 2014.05.22
    * 4. Associative array of key value pair as same as the default keys used in the data array
    * Those are directly assigned to the data array keys and the object is marked loaded
    */
    public function __construct(){
        $intArgsCount = func_num_args();
        if($intArgsCount > 0){
            $arrArg = func_get_arg(0);
            $this->Load($arrArg);
        }else{
            return;
        }
    }

    
    protected function setSavedData(){
        if(empty($this->_savedData)){
            $this->_preSavedData = array();
        }else{
            foreach($this->_savedData as $key=>$val){
                $this->_preSavedData[$key] = $this->_savedData[$key];
            }
        }

        if(empty($this->_data)){
            $this->_savedData = array();
        }else{
            foreach($this->_data as $key=>$val){
                $this->_savedData[$key] = $this->_data[$key];
            }
        }
    }

    // Class Properties //
    public function addToTrace($str){array_unshift($this->_arrTrace, $str);}
    public function getLastTrace(){return $this->_arrTrace[0];}
    public function getTraceArray(){return $this->_arrTrace;}
    public function getIsLoaded(){return $this->_boolLoaded;}
    public function getIsSaved(){
        if(empty($this->_savedData)){
            return false;
        }

        $arrIntersect = array_intersect_key($this->_data, $this->_savedData);
        return ($arrIntersect == $this->_savedData);
    }
    public function getIsModified($name){
        if(array_key_exists($name, $this->_data) && array_key_exists($name, $this->_savedData)){
            if($this->_data[$name] == $this->_savedData[$name])
                return false;
        }

        if(!array_key_exists($name, $this->_data) && !array_key_exists($name, $this->_savedData)){
            return false;
        }

        return true;
    }
    // End of Class Properties //

    /***
    * By Mostafa Zakaria - Last Update 2011.12.22
    *
    * Constructor may accept:
    * 1. Array to be assigned to member variables -> must be of the same count of $_data
    * 2. $objDAL of the samy type of $_strDALClsLoad so that the object can be loaded from
    * 3. object of type ClsFilter
    * 
    * Updated By Mostafa Zakaria - 2014.05.22
    * 4. Associative array of key value pair as same as the default keys used in the data array
    * Those are directly assigned to the data array keys and the object is marked loaded
    * 
    * Updated By Mostafa Zakaria - 2017-06-01
    * 5. Shallow copy another object of the same type to the $this
    */
    public function Load(){
        $arrArg = func_get_arg(0);
        if(!empty($arrArg) && is_array($arrArg)){
            $arrArg = $this->prepareLoadArgs($arrArg);
        }

        $rslt = false;
        $loaded = false;
        $saved = false;

        if(count($arrArg) == 1){
            if (is_array($arrArg)){
                $obj = $arrArg[0];
            }else{
                $obj = $arrArg;
            }

            if(is_a($obj, 'ADODB_Active_Record')){
                // Loading from a DAL object
                $this->_load($obj);
                
                $rslt = true;
                $loaded = $rslt;
                $saved = $rslt;
            }elseif(is_a($obj, 'NsFWK\ClsFilter')){
                // Loading by passing filter
                $strWhere = $obj->GetWhereStatement();
                $objDAL = new $this->_strClsDalLoad;
                $rslt = $objDAL->Load($strWhere);
                if($rslt){
                    $this->_load($objDAL);
                }else{
                    $this->addToTrace($objDAL->ErrorMsg());
                }

                $loaded = $rslt;
                $saved = $rslt;
            }elseif(is_a($obj, get_called_class())){
                // Loading object from another instance of the same class
                // Shallow copy is always performed
                $boolShallow = true;
                foreach($obj->_data as $key=>$value){
                    if(is_a($value, 'NsFWK\ClsBase')){
                        $this->_data[$key] = ($boolShallow)? $value : $value->GetCopy($boolShallow);
                    }elseif(is_object($value)){
                        $this->_data[$key] = $this->copyObj($value, $boolShallow);
                    }elseif(is_array($value)){
                        $this->_data[$key] = $this->copyArray($value, $boolShallow);
                    }else{
                        $this->_data[$key] = $value;
                    }
                }

                $rslt = true;
                $loaded = $obj->getIsLoaded();
                $saved = $obj->getIsSaved();
            }
        }elseif($this->isAssociative($arrArg) && count($arrArg) == count($this->_data)){
            $rslt = true;
            foreach($this->_data as $key=>$value){
                if(!isset($arrArg[$key])){
                    // if any of the current class instance attributes is not found
                    // in the passed array -> reset _data to old values, and false loading
                    $this->_data = $this->_savedData;
                    $rslt = false;
                    break;
                }
                
                $this->_data[$key] = $arrArg[$key];
            }
            
            $loaded = $rslt;
            $saved = $rslt;
        }elseif(count($arrArg) == count($this->_data)){
            $i = 0;
            foreach($this->_data as $key=>$value){
                $this->_data[$key] = $arrArg[$i];
                $i++;
            }

            $rslt = true;
            $loaded = false;
            $saved = false;
        }
        
        if($saved){
            $this->setSavedData();
        }
        $this->_boolLoaded = $loaded;

        return $rslt;
    }

    /***
    * By Mostafa Zakaria - Last Update 2017.06.02
    * 
    * Function returns a copy of the current object.
    * 
    * @param mixed $boolShallow: Whether to do deep-copy for reference type attributes
    * or shallow copy (reference only)
    * @return mixed object that is copy of the current one
    */
    public function GetCopy($boolShallow = false){
        $obj = parent::GetCopy($boolShallow);

        if($boolShallow){
            // Reference copy
            $obj->_boolLoaded = $this->getIsLoaded();
            if($obj->_boolLoaded){
                $obj->setSavedData();
            }
        }

        return $obj;
    }

    public function Save(){
        if($this->getIsSaved()){
            $this->addToTrace('Item has not been changed!');
            //return true;
        }

        $objDAL = new $this->_strClsDalSave();
        $rslt = $this->_save($objDAL);
        if($rslt === true){
            // INSERT Succeeded
            //$this->_boolSaved = true;
            $this->_boolLoaded = true;
            //$this->_savedData = $this->_data;
            $this->setSavedData();
            $this->addToTrace('Item successfully inserted!');
            return true;
        }elseif($rslt === false){
            // INSERT Failed
            //$this->_boolSaved = false;
            $this->_boolLoaded = false;
            $this->addToTrace($objDAL->ErrorMsg());
            return false;
        }elseif($rslt === 1){
            // Update Succeeded
            //$this->_boolSaved = true;
            $this->_boolLoaded = true;
            //$this->_savedData = $this->_data;
            $this->setSavedData();
            $this->addToTrace('Item successfully updated!');
            return true;
        }elseif($rslt === -1){
            // Update Succeeded, no data changed
            //$this->_boolSaved = true;
            $this->_boolLoaded = true;
            //$this->_savedData = $this->_data;
            $this->setSavedData();
            $this->addToTrace('No data changed!');
            return true;
        }elseif($rslt === 0){
            // Update Failed
            //$this->_boolSaved = false;
            $this->_boolLoaded = false;
            $this->addToTrace($objDAL->ErrorMsg());
            return false;
        }elseif($rslt === 2){
            // Replace Successed
            $this->_boolLoaded = true;
            //$this->_savedData = $this->_data;
            $this->setSavedData();
            $this->addToTrace('Item Replace updated!');
            return true;
        }else{
            // Custom Error
            //$this->_boolSaved = false;
            $this->_boolLoaded = false;
            $this->addToTrace($rslt);
            return false;
        }
    }

    public function Delete(){
        if(!$this->_boolLoaded){
            $this->addToTrace('Unloaded items can not be deleted!');
            return false;
        }

        $objDAL = new $this->_strClsDalSave();
        $rslt = $this->_delete($objDAL);
        if(!$rslt){
            $this->addToTrace($objDAL->ErrorMsg());
            return false;
        }else{
            $this->_boolLoaded = false;
            //$this->_boolSaved = false;
            foreach($this->_savedData as $key=>$val){
                $this->_preSavedData[$key] = $this->_savedData[$key];
            }
            $this->_data = array();
            $this->_savedData = array();
            return true;
        }
    }


    // Data Retrieval Methods //        
    public function GetDataSQL($strSQL){
        $DB = &\ADODB_Connection_Manager::GetConnection('customer');

        $arrRow = $DB->GetArray($strSQL);
        $arrRslt = array();
        if(!empty($arrRow)){
            foreach($arrRow as $row){
                $obj = new ClsBase();
                foreach($row as $col => $val){
                    $obj->$col = $val;
                }
                $arrRslt[] = $obj;
            }
        }

        return $arrRslt;
    }

    public function GetDataSQLPage($strSQL, $intPageNo, $intPageSize, $strUrl, &$arrLinks){
        $DB = &\ADODB_Connection_Manager::GetConnection('customer');

        $intRowCount = $DB->GetOne("SELECT COUNT(*) AS fldCount FROM ($strSQL) AS tmp");
        if(!$intRowCount){
            return array();
        }

        $intPageCount = ceil($intRowCount / $intPageSize);
        $intStartIndex = $intPageSize * ($intPageNo - 1);
        
        $strSQL .= " LIMIT $intStartIndex, $intPageSize";
        $arrRow = $DB->GetArray($strSQL);

        $arrRslt = array();
        if(!empty($arrRow)){
            foreach($arrRow as $row){
                $obj = new ClsBase();
                foreach($row as $col => $val){
                    $obj->$col = $val;
                }
                $arrRslt[] = $obj;
            }
            $arrLinks = $this->getPagingLinks($strUrl, PARAM_PAGE_NO, $intPageNo, $intPageCount);
        }

        return $arrRslt;
    }
    
    public function GetDataSQLPageAjax($strSQL, $intPageNo, $intPageSize, $ajaxFunction, &$arrLinks){
        $DB = &\ADODB_Connection_Manager::GetConnection('customer');

        $intRowCount = $DB->GetOne("SELECT COUNT(*) AS fldCount FROM ($strSQL) AS tmp");
        if(!$intRowCount){
            return array();
        }

        $intPageCount = ceil($intRowCount / $intPageSize);
        $intStartIndex = $intPageSize * ($intPageNo - 1);
        
        $strSQL .= " LIMIT $intStartIndex, $intPageSize";
        $arrRow = $DB->GetArray($strSQL);

        $arrRslt = array();
        if(!empty($arrRow)){
            foreach($arrRow as $row){
                $obj = new ClsBase();
                foreach($row as $col => $val){
                    $obj->$col = $val;
                }
                $arrRslt[] = $obj;
            }
            $arrLinks = $this->getAjaxPagingLinks($intPageNo, $intPageCount, $ajaxFunction);
        }

        return $arrRslt;
    }
    
    public function GetDataSQLAssociative($strSQL){
        $DB = &\ADODB_Connection_Manager::GetConnection('customer');

        $arrRow = $DB->GetArray($strSQL);
        $arrRslt = array();
        if(!empty($arrRow)){
            foreach($arrRow as $row){
                $obj = new ClsBase();
                foreach($row as $col => $val){
                    $obj->$col = $val;
                }
                $arrRslt[] = $obj->ToArray();
            }
        }

        return $arrRslt;
    }

    public function GetDataSQLPageAssociative($strSQL, $intPageNo, $intPageSize, &$intPageCount, &$intRowCount){
        $DB = &\ADODB_Connection_Manager::GetConnection('customer');

        $intRowCount = $DB->GetOne("SELECT COUNT(*) AS fldCount FROM ($strSQL) AS tmp");
        if(!$intRowCount){
            return array();
        }

        $intPageCount = ceil($intRowCount / $intPageSize);
        $intStartIndex = $intPageSize * ($intPageNo - 1);
        
        $strSQL .= " LIMIT $intStartIndex, $intPageSize";
        $arrRow = $DB->GetArray($strSQL);

        $arrRslt = array();
        if(!empty($arrRow)){
            foreach($arrRow as $row){
                $obj = new ClsBase();
                foreach($row as $col => $val){
                    $obj->$col = $val;
                }
                $arrRslt[] = $obj->ToArray();
            }
        }

        return $arrRslt;
    }

    
    public function GetData(ClsFilter $objFilter, $strOrder = '', $strGroup = '', $intOffset = false, $intCount = false){
        if($this->_strClsDalLoad == '')
            return array();

        $strBLLCls = get_called_class();
        $objDAL = new $this->_strClsDalLoad;

        $strWhere = $objFilter->GetWhereStatement(); 
        $strSQL = $strWhere;
        $strSQL .= ($strGroup == '') ? '' : " GROUP BY $strGroup";
        $strSQL .= ($strOrder == '') ? '' : " ORDER BY $strOrder";
        if($intOffset !== false && $intCount !== false){
            $strSQL .= " LIMIT $intOffset, $intCount ";
        }
        $arrRecords = $objDAL->Find($strSQL);

        $rslt = array();
        if(is_array($arrRecords) && !empty($arrRecords)){
            foreach($arrRecords as $row){
                $rslt[] = new $strBLLCls($row);
            }
        }

        return $rslt;
    }

    public function GetDataPage($intPageNo, $intPageSize, $strWhere, $strOrder, $strUrl, &$arrLinks){
        if($this->_strClsDalLoad == ''){
            return array();
        }

        $strBLLCls = get_called_class();
        $objDAL = new $this->_strClsDalLoad;

        $pageCount = 0;
        $rowCount = 0;
        $arrRecords = $objDAL->GetPage($intPageNo, $intPageSize, $pageCount, $rowCount, $strWhere, $strOrder);

        $rslt = array();
        if(is_array($arrRecords) && !empty($arrRecords)){
            foreach($arrRecords as $row){
                $rslt[] = new $strBLLCls($row);
            }
            
            $arrLinks = $this->getPagingLinks($strUrl, PARAM_PAGE_NO, $intPageNo, $pageCount);
        }

        return $rslt;
    }
    
    public function GetDataPageAjax($intPageNo, $intPageSize, $strWhere, $strOrder, $ajaxFunction, &$arrLinks){
        if($this->_strClsDalLoad == ''){
            return array();
        }

        $strBLLCls = get_called_class();
        $objDAL = new $this->_strClsDalLoad;

        $pageCount = 0;
        $rowCount = 0;
        $arrRecords = $objDAL->GetPage($intPageNo, $intPageSize, $pageCount, $rowCount, $strWhere, $strOrder);

        $rslt = array();
        if(is_array($arrRecords) && !empty($arrRecords)){
            foreach($arrRecords as $row){
                $rslt[] = new $strBLLCls($row);
            }

            $arrLinks = $this->getAjaxPagingLinks($intPageNo, $pageCount, $ajaxFunction);
        }

        return $rslt;
    }


    public function GetDataAssociative(ClsFilter $objFilter, $strOrder = '', $strGroup = '', $intOffset = false, $intCount = false){
        if($this->_strClsDalLoad == ''){
            return array();
        }

        $strBLLCls = get_called_class();
        $objDAL = new $this->_strClsDalLoad;

        $strWhere = $objFilter->GetWhereStatement();
        $strSQL = $strWhere;
        $strSQL .= ($strGroup == '') ? '' : " GROUP BY $strGroup";
        $strSQL .= ($strOrder == '') ? '' : " ORDER BY $strOrder";
        if($intOffset !== false && $intCount !== false){
            $strSQL .= " LIMIT $intOffset, $intCount ";
        }
        $arrPage = $objDAL->Find($strSQL);

        $rslt = array();
        if(is_array($arrPage) && !empty($arrPage)){
            foreach($arrPage as $page){
                $objTemp = new $strBLLCls($page);
                $rslt[] = $objTemp->ToArray();
                
            }
        }

        return $rslt;
    }
    
    public function GetDataPageAssociative($intPageNo, $intPageSize, $strWhere, $strOrder, &$intPageCount, &$intRowCount){
        if($this->_strClsDalLoad == ''){
            return array();
        }

        $strBLLCls = get_called_class();
        $objDAL = new $this->_strClsDalLoad;
        $arrPage = $objDAL->GetPage($intPageNo, $intPageSize, $intPageCount, $intRowCount, $strWhere, $strOrder);

        $rslt = array();
        if(is_array($arrPage) && !empty($arrPage)){
            foreach($arrPage as $page){
                $objTemp = new $strBLLCls($page);
                $rslt[] = $objTemp->ToArray();
            }
        }

        return $rslt;
    }
    // End of Data Retrieval Methods //
    

    // Late Binding Methods //
    protected function loadBinding(&$arrMasterData, $atrMasterID, $atrMasterDetail, ClsBll $objDetail, $fldDetailID, $atrDetailID, $boolArray=false){
        if(empty($arrMasterData)){
            return true;
        }

        $arrMasterIDs = array();
        foreach($arrMasterData as $objMaster){
            $intMasterID = $objMaster->$atrMasterID;
            if(!in_array($intMasterID,$arrMasterIDs) && $intMasterID > 0){
                $arrMasterIDs[] = $intMasterID;    
            }
        }
        if(empty($arrMasterIDs)){
            return true;
        }
        $strMasterIDs = implode(',', $arrMasterIDs);
        
        $objFilter = new ClsFilter();
        $objFilter->$fldDetailID = "$fldDetailID IN ($strMasterIDs)";
        $arrDetailData = $objDetail->GetData($objFilter);
        if (empty($arrDetailData)) {
            return true;
        }

        if ($boolArray){
            $arrDetailDataIndexed = ClsHlpHelper::IndexObjectArray($arrDetailData, array($atrDetailID), true);
        }else{
            $arrDetailDataIndexed = ClsHlpHelper::IndexObjectArray($arrDetailData, array($atrDetailID));
        }
        
        /*
        $arrDetailDataIndexed = array();
        foreach($arrDetailData as $objDetail){
            if ($boolArray){
                $arrDetailDataIndexed[$objDetail->$atrDetailID][] = $objDetail;
            }else{
                $arrDetailDataIndexed[$objDetail->$atrDetailID] = $objDetail;
            }
        }*/
           
        foreach($arrMasterData as &$objMaster){   
            $tmp = null;
            if (key_exists($objMaster->$atrMasterID, $arrDetailDataIndexed)) {
                $tmp = $arrDetailDataIndexed[$objMaster->$atrMasterID];
            }

            $objMaster->_data[$atrMasterDetail] = $tmp;
        }
        
        return true;
    }

    protected function loadBindingAssociative(&$arrMasterData, $atrMasterID, $atrMasterDetail, ClsBll $objDetail, $fldDetailID, $atrDetailID, $boolArray=false){
        if(empty($arrMasterData)){
            return true;
        }

        $arrMasterIDs = array();
        foreach($arrMasterData as $objMaster){
            $intMasterID = $objMaster[$atrMasterID];
            if(!in_array($intMasterID,$arrMasterIDs) && $intMasterID > 0){
                $arrMasterIDs[] = $intMasterID;    
            }
            
        }
        if(empty($arrMasterIDs)){
            return true;
        }
        $strMasterIDs = implode(',', $arrMasterIDs);
        
        $objFilter = new ClsFilter();
        $objFilter->$fldDetailID = "$fldDetailID IN ($strMasterIDs)";
        $arrDetailData = $objDetail->GetDataAssociative($objFilter);
        if (empty($arrDetailData)) {
            return true;
        }

        if ($boolArray){
            $arrDetailDataIndexed = ClsHlpHelper::IndexObjectArrayAssoc($arrDetailData, array($atrDetailID), true);
        }else{
            $arrDetailDataIndexed = ClsHlpHelper::IndexObjectArrayAssoc($arrDetailData, array($atrDetailID));
        }

        /*
        $arrDetailDataIndexed = array();
        foreach($arrDetailData as $objDetail){
            if ($boolArray){
                $arrDetailDataIndexed[$objDetail[$atrDetailID]][] = $objDetail;
            }else{
                $arrDetailDataIndexed[$objDetail[$atrDetailID]] = $objDetail;
            }
        }*/
           
        foreach($arrMasterData as &$objMaster){   
            $tmp = null;
            if (key_exists($objMaster[$atrMasterID], $arrDetailDataIndexed)) {
                $tmp = $arrDetailDataIndexed[$objMaster[$atrMasterID]];
            }

            $objMaster[$atrMasterDetail] = $tmp;
        }
        
        return true;
    }
    // End of Late Binding Methods //
    
    // Paging Methods //
    /**
    * Function used to load paging links for a certain data page
    * @author Mostafa Zakaria
    * @author Mohamed Adel (Added the associative variable page)
    * @param string $url: URL of web page in which links to be displayed
    * @param string $pageParam
    * @param int $currPage
    * @param int $pageCount
    */
    protected function getPagingLinks($url,$pageParam,$currPage,$pageCount){
        if($pageCount <= 1){
            return false;
        }
        
        $url .= ((strpos($url, '?') === false)? "?" : "&") . "$pageParam=";
        $arrLinks = array();
        
        if($currPage == 1){
            $arrLinks[0] = array('label'=>'<<', 'link'=>'#','page'=>'#');
            $arrLinks[1] = array('label'=>'<', 'link'=>'#','page'=>'#');
        }else{
            $arrLinks[0] = array('label'=>'<<', 'link'=>$url.'1','page'=>1);
            $arrLinks[1] = array('label'=>'<', 'link'=>$url.($currPage-1),'page'=>($currPage-1));
        }
        $j = 1;
        
        for($i=$currPage-2 ; $i<=$currPage+2 ; $i++){
            if($i < 1){
                continue;
            }
            
            if($i>$pageCount){
                break;
            }

            $j++;
            if($i==$currPage){
                $arrLinks[$j] = array('label'=>$i, 'link'=>'#','page'=>'#');
            }else{
                $arrLinks[$j] = array('label'=>$i, 'link'=>$url.$i,'page'=>$i);
            }
        }

        if($currPage == $pageCount){
            $arrLinks[$j+1] = array('label'=>'>', 'link'=>'#','page'=>'#');
            $arrLinks[$j+2] = array('label'=>'>>', 'link'=>'#','page'=>'#');            
        }else{
            if($currPage+1 > $pageCount){
                $nextPage = $pageCount;
            }
            else{
                $nextPage = $currPage + 1;
            }

            $arrLinks[$j+1] = array('label'=>'>', 'link'=>$url.$nextPage,'page'=>$nextPage);
            $arrLinks[$j+2] = array('label'=>'>>', 'link'=>$url.$pageCount,'page'=>$pageCount);
        }
        
        return $arrLinks;
    }
    
    /**
    * Function used to load Ajax paging links for a certain data page
    * @author Mostafa Zakaria
    * @author Mohamed Adel (Added the associative variable page)
    * @param int $currPage
    * @param int $pageCount
    * @param str $ajaxFunction
    */
    protected function getAjaxPagingLinks($currPage,$pageCount,$ajaxFunction){
        $arrLinks = array();

        if($pageCount <= 1){
            //return FALSE;
            $arrLinks[0] = array('label'=>'<<', 'link'=>'#','page'=>'1');
            $arrLinks[1] = array('label'=>'>>', 'link'=>'#','page'=>'1');
            $arrRslt = array('nav'=>$arrLinks, 'cur'=>$currPage, 'cnt'=>$pageCount, 'ajx'=>$ajaxFunction);
        }

        if($currPage == 1){
            $arrLinks[0] = array('label'=>'<<', 'link'=>'#','page'=>'1');
            $arrLinks[1] = array('label'=>'<', 'link'=>'#','page'=>'1');
        }else{
            $arrLinks[0] = array('label'=>'<<', 'link'=>"$ajaxFunction(1)",'page'=>1);
            $prevPage = $currPage - 1;
            $arrLinks[1] = array('label'=>'<', 'link'=>"$ajaxFunction($prevPage)",'page'=>$prevPage);
        }
        
        $j = 1;
        for($i=$currPage-2 ; $i<=$currPage+2 ; $i++){
            if($i < 1){
                continue;
            }
            
            if($i>$pageCount){
                break;
            }

            $j++;
            if($i==$currPage){
                $arrLinks[$j] = array('label'=>$i, 'link'=>'#','page'=>$i);
            }else{
                $arrLinks[$j] = array('label'=>$i, 'link'=>"$ajaxFunction($i)",'page'=>$i);
            }
        }

        if($currPage == $pageCount){
            $arrLinks[$j+1] = array('label'=>'>', 'link'=>'#','page'=>$pageCount);
            $arrLinks[$j+2] = array('label'=>'>>', 'link'=>'#','page'=>$pageCount);
        }else{
            if($currPage+1 > $pageCount){
                $nextPage = $pageCount;
            }
            else{
                $nextPage = $currPage + 1;
            }
            
            $arrLinks[$j+1] = array('label'=>'>', 'link'=>"$ajaxFunction($nextPage)",'page'=>$nextPage);
            $arrLinks[$j+2] = array('label'=>'>>', 'link'=>"$ajaxFunction($pageCount)",'page'=>$pageCount);
        }
        
        //return $arrLinks;
        $arrRslt = array('nav'=>$arrLinks, 'cur'=>$currPage, 'cnt'=>$pageCount, 'ajx'=>$ajaxFunction);
        return $arrRslt;
    }
    // End of Paging Methods //

    
    // Misc Methods //
    private function prepareLoadArgs($arrArg){
        $mixed = $arrArg[0];
        if(is_array($mixed)){
            $rslt = $this->prepareLoadArgs($mixed);
            return $rslt;
        }else{
            return $arrArg;
        }
    }

    private function isAssociative($arr){
        $rslt = is_array($arr) && array_diff_key($arr, array_keys(array_keys($arr)));
        return $rslt;
    }
    // End of Misc Methods //
}