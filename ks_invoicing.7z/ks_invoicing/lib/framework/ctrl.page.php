<?php
namespace NsFWK;

abstract class ClsCtrlPage extends ClsCtrlPagePublic{

    public function __get($name){
        switch($name){
            case 'arrActiveMenuItems':
                if(!array_key_exists($name, $this->_data)){
                    $this->loadSiteMap();
                }
                break;
            case 'arrBreadcrumbItems':
                if(!array_key_exists($name, $this->_data)){
                    $this->loadSiteMap();
                }
                break;
        }

        return parent::__get($name);
    }


    protected function loadSiteMap(){
        if(!isset($this->_session->objUser->arrMenuItems) || empty($this->_session->objUser->arrMenuItems)){
            return array();
        }

        $arrMenuGroups = $this->_session->objUser->arrMenuItems;

        $strModule = $this->_data['module'];
        $strClass = $this->_data['page'];
        $strAction = $this->_data['action'];

        $intLevel = -1;
        $intModuleID = -1;
        $intParentLevel = -1;
        $arrActiveMenuItems = array();
        $arrBreadcrumbItems = array();

        // Loop through all menu gropus
        foreach($arrMenuGroups as $decMenuGroupOrder=>$arrMenu){
            // Traverse each gruop's menu from bottom up looking for the active leaf link
            $l = count($arrMenu) - 1;
            for($i=$l; $i>=0; $i--){
                // $ok1 = true if the currently traversed menu item corresponds to this page
                $ok1 = $arrMenu[$i]['strModule'] == $strModule && $arrMenu[$i]['strControllerClass'] == $strClass && $arrMenu[$i]['strAction'] == $strAction;
                // $ok2 = true if the currently traversed menu item corresponds to the parent of this page
                $ok2 = ($intParentLevel == $arrMenu[$i]['intLevel']);
                if($ok1 || $ok2){
                    if($intModuleID == -1){
                        $intModuleID = $arrMenu[$i]['intModuleID'];
                    }

                    // Active Menu Item
                    $arrItem = array('strURL'=>'', 'strText'=>'');
                    if(is_null($arrMenu[$i]['intActionID'])){
                        $strUrl = '';
                        if(isset($this->_session->objUser->arrDefaultPages[$intModuleID])){
                            $strUrl = $this->_session->objUser->arrDefaultPages[$intModuleID];
                        }
                        $arrItem = array('strURL'=>$strUrl,
                                            'strText'=>$this->cLang($arrMenu[$i]['strMenuText'],array(),'AUX_MENU'));
                    } else {
                        $arrItem = array('strURL'=>"index.php?module={$arrMenu[$i]['strModule']}&page={$arrMenu[$i]['strControllerClass']}&action={$arrMenu[$i]['strAction']}",
                                            'strText'=>$this->cLang($arrMenu[$i]['strMenuText'],array(),'AUX_MENU'));
                    }

                    $arrActiveMenuItems[] = $arrMenu[$i]['intMenuItemID'];
                    $arrBreadcrumbItems[] = $arrItem;
                    $intLevel = $arrMenu[$i]['intLevel'];
                    $intParentLevel = $intLevel-1;
                }
            }

            if(!empty($arrActiveMenuItems)){
                // arrActiveMenuItems is already populated
                // No need to check other menu groups as an active menu should be with its Ancestots in a single group
                break;
            }
        }

        $this->_data['arrActiveMenuItems'] = $arrActiveMenuItems;
        // reverse the bread crumb as it is pushed in reversed order
        $this->_data['arrBreadcrumbItems'] = array_reverse($arrBreadcrumbItems);
    }

    protected function initSmarty($template=SMARTY_TEMPLATE_DIR, $config=SMARTY_CONFIG_DIR, $cache=SMARTY_CACHE_DIR, $compile=SMARTY_COMPILE_DIR){
        parent::initSmarty($template, $config, $cache, $compile);

        $this->_smarty->assign('_User', $this->objUser);
        $this->_smarty->assign('_Config', $this->_config);
        $this->_smarty->assign('_UserPermission', $this->arrPermissions);
        $this->_smarty->assign('_ActiveMenuItems', $this->arrActiveMenuItems);
        $this->_smarty->assign('_BreadcrumbItems', $this->arrBreadcrumbItems);
    }


    protected function do_NotLoggedIn(){
        // redirect user to Login page
        if (isset($_SERVER['QUERY_STRING']) && $_SERVER['QUERY_STRING']!=''){
            $url = "index.php?" . $_SERVER['QUERY_STRING'];
            $url = urlencode($url);
            header("location:index.php?module=cmn&page=Index&action=Login&url=$url");
        }else{
            header("location:index.php?module=cmn&page=Index&action=Login");
        }
    }

    protected function do_AccessDenied(){  
        // redirect user to Access Denied page
        if(!isset($this->_data['module']) or !isset($this->_data['page'])){
            $strUrl = $this->_session->strDefaultPage;
        }else{
            $strUrl = 'index.php?';
            if (isset($this->_data['module'])){
                $strUrl .= 'module=' . $this->_data['module'];
            }
            if (isset($this->_data['page'])){
                $strUrl .= '&page=' . $this->_data['page'];
            }
            if (isset($this->_data['action'])){
                $strUrl .= '&action=' . $this->_data['action'];
            }
        }

        $url = urlencode($strUrl);
        header("location:index.php?module=cmn&page=Index&action=Unauthorized&url=$url");
    }


    public function DoAction(){
        $this->initSmarty();

        if(RUN_MODE === 'PRODUCTION'){
            if(!$this->boolIsLogged){
                $this->do_NotLoggedIn();
                return true;
            }else{
                $objUser = $this->objUser;
                $rslt = $this->canView();
                if(!$rslt){
                    $this->do_AccessDenied();
                    return true;
                }
            }
        }

        if(key_exists('action', $this->_data)){
            $fnAction = "do_".$this->_data['action'];
            $fnBefore = "before_".$this->_data['action'];
            $fnAfter  = "after_".$this->_data['action'];
        }else{
            $fnAction = 'do_Default';
            $fnBefore = "before_Default";
            $fnAfter  = "after_Default";
        }

        if(method_exists($this, $fnBefore)){
            \NsFWK\ClsLogger::GetInstance()->LogDebug("Calling: $fnBefore()");
            $rslt = $this->$fnBefore();
            if(!$rslt){
                // Terminate execution as the before function will be doing some redirection
                return true;
            }
        }

        if(method_exists($this, $fnAction)){
            \NsFWK\ClsLogger::GetInstance()->LogDebug("Calling: $fnAction()");
            $rslt = $this->$fnAction();
        }else{
            // Method does not exist
            // Terminate execution and redirect to PageNotFound controller
            \NsFWK\ClsLogger::GetInstance()->LogDebug("Calling: PageNotFound()");
            self::PageNotFound();
            return false;
        }

        if(method_exists($this, $fnAfter)){
            \NsFWK\ClsLogger::GetInstance()->LogDebug("Calling: $fnAfter()");
            $this->$fnAfter();
        }

        return true;
    }
}