<?php
namespace NsFWK;

class ClsConfiguration{
    protected $_data = array();

    static private $_instance;


    public function __set($name, $value){
        return false;
    }

    public function __get($name){
        if(array_key_exists($name, $this->_data)){
            return $this->_data[$name];
        }

        return null;
    }

    public function __isset($name){
        $value = $this->__get($name);
        return isset($value);
    }


    private function __construct(){
        $this->_data = array();

        // get enabled modules
        $arrEnabledModulesIDs = \NsCMN\ClsBllModule::GetEnabledModulesIDs();
        $strEnabledModulesIDs = implode(",",$arrEnabledModulesIDs);

        // get modules info
        $objFilter = new ClsFilter();
        $objFilter->intModuleID = "pkModuleID IN ($strEnabledModulesIDs)";
        
        $obj = new \NsCMN\ClsBllModule();
        $arrModules = $obj->GetData($objFilter);
        
        $arrModulesInfo = array();
        foreach($arrModules as $module){
            $arrModulesInfo[$module->intID] = $module;
        }
        
        // get configs
        $objFilter = new ClsFilter();
        $objFilter->intModuleID = "fkModuleID IS Null OR fkModuleID IN ($strEnabledModulesIDs)";
        
        $objConfig = new \NsCMN\ClsBllConfig();
        $arrConfigs = $objConfig->GetData($objFilter);
        
        // construct config array
        if($arrConfigs){
            foreach($arrConfigs as $config){
                //extract($arrRow, EXTR_OVERWRITE);
                $strConfigKey = $config->strConfigKey; 
                $strConfigValue = $config->strConfigValue;
                if($config->intModuleID == -1){
                    $this->_data[$strConfigKey] = $strConfigValue;
                }else{
                    $this->_data[$arrModulesInfo[$config->intModuleID]->strModule . '_' . $strConfigKey] = $strConfigValue;
                }
            }
        }
    }


    public function ToJson(){
        $arr = $this->ToArray();
        return json_encode($arr);
    }

    public function ToArray(){
        return $this->_data;
    }


    static public function GetInstance(){
        if(is_null(self::$_instance)){
            self::$_instance = new ClsConfiguration();
        }
        return self::$_instance;
    }
}