<?php
namespace NsFWK;

class ClsSession{
    static private $_instance = null;
    static private $_sessionHandler = null;
    static private $_strSessionHandler = '';

    public function __set($name, $value){
        // Use Set function instead
        //$_SESSION[$name] = $value;
        //return false;

        if (is_object($value)){
            $_SESSION[$name] = clone $value;
        }else{
            $_SESSION[$name] = $value;
        }
    }

    public function __get($name){
        if(array_key_exists($name, $_SESSION)){
            $value = $_SESSION[$name];
            if (is_object($value)){
                return (clone $value);
            }else{
                return $value;
            }
        }

        return null;
    }

    public function __isset($name){
        $value = $this->__get($name);
        return isset($value);
    }

    private function __construct(){
        session_start();
    }


    public function GetAll(){
        return $_SESSION;
    }

    public function Set($name, $value){
        if (is_object($value)){
            $_SESSION[$name] = clone $value;
        }else{
            $_SESSION[$name] = $value;
        }
    }

    public function Remove($strVarName){
        if(array_key_exists($name, $_SESSION)){
            unset($_SESSION[$name]);
        }            
    }

    public function Destroy(){
        session_destroy();
    }


    static public function GetInstance(){
        if(is_null(self::$_instance)){
            self::init();
            self::$_instance = new ClsSession();
        }

        return self::$_instance;
    }

    static private function init(){
        if(defined('SESSION_HANDLER')){
            self::$_strSessionHandler = strtoupper(SESSION_HANDLER);
        }else{
            self::$_strSessionHandler = 'FILE';
        }

        if(self::$_strSessionHandler == 'MEMORY' && !defined('DSN_REDIS_SESSION')){
            // Could not use REDIS
            self::$_strSessionHandler = 'FILE';
        }

        session_module_name('user');
        switch(self::$_strSessionHandler){
            case 'DB':
                require_once('session.handler.mysql.php');
                self::$_sessionHandler = new ClsSessionHandlerMysql(SESSION_LIFETIME, 'customer', 'aux_session');
                break;
            case 'MEMORY':
                require_once('session.handler.memory.php');
                self::$_sessionHandler = new ClsSessionHandlerMemory();
                break;
            default:
                require_once('session.handler.file.php');
                self::$_sessionHandler = new ClsSessionHandlerFile();
        }

        session_set_save_handler(self::$_sessionHandler, true);
        register_shutdown_function('session_write_close');
    }
}