<?php
namespace NsFWK;

abstract class ClsCtrlService extends ClsCtrl{

    //protected $_arrResult = array();
    
    public function DoAction(){
        header('Content-Type: application/json');

        if(RUN_MODE === 'PRODUCTION'){
            if(!$this->boolIsLogged){
                $arr = array();
                $arr['result'] = false;
                $arr['title'] = 'Error';    
                $arr['message'] = 'Session has timed out. Press F5 to refresh page.';
                print json_encode($arr);    
                return false;
            }
        }

        if(key_exists('action', $this->_data)){
            $fnAction = "do_".$this->_data['action'];
            $fnBefore = "before_".$this->_data['action'];
            $fnAfter  = "after_".$this->_data['action'];
        }else{
            $fnAction = 'do_Default';
            $fnBefore = "before_Default";
            $fnAfter  = "after_Default";
        }

        if(method_exists($this, $fnBefore)){
            \NsFWK\ClsLogger::GetInstance()->LogDebug("Calling: $fnBefore()");
            $rslt = $this->$fnBefore();
            if(!$rslt){
                return true;
            }
        }

        if(method_exists($this, $fnAction)){
            \NsFWK\ClsLogger::GetInstance()->LogDebug("Calling: $fnAction()");
            $this->$fnAction();
        }else{
            // Terminate execution and redirect to page not found controller
            $strLog = "Service not found.";
            \NsFWK\ClsLogger::GetInstance()->LogDebug($strLog);
            ClsCtrlApi::SetResponse(ClsCtrlApi::HTTP_STATUS_404, '404 Not Found', $strLog);
            return false;
        }

        if(method_exists($this, $fnAfter)){
            \NsFWK\ClsLogger::GetInstance()->LogDebug("Calling: $fnAfter()");
            $this->$fnAfter();
        }

        return true;
    }
}