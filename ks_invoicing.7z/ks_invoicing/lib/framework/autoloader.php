<?php

spl_autoload_register('fwAutoLoad');

function fwAutoLoad($strIdentifierName){
    //print('<br>' . $strIdentifierName);

    switch (true){
        case strpos($strIdentifierName, 'NsFWK') !== false:
            clsLoadFrameWork($strIdentifierName);
            break;
        case strpos($strIdentifierName, 'ClsBll') !== false:
        case strpos($strIdentifierName, 'ClsFilter') !== false:
            clsLoadBll($strIdentifierName);
            break;
        case strpos($strIdentifierName, 'ClsDal') !== false:
            clsLoadDal($strIdentifierName);
            break;
        case strpos($strIdentifierName, 'ClsCtrl') !== false:
            clsLoadCtrl($strIdentifierName);
            break;
    }
}

function clsLoadFrameWork($strIdentifierName){
    // Identifier IS a namespace member
    // if $strIdentifierName is not preceded by \, add a leading \
    $str = substr($strIdentifierName, 0, 1);
    if ($str != '\\'){
        $strIdentifierName = '\\' . $strIdentifierName;
    }

    $strIdentifier = explode('\\', $strIdentifierName);
    $strIdentifier = end($strIdentifier);
    $strFileName = getFileName($strIdentifier);
    $strPath = LOCAL__FRAMEWORK . '/' . $strFileName;
    require_once($strPath);
}

function clsLoadBll($strIdentifierName){
    // Identifier IS a namespace member
    // if $strIdentifierName is not preceded by \, add a leading \
    $str = substr($strIdentifierName, 0, 1);
    if ($str != '\\'){
        $strIdentifierName = '\\' . $strIdentifierName;
    }

    $strIdentifier = explode('\\', $strIdentifierName);
    $strIdentifier = end($strIdentifier);
    $strModule = str_replace($strIdentifier, '', $strIdentifierName);
    $strModule = str_replace('\\Ns', '/', $strModule);
    $strModule = strtolower($strModule);
    $strPath = LOCAL__MODULES . $strModule . 'model/';
    $strPath = str_replace('\\','/', $strPath);

    $strFileName = getFileName($strIdentifier);

    require_once($strPath . '.dal.php');
    require_once($strPath . $strFileName);
}

function clsLoadDal($strIdentifierName){
    // Identifier IS a namespace member
    // if $strIdentifierName is not preceded by \, add a leading \
    $str = substr($strIdentifierName, 0, 1);
    if ($str != '\\'){
        $strIdentifierName = '\\' . $strIdentifierName;
    }

    $strIdentifier = explode('\\', $strIdentifierName);
    $strIdentifier = end($strIdentifier);
    $strModule = str_replace($strIdentifier, '', $strIdentifierName);
    $strModule = str_replace('\\Ns', '/', $strModule);
    $strModule = strtolower($strModule);
    $strPath = LOCAL__MODULES . $strModule . 'model/';
    $strPath = str_replace('\\','/', $strPath);

    require_once($strPath . '.dal.php');
}

function clsLoadCtrl($strIdentifierName){
    // Identifier is a namespace member
    // if $strIdentifierName is not preceded by \, add a leading \
    $str = substr($strIdentifierName, 0, 1);
    if ($str != '\\'){
        $strIdentifierName = '\\' . $strIdentifierName;
    }

    $strIdentifier = explode('\\', $strIdentifierName);
    $strIdentifier = end($strIdentifier);
    $strFileName = getFileName($strIdentifier);
    $arrFileName = explode('.', $strFileName);
    $strControllerType = $arrFileName[1]; // ctrl.page.employee.php ctrl.service.employee.php

    $strModule = str_replace($strIdentifier, '', $strIdentifierName);
    $strModule = str_replace('\\Ns', '/', $strModule);
    $strModule = strtolower($strModule);
    $strConfigPath = LOCAL__MODULES . "$strModule/.config.php";
    $strConfigPath = str_replace('\\','/', $strConfigPath);
    
    $strPath = LOCAL__MODULES . $strModule . 'controller/' . $strControllerType . '/';
    $strPath = str_replace('\\','/', $strPath);
    $strClassFile = $strPath . $strFileName;

    // Make sure the requested controller exists
    if(file_exists($strClassFile)){
        require_once($strConfigPath);
        require_once($strClassFile);
    }else{
        switch($strControllerType){
            case \NsFWK\ClsCtrl::TYPE_PAGE:
                header("location:" . WEB__PUBLIC . "/index.php?response=404");
                break;
            default:
                header("location:" . WEB__PUBLIC . "/service.php?response=404");
                break;
        }

        die();
    }
}

function getFileName($strClassName){
    $strStartChar = substr($strClassName, 0, 3);
    switch ($strStartChar){
        case 'Cls':
            // class
            $strClassName = str_replace('Cls', '', $strClassName);
            break;
        case 'Trt':
            // trait
            $strClassName = str_replace('Trt', '', $strClassName);
            break;
        default:
            return;
    }

    preg_match_all('/((?:^|[A-Z])[a-z0-9]+)/', $strClassName, $arrPart);
    $arrFileName = array();
    foreach($arrPart[0] as $part){
        $arrFileName[] = strtolower($part);
    }
    $arrFileName[] = 'php'; // for the extension
    
    $strFileName = implode('.', $arrFileName);
    return $strFileName;
}