<?php
namespace NsFWK;

class ClsFilter extends ClsBase{
    public function __construct($arrCondition = array()){
        $this->LoadCondition($arrCondition);
    }

    public function LoadCondition($arrCondition){
        if(!empty($arrCondition)){
            foreach($arrCondition as $key=>$val){
                $this->_data[$key] = $val;
            }
        }
    }

    public function ResetConditions(){
        $this->_data = array();
    }

    /***
    * By Mostafa Zakaria - Last Update 2011.12.22
    * 
    * This function can be overriden for custom implementation
    * Default implementation handles the $_data array, which should by of the following format:
    * $_data = array(condition1, condition2, condition3)
    * condition1 = 'fkCategoryID = 5'
    * condition2 = "fldItemName LIKE '%glass%'"
    */
    public function GetWhereStatement(){
        $strWhere = '';
        if(count($this->_data) > 0){
            foreach($this->_data as $item){
                $strWhere .= (($strWhere == '')? '' : ' AND ');
                $strWhere .= $item;
            }
        }
        $strWhere = (($strWhere == '')? '1=1' : $strWhere);
        return $strWhere;
    }
}