<?php

/* 
* This class has been based on the orginal code by Kenneth Katzgaru.
* I'm keeping the original comment for copyrights
* Mostafa Zakaria
*  
* Finally, A light, permissions-checking logging class. 
* 
* Author    : Kenneth Katzgrau < katzgrau@gmail.com >
* Date      : July 26, 2008
* Comments  : Originally written for use with wpSearch
* Website   : http://codefury.net
* Version   : 1.0
*
* Usage: 
*        $log = new ClsLogger("log.txt", self::LEVEL_INFO);
*        $log->LogInfo("Returned a million search results");    //Prints to the log file
*        $log->LogFATAL("Oh dear.");                //Prints to the log file
*        $log->LogDebug("x = 5");                    //Prints nothing due to level setting
*/

namespace NsFWK;

class ClsLogger{

    const LEVEL_DEBUG = 1;  // Most Verbose
    const LEVEL_INFO = 2;   // ...
    const LEVEL_WARN = 3;   // ...
    const LEVEL_ERROR = 4;  // ...
    const LEVEL_FATAL = 5;  // Least Verbose
    const LEVEL_OFF = 6;    // Nothing at all.

    const LOG_OPEN      = 1;
    const OPEN_FAILED   = 2;
    const LOG_CLOSED    = 3;

    protected $_data = array();
    static private $_me = null;

    public function __set($name, $value){
        return false;
    }

    public function __get($name){
        if(array_key_exists($name, $this->_data)){
            return $this->_data[$name];
        }

        return null;
    }
    
    public function __isset($name){
        $value = $this->__get($name);
        return isset($value);
    }

    private function __construct($strLogFile, $intLogLevel){
        $this->_data = array('intLogStatus'=>self::LOG_CLOSED,
                            'strLogFile'=>'',
                            'intLogLevel'=>self::LEVEL_OFF,
                            'arrMessageQueue'=>array(),
                            'fileHandle'=>null);
        
        if($intLogLevel == self::LEVEL_OFF){
            return;
        }

        $this->_data['strLogFile'] = $strLogFile;
        $this->_data['intLogLevel'] = $intLogLevel;
        $this->_data['arrMessageQueue'] = array();

        if(file_exists($this->_data['strLogFile'])){
            if (!is_writable($this->_data['strLogFile'])){
                $this->_data['intLogStatus'] = self::OPEN_FAILED;
                $this->_data['arrMessageQueue'][] = "The file exists, but could not be opened for writing. Check that appropriate permissions have been set.";
                return;
            }
        }

        if($this->_data['fileHandle'] = fopen($this->_data['strLogFile'], "a")){
            $this->_data['intLogStatus'] = self::LOG_OPEN;
            $this->_data['arrMessageQueue'][] = "The log file was opened successfully.";
        }else{
            $this->_data['intLogStatus'] = self::OPEN_FAILED;
            $this->_data['arrMessageQueue'][] = "The file could not be opened. Check permissions.";
        }

        return;
    }

    public function __destruct(){
        if($this->_data['fileHandle']){
            fclose($this->_data['fileHandle']);
        }
    }


    private function getTimeLine( $level ){
        $time = date('Y-m-d H:i:s');
        switch( $level ){
            case self::LEVEL_INFO:
                return "$time - INFO  -";
            case self::LEVEL_WARN:
                return "$time - WARN  -";                
            case self::LEVEL_DEBUG:
                return "$time - DEBUG -";                
            case self::LEVEL_ERROR:
                return "$time - ERROR -";
            case self::LEVEL_FATAL:
                return "$time - FATAL -";
            default:
                return "$time - LOG   -";
        }
    }


    public function LogDebug($strLine){
        $this->Log($strLine, self::LEVEL_DEBUG);
    }

    public function LogInfo($strLine){
        $this->Log($strLine, self::LEVEL_INFO);
    }

    public function LogWarn($strLine){
        $this->Log($strLine, self::LEVEL_WARN);    
    }

    public function LogError($strLine){
        $this->Log($strLine, self::LEVEL_ERROR);        
    }

    public function LogFatal($strLine){
        $this->Log($strLine, self::LEVEL_FATAL);
    }

    public function Log($strLine, $intLogLevel){
        if($this->_data['intLogLevel'] <= $intLogLevel){
            $status = $this->getTimeLine($intLogLevel);
            $this->FreeLog("$status $strLine");
        }
    }

    public function FreeLog($strLine){
        $this->_data['arrMessageQueue'][] = $strLine;
        
        if($this->_data['intLogStatus'] == self::LOG_OPEN && $this->_data['intLogLevel'] != self::LEVEL_OFF){
            if(fwrite($this->_data['fileHandle'] , "$strLine\n") === false) {
                $this->_data['arrMessageQueue'][] = "The file could not be written to. Check that appropriate permissions have been set.";
            }
        }
    }


    static public function GetInstance(){
        if(is_null(self::$_me)){
            $strFileName = 'log_' . date('Ymd') . '.log';
            $strFilePath = LOCAL__LOGS . "/$strFileName";

            $obj = new ClsLogger($strFilePath, LOG_LEVEL);
            self::$_me = $obj;
        }
        return self::$_me;
    }
}