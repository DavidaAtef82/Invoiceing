<?php
namespace NsFWK;

abstract class ClsCtrlApi extends ClsBase{
    // $this->_boolRequireKey has to be set by every API
    protected $_boolRequireKey = false;
    protected $_objClient = null;

    const HTTP_STATUS_100 = "HTTP/1.0 100 Continue";
    const HTTP_STATUS_101 = "HTTP/1.0 101 Switching Protocols";
    const HTTP_STATUS_102 = "HTTP/1.0 102 Processing";
    const HTTP_STATUS_200 = "HTTP/1.0 200 OK";
    const HTTP_STATUS_201 = "HTTP/1.0 201 Created";
    const HTTP_STATUS_202 = "HTTP/1.0 202 Accepted";
    const HTTP_STATUS_203 = "HTTP/1.0 203 Non-Authoritative Information";
    const HTTP_STATUS_204 = "HTTP/1.0 204 No Content";
    const HTTP_STATUS_205 = "HTTP/1.0 205 Reset Content";
    const HTTP_STATUS_206 = "HTTP/1.0 206 Partial Content";
    const HTTP_STATUS_207 = "HTTP/1.0 207 Multi-Status";
    const HTTP_STATUS_208 = "HTTP/1.0 208 Already Reported";
    const HTTP_STATUS_226 = "HTTP/1.0 226 IM Used";
    const HTTP_STATUS_300 = "HTTP/1.0 300 Multiple Choices";
    const HTTP_STATUS_301 = "HTTP/1.0 301 Moved Permanently";
    const HTTP_STATUS_302 = "HTTP/1.0 302 Found";
    const HTTP_STATUS_303 = "HTTP/1.0 303 See Other";
    const HTTP_STATUS_304 = "HTTP/1.0 304 Not Modified";
    const HTTP_STATUS_305 = "HTTP/1.0 305 Use Proxy";
    const HTTP_STATUS_307 = "HTTP/1.0 307 Temporary Redirect";
    const HTTP_STATUS_308 = "HTTP/1.0 308 Permanent Redirect";
    const HTTP_STATUS_400 = "HTTP/1.0 400 Bad Request";
    const HTTP_STATUS_401 = "HTTP/1.0 401 Unauthorized";
    const HTTP_STATUS_402 = "HTTP/1.0 402 Payment Required";
    const HTTP_STATUS_403 = "HTTP/1.0 403 Forbidden";
    const HTTP_STATUS_404 = "HTTP/1.0 404 Not Found";
    const HTTP_STATUS_405 = "HTTP/1.0 405 Method Not Allowed";
    const HTTP_STATUS_406 = "HTTP/1.0 406 Not Acceptable";
    const HTTP_STATUS_407 = "HTTP/1.0 407 Proxy Authentication Required";
    const HTTP_STATUS_408 = "HTTP/1.0 408 Request Timeout";
    const HTTP_STATUS_409 = "HTTP/1.0 409 Conflict";
    const HTTP_STATUS_410 = "HTTP/1.0 410 Gone";
    const HTTP_STATUS_411 = "HTTP/1.0 411 Length Required";
    const HTTP_STATUS_412 = "HTTP/1.0 412 Precondition Failed";
    const HTTP_STATUS_413 = "HTTP/1.0 413 Payload Too Large";
    const HTTP_STATUS_414 = "HTTP/1.0 414 URI Too Long";
    const HTTP_STATUS_415 = "HTTP/1.0 415 Unsupported Media Type";
    const HTTP_STATUS_416 = "HTTP/1.0 416 Requested Range Not Satisfiable";
    const HTTP_STATUS_417 = "HTTP/1.0 417 Expectation Failed";
    const HTTP_STATUS_422 = "HTTP/1.0 422 Unprocessable Entity";
    const HTTP_STATUS_423 = "HTTP/1.0 423 Locked";
    const HTTP_STATUS_424 = "HTTP/1.0 424 Failed Dependency";
    const HTTP_STATUS_425 = "HTTP/1.0 425 Unassigned";
    const HTTP_STATUS_426 = "HTTP/1.0 426 Upgrade Required";
    const HTTP_STATUS_427 = "HTTP/1.0 427 Unassigned";
    const HTTP_STATUS_428 = "HTTP/1.0 428 Precondition Required";
    const HTTP_STATUS_429 = "HTTP/1.0 429 Too Many Requests";
    const HTTP_STATUS_430 = "HTTP/1.0 430 Unassigned";
    const HTTP_STATUS_431 = "HTTP/1.0 431 Request Header Fields Too Large";
    const HTTP_STATUS_500 = "HTTP/1.0 500 Internal Server Error";
    const HTTP_STATUS_501 = "HTTP/1.0 501 Not Implemented";
    const HTTP_STATUS_502 = "HTTP/1.0 502 Bad Gateway";
    const HTTP_STATUS_503 = "HTTP/1.0 503 Service Unavailable";
    const HTTP_STATUS_504 = "HTTP/1.0 504 Gateway Timeout";
    const HTTP_STATUS_505 = "HTTP/1.0 505 HTTP Version Not Supported";
    const HTTP_STATUS_506 = "HTTP/1.0 506 Variant Also Negotiates (Experimental)";
    const HTTP_STATUS_507 = "HTTP/1.0 507 Insufficient Storage";
    const HTTP_STATUS_508 = "HTTP/1.0 508 Loop Detected";
    const HTTP_STATUS_509 = "HTTP/1.0 509 Unassigned";
    const HTTP_STATUS_510 = "HTTP/1.0 510 Not Extended";
    const HTTP_STATUS_511 = "HTTP/1.0 511 Network Authentication Required";

    public function __get($name){
        switch($name){
            case 'boolRequireKey':
                return $this->_boolRequireKey;
                break;
            case 'objClient':
                if(is_null($this->_objClient) && isset($this->_data['key'])){
                    $obj = new \NsCMN\ClsBllApiClient();
                    $rslt = $obj->LoadByKey($this->_data['key']);
                    if($rslt){
                        $this->_objClient = $obj;
                    }else{
                        $this->_objClient = null;
                    }
                }
                return $this->_objClient;
                break;
        }

        return parent::__get($name);
    }

    public function __construct($arrParameters){
        $this->_data = $arrParameters;
        $this->_payload = json_decode(file_get_contents('php://input'), true);
        $this->logCtrlCall();
    }
    

    protected function logCtrlCall(){
        $strLog =  "New API call";
        \NsFWK\ClsLogger::GetInstance()->LogDebug($strLog);
        $strLog = "Parameters: " . json_encode($this->_data);
        \NsFWK\ClsLogger::GetInstance()->LogDebug($strLog);
        $strLog = "PayLoad: " . json_encode($this->_payload);
        \NsFWK\ClsLogger::GetInstance()->LogDebug($strLog);

        if(!is_null($this->objClient)){
            $strLog =  "Client: " . json_encode($this->objClient);
        }else{
            $strLog =  "Client: Unidentified";
        }
        \NsFWK\ClsLogger::GetInstance()->LogDebug($strLog);
    }

    
    public function DoAction(){
        if($this->_boolRequireKey){
            if(!isset($this->_data['key'])){
                ClsCtrlApi::SetResponse(ClsCtrlApi::HTTP_STATUS_401);
                return;
            }

            if(is_null($this->objClient)){
                ClsCtrlApi::SetResponse(ClsCtrlApi::HTTP_STATUS_401);
                return;
            }
        }
        
        if(key_exists('action', $this->_data)){
            $fnAction = "do_".$this->_data['action'];
            $fnBefore = "before_".$this->_data['action'];
            $fnAfter  = "after_".$this->_data['action'];
        }else{
            $fnAction = 'do_Default';
            $fnBefore = "before_Default";
            $fnAfter  = "after_Default";
        }

        if(method_exists($this, $fnBefore)){
            \NsFWK\ClsLogger::GetInstance()->LogDebug("Calling: $fnBefore()");
            $rslt = $this->$fnBefore();
            if(!$rslt){
                return ;
            }
        }

        if(method_exists($this, $fnAction)){
            \NsFWK\ClsLogger::GetInstance()->LogDebug("Calling: $fnAction()");
            $this->$fnAction();
        }else{
            // Terminate execution and redirect to page not found controller
            $strLog = "API not found.";
            \NsFWK\ClsLogger::GetInstance()->LogDebug($strLog);
            ClsCtrlApi::SetResponse(ClsCtrlApi::HTTP_STATUS_404, '404', $strLog);
            return false;
        }

        if(method_exists($this, $fnAfter)){
            \NsFWK\ClsLogger::GetInstance()->LogDebug("Calling: $fnAfter()");
            $this->$fnAfter();
        }
    }


    static public function SetResponse($strStatusCode, $strTitle='', $strMessage='', $boolDieAfter=true){
        header($strStatusCode);
        header('Content-Type: application/json');

        $arr = array();
        $arr['title'] = $strTitle;    
        $arr['message'] = $strMessage;
        print json_encode($arr);    

        if ($boolDieAfter){
            die();
        }
    }

    static public function SetDataResponse($strStatusCode, $boolResult=true, $strTitle='', $strMessage='', $data=null, $boolDieAfter=true){
        header($strStatusCode);
        header('Content-Type: application/json');

        $arr = array();
        $arr['result'] = $boolResult;    
        $arr['title'] = $strTitle;    
        $arr['message'] = $strMessage;
        $arr['object'] = $data;
        print json_encode($arr);

        if ($boolDieAfter){
            die();
        } else {
            return $boolResult;
        }
    }
}