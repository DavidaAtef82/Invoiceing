<?php
namespace NsFWK;

class ClsBase{
    protected $_data = array();

    public function __set($name, $value){
        $this->_data[$name] = $value;
    }

    public function __get($name){
        if(array_key_exists($name, $this->_data)){
            return $this->_data[$name];
        }

        return null;
    }

    public function __isset($name){
        $value = $this->__get($name);
        return isset($value);
    }

    public function __toString(){
        $INITIAL_INDENT = 10;

        return $this->dumpObject($INITIAL_INDENT);
    }

    public function __construct(){}

    public function __destruct(){}
    

    protected function dumpObject($indent){
        $INDENT_STEP = 10;

        $tmp = "<div style='color:red; font-family:courier; font-size:12px; padding-left:$indent'>";
        $tmp .= get_called_class() . '{<br/>';
        $indent += $INDENT_STEP;
        $tmp .= "<div style='padding-left:$indent'>";

        foreach($this->_data as $key=>$value){
            $rslt = is_a($value, __CLASS__);
            if($rslt){
                $tmp .= "$key:" . $value->dumpObject($indent+10);
            }else{
                $tmp .= "$key: $value<br />";
            }
        }

        $tmp .= '</div>}</div>';
        return $tmp;            
    }


    public function ToJson(){
        $arr = $this->ToArray();
        return json_encode($arr, JSON_UNESCAPED_UNICODE);
    }


    public function ToArray(){
        $arrRslt = array();
        $arrData = $this->_data;
        foreach($arrData as $key=>$value){
            if(is_a($value, __CLASS__)){
                $arrRslt[$key] = $value->ToArray();
            }elseif(is_array($value)){
                $arrRslt[$key] = $this->arrayToArray($value);
            }else{
                $arrRslt[$key] = $value;
            }
        }

        return $arrRslt;
    }

    private function arrayToArray($arr){
        $arrRslt = array();

        foreach($arr as $k=>$v){
            if(is_a($v, __CLASS__)){
                $arrRslt[$k] = $v->ToArray();
            }elseif(is_array($v)){
                $arrRslt[$k] = $this->arrayToArray($v);
            }else{
                $arrRslt[$k] = $v;
            }
        }
        
        return $arrRslt;
    }


    public function ToXml(){
        $strTag = get_class($this);
        if(strstr($strTag, '\\')){
            $strTag = substr(strrchr(get_class($this), '\\'), 1);
        }
        if(strstr($strTag, 'ClsBll')){
            $strTag = str_replace('ClsBll', '', $strTag);
        }elseif(strstr($strTag, 'Cls')){
            $strTag = str_replace('Cls', '', $strTag);
        }
        
        $strNodes = '';
        $strAttributes = '';

        $arrData = $this->_data;
        foreach($arrData as $key=>$value){
            if($key == '_type'){
                $strTag = $value;
                continue;
            }
            
            if(is_null($value)){
                // NULL value
                $strAttributes .= ' ' . $key . '=""';
            }elseif(is_scalar($value)){
                // Scalar attribute
				$strAttributes .= ' ' . $key . '="' . $value . '"';
            }elseif(is_a($value, __CLASS__)){
                // Object attribute
                $strNodes .= $value->ToXml();
            }else{
                // Array attribute
                $strNodes .= $this->arrayToXml($key, $value);
            }
        }
        
        $strXml = '<' . $strTag . $strAttributes . '>';
        $strXml .= $strNodes;
        $strXml .= '</' . $strTag . '>';
        return $strXml;
    }
    
    private function arrayToXml($key, $value){
        $strXml = '<' . $key . '>';

        foreach($value as $k=>$v){
            if(is_a($v, __CLASS__)){
                $strXml .= $v->ToXml();
            }elseif(is_array($v)){
                $strXml .= $this->arrayToXml($k, $v);
            }else{
                $strXml .= '<' . $k . '>';
                $strXml .= htmlspecialchars($v, ENT_QUOTES);
                $strXml .= '</' . $k . '>';
            }
        }
        
        $strXml .= '</' . $key . '>';
        return $strXml;
    }


    /***
    * By Mostafa Zakaria - Last Update 2017.06.02
    * 
    * Function returns a copy of the current object.
    * 
    * @param mixed $boolShallow: Whether to do deep-copy for reference type attributes
    * or shallow copy (reference only)
    * @return mixed object that is copy of the current one
    */
    public function GetCopy($boolShallow = false){
        $obj = new static();

        foreach($this->_data as $key=>$value){
            if(is_a($value, __CLASS__)){
                $obj->_data[$key] = ($boolShallow)? $value : $value->GetCopy($boolShallow);
            }elseif(is_object($value)){
                $obj->_data[$key] = $this->copyObj($value, $boolShallow);
            }elseif(is_array($value)){
                $obj->_data[$key] = $this->copyArray($value, $boolShallow);
            }else{
                $obj->_data[$key] = $value;
            }
        }
        
        return $obj;
    }

    protected function copyObj($obj, $boolShallow = false){
        $class = get_class($obj);
        $objCopy = new $class();

        foreach($obj as $k=>$v){
            if(is_a($v, __CLASS__)){
                $objCopy->$k = ($boolShallow)? $v : $v->GetCopy($boolShallow);
            }elseif(is_object($v)){
                $objCopy->$k = ($boolShallow)? $v : $this->copyObj($v, $boolShallow);
            }elseif(is_array($v)){
                $objCopy->$k = $this->copyArray($v, $boolShallow);
            }else{
                $objCopy->$k = $v;
            }
        }
        
        return $objCopy;
    }

    protected function copyArray($arr, $boolShallow = false){
        $arrCopy = array();

        foreach($arr as $k=>$v){
            if(is_a($v, __CLASS__)){
                $arrCopy[$k] = ($boolShallow)? $v : $v->GetCopy($boolShallow);
            }elseif(is_object($v)){
                $arrCopy[$k] = ($boolShallow)? $v : $this->copyObj($v, $boolShallow);
            }elseif(is_array($v)){
                $arrCopy[$k] = $this->copyArray($v, $boolShallow);
            }else{
                $arrCopy[$k] = $v;
            }
        }
        
        return $arrCopy;
    }
}