<?php
namespace NsFWK;

abstract class ClsCtrlApiPublic extends ClsCtrlApi {

    // Overrides the parent DoAction()
    public function DoAction(){
        // token should be passed in the query string
        if (!isset($_GET['token'])) {
            self::SetDataResponse(parent::HTTP_STATUS_400, false, 'Error', 'Authorization token required.', null, true);
            return false;            
        }

        $strToken = $_GET['token'];
        $strIPAddress = $_SERVER['REMOTE_ADDR'];
        $ok = $this->authenticate($strToken, $strIPAddress);
        if (!$ok) {
            // Authentication failed
            return false;
        }

        return parent::DoAction();
    }

    private function authenticate($strToken, $strIPAddress){
        $objToken = \NsCMN\ClsBllApiToken::ValidateToken($strToken, $strIPAddress);
        // -3: invalid IP Address, -2: invalid Account, -1: invalid App ID, 0: invalid/expired token
        if (is_scalar($objToken)) {
            switch ($objToken) {
                case -3:
                    // Invalid IP Address
                    self::SetDataResponse(parent::HTTP_STATUS_401, false, 'Error', 'Invalid IP Address', null, true);
                    return false;
                    break;
                case -2:
                    // Invalid Account
                    self::SetDataResponse(parent::HTTP_STATUS_401, false, 'Error', 'Invalid Account', null, true);
                    return false;
                    break;
                case -1:
                    // Invalid App ID
                    self::SetDataResponse(parent::HTTP_STATUS_401, false, 'Error', 'Invalid App ID', null, true);
                    return false;
                    break;
                default:
                    // Invalid token
                    self::SetDataResponse(parent::HTTP_STATUS_401, false, 'Error', 'Invalid or Expired Token', null, true);
                    return false;                
                    break;
            }
        }
        
        $objApp = new \NsCMN\ClsBllApiApp();
        $ok = $objApp->LoadByID($objToken->intAppID);
        if (!$ok) {
            // Could not load App
            self::SetDataResponse(parent::HTTP_STATUS_404, false, 'Error', 'App not found.', null, true);
            return false;
        }

        $module = $this->_data['module'];
        $method = $this->_data['api'];
        $objMethod = new \NsCMN\ClsBllApiMethod();
        $ok = $objMethod->LoadByMethodName($module, $method);
        if (!$ok) {
            // Could not load method
            self::SetDataResponse(parent::HTTP_STATUS_404, false, 'Error', 'API not found.', null, true);
            return false;
        }
        
        $ok = $objApp->ValidateAccessToMethod($objMethod->intID);
        if (!$ok) {
            // App has no access to this method
            self::SetDataResponse(parent::HTTP_STATUS_401, false, 'Error', 'App is not authorized to call this API.', null, true);
            return false;
        }

        return true; 
    }

}