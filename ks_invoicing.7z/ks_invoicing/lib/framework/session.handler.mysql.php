<?php
namespace NsFWK;

class ClsSessionHandlerMysql implements \SessionHandlerInterface {
    private $_conn = '';
    private $_table = 'aux_session';
    private $_keyField = 'sesskey';
    private $_dataField = 'sessdata';
    private $_expiryField = 'expiry';
    private $_expireRefField = 'expireref';
    private $_createdField = 'created';
    private $_modifiedField = 'modified';

    private $_lifetime = '';
    private $_crc = '00'; // initial value for empty data field: strlen($data) = 0, crc32($data) = 0
    
    public function __construct($lifetime, $conn, $table){
        $this->_lifetime = $lifetime;
        $this->_conn = $conn;
        $this->_table = $table;
    }
    
    public function open($strSavePath, $strSessionName) {
        $DB = &\ADODB_Connection_Manager::GetConnection($this->_conn);
        $ok = $DB->IsConnected();
        if ($ok) {
            return true;
        } else {
            return false;
        }
    }

    public function close() {
        return true;
    }

    public function read($strSessionID) {
        $DB = &\ADODB_Connection_Manager::GetConnection($this->_conn);
        if (!$DB){
            return false;
        }

        $strSQL = "SELECT {$this->_dataField}
                    FROM {$this->_table}
                    WHERE {$this->_keyField} = ?
                    AND {$this->_expiryField} >= ?";
        $data = $DB->GetOne($strSQL, array($strSessionID, date('Y-m-d H:i:s')));
        if ($data) {
            $data = rawurldecode($data);
            $this->_crc = strlen($data) . crc32($data);
            return $data;
        }

        return '';
    }

    public function write($strSessionID, $strData) {
        $DB = &\ADODB_Connection_Manager::GetConnection($this->_conn);
        if (!$DB) {
            return false;
        }

        $lifetime = $this->_lifetime;
        $crc = $this->_crc;
        $timeStamp = date('Y-m-d H:i:s');
        $expiry = date('Y-m-d H:i:s', strtotime("+ $lifetime sec"));

        // crc32 optimization - no update if session data not modified
        if ($crc !== '00' && $crc !== false && $crc == (strlen($strData) . crc32($strData))) {
            // CRC not modified
            $strSQL = "UPDATE {$this->_table}
                        SET {$this->_expiryField} = ?, {$this->_modifiedField} = ?
                        WHERE {$this->_keyField} = ?
                        AND {$this->_expiryField} >= ?";
            $ok = $DB->Execute($strSQL, array($expiry, $timeStamp, $strSessionID, $timeStamp));
            return true;
        }

        $strDataEncoded = rawurlencode($strData);
        $strSQL = "INSERT INTO {$this->_table} ({$this->_keyField}, {$this->_expiryField}, {$this->_dataField}, {$this->_createdField}, {$this->_modifiedField})
                    VALUES (?, ?, ?, ?, ?)
                    ON DUPLICATE KEY UPDATE {$this->_expiryField} = ?, {$this->_dataField} = ?, {$this->_modifiedField} = ?";
        $rslt = $DB->Execute($strSQL, array($strSessionID, $expiry, $strDataEncoded, $timeStamp, $timeStamp, $expiry, $strDataEncoded, $timeStamp));
        if (!$rslt) {
            \ADOConnection::outp('<p>Session Replace: ' . $DB->ErrorMsg() . '</p>', false);
            return false;
        }

        return true;
    }

    public function destroy($strSessionID) {
        $DB = &\ADODB_Connection_Manager::GetConnection($this->_conn);
        if (!$DB) {
            return false;
        }

        $strSQL = "DELETE FROM {$this->_table} WHERE {$this->_keyField} = ?";
        $ok = $DB->Execute($strSQL, array($strSessionID));
        if($ok){
            return true;
        }else{
            return false;
        }
    }

    public function gc($intMaxLifetime) {
        $DB = &\ADODB_Connection_Manager::GetConnection($this->_conn);
        if (!$DB) {
            return false;
        }

        $expiry = date('Y-m-d H:i:s', strtotime("- $intMaxLifetime sec"));
        $strSQL = "DELETE
                    FROM {$this->_table}
                    WHERE {$this->_expiryField} < ?";
        $ok = $DB->Execute($strSQL, array($expiry));
        return true;
    }
    
}