<?php
namespace NsFWK;

abstract class ClsCtrl extends ClsBase{
    const TYPE_API = 'api';
    const TYPE_CRON = 'cron';
    const TYPE_PAGE = 'page';
    const TYPE_SERVICE = 'service';
    
    protected $_config;
    protected $_session;
    protected $_payload;
    protected $_section;

    protected $_arrLangSession;
    protected $_arrLangDefault;

    abstract protected function do_Default();

    public function __get($name){
        switch($name){
            case 'boolIsLogged':
                if(is_null($this->_session->intUserID)){
                    return false;
                }else{
                    return true;
                }
                break;
            case 'objUser':
                // Do not cache in internal class variable, in order to instantaneously reflect changes to session
                return $this->_session->objUser;
                break;
            case 'arrPermissions':
                if($this->boolIsLogged){
                    $this->_data[$name] = $this->getPermissions();
                }
                break;
        }

        return parent::__get($name);
    }

    public function __construct($arrParameters){
        $this->_data = $arrParameters;
        $this->_payload = json_decode(file_get_contents('php://input'), true);
        $this->_config = \NsFWK\ClsConfiguration::GetInstance()->ToArray();
        $this->_session = \NsFWK\ClsSession::GetInstance();
        $this->_section = strtoupper($this->_data['controller_type'] . '_'. $this->_data['controller_class'] . '_' . $this->_data['action']);

        // Find out if lang parameter is passed to switch language
        $objLang = new ClsLanguage();
        if(isset($this->_data['lang'])){
            $strLang = strtolower($this->_data['lang']);
            $objLang->Load($strLang);
        }

        if(empty($objLang->strLang)){
            // Either 'lang' parameter not passed or failed to load
            $objLang->Load(DEFAULT_LANGUAGE);
        }

        // Set session vars: lang and direction
        $this->_session->Set('strLanguage', $objLang->strLang);
        $this->_session->Set('strDirection', $objLang->strDir);

        $this->logCtrlCall();
    }


    /***
    * Return the the appropriate language value for controller and lookup keys
    * 
    * @param mixed $strLangKey
    * @param mixed $arrData: You pass any paramters that you would like to be replaced from the language value. For instance if you want to pass user_id and want to replace it with a value; arrData('user_id'=>10);
    * @param mixed $strSection
    */
    protected function cLang($strLangKey, $arrData=array(), $strSection='', $boolUseDefaultLanguage=false){
        // Load the default language only if parameter passed and the selected language is not the default one
        if($boolUseDefaultLanguage && $this->_session->strLanguage != DEFAULT_LANGUAGE){
            if(empty($this->_arrLangDefault)){
                $this->_arrLangDefault = parse_ini_file(SMARTY_CONFIG_DIR . "/lang." . DEFAULT_LANGUAGE . ".conf", true);
            }
            $arrLanguage = $this->_arrLangDefault;
        }else{
            if(empty($this->_arrLangSession)){
                $this->_arrLangSession = parse_ini_file(SMARTY_CONFIG_DIR . "/lang.{$this->_session->strLanguage}.conf",true);
            }
            $arrLanguage = $this->_arrLangSession;
        }

        $temp = '';
        switch(true){
            case is_null($strSection):
                if(isset($arrLanguage[$strLangKey])){
                    $temp = @$arrLanguage[$strLangKey];
                }
                break;
            case empty($strSection):
                if(isset($arrLanguage[$this->_section][$strLangKey])){
                    $temp = @$arrLanguage[$this->_section][$strLangKey];
                }
                break;
            default:
                if(isset($arrLanguage[$strSection][$strLangKey])){
                    $temp = $arrLanguage[$strSection][$strLangKey];
                }
        }

        if(!empty($arrData)){
            foreach($arrData as $key=>$value){
                $temp = str_replace($key, $value, $temp);
            }            
        }

        return $temp;
    }

    protected function cLangError($intErrorCode, $arrData=array()){
        $strLangKey = "ERR_$intErrorCode";
        return $this->cLang($strLangKey, $arrData, 'ERROR_CODE');
    }

    protected function canView(){
        if(!empty($this->arrPermissions)){
            return true;
        }else{
            return false;
        }
    }

    protected function getPermissions(){
        $strKey = $this->_data['module'] . '-' . $this->_data['controller_type'] . '-' . $this->_data['controller_class'] . '-' . $this->_data['action'];
        $strKey = strtolower($strKey);

        $strPermissions = isset($this->_session->objUser->arrActions[$strKey])? $this->_session->objUser->arrActions[$strKey] : '';
        if($strPermissions == ''){
            return array();
        }else{
            return explode(',', $strPermissions);
        }
    }
    
    protected function logCtrlCall(){
        if(isset($_SERVER['HTTP_USER_AGENT']) && isset($_SERVER['REMOTE_ADDR'])){
            $strLog =  "New call by User Agent: [{$_SERVER['HTTP_USER_AGENT']}] - FROM IP Address [".$_SERVER['REMOTE_ADDR']."]";
        }else{
            $strLog =  "New call by API or Command Line";
        }

        \NsFWK\ClsLogger::GetInstance()->LogDebug($strLog);
        $strLog = "Parameters: " . json_encode($this->_data);
        \NsFWK\ClsLogger::GetInstance()->LogDebug($strLog);
        $strLog = "PayLoad: " . json_encode($this->_payload);
        \NsFWK\ClsLogger::GetInstance()->LogDebug($strLog);
    }


    public function DoAction(){
        if(key_exists('action', $this->_data)){
            $fnAction = "do_".$this->_data['action'];
            $fnBefore = "before_".$this->_data['action'];
            $fnAfter  = "after_".$this->_data['action'];
        }else{
            $fnAction = 'do_Default';
            $fnBefore = "before_Default";
            $fnAfter  = "after_Default";
        }

        if(method_exists($this, $fnBefore)){
            \NsFWK\ClsLogger::GetInstance()->LogDebug("Calling: $fnBefore()");
            $this->$fnBefore();
        }

        if(method_exists($this, $fnAction)){
            \NsFWK\ClsLogger::GetInstance()->LogDebug("Calling: $fnAction()");
            $this->$fnAction();
        }else{
            return false;
        }

        if(method_exists($this, $fnAfter)){
            \NsFWK\ClsLogger::GetInstance()->LogDebug("Calling: $fnAfter()");
            $this->$fnAfter();
        }

        return true;
    }
}