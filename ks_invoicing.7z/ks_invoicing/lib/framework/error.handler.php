<?php

/**
* Error handler, passes flow over the exception logger with new ErrorException.
*/      
function logError( $num, $str, $file, $line, $context = null ){
    if (error_reporting() == 0) {
        // Error Reporting is suppressed
        return;
    }

    logException( new ErrorException( $str, 0, $num, $file, $line ) );
}

/**
* Uncaught exception handler.
*/
function logException( Exception $e ){
    $strLogID = '';
    $strDetails = '';
    $strSeparator = ' | ';
    $backtrace = debug_backtrace();
    // Remove first array entry which points to logException @ error.handler.php
    array_shift($backtrace);

    if(!file_exists(LOCAL__TMP__ERROR)){
        mkdir(LOCAL__TMP__ERROR, 0711, true);
    }

    if ( RUN_MODE == 'DEBUG' ){
        $arrDetails = array('type'=>get_class($e),
                            'message'=>$e->getMessage(),
                            'file'=>$e->getFile(),
                            'line'=>$e->getLine(),
                            'backtrace'=>$backtrace);
        $strDetails = json_encode($arrDetails);
        
        $strLogID = \NsFWK\ClsHlpHelper::GUID();
        $strLogPath = LOCAL__TMP__ERROR . '/' . $strLogID . '.err';
        file_put_contents( $strLogPath, $strDetails );
    }else{
        $strDetails = date('Y-m-d H:i:s');
        $strDetails .= $strSeparator . ( ( defined('ACCOUNT_NAME') ) ? ACCOUNT_NAME : '~' );
        $strDetails .= $strSeparator . "Type: " . get_class( $e );
        $strDetails .= $strSeparator . "Message: {$e->getMessage()}";
        $strDetails .= $strSeparator . "File: {$e->getFile()}";
        $strDetails .= $strSeparator . "Line: {$e->getLine()}";
        $strDetails .= $strSeparator . "Backtrace: " . json_encode($backtrace) . ";";

        $strLogPath = LOCAL__TMP__ERROR . '/_error.log';
        file_put_contents( $strLogPath, $strDetails . PHP_EOL, FILE_APPEND );
    }
    
    if(ENTRY_POINT == 'INDEX'){
        if(empty($strLogID)){
            header( "location:" . WEB__PUBLIC . "/index.php?response=500" );
        }else{
            header( "location:" . WEB__PUBLIC . "/index.php?response=500&log_id=$strLogID" );
        }
    }else{
        // SERVICE / API / CRON
        if(php_sapi_name() == 'cli'){
            print('500 Internal Server Error');
        }else{
            if(empty($strLogID)){
                header( "location:" . WEB__PUBLIC . "/service.php?response=500" );
            }else{
                header( "location:" . WEB__PUBLIC . "/service.php?response=500&log_id=$strLogID" );
            }
        }
    }
    
    die();
}

/**
* Checks for a fatal error, work around for set_error_handler not working on fatal errors.
*/
function checkForFatal(){
    $error = error_get_last();
    if ( $error["type"] == E_ERROR ){
        logError( $error["type"], $error["message"], $error["file"], $error["line"] );
    }
}

register_shutdown_function( "checkForFatal" );
set_error_handler( "logError" );
set_exception_handler( "logException" );
ini_set( "display_errors", "off" );