<?php
namespace NsFWK;

class ClsSessionHandlerFile implements \SessionHandlerInterface {
    private $strSavePath;

    public function open($strSavePath, $strSessionName) {
        $this->strSavePath = $strSavePath;
        if (!is_dir($this->strSavePath)) {
            mkdir($this->strSavePath);
        }

        return true;
    }

    public function close() {
        return true;
    }

    public function read($strSessionID) {
        $strSessionName = ACCOUNT_NAME . "_$strSessionID";

        $file = $this->strSavePath . "/sess_$strSessionName";
        if (!file_exists($file)) {
            return null;
        }

        $tmThreshold = time() - SESSION_LIFETIME;
        $tmFileLastModified = filemtime($file);

        if ($tmFileLastModified < $tmThreshold) {
            unlink($file);
            return null;
        }
        
        touch($file); // update last access time
        $strData = (string)@file_get_contents($file);
        $strDataDecoded = rawurldecode($strData);
        return $strDataDecoded;
    }

    public function write($strSessionID, $strData) {
        $strSessionName = ACCOUNT_NAME . "_$strSessionID";

        $file = $this->strSavePath . "/sess_$strSessionName";
        $strDataEncoded = rawurlencode($strData);
        
        return file_put_contents($file, $strDataEncoded) === false ? false : true;
    }

    public function destroy($strSessionID) {
        $strSessionName = ACCOUNT_NAME . "_$strSessionID";

        $file = $this->strSavePath . "/sess_$strSessionName";
        if (file_exists($file)) {
            unlink($file);
        }

        return true;
    }

    public function gc($intMaxLifetime) {
        if(defined('SESSION_LIFETIME') && is_numeric(SESSION_LIFETIME)){
            $tmThreshold = time() - SESSION_LIFETIME;
        }else{
            $tmThreshold = time() - $intMaxLifetime;
        }
        
        $strPath = $this->strSavePath . "/sess_*";
        $arrFile = glob($strPath);
        foreach ($arrFile as $file) {
            if (!file_exists($file)) {
                continue;
            }
            
            if (filemtime($file) < $tmThreshold) {
                unlink($file);
            }
        }

        return true;
    }

}