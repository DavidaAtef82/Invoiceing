<?php
namespace NsFWK;

class ClsSessionHandlerMemory implements \SessionHandlerInterface {

    public function __construct(){}

    public function open($strSavePath, $strSessionName) {return true;}

    public function close() {return true;}

    public function read($strSessionID) {
        $strData = self::getSession($strSessionID);
        if (!empty($strData)) {
            self::extSession($strSessionID, SESSION_LIFETIME);
            $strDataDecoded = rawurldecode($strData);
            return $strDataDecoded;
        }
        return null;
    }

    public function write($strSessionID, $strData) {
        $strDataEncoded = rawurlencode($strData);
        self::setSession($strSessionID, $strDataEncoded, SESSION_LIFETIME);
        return true;
    }

    public function destroy($strSessionID) {
        self::delSession($strSessionID);
        return true;
    }

    public function gc($intMaxLifetime) {
        // No need to implement this as REDIS automtically deletes expired entries
        return true;
    }
    
    
    private static function setSession($strSessionID, $strData, $intTTL) {
        try {
            $strKey = ACCOUNT_NAME . "_$strSessionID";
            $client = new \Predis\Client(DSN_REDIS_SESSION);
            $client->connect();
            $client->setex($strKey, $intTTL, $strData);

            return true;
        } catch (Predis\CommunicationException $exception) {
            return false;
        }        
    }

    private static function getSession($strSessionID) {
        try {
            $strKey = ACCOUNT_NAME . "_$strSessionID";
            $client = new \Predis\Client(DSN_REDIS_SESSION);
            $client->connect();
            $strData = $client->get($strKey);
            return $strData;
        } catch (Predis\CommunicationException $exception) {
            return false;
        }        
    }
    
    private static function delSession($strSessionID) {
        try {
            $strKey = ACCOUNT_NAME . "_$strSessionID";
            $client = new \Predis\Client(DSN_REDIS_SESSION);
            $client->connect();
            $client->del($strKey);
            return true;
        } catch (Predis\CommunicationException $exception) {
            return false;
        }        
    }
    
    private static function extSession($strSessionID, $intTTL) {
        try {
            $strKey = ACCOUNT_NAME . "_$strSessionID";
            $client = new \Predis\Client(DSN_REDIS_PUBLIC_API_TOKEN);
            $client->connect();
            $client->expire($strKey, $intTTL);
            return true;
        } catch (Predis\CommunicationException $exception) {
            return false;
        }        
    }

}