<?php
namespace NsFWK;

// This controller class is important for all pages that can't inherit regular ctrlPage;
// due to ctrlPage will make regular checks on permission which is not needed in our case.

abstract class ClsCtrlPagePublic extends ClsCtrl{
    protected $_smarty;
    protected $_template;

    protected function initSmarty($template=SMARTY_TEMPLATE_DIR, $config=SMARTY_CONFIG_DIR, $cache=SMARTY_CACHE_DIR, $compile=SMARTY_COMPILE_DIR){
        $this->_smarty = new \Smarty();
        $this->_smarty->setTemplateDir($template);
        $this->_smarty->setConfigDir($config) ;
        $this->_smarty->setCacheDir($cache);
        $this->_smarty->setCompileDir($compile);
        $this->_smarty->compile_check = true;
        $this->_smarty->force_compile = false;
        $this->_smarty->debugging = false;

        $this->_smarty->assign('_Session', $this->_session);
        $this->_smarty->assign('_Direction', $this->_session->strDirection);
        $this->_smarty->assign('_Language', $this->_session->strLanguage);
        $this->_smarty->assign('_LanguageFile', "lang.{$this->_session->strLanguage}.conf");
        $this->_smarty->assign('_LanguageSection', $this->_section);
        $this->_smarty->assign('_ClientSideLanguage', PATH__LANG . "/lang.{$this->_session->strLanguage}.js");

        if (RUN_MODE=='PRODUCTION'){
            $this->_smarty->loadFilter('output', 'trimwhitespace');
        }
        $this->_smarty->loadFilter('pre', 'angular');
    }


    public function DoAction(){
        $this->initSmarty();

        if(RUN_MODE === 'PRODUCTION'){
        }

        if(key_exists('action', $this->_data)){
            $fnAction = "do_".$this->_data['action'];
            $fnBefore = "before_".$this->_data['action'];
            $fnAfter  = "after_".$this->_data['action'];
        }else{
            $fnAction = 'do_Default';
            $fnBefore = "before_Default";
            $fnAfter  = "after_Default";
        }

        if(method_exists($this, $fnBefore)){
            \NsFWK\ClsLogger::GetInstance()->LogDebug("Calling: $fnBefore()");
            $rslt = $this->$fnBefore();
            if(!$rslt){
                // Terminate execution as the before function will be doing some redirection
                return true;
            }
        }

        if(method_exists($this, $fnAction)){
            \NsFWK\ClsLogger::GetInstance()->LogDebug("Calling: $fnAction()");
            $rslt = $this->$fnAction();
        }else{
            // Method does not exist
            // Terminate execution and redirect to PageNotFound controller
            \NsFWK\ClsLogger::GetInstance()->LogDebug("Calling: PageNotFound()");
            self::PageNotFound();
            return false;
        }

        if(method_exists($this, $fnAfter)){
            \NsFWK\ClsLogger::GetInstance()->LogDebug("Calling: $fnAfter()");
            $this->$fnAfter();
        }

        return true;
    }


    static public function PageNotFound(){
        header( "location:" . WEB__PUBLIC . "/index.php?response=404" );
        die();
    }
    
    static public function PageError($strReason=''){
        trigger_error($strReason);
    }
}