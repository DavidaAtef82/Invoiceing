<?php
/*
* Naming Convention
* When including a local pat use LOCAL__ then the path you want to use.
* This will help identifying local pathes from relative pathes 
*/

// Executables Pathes
define('LOCAL__PHP__CLI', 'C:\xampp\php\php.exe'); // windows
define('LOCAL__REDIS__CLI', 'C:/xampp/Redis/redis-cli.exe'); // windows
//define('LOCAL__PHP__CLI', '/usr/local/bin/php'); // linux
//define('LOCAL__REDIS__CLI', 'redis-cli'); // linux

// Root Paths
if(PHP_SAPI == 'cli'){
    set_time_limit(0);
    //$strServerName = 'hitstc.org/app'; // Production Environment
    $strServerName = 'localhost/ks_invoicing'; // Development Environment
}else{
    set_time_limit(0);
    ob_start('ob_gzhandler');
    //$strServerName = $_SERVER['SERVER_NAME'];  // Production Environment
    $strServerName = $_SERVER['SERVER_NAME'] . ':' . $_SERVER['SERVER_PORT'] . '/ks_invoicing'; // Development Environment
}

define('WEB__ROOT__PATH', 'http://' . $strServerName);
define('LOCAL__ROOT__PATH', dirname(__DIR__));

// Root Local
define('LOCAL__INC', LOCAL__ROOT__PATH . '/inc');
define('LOCAL__LIB', LOCAL__ROOT__PATH . '/lib');
define('LOCAL__MODULES', LOCAL__ROOT__PATH . '/modules');
define('LOCAL__PUBLIC', LOCAL__ROOT__PATH . '/public');
define('LOCAL__THEMES', LOCAL__ROOT__PATH . '/themes');
define('LOCAL__TMP', LOCAL__ROOT__PATH . '/tmp');
define('LOCAL__UPLOAD', LOCAL__ROOT__PATH . '/upload');
define('LOCAL__VENDOR', LOCAL__ROOT__PATH . '/vendor');

// Root Web
define('WEB__ASSETS', WEB__ROOT__PATH . '/assets');
define('WEB__MODULES', WEB__ROOT__PATH . '/modules');
define('WEB__PUBLIC', WEB__ROOT__PATH . '/public');
define('WEB__THEMES', WEB__ROOT__PATH . '/themes');
define('WEB__UPLOAD', WEB__ROOT__PATH . '/upload');

// Lib
define('LOCAL__FRAMEWORK', LOCAL__LIB . '/framework');

// TMP and Log
define('LOCAL__FILES', LOCAL__TMP . '/files');
define('LOCAL__LOGS', LOCAL__TMP . '/logs');
define('LOCAL__ADODB__CACHE', LOCAL__TMP . '/adodb');
define('LOCAL__TMP__UPLOAD', LOCAL__TMP . '/upload');
define('LOCAL__TMP__ERROR', LOCAL__TMP . '/error');

// Theme
define('LOCAL__THEME', LOCAL__THEMES . '/' . THEME);
define('LOCAL__THEME__BLOCKS', LOCAL__THEME . '/template/blocks');
define('LOCAL__THEME__COMPONENTS', LOCAL__THEME . '/template/components');
define('LOCAL__THEME__MAIL', LOCAL__THEMES . '/mail');

define('WEB__THEME', WEB__THEMES . '/' . THEME);
define('WEB__THEME__MAIL', LOCAL__THEMES . '/mail');

// Assets
define('WEB__ASSETS__JQUERY', WEB__ASSETS . '/jquery');
define('WEB__ASSETS__BOOTSTRAP', WEB__ASSETS . '/bootstrap');
define('WEB__ASSETS__ANGULAR', WEB__ASSETS . '/angular');

define('WEB__ASSETS__FONT', WEB__ASSETS . '/font');
define('WEB__ASSETS__FONTS', WEB__ASSETS__FONT . '/fonts');
define('WEB__ASSETS__FONTS__AWESOME', WEB__ASSETS__FONT . '/font-awesome');
define('WEB__ASSETS__FONTS__SIMPLE_LINE_ICON', WEB__ASSETS__FONT . '/simple-line-icon');

define('WEB__ASSETS__OTHER', WEB__ASSETS . '/other');
define('WEB__ASSETS__OTHER__UNDERSCORE', WEB__ASSETS__OTHER . '/underscore');
define('WEB__ASSETS__OTHER__MOMENT', WEB__ASSETS__OTHER . '/moment');
define('WEB__ASSETS__OTHER__EGYNILE', WEB__ASSETS__OTHER . '/egynile');