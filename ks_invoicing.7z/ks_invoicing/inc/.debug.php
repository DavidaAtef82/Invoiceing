<?php

if(RUN_MODE === 'DEBUG'){
    //\Tracy\Debugger::enable();
    \NsFWK\ClsLogger::GetInstance()->LogDebug("Debug Session Initiated ...");
/*
}

if (defined('AUTO_LOGIN') && AUTO_LOGIN) {
*/
    // Destroy existing session
    //\NsFWK\ClsSession::GetInstance()->Destroy();

    // Define debug session UserID
    $intUserID = 1;
    
    // Init Session
    $objUser = new \NsCMN\ClsBllUser();
    $objUser->LoadByID($intUserID);
    initSession($objUser);
}

function initSession($objUser){

    $objUser->arrActions;
    $objUser->arrMenuItems;
    $objUser->arrUserLevels;

    // Set User in Session
    $objSession = \NsFWK\ClsSession::GetInstance();
		echo "sss";die();

    $objSession->Set('objUser', $objUser);
	
    $objSession->Set('intUserID', $objUser->intID);
    $objSession->Set('strDefaultPage', $objUser->objUserLevel->strDefaultPage);

    // Set Config in Session
    $arrConfig = \NsFWK\ClsConfiguration::GetInstance()->ToArray();
    $objSession->Set('arrConfig', $arrConfig);
	
}
