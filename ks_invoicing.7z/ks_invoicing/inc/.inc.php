<?php
// General Config
require_once('.config.php');
// Paths
require_once('.path.php');

setlocale(LC_ALL, 'en_En.UTF-8');
date_default_timezone_set(TIME_ZONE);

// RUN_MODE defined in Info File
switch(RUN_MODE){
    case 'SUSPENDED':
        if(defined('ENTRY_POINT') && ENTRY_POINT == 'INDEX'){
            header("location:" . WEB__ROOT__PATH . "/index.php?module=err&page=403");
            die();
        }elseif(defined('ENTRY_POINT') && ENTRY_POINT == 'SERVICE'){
            header("location:" . WEB__ROOT__PATH . "/service.php?module=err&service=403");
            die();
        }
    case 'DEBUG':
        error_reporting(E_ALL | E_STRICT);
        break;
    case 'PRODUCTION':
        error_reporting(E_ERROR);
        break;
}

// 1.Composer Auto load
require_once(LOCAL__VENDOR . '/autoload.php');
// 2.Custom Auto load
require_once('.autoloader.php');
// 3.Framework Auto load
require_once(LOCAL__FRAMEWORK . '/autoloader.php');

// Admin DB
require_once('.connection.php');
// DB
require_once('.db.php');
// Debug values
require_once('.debug.php');