<?php

define('VERSION','6.10.0.2');

define('BROWSER_AGENT','');
define('RUN_MODE', 'DEBUG');          // PRODUCTION  DEBUG  SUSPENDED
define('ADODB_DEBUG', false);              // DEBUG_ON=true DEBUG_OFF=false
define('LOG_LEVEL', 6);                    // LEVEL_DEBUG=1 LEVEL_INFO=2 LEVEL_WARN=3 LEVEL_ERROR=4 LEVEL_FATAL=5 LEVEL_OFF=6

define('DEFAULT_LANGUAGE', 'en');          // Default language => affects login screen as well
define('TIME_ZONE', 'Egypt');

define('SESSION_HANDLER', 'DB');         // FILE, DB, MEMORY
define('SESSION_LIFETIME', 3600);      // session time in seconds -> default = 3600 seconds (1 hours = 1*60*60 = 3600 seconds)

define('ADODB_CACHE_TIME', 86400);    // structure cache time in seconds -> default = 86400 seconds (24 hours = 24*60*60 = 86400 seconds)
define('SMTP_CONNECTION', 'PRODUCTION');   // PRODUCTION, SANDBOX

define('THEME', 'admin2');
define('MAIL_TEMPLATE', 'template.html');
define('THEME_FAV_LOGO', 'fav.png');
define('THEME_TOP_LOGO', 'logo_large.png');
define('THEME_LOGIN_LOGO', 'logo_large.png');
define('THEME_DARK_LOGO', 'logo_large.png');

define('LANGUAGES', 'ar|fldLangAr|rtl,en|fldLangEn|ltr');