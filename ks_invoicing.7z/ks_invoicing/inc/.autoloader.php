<?php

/***
* You can use getCustomLoaders() to define 
* Lib Name or Partial name and corresponding Lib Path to load
***/

spl_autoload_register('customAutoLoad');

function getCustomLoaders(){
    $arrCustomLoaders = array(
                            'ADODB_Active_Record' => LOCAL__VENDOR . '/adodb/adodb-php/adodb-active-record.inc.php',
                            'ADODB_Connection_Manager' => LOCAL__VENDOR . '/adodb/adodb-php/adodb-connection-manager.inc.php'
                        );
    return $arrCustomLoaders;
}

function customAutoLoad($strIdentifierName){
    //print('<br>' . $strIdentifierName);
    
    $arrCustomLoaders = getCustomLoaders();

    // File Include
    foreach($arrCustomLoaders as $class => $path){
        if(strpos($strIdentifierName, $class) !== false){
            require_once($path);
            break;
        }
    }
    
    // Custom autoload calls
    switch($strIdentifierName){

    }
}