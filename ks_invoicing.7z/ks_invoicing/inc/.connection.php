<?php
/**
* MySQL common DB connection
* This is the DB that holds lang, actions, userlevels, permissions, etc.
*/
define('DB_HOST', '127.0.0.1');
define('DB_PORT', '3306');
define('DB_USER', 'root');
define('DB_PASSWORD', '');
define('DB_CATALOG', 'db_ks_invoice');

define('DB_COMMON_HOST', '127.0.0.1');
define('DB_COMMON_PORT', '3306');
define('DB_COMMON_USER', 'root');
define('DB_COMMON_PASSWORD', '');
define('DB_COMMON_CATALOG', 'db_ks_invoice_common');


/**
* General REDIS (in-memory DB connection)
* Session REDIS DB Connection 
*/
define('DSN_REDIS', 'tcp://localhost:6379');
define('DSN_REDIS_SESSION', 'tcp://localhost:6379?timeout=0.01&database=0');
define('DSN_REDIS_PUBLIC_API_TOKEN', 'tcp://localhost:6379?timeout=0.01&database=1');

/**
* MAIL_DEBUG
* 0: DEBUG_OFF - Off
* 1: DEBUG_CLIENT - Debug level to show client -> server messages
* 2: DEBUG_SERVER - Debug level to show client -> server and server -> client messages
* 3: DEBUG_CONNECTION - Debug level to show connection status, client -> server and server -> client messages
* 4: DEBUG_LOWLEVEL - Debug level to show all messages
*/
switch(SMTP_CONNECTION){
    case 'PRODUCTION':
        define('MAIL_DEBUG', 0);
        define('MAIL_CHARSET', 'UTF-8');
        define('MAIL_PORT', 465);
        define('MAIL_CRYPTOGRAPHY', 'ssl'); // ssl / tls
        define('MAIL_HOST', '');
        define('MAIL_USER', '');
        define('MAIL_PASS', '');
        define('MAIL_NAME', '');
        define('MAIL_REPLY', '');
        define('MAIL_HTML', true);
        break;
    case 'SANDBOX':
        define('MAIL_DEBUG', 0);
        define('MAIL_CHARSET', 'UTF-8');
        define('MAIL_PORT', 465);
        define('MAIL_CRYPTOGRAPHY', 'ssl'); // ssl / tls
        define('MAIL_HOST', '');
        define('MAIL_USER', '');
        define('MAIL_PASS', '');
        define('MAIL_NAME', '');
        define('MAIL_REPLY', '');
        define('MAIL_HTML', true);
        break;
}