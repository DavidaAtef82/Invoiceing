<?php

if(RUN_MODE === 'PRODUCTION'){
    \ADODB_Connection_Manager::Init(2, 2, LOCAL__ADODB__CACHE, ADODB_CACHE_TIME);
}else{
    \ADODB_Connection_Manager::Init(2, 2, '', '');
}

\ADODB_Connection_Manager::AddConnection('customer', 'mysqli', DB_HOST, DB_PORT, DB_USER, DB_PASSWORD, DB_CATALOG, ADODB_DEBUG);
\ADODB_Connection_Manager::AddConnection('common', 'mysqli', DB_COMMON_HOST, DB_COMMON_PORT, DB_COMMON_USER, DB_COMMON_PASSWORD, DB_COMMON_CATALOG, ADODB_DEBUG);

// ADODB Custom Log function
function adodbOutp($strMsg, $boolNewline){
    $strMsg = strip_tags($strMsg);
    $strMsg = trim($strMsg);
    \NsFWK\ClsLogger::GetInstance()->LogDebug($strMsg);
}
define('ADODB_OUTP', 'adodbOutp');